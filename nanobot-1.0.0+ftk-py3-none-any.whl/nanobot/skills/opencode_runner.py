import subprocess
import uuid
from pathlib import Path


class OpencodeRunner:
    def __init__(self, workspace: Path):
        self.workspace = workspace
        self.result_dir = workspace / "opencode_results"
        self.result_dir.mkdir(exist_ok=True)
        self.timeout = 300

    def _generate_result_path(self) -> Path:
        return self.result_dir / f"result_{uuid.uuid4()}.txt"

    def run_task(self, prompt: str, timeout: int = None) -> str:
        timeout = timeout or self.timeout
        result_file = self._generate_result_path()

        cmd = f'opencode run "{prompt}" --save-to {result_file}'

        process = subprocess.Popen(
            cmd, shell=True,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE
        )

        try:
            stdout, stderr = process.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            process.kill()
            raise TimeoutError(f"opencode task timed out after {timeout}s")

        if result_file.exists():
            return result_file.read_text(encoding='utf-8')

        if stderr:
            raise RuntimeError(f"opencode error: {stderr.decode()}")

        return stdout.decode(encoding='utf-8')
