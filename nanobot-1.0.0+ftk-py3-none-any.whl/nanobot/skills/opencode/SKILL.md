---
name: opencode
description: "使用 opencode 执行代码开发、设计规划、测试驱动开发、环境配置等任务。支持短任务直接执行和长任务后台执行两种模式。当用户需要写代码、修复bug、设计方案、编写测试、配置环境时触发此技能。"
metadata: {"nanobot":{"emoji":"🤖","os":["darwin","linux"],"requires":{"bins":["opencode","tmux"]}}}
---

# Opencode 技能

## 执行模式

### 直接执行模式
适用：快速修复、代码编写、代码解释、文档编写
超时：30-60秒

### 后台执行模式
适用：设计方案、重构、测试开发、环境配置
超时：5-30分钟

## 使用示例

执行简单任务：
```python
result = opencode_skill.execute("修复 users.py 中的空指针异常")
```

执行复杂任务：
```python
result = opencode_skill.execute("设计用户认证系统", task_type="design")
```
