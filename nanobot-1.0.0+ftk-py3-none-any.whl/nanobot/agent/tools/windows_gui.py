"""Windows GUI automation tool via bridge connection."""

import asyncio
import base64
import json
import socket
import uuid
from datetime import datetime
from typing import Any

from loguru import logger

from nanobot.agent.tools.base import Tool


class WindowsBridgeClient:
    """Client for connecting to Windows bridge from WSL."""

    DEFAULT_PORT = 9527
    DEFAULT_TIMEOUT = 30.0
    RECONNECT_DELAY = 5.0

    def __init__(self, host: str | None = None, port: int = DEFAULT_PORT):
        self._host = host
        self._port = port
        self._socket: socket.socket | None = None
        self._connected = False
        self._pending_requests: dict[str, asyncio.Event] = {}
        self._responses: dict[str, Any] = {}
        self._reader_task: asyncio.Task | None = None
        self._lock = asyncio.Lock()

    @staticmethod
    def get_windows_host_ip() -> str | None:
        """Get Windows host IP from WSL's /etc/resolv.conf."""
        try:
            with open("/etc/resolv.conf") as f:
                for line in f:
                    if line.startswith("nameserver"):
                        return line.split()[1].strip()
        except Exception as e:
            logger.warning(f"Failed to get Windows host IP: {e}")
        return None

    @property
    def is_connected(self) -> bool:
        return self._connected

    @property
    def host(self) -> str | None:
        return self._host

    @property
    def port(self) -> int:
        return self._port

    async def connect(self, host: str | None = None, port: int | None = None) -> bool:
        """Connect to Windows bridge."""
        if self._connected:
            return True

        self._host = host or self._host or self.get_windows_host_ip()
        self._port = port or self._port

        if not self._host:
            logger.error("No Windows host IP available")
            return False

        try:
            self._socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self._socket.settimeout(10.0)
            self._socket.connect((self._host, self._port))
            self._socket.setblocking(False)
            self._connected = True

            self._reader_task = asyncio.create_task(self._receive_loop())
            logger.info(f"Connected to Windows bridge at {self._host}:{self._port}")
            return True

        except Exception as e:
            logger.error(f"Failed to connect to Windows bridge: {e}")
            self._connected = False
            return False

    async def disconnect(self) -> None:
        """Disconnect from Windows bridge."""
        self._connected = False
        if self._reader_task:
            self._reader_task.cancel()
            try:
                await self._reader_task
            except asyncio.CancelledError:
                pass
            self._reader_task = None

        if self._socket:
            try:
                self._socket.close()
            except Exception:
                pass
            self._socket = None

    async def _receive_loop(self) -> None:
        """Background task to receive responses."""
        loop = asyncio.get_event_loop()
        buffer = ""

        while self._connected and self._socket:
            try:
                data = await loop.sock_recv(self._socket, 65536)
                if not data:
                    break
                buffer += data.decode("utf-8")

                while "\n" in buffer:
                    line, buffer = buffer.split("\n", 1)
                    if line.strip():
                        await self._handle_response(line.strip())

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.debug(f"Receive error: {e}")
                break

        self._connected = False

    async def _handle_response(self, message_str: str) -> None:
        """Handle incoming response message."""
        try:
            data = json.loads(message_str)
            msg_id = data.get("id", "")
            if msg_id in self._pending_requests:
                self._responses[msg_id] = data
                self._pending_requests[msg_id].set()
        except Exception as e:
            logger.warning(f"Failed to handle response: {e}")

    async def send_request(
        self,
        action: str,
        params: dict[str, Any] | None = None,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> dict[str, Any] | None:
        """Send a request to Windows bridge and wait for response."""
        if not self._connected or not self._socket:
            return None

        request_id = str(uuid.uuid4())
        event = asyncio.Event()
        self._pending_requests[request_id] = event

        message = {
            "version": "1.0",
            "type": "request",
            "id": request_id,
            "timestamp": datetime.now().isoformat(),
            "payload": {
                "action": action,
                "params": params or {},
            },
        }

        try:
            loop = asyncio.get_event_loop()
            await loop.sock_sendall(self._socket, (json.dumps(message) + "\n").encode("utf-8"))

            try:
                await asyncio.wait_for(event.wait(), timeout=timeout)
                response = self._responses.pop(request_id, None)
                if response:
                    payload = response.get("payload", {})
                    if payload.get("error"):
                        return {"success": False, "error": payload.get("error")}
                    return payload.get("result") or payload
            except asyncio.TimeoutError:
                logger.warning(f"Request {action} timed out")
                return {"success": False, "error": "Request timed out"}

        except Exception as e:
            logger.error(f"Request failed: {e}")
            return {"success": False, "error": str(e)}
        finally:
            self._pending_requests.pop(request_id, None)

        return None


class WindowsGUITool(Tool):
    """Tool for Windows GUI automation via bridge."""

    _client: WindowsBridgeClient | None = None

    @property
    def name(self) -> str:
        return "windows_gui"

    @property
    def description(self) -> str:
        return """Control Windows GUI applications from WSL.

This tool allows you to automate Windows applications by controlling mouse, 
keyboard, and taking screenshots. It connects to a Windows bridge service 
running on the Windows host.

Actions available:
- mouse_click: Click at position (x, y)
- mouse_move: Move mouse to position (x, y)
- mouse_scroll: Scroll the mouse wheel
- keyboard_type: Type text
- keyboard_press: Press a single key
- keyboard_hotkey: Press keyboard shortcut (e.g., Ctrl+C)
- screenshot: Capture screen or region
- find_window: Find a window by title
- launch_app: Launch an application
- get_clipboard: Get clipboard text
- set_clipboard: Set clipboard text
- get_screen_size: Get screen dimensions
- get_mouse_position: Get current mouse position"""

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": [
                        "connect", "disconnect", "mouse_click", "mouse_move",
                        "mouse_scroll", "keyboard_type", "keyboard_press",
                        "keyboard_hotkey", "screenshot", "find_window",
                        "launch_app", "get_clipboard", "set_clipboard",
                        "get_screen_size", "get_mouse_position", "get_status"
                    ],
                    "description": "The action to perform"
                },
                "params": {
                    "type": "object",
                    "description": "Parameters for the action",
                    "properties": {
                        "host": {"type": "string", "description": "Windows host IP (for connect)"},
                        "port": {"type": "integer", "description": "Bridge port (default 9527)"},
                        "x": {"type": "integer", "description": "X coordinate"},
                        "y": {"type": "integer", "description": "Y coordinate"},
                        "button": {"type": "string", "enum": ["left", "right", "middle"], "description": "Mouse button"},
                        "clicks": {"type": "integer", "description": "Number of clicks"},
                        "duration": {"type": "number", "description": "Duration in seconds"},
                        "text": {"type": "string", "description": "Text to type or set clipboard"},
                        "key": {"type": "string", "description": "Key to press"},
                        "keys": {"type": "array", "items": {"type": "string"}, "description": "Keys for hotkey"},
                        "interval": {"type": "number", "description": "Interval between keystrokes"},
                        "region": {"type": "array", "items": {"type": "integer"}, "description": "Screenshot region [x, y, width, height]"},
                        "title": {"type": "string", "description": "Window title to find"},
                        "app_path": {"type": "string", "description": "Application path to launch"},
                        "args": {"type": "array", "items": {"type": "string"}, "description": "Application arguments"}
                    }
                }
            },
            "required": ["action"]
        }

    def _get_client(self) -> WindowsBridgeClient:
        if WindowsGUITool._client is None:
            WindowsGUITool._client = WindowsBridgeClient()
        return WindowsGUITool._client

    async def execute(self, **kwargs: Any) -> str:
        action = kwargs.get("action")
        params = kwargs.get("params", {})

        client = self._get_client()

        if action == "connect":
            host = params.get("host")
            port = params.get("port", 9527)
            if await client.connect(host, port):
                return f"Connected to Windows bridge at {client.host}:{client.port}"
            return "Failed to connect to Windows bridge"

        if action == "disconnect":
            await client.disconnect()
            return "Disconnected from Windows bridge"

        if action == "get_status":
            if client.is_connected:
                return f"Connected to Windows bridge at {client.host}:{client.port}"
            return "Not connected to Windows bridge"

        if not client.is_connected:
            if not await client.connect():
                return "Failed to connect to Windows bridge. Is FTK_bot_A running?"

        if action == "mouse_click":
            result = await client.send_request("mouse_click", {
                "x": params.get("x", 0),
                "y": params.get("y", 0),
                "button": params.get("button", "left"),
                "clicks": params.get("clicks", 1)
            })
            return self._format_result(result, f"Clicked at ({params.get('x')}, {params.get('y')})")

        if action == "mouse_move":
            result = await client.send_request("mouse_move", {
                "x": params.get("x", 0),
                "y": params.get("y", 0),
                "duration": params.get("duration", 0.0)
            })
            return self._format_result(result, f"Mouse moved to ({params.get('x')}, {params.get('y')})")

        if action == "mouse_scroll":
            result = await client.send_request("mouse_scroll", {
                "clicks": params.get("clicks", 0),
                "x": params.get("x"),
                "y": params.get("y")
            })
            return self._format_result(result, f"Scrolled {params.get('clicks')} clicks")

        if action == "keyboard_type":
            result = await client.send_request("keyboard_type", {
                "text": params.get("text", ""),
                "interval": params.get("interval", 0.0)
            })
            return self._format_result(result, f"Typed: {params.get('text')[:50]}...")

        if action == "keyboard_press":
            result = await client.send_request("keyboard_press", {
                "key": params.get("key", "")
            })
            return self._format_result(result, f"Pressed key: {params.get('key')}")

        if action == "keyboard_hotkey":
            keys = params.get("keys", [])
            result = await client.send_request("keyboard_hotkey", {"keys": keys})
            return self._format_result(result, f"Pressed hotkey: {'+'.join(keys)}")

        if action == "screenshot":
            result = await client.send_request("screenshot", {
                "region": params.get("region")
            })
            if result and result.get("success"):
                data = result.get("data", "")
                if data:
                    img_data = base64.b64decode(data)
                    import tempfile
                    import os
                    temp_dir = tempfile.gettempdir()
                    filepath = os.path.join(temp_dir, f"screenshot_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png")
                    with open(filepath, "wb") as f:
                        f.write(img_data)
                    return f"Screenshot saved to: {filepath}"
            return self._format_result(result, "Screenshot captured")

        if action == "find_window":
            result = await client.send_request("find_window", {
                "title": params.get("title", "")
            })
            if result and result.get("success"):
                window = result.get("window", {})
                return f"Found window: {window.get('title')}\nHandle: {window.get('handle')}\nRect: {window.get('rect')}"
            return f"Window not found: {params.get('title')}"

        if action == "launch_app":
            result = await client.send_request("launch_app", {
                "app_path": params.get("app_path", ""),
                "args": params.get("args", [])
            })
            return self._format_result(result, f"Launched: {params.get('app_path')}")

        if action == "get_clipboard":
            result = await client.send_request("get_clipboard", {})
            if result:
                return f"Clipboard: {result.get('text', '')}"
            return "Failed to get clipboard"

        if action == "set_clipboard":
            result = await client.send_request("set_clipboard", {
                "text": params.get("text", "")
            })
            return self._format_result(result, f"Clipboard set to: {params.get('text')[:50]}...")

        if action == "get_screen_size":
            result = await client.send_request("get_screen_size", {})
            if result and result.get("success"):
                return f"Screen size: {result.get('width')}x{result.get('height')}"
            return "Failed to get screen size"

        if action == "get_mouse_position":
            result = await client.send_request("get_mouse_position", {})
            if result and result.get("success"):
                return f"Mouse position: ({result.get('x')}, {result.get('y')})"
            return "Failed to get mouse position"

        return f"Unknown action: {action}"

    def _format_result(self, result: dict[str, Any] | None, success_msg: str) -> str:
        if result is None:
            return "No response from Windows bridge"
        if result.get("success"):
            return success_msg
        return f"Failed: {result.get('error', 'Unknown error')}"
