"""Memory system for persistent agent memory."""

import json
from datetime import datetime
from pathlib import Path

from nanobot.utils.helpers import ensure_dir


class BehaviorTracker:
    """Track user behavior preferences and feedback."""

    def __init__(self, memory_dir: Path):
        self.memory_dir = memory_dir
        self.feedback_file = memory_dir / "feedback.json"
        self.preferences_file = memory_dir / "preferences.json"

    def record_feedback(self, feedback_type: str, context: str = "") -> None:
        """Record user feedback."""
        data = []
        if self.feedback_file.exists():
            data = json.loads(self.feedback_file.read_text(encoding="utf-8"))
        data.append({
            "type": feedback_type,
            "context": context,
            "timestamp": datetime.now().isoformat()
        })
        self.feedback_file.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    def get_preferences(self) -> dict:
        """Get user preferences."""
        if self.preferences_file.exists():
            return json.loads(self.preferences_file.read_text(encoding="utf-8"))
        return {"reply_length": "medium", "explanation_depth": "medium"}

    def update_preference(self, key: str, value: str) -> None:
        """Update a preference."""
        prefs = self.get_preferences()
        prefs[key] = value
        self.preferences_file.write_text(json.dumps(prefs, ensure_ascii=False, indent=2), encoding="utf-8")

    def get_feedback_stats(self) -> dict:
        """Get feedback statistics."""
        if not self.feedback_file.exists():
            return {"positive": 0, "negative": 0, "total": 0}
        data = json.loads(self.feedback_file.read_text(encoding="utf-8"))
        positive = sum(1 for item in data if item.get("type") == "positive")
        negative = sum(1 for item in data if item.get("type") == "negative")
        return {"positive": positive, "negative": negative, "total": len(data)}


class MemoryStore:
    """Two-layer memory: MEMORY.md (long-term facts) + HISTORY.md (grep-searchable log)."""

    def __init__(self, workspace: Path):
        self.memory_dir = ensure_dir(workspace / "memory")
        self.memory_file = self.memory_dir / "MEMORY.md"
        self.history_file = self.memory_dir / "HISTORY.md"
        self.behavior_tracker = BehaviorTracker(self.memory_dir)

    def read_long_term(self) -> str:
        if self.memory_file.exists():
            return self.memory_file.read_text(encoding="utf-8")
        return ""

    def write_long_term(self, content: str) -> None:
        self.memory_file.write_text(content, encoding="utf-8")

    def append_history(self, entry: str) -> None:
        with open(self.history_file, "a", encoding="utf-8") as f:
            f.write(entry.rstrip() + "\n\n")

    def get_memory_context(self) -> str:
        long_term = self.read_long_term()
        return f"## Long-term Memory\n{long_term}" if long_term else ""
