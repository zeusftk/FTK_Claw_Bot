"""WebSocket channel implementation for FTK_bot_A communication."""

from __future__ import annotations

import asyncio
import json
import time
from typing import Any, Dict, Optional, Set
from loguru import logger

import websockets
from websockets.server import WebSocketServerProtocol

from nanobot.bus.events import InboundMessage, OutboundMessage
from nanobot.bus.queue import MessageBus
from nanobot.channels.base import BaseChannel
from nanobot.config.schema import GatewayConfig


class WebSocketChannel(BaseChannel):
    """
    WebSocket channel for communicating with FTK_bot_A.
    
    This channel starts a WebSocket server that listens for connections
    from FTK_bot_A and handles bidirectional message communication.
    """
    
    name = "websocket"
    
    def __init__(
        self,
        config: GatewayConfig,
        bus: MessageBus,
    ):
        super().__init__(config, bus)
        self.config: GatewayConfig = config
        self._server: Optional[websockets.server.WebSocketServer] = None
        self._connected_clients: Set[WebSocketServerProtocol] = set()
        self._chat_id_map: Dict[str, WebSocketServerProtocol] = {}
        self._message_id_counter = 0
    
    async def start(self) -> None:
        """Start the WebSocket server."""
        self._running = True
        
        logger.info(f"Starting WebSocket server on {self.config.host}:{self.config.port}...")
        
        try:
            self._server = await websockets.serve(
                self._handle_client,
                self.config.host,
                self.config.port,
                ping_interval=30,
                ping_timeout=10,
            )
            
            logger.info(f"WebSocket server listening on ws://{self.config.host}:{self.config.port}/ws")
            
            while self._running:
                await asyncio.sleep(1)
                
        except Exception as e:
            logger.error(f"WebSocket server error: {e}")
            self._running = False
    
    async def stop(self) -> None:
        """Stop the WebSocket server."""
        self._running = False
        
        for client in list(self._connected_clients):
            try:
                await client.close()
            except Exception:
                pass
        
        self._connected_clients.clear()
        self._chat_id_map.clear()
        
        if self._server:
            self._server.close()
            await self._server.wait_closed()
            self._server = None
        
        logger.info("WebSocket server stopped")
    
    async def send(self, msg: OutboundMessage) -> None:
        """Send a message through WebSocket to the connected client."""
        client = self._chat_id_map.get(msg.chat_id)
        if not client:
            logger.warning(f"No WebSocket client found for chat_id: {msg.chat_id}")
            return
        
        try:
            payload = {
                "type": "response",
                "id": str(self._message_id_counter),
                "content": msg.content,
                "timestamp": time.time(),
            }
            self._message_id_counter += 1
            
            await client.send(json.dumps(payload))
            logger.debug(f"Sent message to {msg.chat_id}: {msg.content[:50]}...")
            
        except Exception as e:
            logger.error(f"Failed to send WebSocket message: {e}")
    
    async def _handle_client(self, websocket: WebSocketServerProtocol) -> None:
        """Handle a new WebSocket client connection."""
        path = "/ws"  # Default path for compatibility
        if path != "/ws" and path != "/":
            logger.warning(f"Invalid WebSocket path: {path}")
            await websocket.close()
            return
        
        client_id = f"client_{id(websocket)}"
        self._connected_clients.add(websocket)
        self._chat_id_map[client_id] = websocket
        
        logger.info(f"New WebSocket client connected: {client_id}")
        
        try:
            async for message in websocket:
                await self._handle_message_from_client(websocket, client_id, message)
                
        except websockets.exceptions.ConnectionClosed:
            logger.info(f"WebSocket client disconnected: {client_id}")
        except Exception as e:
            logger.error(f"WebSocket client error: {e}")
        finally:
            self._connected_clients.discard(websocket)
            self._chat_id_map.pop(client_id, None)
    
    async def _handle_message_from_client(
        self,
        websocket: WebSocketServerProtocol,
        client_id: str,
        message: str,
    ) -> None:
        """Handle an incoming message from a WebSocket client."""
        try:
            data = json.loads(message)
            msg_type = data.get("type", "message")
            content = data.get("content", "")
            msg_id = data.get("id", "")
            
            logger.debug(f"Received {msg_type} from {client_id}: {content[:50]}...")
            
            if msg_type == "message":
                await self._handle_message(
                    sender_id=client_id,
                    chat_id=client_id,
                    content=content,
                    metadata={"message_id": msg_id},
                )
                
            elif msg_type == "ping":
                pong_payload = {
                    "type": "pong",
                    "id": msg_id,
                    "timestamp": time.time(),
                }
                await websocket.send(json.dumps(pong_payload))
                
        except json.JSONDecodeError:
            logger.warning(f"Invalid JSON from client: {message[:100]}")
        except Exception as e:
            logger.error(f"Error handling client message: {e}")
