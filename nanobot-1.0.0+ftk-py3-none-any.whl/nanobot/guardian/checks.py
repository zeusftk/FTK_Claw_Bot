"""Built-in health check utilities for GuardianService."""

from typing import Protocol


class MonitoredService(Protocol):
    """Protocol for services that can be monitored by GuardianService."""

    async def start(self) -> None:
        """Start the service."""
        ...

    def stop(self) -> None:
        """Stop the service."""
        ...

    def is_running(self) -> bool:
        """Check if the service is currently running."""
        ...
