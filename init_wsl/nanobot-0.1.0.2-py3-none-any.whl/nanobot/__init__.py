"""
nanobot - A lightweight AI agent framework
"""

__version__ = "0.1.0.2"
__logo__ = "🐈"
