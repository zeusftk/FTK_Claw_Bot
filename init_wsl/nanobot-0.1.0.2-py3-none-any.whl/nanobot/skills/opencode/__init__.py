"""
Opencode skill for nanobot - Execute tasks using opencode with mixed mode support
"""

from .background_manager import BackgroundTaskManager
from .opencode_skill import OpencodeSkill
from .task_router import TaskRouter

__all__ = ["OpencodeSkill", "TaskRouter", "BackgroundTaskManager"]
