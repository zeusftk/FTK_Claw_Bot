import re
from typing import Dict


class TaskRouter:
    """任务路由器，根据关键词识别任务类型"""

    TASK_PATTERNS = {
        "fix": {
            "keywords": [r"fix", r"bug", r"修复", r"解决", r"debug"],
            "mode": "direct",
            "timeout": 30,
            "description": "修复代码bug"
        },
        "coding": {
            "keywords": [r"write", r"create", r"implement", r"写代码", r"编写", r"实现"],
            "mode": "direct",
            "timeout": 60,
            "description": "编写代码"
        },
        "explain": {
            "keywords": [r"explain", r"解释", r"分析", r"说明", r"what", r"how"],
            "mode": "direct",
            "timeout": 30,
            "description": "解释代码"
        },
        "design": {
            "keywords": [r"design", r"plan", r"设计", r"方案", r"架构", r"如何"],
            "mode": "background",
            "timeout": 300,
            "description": "设计方案"
        },
        "refactor": {
            "keywords": [r"refactor", r"重构", r"优化", r"improve"],
            "mode": "background",
            "timeout": 600,
            "description": "重构代码"
        },
        "testing": {
            "keywords": [r"test", r"TDD", r"测试", r"unittest", r"pytest"],
            "mode": "background",
            "timeout": 300,
            "description": "编写测试"
        },
        "setup": {
            "keywords": [r"setup", r"install", r"配置", r"安装", r"部署", r"deploy"],
            "mode": "background",
            "timeout": 600,
            "description": "环境配置"
        },
        "documentation": {
            "keywords": [r"doc", r"readme", r"文档", r"注释", r"comment"],
            "mode": "direct",
            "timeout": 60,
            "description": "编写文档"
        }
    }

    def classify(self, prompt: str) -> Dict:
        """对提示词进行分类，返回任务类型和配置"""
        prompt_lower = prompt.lower()

        for task_type, config in self.TASK_PATTERNS.items():
            for keyword in config["keywords"]:
                if re.search(keyword, prompt_lower, re.IGNORECASE):
                    return {
                        "type": task_type,
                        "mode": config["mode"],
                        "timeout": config["timeout"],
                        "description": config["description"]
                    }

        return {
            "type": "general",
            "mode": "direct",
            "timeout": 60,
            "description": "通用任务"
        }

    def get_config(self, task_type: str) -> Dict:
        """获取指定任务类型的配置"""
        return self.TASK_PATTERNS.get(task_type, {
            "mode": "direct",
            "timeout": 60
        })
