import subprocess
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional

from loguru import logger

from .background_manager import BackgroundTaskManager
from .task_router import TaskRouter


class OpencodeSkill:
    """
    Opencode 技能核心类，支持混合执行模式

    支持两种执行模式：
    - direct: 直接执行，适用于短任务
    - background: 后台执行（tmux），适用于长任务
    """

    def __init__(self, workspace: Path):
        self.workspace = workspace
        self.result_dir = workspace / "opencode_results"
        self.result_dir.mkdir(exist_ok=True)

        self.timeout_short = 30    # 短任务超时
        self.timeout_long = 1800   # 长任务超时（30分钟）

        self.task_router = TaskRouter()
        self.bg_manager = BackgroundTaskManager(workspace)

    def execute(self, prompt: str, task_type: str = None) -> Dict:
        """
        执行 opencode 任务

        Args:
            prompt: 任务描述
            task_type: 可选，显式指定任务类型

        Returns:
            Dict: 包含状态、结果、任务ID等信息的字典
        """
        if task_type:
            task_config = self.task_router.get_config(task_type)
            mode = task_config["mode"]
            timeout = task_config["timeout"]
        else:
            classification = self.task_router.classify(prompt)
            mode = classification["mode"]
            timeout = classification["timeout"]
            task_type = classification["type"]

        logger.info(f"Executing opencode task: type={task_type}, mode={mode}")

        if mode == "direct":
            return self._run_direct(prompt, timeout, task_type)
        else:
            return self._run_background(prompt, task_type)

    def _run_direct(self, prompt: str, timeout: int, task_type: str) -> Dict:
        """直接执行模式"""
        result_file = self._generate_result_path()
        cmd = f'opencode run "{prompt}" --save-to {result_file}'

        start_time = datetime.now()

        try:
            process = subprocess.Popen(
                cmd, shell=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE
            )

            stdout, stderr = process.communicate(timeout=timeout)
            duration = (datetime.now() - start_time).total_seconds()

            if result_file.exists():
                result = result_file.read_text(encoding='utf-8')
            elif stderr:
                result = stderr.decode(encoding='utf-8')
                return {
                    "status": "error",
                    "error": result,
                    "duration": duration,
                    "mode": "direct",
                    "type": task_type
                }
            else:
                result = stdout.decode(encoding='utf-8')

            return {
                "status": "success",
                "result": result,
                "duration": duration,
                "mode": "direct",
                "type": task_type
            }

        except subprocess.TimeoutExpired:
            process.kill()
            logger.warning(f"Task timeout after {timeout}s, switching to background mode")
            return self._run_background(prompt, task_type, is_retry=True)

        except Exception as e:
            return {
                "status": "error",
                "error": str(e),
                "mode": "direct",
                "type": task_type
            }

    def _run_background(self, prompt: str, task_type: str, is_retry: bool = False) -> Dict:
        """后台执行模式"""
        try:
            task_id = self.bg_manager.create_task(prompt)

            message = f"任务正在后台执行，任务ID: {task_id}"
            if is_retry:
                message = f"任务已转为后台执行，任务ID: {task_id}"

            return {
                "status": "background",
                "task_id": task_id,
                "message": message,
                "mode": "background",
                "type": task_type
            }

        except Exception as e:
            return {
                "status": "error",
                "error": str(e),
                "mode": "background",
                "type": task_type
            }

    def get_task_status(self, task_id: str) -> Dict:
        """获取后台任务状态"""
        return self.bg_manager.get_status(task_id)

    def get_task_result(self, task_id: str) -> Optional[str]:
        """获取后台任务结果"""
        return self.bg_manager.get_result(task_id)

    def list_tasks(self) -> list:
        """列出所有后台任务"""
        return self.bg_manager.list_tasks()

    def cancel_task(self, task_id: str) -> bool:
        """取消后台任务"""
        return self.bg_manager.cancel_task(task_id)

    def _generate_result_path(self) -> Path:
        """生成结果文件路径"""
        return self.result_dir / f"result_{uuid.uuid4().hex[:8]}.txt"
