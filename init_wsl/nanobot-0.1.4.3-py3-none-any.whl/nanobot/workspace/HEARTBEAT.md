# Heartbeat Tasks

This file is checked every 30 minutes by your nanobot agent.
Add tasks below that you want the agent to work on periodically.

If this file has no tasks (only headers and comments), the agent will skip the heartbeat.

## Active Tasks

<!-- Add your periodic tasks below this line -->

- [ ] 每10次对话后自动触发自我反思 (已启用: AgentLoop 自动每10次对话后生成反思报告)
- [ ] 每月生成行为分析报告


## Completed

<!-- Move completed tasks here or delete them -->

