"""Configuration loading utilities."""

import json
import shutil
from pathlib import Path
from typing import Any

from nanobot.config.schema import Config

BOOTSTRAP_FILES = ["AGENTS.md", "SOUL.md", "USER.md", "TOOLS.md", "IDENTITY.md"]

BOOTSTRAP_DEFAULTS = {
    "AGENTS.md": """# Agent Instructions

You are a helpful AI assistant. Be concise, accurate, and friendly.

## Guidelines

- Always explain what you're doing before taking actions
- Ask for clarification when the request is ambiguous
- Use tools to help accomplish tasks
- Remember important information in memory/MEMORY.md; past events are logged in memory/HISTORY.md
""",
    "SOUL.md": """# Soul

I am nanobot, a lightweight AI assistant.

## Personality

- Helpful and friendly
- Concise and to the point
- Curious and eager to learn

## Values

- Accuracy over speed
- User privacy and safety
- Transparency in actions
""",
    "USER.md": """# User

Information about the user goes here.

## Preferences

- Communication style: (casual/formal)
- Timezone: (your timezone)
- Language: (your preferred language)
""",
    "TOOLS.md": """# Tools

Add your custom tools and instructions here.
""",
    "IDENTITY.md": """# Identity

Add your agent's identity configuration here.
""",
}


def get_config_path() -> Path:
    """Get the default configuration file path."""
    return Path.home() / ".nanobot" / "config.json"


def get_data_dir() -> Path:
    """Get the nanobot data directory."""
    from nanobot.utils.helpers import get_data_path

    return get_data_path()


def get_last_workspace_path() -> Path:
    """Get the path to the last workspace tracking file."""
    return get_data_dir() / "last_workspace.json"


def load_last_workspace() -> str | None:
    """Load the last workspace path from tracking file."""
    path = get_last_workspace_path()
    if path.exists():
        try:
            with open(path) as f:
                data = json.load(f)
                return data.get("workspace")
        except (json.JSONDecodeError, KeyError):
            pass
    return None


def save_last_workspace(workspace: Path) -> None:
    """Save the current workspace path to tracking file."""
    path = get_last_workspace_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump({"workspace": str(workspace)}, f)


def migrate_bootstrap_files(old_workspace: Path, new_workspace: Path) -> list[str]:
    """
    Migrate bootstrap files from old workspace to new workspace.

    Args:
        old_workspace: Path to the previous workspace.
        new_workspace: Path to the new workspace.

    Returns:
        List of migrated file names.
    """
    migrated = []
    new_workspace.mkdir(parents=True, exist_ok=True)

    for filename in BOOTSTRAP_FILES:
        old_file = old_workspace / filename
        new_file = new_workspace / filename

        if old_file.exists() and not new_file.exists():
            shutil.copy2(old_file, new_file)
            migrated.append(filename)

    return migrated


def ensure_bootstrap_files(workspace: Path) -> list[str]:
    """
    Ensure bootstrap files exist in workspace, creating defaults if missing.

    Args:
        workspace: Path to the workspace.

    Returns:
        List of created file names.
    """
    created = []
    workspace.mkdir(parents=True, exist_ok=True)
    
    package_dir = Path(__file__).parent.parent
    package_workspace = package_dir / "workspace"

    for filename in BOOTSTRAP_FILES:
        file_path = workspace / filename
        if not file_path.exists():
            package_template = package_workspace / filename
            if package_template.exists():
                content = package_template.read_text(encoding="utf-8")
            elif filename in BOOTSTRAP_DEFAULTS:
                content = BOOTSTRAP_DEFAULTS[filename]
            else:
                continue
            file_path.write_text(content, encoding="utf-8")
            created.append(filename)

    return created


def load_config(config_path: Path | None = None, migrate_workspace: bool = True) -> Config:
    """
    Load configuration from file or create default.

    Args:
        config_path: Optional path to config file. Uses default if not provided.
        migrate_workspace: If True, migrate bootstrap files when workspace changes.

    Returns:
        Loaded configuration object.
    """
    path = config_path or get_config_path()

    if path.exists():
        try:
            with open(path) as f:
                data = json.load(f)
            data = _migrate_config(data)
            config = Config.model_validate(convert_keys(data))
        except (json.JSONDecodeError, ValueError) as e:
            print(f"Warning: Failed to load config from {path}: {e}")
            print("Using default configuration.")
            config = Config()
    else:
        config = Config()

    if migrate_workspace:
        _check_and_migrate_workspace(config)

    return config


def _check_and_migrate_workspace(config: Config) -> None:
    """
    Check if workspace path changed and migrate bootstrap files if needed.

    Args:
        config: The loaded configuration.
    """
    current_workspace = config.workspace_path
    last_workspace_str = load_last_workspace()

    if last_workspace_str:
        last_workspace = Path(last_workspace_str).expanduser().resolve()
        current_resolved = current_workspace.resolve()

        if last_workspace != current_resolved and last_workspace.exists():
            migrated = migrate_bootstrap_files(last_workspace, current_resolved)
            if migrated:
                print(
                    f"Migrated bootstrap files from {last_workspace} to "
                    f"{current_resolved}: {', '.join(migrated)}"
                )
    else:
        save_last_workspace(current_workspace)

    created = ensure_bootstrap_files(current_workspace)
    if created:
        print(f"Created bootstrap files: {', '.join(created)}")


def save_config(config: Config, config_path: Path | None = None) -> None:
    """
    Save configuration to file.

    Args:
        config: Configuration to save.
        config_path: Optional path to save to. Uses default if not provided.
    """
    path = config_path or get_config_path()
    path.parent.mkdir(parents=True, exist_ok=True)

    # Convert to camelCase format
    data = config.model_dump()
    data = convert_to_camel(data)

    with open(path, "w") as f:
        json.dump(data, f, indent=2)


def _migrate_config(data: dict) -> dict:
    """Migrate old config formats to current."""
    # Move tools.exec.restrictToWorkspace → tools.restrictToWorkspace
    tools = data.get("tools", {})
    exec_cfg = tools.get("exec", {})
    if "restrictToWorkspace" in exec_cfg and "restrictToWorkspace" not in tools:
        tools["restrictToWorkspace"] = exec_cfg.pop("restrictToWorkspace")
    return data


def convert_keys(data: Any) -> Any:
    """Convert camelCase keys to snake_case for Pydantic."""
    if isinstance(data, dict):
        return {camel_to_snake(k): convert_keys(v) for k, v in data.items()}
    if isinstance(data, list):
        return [convert_keys(item) for item in data]
    return data


def convert_to_camel(data: Any) -> Any:
    """Convert snake_case keys to camelCase."""
    if isinstance(data, dict):
        return {snake_to_camel(k): convert_to_camel(v) for k, v in data.items()}
    if isinstance(data, list):
        return [convert_to_camel(item) for item in data]
    return data


def camel_to_snake(name: str) -> str:
    """Convert camelCase to snake_case."""
    result = []
    for i, char in enumerate(name):
        if char.isupper() and i > 0:
            result.append("_")
        result.append(char.lower())
    return "".join(result)


def snake_to_camel(name: str) -> str:
    """Convert snake_case to camelCase."""
    components = name.split("_")
    return components[0] + "".join(x.title() for x in components[1:])
