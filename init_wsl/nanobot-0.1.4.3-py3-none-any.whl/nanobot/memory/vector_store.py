"""Local vector store for semantic memory.

This module provides a local vector store that stores embeddings in SQLite.
All data is stored locally in the nanobot workspace for privacy and security.
"""

import json
import logging
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

import numpy as np

logger = logging.getLogger(__name__)


class VectorStore:
    """Local vector store using SQLite and numpy.
    
    All data is stored locally in the nanobot workspace.
    Supports efficient similarity search using cosine similarity.
    
    Attributes:
        storage_path: Path to the storage directory.
        db_path: Path to the SQLite database file.
    """
    
    def __init__(self, storage_path: Path):
        """Initialize the vector store.
        
        Args:
            storage_path: Path to the storage directory.
        """
        self.storage_path = Path(storage_path)
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        self.db_path = self.storage_path / "memory.db"
        self._dimension: Optional[int] = None
        self._init_db()
        
    def _init_db(self):
        """Initialize SQLite database."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS memories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT NOT NULL,
                content TEXT NOT NULL,
                embedding BLOB,
                metadata TEXT,
                created_at TEXT,
                updated_at TEXT
            )
        """)
        
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_user_id ON memories(user_id)
        """)
        
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_created_at ON memories(created_at)
        """)
        
        conn.commit()
        conn.close()
        
    def add(
        self, 
        user_id: str, 
        content: str, 
        embedding: list[float],
        metadata: Optional[dict] = None
    ) -> int:
        """Add a memory with its embedding.
        
        Args:
            user_id: User ID for isolation.
            content: Memory content text.
            embedding: Embedding vector.
            metadata: Optional metadata dict.
            
        Returns:
            Memory ID.
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        now = datetime.now().isoformat()
        embedding_blob = np.array(embedding, dtype=np.float32).tobytes()
        metadata_json = json.dumps(metadata or {})
        
        cursor.execute("""
            INSERT INTO memories (user_id, content, embedding, metadata, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (user_id, content, embedding_blob, metadata_json, now, now))
        
        memory_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        if self._dimension is None:
            self._dimension = len(embedding)
            
        logger.debug(f"Added memory {memory_id}: {content[:50]}...")
        return memory_id
        
    def add_batch(
        self,
        items: list[dict[str, Any]],
        user_id: str = "default"
    ) -> int:
        """Add multiple memories at once.
        
        Args:
            items: List of dicts with 'content', 'embedding', and optional 'metadata'.
            user_id: User ID for isolation.
            
        Returns:
            Number of items added.
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        now = datetime.now().isoformat()
        count = 0
        
        for item in items:
            content = item.get("content", "")
            embedding = item.get("embedding", [])
            metadata = item.get("metadata", {})
            
            if not content or not embedding:
                continue
                
            embedding_blob = np.array(embedding, dtype=np.float32).tobytes()
            metadata_json = json.dumps(metadata)
            
            cursor.execute("""
                INSERT INTO memories (user_id, content, embedding, metadata, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (user_id, content, embedding_blob, metadata_json, now, now))
            count += 1
            
        conn.commit()
        conn.close()
        
        if items and self._dimension is None:
            self._dimension = len(items[0].get("embedding", []))
            
        logger.debug(f"Added {count} memories in batch")
        return count
        
    def search(
        self, 
        query_embedding: list[float], 
        user_id: str = "default",
        top_k: int = 10
    ) -> list[dict[str, Any]]:
        """Search for similar memories.
        
        Args:
            query_embedding: Query embedding vector.
            user_id: User ID for isolation.
            top_k: Maximum number of results.
            
        Returns:
            List of memory items with content, score, and metadata.
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, content, embedding, metadata, created_at
            FROM memories
            WHERE user_id = ?
            ORDER BY created_at DESC
        """, (user_id,))
        
        rows = cursor.fetchall()
        conn.close()
        
        if not rows:
            return []
            
        query_vec = np.array(query_embedding, dtype=np.float32)
        query_norm = np.linalg.norm(query_vec)
        
        if query_norm == 0:
            return []
            
        results = []
        for row in rows:
            memory_id, content, embedding_blob, metadata_json, created_at = row
            memory_vec = np.frombuffer(embedding_blob, dtype=np.float32)
            
            memory_norm = np.linalg.norm(memory_vec)
            if memory_norm == 0:
                continue
                
            score = float(np.dot(query_vec, memory_vec) / (query_norm * memory_norm))
                
            results.append({
                "id": memory_id,
                "content": content,
                "score": score,
                "metadata": json.loads(metadata_json),
                "created_at": created_at
            })
            
        results.sort(key=lambda x: x["score"], reverse=True)
        return results[:top_k]
        
    def count(self, user_id: str = "default") -> int:
        """Count memories for a user.
        
        Args:
            user_id: User ID.
            
        Returns:
            Number of memories.
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT COUNT(*) FROM memories WHERE user_id = ?
        """, (user_id,))
        
        count = cursor.fetchone()[0]
        conn.close()
        
        return count
        
    def clear(self, user_id: str = "default") -> int:
        """Clear all memories for a user.
        
        Args:
            user_id: User ID.
            
        Returns:
            Number of memories deleted.
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            DELETE FROM memories WHERE user_id = ?
        """, (user_id,))
        
        deleted = cursor.rowcount
        conn.commit()
        conn.close()
        
        logger.info(f"Cleared {deleted} memories for user {user_id}")
        return deleted
        
    def get_dimension(self) -> Optional[int]:
        """Get the embedding dimension.
        
        Returns:
            Dimension or None if no memories stored.
        """
        if self._dimension is not None:
            return self._dimension
            
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT embedding FROM memories LIMIT 1
        """)
        
        row = cursor.fetchone()
        conn.close()
        
        if row:
            embedding_blob = row[0]
            vec = np.frombuffer(embedding_blob, dtype=np.float32)
            self._dimension = len(vec)
            return self._dimension
            
        return None
