"""Hybrid memory manager combining local file storage with optional semantic search.

This module provides a unified interface for memory management that:
1. Preserves the existing MEMORY.md/HISTORY.md system (always works)
2. Optionally uses Embedding API for vector inference (when available)
3. Stores all vectors locally for privacy and security
4. Performs local semantic search (no network needed for search)
5. Gracefully degrades when API is unavailable

All data is stored locally for privacy and security.
"""

import asyncio
import logging
from pathlib import Path
from typing import Any, Optional, TYPE_CHECKING

from nanobot.memory.config import MemOSConfig, EmbeddingApiConfig
from nanobot.memory.api_client import EmbeddingAPIClient
from nanobot.memory.vector_store import VectorStore

if TYPE_CHECKING:
    from nanobot.agent.memory import MemoryStore

logger = logging.getLogger(__name__)


class HybridMemoryManager:
    """Hybrid memory manager - unified local memory interface.
    
    This manager combines:
    - Local file storage (MEMORY.md, HISTORY.md) for human-readable persistence (always works)
    - Optional Embedding API for vector inference (when available)
    - Local vector storage for all embeddings
    - Local semantic search (no network needed)
    
    All data is stored locally in the workspace.
    
    Attributes:
        workspace: Path to the workspace directory.
        local_store: Local file-based memory store.
        api_client: Optional Embedding API client for inference.
        vector_store: Local vector store for embeddings.
    """
    
    def __init__(
        self, 
        workspace: Path, 
        embedding_api_config: Optional[EmbeddingApiConfig] = None,
        memos_config: Optional[MemOSConfig] = None
    ):
        """Initialize the hybrid memory manager.
        
        Args:
            workspace: Path to the workspace directory.
            embedding_api_config: Optional Embedding API configuration.
            memos_config: Optional MemOS configuration (for future use).
        """
        from nanobot.agent.memory import MemoryStore
        
        self.workspace = workspace
        self.local_store: "MemoryStore" = MemoryStore(workspace)
        self.api_client: Optional[EmbeddingAPIClient] = None
        self._api_available: bool = False
        
        vector_store_path = workspace / "memory" / "vectors"
        self.vector_store = VectorStore(vector_store_path)
        
        if embedding_api_config and embedding_api_config.enabled:
            self.api_client = EmbeddingAPIClient(embedding_api_config)
            logger.info(f"Embedding API client initialized: {embedding_api_config.base_url}")
        else:
            logger.debug("Embedding API disabled, using local memory only")
            
    async def _check_api_available(self) -> bool:
        """Check if API is available.
        
        Returns:
            True if API is available, False otherwise.
        """
        if not self.api_client:
            return False
        self._api_available = await self.api_client.is_available()
        return self._api_available
        
    async def _get_embedding(self, text: str) -> Optional[list[float]]:
        """Get embedding for text from API.
        
        Args:
            text: Text to embed.
            
        Returns:
            Embedding vector or None if unavailable.
        """
        if not self.api_client:
            return None
        return await self.api_client.embed_single(text)
        
    def _parse_history_entry(self, entry: str) -> Optional[dict[str, str]]:
        """Parse a history entry to extract user/assistant messages.
        
        Args:
            entry: History entry string.
            
        Returns:
            Parsed message dict or None if parsing fails.
        """
        entry = entry.strip()
        if not entry:
            return None
            
        if entry.startswith("User:"):
            content = entry[5:].strip()
            return {"role": "user", "content": content}
        elif entry.startswith("Assistant:"):
            content = entry[10:].strip()
            return {"role": "assistant", "content": content}
        elif entry.startswith("##"):
            return None
        else:
            return {"role": "user", "content": entry}
            
    async def recall(self, query: str, user_id: str = "default") -> str:
        """Recall relevant memories combining local files and semantic search.
        
        Args:
            query: Search query for semantic recall.
            user_id: User ID for memory isolation.
            
        Returns:
            Combined memory context string.
        """
        context_parts = []
        
        local_memory = self.local_store.read_long_term()
        if local_memory:
            context_parts.append(f"## 长期记忆\n{local_memory}")
            
        if self.vector_store.count(user_id) > 0:
            query_embedding = None
            
            if self.api_client and await self._check_api_available():
                query_embedding = await self._get_embedding(query)
                
            if query_embedding:
                semantic_results = self.vector_store.search(
                    query_embedding=query_embedding,
                    user_id=user_id,
                    top_k=5
                )
                if semantic_results:
                    semantic_text = self._format_semantic_results(semantic_results)
                    context_parts.append(f"## 相关记忆\n{semantic_text}")
                
        return "\n\n".join(context_parts) if context_parts else ""
        
    def _format_semantic_results(
        self, 
        results: list[dict[str, Any]], 
        max_items: int = 5
    ) -> str:
        """Format semantic search results for context.
        
        Args:
            results: List of memory items from semantic search.
            max_items: Maximum number of items to include.
            
        Returns:
            Formatted string of memory items.
        """
        formatted = []
        for item in results[:max_items]:
            content = item.get("content", "")
            score = item.get("score", 0)
            if content:
                formatted.append(f"- {content}")
        return "\n".join(formatted)
        
    async def consolidate(
        self, 
        messages: list[dict[str, str]], 
        user_id: str = "default"
    ) -> None:
        """Consolidate memories with local vector storage.
        
        Args:
            messages: List of messages to consolidate.
            user_id: User ID for memory isolation.
        """
        if not messages or not self.api_client:
            return
            
        if not await self._check_api_available():
            return
            
        texts = [m.get("content", "") for m in messages if m.get("content")]
        if not texts:
            return
            
        embeddings = await self.api_client.embed(texts)
        if not embeddings:
            return
            
        for i, msg in enumerate(messages):
            content = msg.get("content", "")
            if content and i < len(embeddings):
                self.vector_store.add(
                    user_id=user_id,
                    content=content,
                    embedding=embeddings[i],
                    metadata={"role": msg.get("role", "unknown")}
                )
                
        logger.debug(f"Consolidated {len(messages)} messages to vector store")
            
    def get_memory_context(self) -> str:
        """Get memory context for backward compatibility.
        
        Returns:
            Memory context string.
        """
        return self.local_store.get_memory_context()
        
    def read_long_term(self) -> str:
        """Read long-term memory from MEMORY.md.
        
        Returns:
            Long-term memory content.
        """
        return self.local_store.read_long_term()
        
    def write_long_term(self, content: str) -> None:
        """Write long-term memory to MEMORY.md.
        
        Args:
            content: Memory content to write.
        """
        self.local_store.write_long_term(content)
        
    def append_history(self, entry: str, user_id: str = "default") -> None:
        """Append entry to HISTORY.md and store embedding locally.
        
        This method:
        1. Writes to local HISTORY.md (always works)
        2. Gets embedding from API and stores locally (when available)
        
        Args:
            entry: History entry to append.
            user_id: User ID for isolation.
        """
        self.local_store.append_history(entry)
        
        if self.api_client and entry.strip():
            message = self._parse_history_entry(entry)
            if message and message.get("content"):
                try:
                    loop = asyncio.get_event_loop()
                    if loop.is_running():
                        asyncio.create_task(self._async_add_to_vector_store(message, user_id))
                except RuntimeError:
                    pass
                    
    async def _async_add_to_vector_store(
        self, 
        message: dict[str, str], 
        user_id: str
    ) -> None:
        """Async add message to vector store.
        
        Args:
            message: Message dict with role and content.
            user_id: User ID for isolation.
        """
        if not await self._check_api_available():
            return
            
        content = message.get("content", "")
        embedding = await self._get_embedding(content)
        
        if embedding:
            self.vector_store.add(
                user_id=user_id,
                content=content,
                embedding=embedding,
                metadata={"role": message.get("role", "unknown")}
            )
            logger.debug(f"Added to vector store: {content[:50]}...")
        
    async def sync_all_history(self, user_id: str = "default") -> int:
        """Sync all history to local vector store.
        
        This method reads the entire HISTORY.md and syncs it to the
        local vector store. Useful for initial sync or recovery.
        
        Args:
            user_id: User ID for isolation.
            
        Returns:
            Number of messages synced.
        """
        if not self.api_client or not await self._check_api_available():
            logger.debug("Embedding API not available, skipping history sync")
            return 0
            
        history_file = self.local_store.history_file
        if not history_file.exists():
            logger.debug("No history file to sync")
            return 0
            
        messages = []
        texts = []
        
        try:
            content = history_file.read_text(encoding="utf-8")
            for line in content.split("\n"):
                line = line.strip()
                if line:
                    message = self._parse_history_entry(line)
                    if message and message.get("content"):
                        messages.append(message)
                        texts.append(message["content"])
                        
            if not texts:
                return 0
                
            embeddings = await self.api_client.embed(texts)
            if not embeddings:
                return 0
                
            items = []
            for i, msg in enumerate(messages):
                if i < len(embeddings):
                    items.append({
                        "content": msg["content"],
                        "embedding": embeddings[i],
                        "metadata": {"role": msg.get("role", "unknown")}
                    })
                    
            count = self.vector_store.add_batch(items, user_id)
            logger.info(f"Synced {count} history messages to local vector store")
            return count
                
        except Exception as e:
            logger.error(f"Failed to sync history: {e}")
            return 0
        
    @property
    def behavior_tracker(self):
        """Get the behavior tracker for backward compatibility."""
        return self.local_store.behavior_tracker
        
    async def close(self) -> None:
        """Close any open connections."""
        if self.api_client:
            await self.api_client.close()
            
    def get_status(self) -> dict[str, Any]:
        """Get the status of the memory system.
        
        Returns:
            Dictionary with status information.
        """
        status = {
            "local_store": {
                "memory_file": str(self.local_store.memory_file),
                "history_file": str(self.local_store.history_file),
            },
            "vector_store": {
                "path": str(self.vector_store.db_path),
                "count": self.vector_store.count(),
                "dimension": self.vector_store.get_dimension()
            },
            "api": {"enabled": False, "available": False}
        }
        
        if self.api_client:
            status["api"] = self.api_client.get_status()
            
        return status
