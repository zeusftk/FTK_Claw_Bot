"""
nanobot - A lightweight AI agent framework
"""

__version__ = "0.1.4.2"
__logo__ = "🦐"  # 虾图标
