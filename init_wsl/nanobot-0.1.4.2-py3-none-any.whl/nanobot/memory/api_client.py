"""Embedding API client for semantic memory search.

This module provides an HTTP client to connect to an external embedding service.
The service is stateless - it only provides embedding inference.
All data is stored locally in nanobot.

Key features:
- Health check for API availability
- Get embeddings from remote service
- Timeout and error handling
"""

import logging
import time
from typing import Any, Optional

import httpx

from nanobot.memory.config import EmbeddingApiConfig

logger = logging.getLogger(__name__)


class EmbeddingAPIClient:
    """HTTP client for stateless Embedding API service.
    
    This client connects to an external embedding service for inference only.
    All data (embeddings) are stored locally in nanobot.
    
    Attributes:
        config: Embedding API configuration.
        available: Whether the API is currently available.
    """
    
    def __init__(self, config: EmbeddingApiConfig):
        """Initialize the API client.
        
        Args:
            config: Embedding API configuration.
        """
        self.config = config
        self._available: bool = False
        self._last_check: float = 0
        self._check_interval: int = 60
        self._client: Optional[httpx.AsyncClient] = None
        self._init_error: Optional[str] = None
        self._dimension: Optional[int] = None
        
    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create HTTP client.
        
        Returns:
            AsyncClient instance.
        """
        if self._client is None:
            self._client = httpx.AsyncClient(
                base_url=self.config.base_url,
                timeout=self.config.timeout,
            )
        return self._client
        
    async def check_health(self) -> bool:
        """Check if the API service is healthy.
        
        Returns:
            True if healthy, False otherwise.
        """
        if not self.config.enabled:
            return False
            
        try:
            client = await self._get_client()
            response = await client.get("/health")
            if response.status_code == 200:
                data = response.json()
                self._available = True
                self._last_check = time.time()
                self._init_error = None
                self._dimension = data.get("dimension")
                logger.debug(f"Embedding API healthy: {data.get('model', 'unknown')}, dimension: {self._dimension}")
                return True
        except Exception as e:
            self._available = False
            self._init_error = str(e)
            logger.debug(f"Embedding API health check failed: {e}")
        return False
        
    async def is_available(self) -> bool:
        """Check if API is available, with caching.
        
        Returns:
            True if available, False otherwise.
        """
        if not self.config.enabled:
            return False
            
        now = time.time()
        if self._available and (now - self._last_check) < self._check_interval:
            return True
            
        return await self.check_health()
        
    async def embed(self, texts: list[str]) -> Optional[list[list[float]]]:
        """Get embeddings for texts from the remote service.
        
        Args:
            texts: List of texts to embed.
            
        Returns:
            List of embeddings or None if unavailable.
        """
        if not await self.is_available():
            return None
            
        if not texts:
            return []
            
        try:
            client = await self._get_client()
            response = await client.post(
                "/embed",
                json={"texts": texts}
            )
            if response.status_code == 200:
                data = response.json()
                self._dimension = data.get("dimension")
                return data.get("embeddings", [])
        except Exception as e:
            logger.warning(f"Embedding API embed failed: {e}")
            self._available = False
        return None
        
    async def embed_single(self, text: str) -> Optional[list[float]]:
        """Get embedding for a single text.
        
        Args:
            text: Text to embed.
            
        Returns:
            Embedding vector or None if unavailable.
        """
        embeddings = await self.embed([text])
        if embeddings:
            return embeddings[0]
        return None
        
    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client:
            await self._client.aclose()
            self._client = None
            
    def get_status(self) -> dict[str, Any]:
        """Get the status of the API client.
        
        Returns:
            Dictionary with status information.
        """
        return {
            "enabled": self.config.enabled,
            "available": self._available,
            "base_url": self.config.base_url,
            "last_check": self._last_check,
            "dimension": self._dimension,
            "error": self._init_error
        }
