"""Memory configuration for MemOS integration."""

from typing import Optional
from pydantic import BaseModel, Field


class EmbeddingApiConfig(BaseModel):
    """Embedding API configuration.
    
    Connect to an external embedding service for semantic memory.
    If the API is unavailable, falls back to local memory storage.
    """
    enabled: bool = False
    base_url: str = "http://localhost:8765"
    timeout: int = 30
    fallback_to_local: bool = True


class MemOSConfig(BaseModel):
    """MemOS local memory system configuration.
    
    All data is stored locally in the workspace for privacy and security.
    No cloud API or external services are used.
    """
    enabled: bool = False
    storage_path: Optional[str] = None
    embed_model: str = "Qwen/Qwen3-Embedding-0.6B"
    top_k: int = 10
    include_preference: bool = True


class MemoryConfig(BaseModel):
    """Memory system configuration."""
    embedding_api: EmbeddingApiConfig = Field(default_factory=EmbeddingApiConfig)
    memos: MemOSConfig = Field(default_factory=MemOSConfig)
    consolidation_interval: int = 100
    max_history_tokens: int = 8000
