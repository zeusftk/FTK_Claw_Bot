"""Chat channels module with plugin architecture."""

from clawbot.channels.base import BaseChannel
from clawbot.channels.manager import ChannelManager

__all__ = ["BaseChannel", "ChannelManager"]
