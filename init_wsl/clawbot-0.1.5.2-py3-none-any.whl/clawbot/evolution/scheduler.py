"""
EvolutionScheduler - 进化调度器

定时执行自我进化任务。
"""

from __future__ import annotations

import asyncio
from loguru import logger
from datetime import datetime, timedelta
from typing import TYPE_CHECKING

from clawbot.evolution.types import EvolutionResult

if TYPE_CHECKING:
    from clawbot.evolution.hybrid_engine import HybridEvolutionEngine



class EvolutionScheduler:
    """
    进化调度器
    
    功能：
    1. 定时触发进化
    2. 手动触发进化
    3. 状态监控
    """
    
    def __init__(
        self,
        engine: "HybridEvolutionEngine",
        interval_hours: int = 24,
    ):
        self.engine = engine
        self.interval = timedelta(hours=interval_hours)
        self._task: asyncio.Task | None = None
        self._running = False
        self._last_evolution: datetime | None = None
        self._evolution_count = 0
        self._deep_analysis_interval = 7
    
    async def start(self) -> None:
        """启动调度器"""
        if self._running:
            return
        
        self._running = True
        self._task = asyncio.create_task(self._run_loop())
        
        logger.info(f"Evolution scheduler started, interval: {self.interval}")
    
    async def stop(self) -> None:
        """停止调度器"""
        self._running = False
        
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None
        
        logger.info("Evolution scheduler stopped")
    
    async def _run_loop(self) -> None:
        """运行进化循环"""
        while self._running:
            try:
                await asyncio.sleep(self.interval.total_seconds())
                
                if not self._running:
                    break
                
                deep_analysis = (
                    self._evolution_count % self._deep_analysis_interval == 0
                )
                
                result = await self.trigger_enhancement(deep_analysis=deep_analysis)
                
                logger.info(
                    f"Scheduled evolution #{self._evolution_count} complete: "
                    f"applied={result.applied}"
                )
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Scheduled evolution failed: {e}")
    
    async def trigger_enhancement(
        self,
        deep_analysis: bool = False,
    ) -> EvolutionResult:
        """手动触发进化"""
        result = await self.engine.evolve(deep_analysis=deep_analysis)
        
        self._last_evolution = result.timestamp
        self._evolution_count += 1
        
        return result
    
    def get_status(self) -> dict:
        """获取调度器状态"""
        return {
            "running": self._running,
            "interval_hours": self.interval.total_seconds() / 3600,
            "last_evolution": (
                self._last_evolution.isoformat() if self._last_evolution else None
            ),
            "evolution_count": self._evolution_count,
            "deep_analysis_interval": self._deep_analysis_interval,
            "next_evolution": (
                (self._last_evolution + self.interval).isoformat()
                if self._last_evolution else None
            ),
        }
    
    def set_interval(self, hours: int) -> None:
        """设置进化间隔"""
        self.interval = timedelta(hours=hours)
        logger.info(f"Evolution interval updated to {hours} hours")
