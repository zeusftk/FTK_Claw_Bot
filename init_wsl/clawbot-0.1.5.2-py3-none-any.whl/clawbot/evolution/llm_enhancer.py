"""
LLMEnhancer - LLM 增强进化器

使用 LLM 进行深度分析和优化建议。
"""

from __future__ import annotations

import json
from loguru import logger
from datetime import datetime
from typing import TYPE_CHECKING, Any

from clawbot.evolution.types import (
    LLMEnhancementResult,
    StatisticalResult,
)

if TYPE_CHECKING:
    from clawbot.openwork.memory import OpenWorkMemoryBridge



class LLMEnhancer:
    """
    LLM 增强进化器
    
    功能：
    1. 深度模式分析 - 识别复杂模式
    2. 优化建议生成 - 生成改进建议
    3. 提示词优化 - 优化决策提示词
    4. 能力评估 - 生成能力评估报告
    """
    
    def __init__(
        self,
        memory: "OpenWorkMemoryBridge",
        llm: Any,
    ):
        self.memory = memory
        self.llm = llm
    
    async def enhance(
        self,
        statistical_result: StatisticalResult,
    ) -> LLMEnhancementResult:
        """执行 LLM 增强"""
        logger.info("Starting LLM enhancement...")
        
        context = await self._build_context(statistical_result)
        
        prompt = self._build_enhancement_prompt(context)
        
        try:
            response = await self._call_llm(prompt)
            result = self._parse_response(response)
            
            logger.info(
                f"LLM enhancement complete: "
                f"{len(result.threshold_suggestions)} threshold suggestions, "
                f"{len(result.new_rules_suggestions)} rule suggestions"
            )
            
            return result
            
        except Exception as e:
            logger.error(f"LLM enhancement failed: {e}")
            return LLMEnhancementResult(
                reasoning=f"LLM enhancement failed: {str(e)}",
            )
    
    async def _build_context(
        self,
        statistical_result: StatisticalResult,
    ) -> dict:
        """构建上下文"""
        decisions = await self.memory.get_all_decisions()
        recent_decisions = decisions[-20:] if len(decisions) > 20 else decisions
        
        success_cases = await self.memory.get_success_cases(limit=5)
        
        error_patterns = await self.memory.get_error_patterns(limit=5)
        
        return {
            "patterns": [
                {
                    "operation_type": p.get("operation_type"),
                    "success_rate": p.get("success_rate"),
                    "sample_count": p.get("sample_count"),
                }
                for p in statistical_result.patterns[:10]
            ],
            "recent_decisions": [
                {
                    "event_type": d.get("event_type"),
                    "success": d.get("success"),
                    "user_rating": d.get("user_rating"),
                }
                for d in recent_decisions
            ],
            "success_cases": [
                {
                    "idea": c.get("idea", "")[:100],
                    "quality_score": c.get("quality_score"),
                }
                for c in success_cases
            ],
            "error_patterns": [
                {
                    "error_type": e.get("error_type"),
                    "occurrence_count": e.get("occurrence_count"),
                }
                for e in error_patterns
            ],
            "statistical_adjustments": statistical_result.adjustments,
            "statistical_new_rules": statistical_result.new_rules[:5],
        }
    
    def _build_enhancement_prompt(self, context: dict) -> str:
        """构建增强提示词"""
        patterns_str = self._format_patterns(context.get("patterns", []))
        decisions_str = self._format_decisions(context.get("recent_decisions", []))
        errors_str = self._format_errors(context.get("error_patterns", []))
        
        return f"""你是一个 AI 系统的自我进化顾问。请分析以下数据并提供优化建议。

## 当前系统状态

### 决策模式统计
{patterns_str}

### 最近决策记录
{decisions_str}

### 错误模式
{errors_str}

### 统计分析建议
- 阈值调整: {json.dumps(context.get('statistical_adjustments', {}), ensure_ascii=False)}
- 新规则: {json.dumps(context.get('statistical_new_rules', []), ensure_ascii=False)}

## 请提供以下建议

1. **阈值调整建议** - 是否需要调整 auto_resolve 和 require_human 阈值？
2. **新规则建议** - 是否有新的操作类型应该自动审批？
3. **提示词优化** - 决策提示词如何改进？
4. **能力扩展** - 哪些操作可以从 require_human 提升到 auto_safe：
5. **风险评估** - 当前系统存在哪些潜在风险：

请以 JSON 格式返回结果，格式如下：
```json
{{
    "threshold_suggestions": {{
        "auto_resolve": 0.65,
        "require_human": 0.35
    }},
    "new_rules_suggestions": [
        {{"operation": "operation_name", "level": "auto_safe", "reason": "原因"}}
    ],
    "prompt_updates": [
        {{"type": "decision_guidelines", "content": "新指导原则"}}
    ],
    "capability_expansions": [
        {{"operation": "operation_name", "reason": "原因", "confidence": 0.85}}
    ],
    "risk_assessment": {{
        "level": "low/medium/high",
        "concerns": ["关注点1", "关注点2"],
        "recommendations": ["建议1", "建议2"]
    }},
    "reasoning": "整体分析和建议的详细说明"
}}
```
"""
    
    def _format_patterns(self, patterns: list[dict]) -> str:
        """格式化模式"""
        if not patterns:
            return "暂无模式数据"
        
        lines = []
        for p in patterns:
            lines.append(
                f"- {p.get('operation_type', 'unknown')}: "
                f"成功率 {p.get('success_rate', 0):.0%}, "
                f"样本数 {p.get('sample_count', 0)}"
            )
        return "\n".join(lines)
    
    def _format_decisions(self, decisions: list[dict]) -> str:
        """格式化决策"""
        if not decisions:
            return "暂无决策记录"
        
        lines = []
        for d in decisions:
            success = "✅" if d.get("success") else "❌"
            rating = d.get("user_rating", "-")
            lines.append(
                f"- {d.get('event_type', 'unknown')}: {success} (评分: {rating})"
            )
        return "\n".join(lines)
    
    def _format_errors(self, errors: list[dict]) -> str:
        """格式化错误"""
        if not errors:
            return "暂无错误模式"
        
        lines = []
        for e in errors:
            lines.append(
                f"- {e.get('error_type', 'unknown')}: "
                f"出现 {e.get('occurrence_count', 0)} 次"
            )
        return "\n".join(lines)
    
    async def _call_llm(self, prompt: str) -> str:
        """调用 LLM"""
        if hasattr(self.llm, 'chat'):
            return await self.llm.chat(prompt)
        elif hasattr(self.llm, 'acomplete'):
            return await self.llm.acomplete(prompt)
        elif hasattr(self.llm, 'complete'):
            return self.llm.complete(prompt)
        elif callable(self.llm):
            result = self.llm(prompt)
            if hasattr(result, '__await__'):
                return await result
            return str(result)
        else:
            raise ValueError("LLM provider does not have a compatible interface")
    
    def _parse_response(self, response: str) -> LLMEnhancementResult:
        """解析 LLM 响应"""
        try:
            json_start = response.find('{')
            json_end = response.rfind('}') + 1
            
            if json_start >= 0 and json_end > json_start:
                json_str = response[json_start:json_end]
                data = json.loads(json_str)
                
                return LLMEnhancementResult(
                    threshold_suggestions=data.get("threshold_suggestions", {}),
                    new_rules_suggestions=data.get("new_rules_suggestions", []),
                    prompt_updates=data.get("prompt_updates", []),
                    capability_expansions=data.get("capability_expansions", []),
                    risk_assessment=data.get("risk_assessment", {}),
                    reasoning=data.get("reasoning", ""),
                )
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse LLM response as JSON: {e}")
        
        return LLMEnhancementResult(
            reasoning=response[:500] if response else "No response from LLM",
        )
    
    async def generate_capability_report(self) -> dict:
        """生成能力评估报告"""
        decisions = await self.memory.get_all_decisions()
        success_cases = await self.memory.get_success_cases(limit=100)
        
        if not decisions:
            return {
                "status": "no_data",
                "message": "暂无足够数据生成报告",
            }
        
        total_decisions = len(decisions)
        successful = sum(1 for d in decisions if d.get("success"))
        ratings = [d.get("user_rating", 0) for d in decisions if d.get("user_rating")]
        avg_rating = sum(ratings) / len(ratings) if ratings else 0
        
        operation_stats: dict[str, dict] = {}
        for d in decisions:
            op = d.get("event_type", "unknown")
            if op not in operation_stats:
                operation_stats[op] = {"total": 0, "success": 0}
            operation_stats[op]["total"] += 1
            if d.get("success"):
                operation_stats[op]["success"] += 1
        
        strengths = []
        weaknesses = []
        
        for op, stats in operation_stats.items():
            rate = stats["success"] / stats["total"] if stats["total"] > 0 else 0
            if rate >= 0.9 and stats["total"] >= 5:
                strengths.append(op)
            elif rate < 0.7 and stats["total"] >= 5:
                weaknesses.append(op)
        
        return {
            "status": "success",
            "generated_at": datetime.now().isoformat(),
            "summary": {
                "total_decisions": total_decisions,
                "success_rate": successful / total_decisions if total_decisions > 0 else 0,
                "average_rating": avg_rating,
                "success_cases_count": len(success_cases),
            },
            "strengths": strengths[:5],
            "weaknesses": weaknesses[:5],
            "recommendations": [
                f"继续优化 {op} 操作的成功率" for op in weaknesses[:3]
            ],
        }
