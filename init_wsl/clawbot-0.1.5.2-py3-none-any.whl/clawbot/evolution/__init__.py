"""
Evolution Module - 进化模块

提供混合进化引擎，结合统计驱动和 LLM 增强的自我进化能力。
"""

from clawbot.evolution.types import (
    StatisticalResult,
    LLMEnhancementResult,
    CombinedEvolution,
    ValidationResult,
    EvolutionResult,
    ImmediateAction,
    EvolutionAdjustment,
    EvolutionStats,
)
from clawbot.evolution.hybrid_engine import HybridEvolutionEngine
from clawbot.evolution.statistical import StatisticalEvolver
from clawbot.evolution.llm_enhancer import LLMEnhancer
from clawbot.evolution.validator import EvolutionValidator
from clawbot.evolution.scheduler import EvolutionScheduler

__all__ = [
    "StatisticalResult",
    "LLMEnhancementResult",
    "CombinedEvolution",
    "ValidationResult",
    "EvolutionResult",
    "ImmediateAction",
    "EvolutionAdjustment",
    "EvolutionStats",
    "HybridEvolutionEngine",
    "StatisticalEvolver",
    "LLMEnhancer",
    "EvolutionValidator",
    "EvolutionScheduler",
]
