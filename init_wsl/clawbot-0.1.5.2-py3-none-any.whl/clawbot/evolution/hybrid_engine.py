"""
HybridEvolutionEngine - 混合进化引擎

结合统计驱动和 LLM 增强的自我进化能力。
"""

from __future__ import annotations

from loguru import logger
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

from clawbot.evolution.types import (
    CombinedEvolution,
    EvolutionResult,
    EvolutionStats,
    ImmediateAction,
    LLMEnhancementResult,
    StatisticalResult,
)

if TYPE_CHECKING:
    from clawbot.openwork.memory import OpenWorkMemoryBridge
    from clawbot.openwork.feedback_collector import FeedbackCollector



class HybridEvolutionEngine:
    """
    混合进化引擎
    
    进化流程：
    1. StatisticalEvolver 快速分析（每次反馈后）
    2. LLMEnhancer 深度优化（定时或触发：
    3. EvolutionValidator 验证结果
    4. 应用进化结果
    """
    
    def __init__(
        self,
        memory: "OpenWorkMemoryBridge",
        llm: Any,
        feedback_processor: "FeedbackCollector | None" = None,
        config_path: Path | None = None,
    ):
        self.memory = memory
        self.llm = llm
        self.feedback_processor = feedback_processor
        self.config_path = config_path or memory.workspace / "evolution_config.json"
        
        from clawbot.evolution.statistical import StatisticalEvolver
        from clawbot.evolution.llm_enhancer import LLMEnhancer
        from clawbot.evolution.validator import EvolutionValidator
        
        self.statistical_evolver = StatisticalEvolver(
            memory=memory,
            feedback_processor=feedback_processor,
            config_path=self.config_path,
        )
        
        self.llm_enhancer = LLMEnhancer(
            memory=memory,
            llm=llm,
        )
        
        self.validator = EvolutionValidator()
        
        self._evolution_history: list[EvolutionResult] = []
        self._last_evolution: datetime | None = None
        self._evolution_count = 0
    
    async def evolve(self, deep_analysis: bool = False) -> EvolutionResult:
        """
        执行进化
        
        Args:
            deep_analysis: 是否执行深度 LLM 分析
            
        Returns:
            EvolutionResult 进化结果
        """
        logger.info("Starting hybrid evolution process...")
        
        statistical_result = await self.statistical_evolver.analyze()
        
        llm_result = None
        if deep_analysis or self._should_deep_analyze():
            try:
                llm_result = await self.llm_enhancer.enhance(
                    statistical_result=statistical_result,
                )
            except Exception as e:
                logger.error(f"LLM enhancement failed: {e}")
        
        combined = self._combine_results(statistical_result, llm_result)
        
        validated = await self.validator.validate(combined)
        
        if validated.is_valid:
            await self._apply_evolution(combined)
            logger.info(
                f"Evolution applied: {len(combined.new_rules)} new rules, "
                f"{len(combined.added_auto_safe)} capability expansions"
            )
        else:
            logger.warning(
                f"Evolution rejected: {validated.errors}"
            )
        
        result = EvolutionResult(
            timestamp=datetime.now(),
            statistical=statistical_result,
            llm=llm_result,
            validated=validated,
            applied=validated.is_valid,
        )
        
        self._evolution_history.append(result)
        self._last_evolution = result.timestamp
        self._evolution_count += 1
        
        if len(self._evolution_history) > 100:
            self._evolution_history = self._evolution_history[-50:]
        
        return result
    
    async def process_feedback_immediate(self, feedback: Any) -> ImmediateAction:
        """
        处理反馈的即时响应
        
        低评分：立即降级
        高评分：标记升级候选
        """
        return await self.statistical_evolver.process_immediate(feedback)
    
    def _should_deep_analyze(self) -> bool:
        """判断是否需要深度分析"""
        if not self.feedback_processor:
            return False
        
        try:
            recent_feedback = self.feedback_processor.get_recent(count=10)
            if len(recent_feedback) < 5:
                return False
            
            ratings = []
            for f in recent_feedback:
                if hasattr(f, 'rating') and f.rating:
                    ratings.append(f.rating)
            
            if not ratings:
                return False
            
            avg_rating = sum(ratings) / len(ratings)
            return avg_rating < 3.5 or avg_rating > 4.5
            
        except Exception as e:
            logger.error(f"Failed to check deep analysis condition: {e}")
            return False
    
    def _combine_results(
        self,
        statistical: StatisticalResult,
        llm: LLMEnhancementResult | None,
    ) -> CombinedEvolution:
        """组合统计和 LLM 结果"""
        adjustments = statistical.adjustments or {}
        thresholds = dict(adjustments.get("thresholds", {}) or {})
        new_rules = list(statistical.new_rules or [])
        added_auto_safe = []
        removed_auto_safe = []
        prompt_updates = []
        
        for expansion in statistical.expansions or []:
            if expansion.get("new_level") == "auto_safe":
                added_auto_safe.append(expansion.get("operation_type", ""))
        
        if llm:
            for name, value in (llm.threshold_suggestions or {}).items():
                if isinstance(value, (int, float)) and 0.1 <= value <= 0.9:
                    thresholds[name] = float(value)
            
            new_rules.extend(llm.new_rules_suggestions or [])
            prompt_updates.extend(llm.prompt_updates or [])
        
        return CombinedEvolution(
            statistical=statistical,
            llm=llm,
            thresholds=thresholds,
            new_rules=new_rules,
            removed_auto_safe=removed_auto_safe,
            added_auto_safe=added_auto_safe,
            prompt_updates=prompt_updates,
        )
    
    async def _apply_evolution(self, evolution: CombinedEvolution) -> None:
        """应用进化结果"""
        if evolution.thresholds:
            self.statistical_evolver.thresholds.update(evolution.thresholds)
        
        for rule in evolution.new_rules:
            op = rule.get("operation")
            if op and rule.get("level") == "auto_safe":
                self.statistical_evolver.auto_safe_operations.add(op)
                self.statistical_evolver.require_human_operations.discard(op)
        
        for op in evolution.removed_auto_safe:
            self.statistical_evolver.auto_safe_operations.discard(op)
        
        for op in evolution.added_auto_safe:
            self.statistical_evolver.auto_safe_operations.add(op)
        
        self.statistical_evolver._save_config()
    
    def get_stats(self) -> EvolutionStats:
        """获取进化统计"""
        return EvolutionStats(
            total_evolutions=self._evolution_count,
            successful_evolutions=sum(1 for r in self._evolution_history if r.applied),
            failed_evolutions=sum(1 for r in self._evolution_history if not r.applied),
            last_evolution=self._last_evolution,
            auto_safe_operations_count=len(self.statistical_evolver.auto_safe_operations),
            require_human_operations_count=len(self.statistical_evolver.require_human_operations),
            thresholds=dict(self.statistical_evolver.thresholds),
        )
    
    def get_evolution_history(self, limit: int = 10) -> list[dict]:
        """获取进化历史"""
        history = []
        for result in self._evolution_history[-limit:]:
            history.append({
                "timestamp": result.timestamp.isoformat(),
                "applied": result.applied,
                "validation_checks": result.validated.checks,
                "validation_warnings": result.validated.warnings,
            })
        return history
    
    async def rollback_last(self) -> bool:
        """回滚最后一次进化"""
        if not self._evolution_history:
            return False
        
        last = self._evolution_history[-1]
        if not last.applied:
            return False
        
        logger.warning("Rolling back last evolution...")
        
        self._evolution_history.pop()
        self._evolution_count = max(0, self._evolution_count - 1)
        
        self.statistical_evolver._load_config()
        
        return True
