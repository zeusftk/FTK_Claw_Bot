"""
EvolutionValidator - 进化验证器器

验证进化结果的合理性，防止系统退化化。
"""

from __future__ import annotations

from loguru import logger
from typing import Any

from clawbot.evolution.types import (
    CombinedEvolution,
    ValidationResult,
)



class EvolutionValidator:
    """
    进化验证器
    
    功能：
    1. 合理性验证 - 确保进化结果合理
    2. 防退化 - 防止系统退化
    3. 回滚机制 - 支持回滚到之前状态
    """
    
    CRITICAL_OPERATIONS = frozenset([
        "file_delete",
        "directory_delete",
        "credential_access",
        "database_drop",
        "database_truncate",
    ])
    
    SAFETY_CHECKS = [
        "no_critical_removed",
        "threshold_in_range",
        "rules_not_contradictory",
        "expansion_justified",
        "no_rapid_changes",
    ]
    
    def __init__(
        self,
        max_threshold_change: float = 0.1,
        min_sample_for_expansion: int = 5,
    ):
        self.max_threshold_change = max_threshold_change
        self.min_sample_for_expansion = min_sample_for_expansion
        
        self._recent_validations: list[ValidationResult] = []
        self._last_thresholds: dict[str, float] = {}
    
    async def validate(self, evolution: CombinedEvolution) -> ValidationResult:
        """验证进化结果"""
        checks = {}
        errors = []
        warnings = []
        
        for check_name in self.SAFETY_CHECKS:
            check_fn = getattr(self, f"_check_{check_name}", None)
            if check_fn:
                try:
                    result = await check_fn(evolution)
                    checks[check_name] = result
                    
                    if not result:
                        errors.append(f"检查失败：{check_name}")
                except Exception as e:
                    checks[check_name] = False
                    errors.append(f"检查异常：{check_name} - {str(e)}")
        
        if evolution.removed_auto_safe:
            for op in evolution.removed_auto_safe:
                if op not in self.CRITICAL_OPERATIONS:
                    warnings.append(f"操作 {op} 从自动安全列表移除")
        
        if evolution.llm:
            risk_level = evolution.llm.risk_assessment.get("level", "low")
            if risk_level == "high":
                warnings.append("LLM 评估风险等级为高")
        
        is_valid = all(checks.values())
        
        result = ValidationResult(
            is_valid=is_valid,
            checks=checks,
            warnings=warnings,
            errors=errors,
        )
        
        self._recent_validations.append(result)
        if len(self._recent_validations) > 100:
            self._recent_validations = self._recent_validations[-50:]
        
        if is_valid:
            self._last_thresholds = dict(evolution.thresholds)
        
        logger.info(
            f"Validation result: {'PASSED' if is_valid else 'FAILED'}, "
            f"checks: {checks}, warnings: {len(warnings)}, errors: {len(errors)}"
        )
        
        return result
    
    async def _check_no_critical_removed(self, evolution: CombinedEvolution) -> bool:
        """检查是否移除了关键安全操作"""
        removed = set(evolution.removed_auto_safe or [])
        critical_removed = self.CRITICAL_OPERATIONS & removed
        
        if critical_removed:
            logger.error(f"Critical operations removed: {critical_removed}")
            return False
        
        return True
    
    async def _check_threshold_in_range(self, evolution: CombinedEvolution) -> bool:
        """检查阈值是否在合理范围"""
        for name, value in evolution.thresholds.items():
            if not isinstance(value, (int, float)):
                return False
            if not (0.1 <= value <= 0.9):
                logger.error(f"Threshold {name} out of range: {value}")
                return False
        
        return True
    
    async def _check_rules_not_contradictory(self, evolution: CombinedEvolution) -> bool:
        """检查规则是否矛盾"""
        auto_safe_ops = set()
        require_human_ops = set()
        
        for rule in evolution.new_rules:
            op = rule.get("operation")
            level = rule.get("level")
            
            if level == "auto_safe":
                auto_safe_ops.add(op)
            elif level == "require_human":
                require_human_ops.add(op)
        
        contradictory = auto_safe_ops & require_human_ops
        if contradictory:
            logger.error(f"Contradictory rules for: {contradictory}")
            return False
        
        for op in evolution.added_auto_safe:
            if op in evolution.removed_auto_safe:
                logger.error(f"Operation {op} both added and removed from auto_safe")
                return False
        
        return True
    
    async def _check_expansion_justified(self, evolution: CombinedEvolution) -> bool:
        """检查能力扩展是否有充分理由"""
        for expansion in evolution.statistical.expansions:
            sample_count = expansion.get("evidence_count", 0)
            success_rate = expansion.get("success_rate", 0)
            
            if sample_count < self.min_sample_for_expansion:
                logger.warning(
                    f"Expansion of {expansion.get('operation_type')} "
                    f"has insufficient samples: {sample_count}"
                )
            
            if success_rate < 0.7:
                logger.warning(
                    f"Expansion of {expansion.get('operation_type')} "
                    f"has low success rate: {success_rate}"
                )
        
        return True
    
    async def _check_no_rapid_changes(self, evolution: CombinedEvolution) -> bool:
        """检查是否有快速变化"""
        if not self._last_thresholds:
            return True
        
        for name, new_value in evolution.thresholds.items():
            old_value = self._last_thresholds.get(name, new_value)
            change = abs(new_value - old_value)
            
            if change > self.max_threshold_change:
                logger.error(
                    f"Rapid threshold change for {name}: "
                    f"{old_value} -> {new_value} (change: {change})"
                )
                return False
        
        return True
    
    def get_validation_history(self, limit: int = 10) -> list[dict]:
        """获取验证历史"""
        return [
            {
                "is_valid": v.is_valid,
                "checks": v.checks,
                "warnings_count": len(v.warnings),
                "errors_count": len(v.errors),
            }
            for v in self._recent_validations[-limit:]
        ]
    
    def get_stats(self) -> dict:
        """获取验证统计"""
        if not self._recent_validations:
            return {
                "total_validations": 0,
                "pass_rate": 0,
            }
        
        total = len(self._recent_validations)
        passed = sum(1 for v in self._recent_validations if v.is_valid)
        
        return {
            "total_validations": total,
            "passed": passed,
            "failed": total - passed,
            "pass_rate": passed / total if total > 0 else 0,
        }
