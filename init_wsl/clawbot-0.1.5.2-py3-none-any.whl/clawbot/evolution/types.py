"""
Evolution Types - 进化相关类型定义
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


@dataclass
class StatisticalResult:
    """统计分析结果"""
    patterns: list[Any] = field(default_factory=list)
    adjustments: dict[str, Any] = field(default_factory=dict)
    new_rules: list[dict] = field(default_factory=list)
    expansions: list[dict] = field(default_factory=list)
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class LLMEnhancementResult:
    """LLM 增强结果"""
    threshold_suggestions: dict[str, float] = field(default_factory=dict)
    new_rules_suggestions: list[dict] = field(default_factory=list)
    prompt_updates: list[dict] = field(default_factory=list)
    capability_expansions: list[dict] = field(default_factory=list)
    risk_assessment: dict[str, Any] = field(default_factory=dict)
    reasoning: str = ""
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class CombinedEvolution:
    """组合进化结果"""
    statistical: StatisticalResult
    llm: LLMEnhancementResult | None
    thresholds: dict[str, float] = field(default_factory=dict)
    new_rules: list[dict] = field(default_factory=list)
    removed_auto_safe: list[str] = field(default_factory=list)
    added_auto_safe: list[str] = field(default_factory=list)
    prompt_updates: list[dict] = field(default_factory=list)


@dataclass
class ValidationResult:
    """验证结果"""
    is_valid: bool
    checks: dict[str, bool] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)


@dataclass
class EvolutionResult:
    """进化结果"""
    timestamp: datetime
    statistical: StatisticalResult
    llm: LLMEnhancementResult | None
    validated: ValidationResult
    applied: bool
    rollback_available: bool = True


@dataclass
class ImmediateAction:
    """即时动作"""
    actions: list[dict] = field(default_factory=list)
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class EvolutionAdjustment:
    """进化调整"""
    adjustment_type: str
    target: str
    old_value: Any
    new_value: Any
    reason: str
    confidence: float
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class EvolutionStats:
    """进化统计"""
    total_evolutions: int = 0
    successful_evolutions: int = 0
    failed_evolutions: int = 0
    last_evolution: datetime | None = None
    auto_safe_operations_count: int = 0
    require_human_operations_count: int = 0
    thresholds: dict[str, float] = field(default_factory=dict)
