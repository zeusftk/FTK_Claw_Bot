"""
clawbot - A lightweight AI agent framework
"""

__version__ = "0.1.5.2"
__logo__ = "🦐"
