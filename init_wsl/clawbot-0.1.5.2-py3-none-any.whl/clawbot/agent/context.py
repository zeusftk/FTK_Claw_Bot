"""Context builder for assembling agent prompts."""

import base64
import mimetypes
import platform
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Optional, TYPE_CHECKING

from clawbot.agent.skills import SkillsLoader
from clawbot.memory.config import MemOSConfig, EmbeddingApiConfig

if TYPE_CHECKING:
    from clawbot.agent.memory import MemoryStore
    from clawbot.memory.hybrid_manager import HybridMemoryManager


class ContextBuilder:
    """
    Builds the context (system prompt + messages) for the agent.

    Assembles bootstrap files, memory, skills, and conversation history
    into a coherent prompt for the LLM.
    """

    BOOTSTRAP_FILES = ["AGENTS.md", "SOUL.md", "USER.md", "TOOLS.md", "IDENTITY.md"]

    def __init__(
        self, 
        workspace: Path, 
        embedding_api_config: Optional[EmbeddingApiConfig] = None,
        memos_config: Optional[MemOSConfig] = None,
        skills_config: Optional["SkillsConfig"] = None,
    ):
        from clawbot.memory.hybrid_manager import HybridMemoryManager
        from clawbot.config.schema import SkillsConfig as SkillsConfigSchema
        
        self.workspace = workspace
        self.embedding_api_config = embedding_api_config
        self.memos_config = memos_config
        self.memory: "HybridMemoryManager" = HybridMemoryManager(
            workspace, 
            embedding_api_config=embedding_api_config,
            memos_config=memos_config
        )
        # Pass skills config to SkillsLoader
        skills_config_dict = None
        if skills_config:
            skills_config_dict = {
                "skills": {
                    "enabled": skills_config.enabled,
                    "priorities": skills_config.priorities,
                }
            }
        self.skills = SkillsLoader(workspace, config=skills_config_dict)

    def build_system_prompt(self, skill_names: list[str] | None = None) -> str:
        """
        Build the system prompt from bootstrap files, memory, and skills.
        
        Args:
            skill_names: Optional list of skills to include.
        
        Returns:
            Complete system prompt.
        """
        parts = []

        # Core identity
        parts.append(self._get_identity())

        # Bootstrap files
        bootstrap = self._load_bootstrap_files()
        if bootstrap:
            parts.append(bootstrap)

        # Memory context
        memory = self.memory.get_memory_context()
        if memory:
            parts.append(f"# Memory\n\n{memory}")

        # Skills - progressive loading
        # 1. Always-loaded skills: include full content
        always_skills = self.skills.get_always_skills()
        if always_skills:
            always_content = self.skills.load_skills_for_context(always_skills)
            if always_content:
                parts.append(f"# Active Skills\n\n{always_content}")

        # 2. Available skills: only show summary (agent uses read_file to load)
        skills_summary = self.skills.build_skills_summary()
        if skills_summary:
            parts.append(f"""# Skills

The following skills extend your capabilities. To use a skill, read its SKILL.md file using the read_file tool.
Skills with available="false" need dependencies installed first - you can try installing them with apt/brew.

## Priority Guidelines
- Skills are listed in **priority order** (highest first)
- **Higher priority skills should be considered/executed first** when multiple skills are relevant
- Priority range: 1-1000 (default is 1)
- When planning your actions, prioritize skills with higher priority values
- Example: A skill with priority=100 should be loaded/used before a skill with priority=5

{skills_summary}""")

        return "\n\n---\n\n".join(parts)

    def _get_identity(self) -> str:
        """Get the core identity section."""
        workspace_path = str(self.workspace.expanduser().resolve())
        system = platform.system()
        runtime = f"{'macOS' if system == 'Darwin' else system} {platform.machine()}, Python {platform.python_version()}"

        return f"""# clawbot 🐈

You are clawbot, a helpful AI assistant. 

## Runtime
{runtime}

## Workspace
Your workspace is at: {workspace_path}
- Long-term memory: {workspace_path}/memory/MEMORY.md
- History log: {workspace_path}/memory/HISTORY.md (grep-searchable)
- Custom skills: {workspace_path}/skills/{{skill-name}}/SKILL.md

Reply directly with text for conversations. Only use the 'message' tool to send to a specific chat channel.

## OpenWork/OpenCode Integration
OpenWork and OpenCode are your internal subsystems for autonomous programming tasks.

### Architecture
```
User Idea → ClawbotMaster (主控)
    → IdeaProcessor (解析需求)
    → TaskRouter (路由任务)
    → MemoryManager (检索历史)
    → HTTP POST → OpenWork Server (port 7777)
    → SSE Stream → ProgressReporter (进度监控)
    → Opencode (执行编程任务)
    → HybridEvolutionEngine (混合进化)
        → FeedbackCollector (收集反馈)
        → StatisticalEvolver (统计分析)
        → LLMEnhancer (深度优化)
        → EvolutionValidator (验证进化)
    → Memory Record + Self-Optimization
```

### Key Principles
1. **Internal Subsystem**: OpenWork/OpenCode are YOUR internal tools, NOT external services requiring user setup
2. **HTTP API First**: Always check status via HTTP API (http://localhost:7777/health), NOT shell commands
3. **Auto-Approval**: Safe operations (file read/create/modify, code execution within workspace) are automatically approved
4. **No User Intervention**: You handle all permission decisions autonomously
5. **Direct Connection**: If port 7777 is open, the service is running - use it directly via HTTP API

### Status Check (Correct Method)
- **DO**: Check http://localhost:7777/health via web_fetch or HTTP request
- **DON'T**: Run shell commands like `openwork --version` or `which openwork`
- **DON'T**: Ask user to install openwork CLI - it's NOT required for HTTP API usage

### When Using OpenWork/OpenCode
1. Treat them as your internal tools
2. Make autonomous decisions on permissions
3. Only escalate for truly sensitive operations (system-wide changes, external API keys)
4. Report progress and results naturally

## Tool Call Guidelines
- Before calling tools, you may briefly state your intent (e.g. "Let me check that"), but NEVER predict or describe the expected result before receiving it.
- Before modifying a file, read it first to confirm its current content.
- Do not assume a file or directory exists �?use list_dir or read_file to verify.
- After writing or editing a file, re-read it if accuracy matters.
- If a tool call fails, analyze the error before retrying with a different approach.

## Memory
- Remember important facts: write to {workspace_path}/memory/MEMORY.md
- Recall past events: grep {workspace_path}/memory/HISTORY.md"""

    @staticmethod
    def _inject_runtime_context(
        user_content: str | list[dict[str, Any]],
        channel: str | None,
        chat_id: str | None,
    ) -> str | list[dict[str, Any]]:
        """Append dynamic runtime context to the tail of the user message."""
        now = datetime.now().strftime("%Y-%m-%d %H:%M (%A)")
        tz = time.strftime("%Z") or "UTC"
        lines = [f"Current Time: {now} ({tz})"]
        if channel and chat_id:
            lines += [f"Channel: {channel}", f"Chat ID: {chat_id}"]
        block = "[Runtime Context]\n" + "\n".join(lines)
        if isinstance(user_content, str):
            return f"{user_content}\n\n{block}"
        return [*user_content, {"type": "text", "text": block}]
    
    def _load_bootstrap_files(self) -> str:
        """Load all bootstrap files from workspace."""
        parts = []

        for filename in self.BOOTSTRAP_FILES:
            file_path = self.workspace / filename
            if file_path.exists():
                content = file_path.read_text(encoding="utf-8")
                parts.append(f"## {filename}\n\n{content}")

        return "\n\n".join(parts) if parts else ""

    def build_messages(
        self,
        history: list[dict[str, Any]],
        current_message: str,
        skill_names: list[str] | None = None,
        media: list[str] | None = None,
        channel: str | None = None,
        chat_id: str | None = None,
    ) -> list[dict[str, Any]]:
        """
        Build the complete message list for an LLM call.

        Args:
            history: Previous conversation messages.
            current_message: The new user message.
            skill_names: Optional skills to include.
            media: Optional list of local file paths for images/media.
            channel: Current channel (telegram, feishu, etc.).
            chat_id: Current chat/user ID.

        Returns:
            List of messages including system prompt.
        """
        messages = []

        # System prompt
        system_prompt = self.build_system_prompt(skill_names)
        messages.append({"role": "system", "content": system_prompt})

        # History
        messages.extend(history)

        # Current message (with optional image attachments)
        user_content = self._build_user_content(current_message, media)
        user_content = self._inject_runtime_context(user_content, channel, chat_id)
        messages.append({"role": "user", "content": user_content})

        return messages

    def _build_user_content(self, text: str, media: list[str] | None) -> str | list[dict[str, Any]]:
        """Build user message content with optional base64-encoded images."""
        if not media:
            return text

        images = []
        for path in media:
            p = Path(path)
            mime, _ = mimetypes.guess_type(path)
            if not p.is_file() or not mime or not mime.startswith("image/"):
                continue
            b64 = base64.b64encode(p.read_bytes()).decode()
            images.append({"type": "image_url", "image_url": {"url": f"data:{mime};base64,{b64}"}})

        if not images:
            return text
        return images + [{"type": "text", "text": text}]

    def add_tool_result(
        self,
        messages: list[dict[str, Any]],
        tool_call_id: str,
        tool_name: str,
        result: str
    ) -> list[dict[str, Any]]:
        """
        Add a tool result to the message list.
        
        Args:
            messages: Current message list.
            tool_call_id: ID of the tool call.
            tool_name: Name of the tool.
            result: Tool execution result.
        
        Returns:
            Updated message list.
        """
        messages.append({
            "role": "tool",
            "tool_call_id": tool_call_id,
            "name": tool_name,
            "content": result
        })
        return messages

    def add_assistant_message(
        self,
        messages: list[dict[str, Any]],
        content: str | None,
        tool_calls: list[dict[str, Any]] | None = None,
        reasoning_content: str | None = None,
    ) -> list[dict[str, Any]]:
        """
        Add an assistant message to the message list.
        
        Args:
            messages: Current message list.
            content: Message content.
            tool_calls: Optional tool calls.
            reasoning_content: Thinking output (Kimi, DeepSeek-R1, etc.).
        
        Returns:
            Updated message list.
        """
        msg: dict[str, Any] = {"role": "assistant"}

        # Always include content �?some providers (e.g. StepFun) reject
        # assistant messages that omit the key entirely.
        msg["content"] = content

        if tool_calls:
            msg["tool_calls"] = tool_calls

        # Include reasoning content when provided (required by some thinking models)
        if reasoning_content is not None:
            msg["reasoning_content"] = reasoning_content

        messages.append(msg)
        return messages


class FeedbackParser:
    """解析用户显式反馈和隐式推断"""

    POSITIVE_KEYWORDS = ["谢谢", "好的", "完美", "👍", "感谢", "正确"]
    NEGATIVE_KEYWORDS = ["不对", "不是", "算了", "👎", "错了", "不要"]

    @staticmethod
    def parse_explicit(message: str) -> str | None:
        """解析显式反馈"""
        if "👍" in message:
            return "positive"
        if "👎" in message:
            return "negative"
        return None

    @staticmethod
    def parse_implicit(message: str) -> str | None:
        """解析隐式反馈"""
        for kw in FeedbackParser.POSITIVE_KEYWORDS:
            if kw in message:
                return "positive"
        for kw in FeedbackParser.NEGATIVE_KEYWORDS:
            if kw in message:
                return "negative"
        return None
