"""Shell execution tool."""

import asyncio
import os
import re
import shlex
import unicodedata
from pathlib import Path
from typing import Any

from loguru import logger

from clawbot.agent.tools.base import Tool


class ExecTool(Tool):
    """Tool to execute shell commands."""
    
    SHELL_METACHARACTERS = set('|&;<>()$`\\"\' \t\n!#~*?[]{}')
    
    DANGEROUS_CONSTRUCTS = [
        (r'\$\([^)]+\)', "command substitution"),
        (r'\$\{[^}]+\}', "variable expansion"),
        (r'`[^`]+`', "backtick substitution"),
        (r'\|\s*\S', "pipe to command"),
        (r';\s*\S', "command chaining"),
        (r'&&\s*\S', "conditional AND"),
        (r'\|\|\s*\S', "conditional OR"),
    ]
    
    DEFAULT_DENY_PATTERNS = [
        r"\brm\s+-[rf]{1,2}\b",
        r"\bdel\s+/[fq]\b",
        r"\brmdir\s+/s\b",
        r"(?:^|[;&|]\s*)format\b",
        r"\b(mkfs|diskpart|fdisk)\b",
        r"\bdd\s+if=",
        r">\s*/dev/sd",
        r">\s*/dev/null\s+2>&1\s*;\s*\S",
        r"\b(shutdown|reboot|poweroff|halt)\b",
        r":\(\)\s*\{.*\};\s*:",
        r"\b(sudo|doas|runas)\b",
        r"\b(chmod|chown)\s+[0-7]{3,4}\b",
        r">\s*/etc/",
        r"\b(curl|wget)\s+.*\|\s*(ba)?sh\b",
        r"\beval\s+",
        r"\bexec\s+",
        r"\b(reg\s+delete)\b",
        r"\b(net\s+(user|localgroup|share))\b",
        r"\b(powershell\s+-[ec])\b",
        r"\b(cmd\s+/c)\b",
        r"\b(wmic\s+)\b",
        r"\b(bcdedit)\b",
        r"\b(vssadmin)\b",
        r";\s*(rm|del|format|shutdown)\b",
        r"\|\s*(rm|del|format|shutdown)\b",
        r"\b(taskkill\s+/[fi])\b",
        r"\b(sc\s+(delete|stop|config))\b",
        r"\b(nohup\s+)\b",
        r"\b(setsid\s+)\b",
        r"\b(apt|yum|dnf|pacman|brew|choco|winget)\s+",
        r"\b(pip|npm|yarn|cargo|gem)\s+install\s+.*\|\s*(ba)?sh\b",
        r"\b(crontab\s+-[er])\b",
        r"\b(at\s+)",
        r"\b(sed\s+-i\s+)",
        r"\b(awk\s+.*-f\s+)",
        r"\b(perl\s+-[eE])\b",
        r"\b(python\s+-c\s+)",
        r"\b(ruby\s+-[eE])\b",
        r"\b(php\s+-r\s+)",
        r"\b(node\s+-e\s+)",
        r"\$\([^)]+\)",
        r"\$\{[^}]+\}",
        r"`[^`]+`",
        r"\bexport\s+[A-Za-z_]",
        r"\bunset\s+[A-Za-z_]",
        r"\benv\s+",
        r"\bprintenv\s+",
        r"\b(setenv\s+)",
        r">\s*~/.ssh/",
        r">\s*~/.bashrc",
        r">\s*~/.zshrc",
        r">\s*~/.profile",
        r">\s*/etc/passwd",
        r">\s*/etc/shadow",
        r">\s*/etc/sudoers",
        r">\s*/root/",
        r"\b(ssh\s+-)",
        r"\b(scp\s+)",
        r"\b(rsync\s+.*--rsh)",
        r"\b(nc\s+-[lp])",
        r"\b(netcat\s+)",
        r"\b(nmap\s+)",
        r"\b(iptables\s+)",
        r"\b(ip6tables\s+)",
        r"\b(route\s+)",
        r"\b(ifconfig\s+)",
    ]
    
    ENV_INJECTION_PATTERNS = [
        r"\$\([A-Za-z_][A-Za-z0-9_]*\)",
        r"\$\{[A-Za-z_][A-Za-z0-9_]*\}",
        r"`[^`]+`",
    ]
    
    def __init__(
        self,
        timeout: int = 60,
        working_dir: str | None = None,
        deny_patterns: list[str] | None = None,
        allow_patterns: list[str] | None = None,
        restrict_to_workspace: bool = False,
        allowed_commands: list[str] | None = None,
    ):
        self.timeout = timeout
        self.working_dir = working_dir
        self.deny_patterns = deny_patterns or self.DEFAULT_DENY_PATTERNS
        self.allow_patterns = allow_patterns or []
        self.restrict_to_workspace = restrict_to_workspace
        self.allowed_commands = allowed_commands
    
    @property
    def name(self) -> str:
        return "exec"
    
    @property
    def description(self) -> str:
        return "Execute a shell command and return its output. Use with caution."
    
    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "The shell command to execute"
                },
                "working_dir": {
                    "type": "string",
                    "description": "Optional working directory for the command"
                }
            },
            "required": ["command"]
        }
    
    async def execute(self, command: str, working_dir: str | None = None, **kwargs: Any) -> str:
        cwd = working_dir or self.working_dir or os.getcwd()
        
        audit_info = {
            "command_preview": command[:100],
            "working_dir": cwd,
            "has_shell_chars": bool(self.SHELL_METACHARACTERS.intersection(command)),
        }
        logger.info("Executing command: {}", audit_info)
        
        guard_error = self._guard_command(command, cwd)
        if guard_error:
            logger.warning("Command blocked: {}", guard_error)
            return guard_error
        
        try:
            has_shell_chars = bool(self.SHELL_METACHARACTERS.intersection(command))
            
            if not has_shell_chars:
                try:
                    args = shlex.split(command)
                    if args:
                        process = await asyncio.create_subprocess_exec(
                            args[0],
                            *args[1:],
                            stdout=asyncio.subprocess.PIPE,
                            stderr=asyncio.subprocess.PIPE,
                            cwd=cwd,
                        )
                    else:
                        return "Error: Empty command"
                except ValueError as e:
                    return f"Error: Invalid command syntax: {e}"
            else:
                process = await asyncio.create_subprocess_shell(
                    command,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=cwd,
                )
            
            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(),
                    timeout=self.timeout
                )
            except asyncio.TimeoutError:
                await self._terminate_process_gracefully(process)
                return f"Error: Command timed out after {self.timeout} seconds"
            
            output_parts = []
            
            if stdout:
                output_parts.append(stdout.decode("utf-8", errors="replace"))
            
            if stderr:
                stderr_text = stderr.decode("utf-8", errors="replace")
                if stderr_text.strip():
                    output_parts.append(f"STDERR:\n{stderr_text}")
            
            if process.returncode != 0:
                output_parts.append(f"\nExit code: {process.returncode}")
            
            result = "\n".join(output_parts) if output_parts else "(no output)"
            
            max_len = 10000
            if len(result) > max_len:
                result = result[:max_len] + f"\n... (truncated, {len(result) - max_len} more chars)"
            
            return result
            
        except FileNotFoundError as e:
            return f"Error: Command not found: {e}"
        except PermissionError as e:
            return f"Error: Permission denied: {e}"
        except Exception as e:
            return f"Error executing command: {str(e)}"

    def _guard_command(self, command: str, cwd: str) -> str | None:
        """Best-effort safety guard for potentially destructive commands."""
        cmd = command.strip()
        
        cmd = unicodedata.normalize('NFKC', cmd)
        
        if any(ord(c) < 32 and c not in '\t\n\r' for c in cmd):
            return "Error: Command blocked by safety guard (invalid control characters detected)"
        
        if any(ord(c) > 127 and not unicodedata.category(c).startswith('L') for c in cmd if ord(c) > 127):
            suspicious = [c for c in cmd if ord(c) > 127 and unicodedata.category(c) in ('Po', 'Pd', 'Pc')]
            if suspicious:
                return "Error: Command blocked by safety guard (suspicious Unicode characters detected)"

        lower = cmd.lower()

        for pattern in self.deny_patterns:
            if re.search(pattern, lower):
                return "Error: Command blocked by safety guard (dangerous pattern detected)"

        if self.allow_patterns:
            if not any(re.search(p, lower) for p in self.allow_patterns):
                return "Error: Command blocked by safety guard (not in allowlist)"

        if self.restrict_to_workspace:
            if "..\\" in cmd or "../" in cmd:
                logger.warning("Path traversal detected in command")
                return "Error: Command blocked by safety guard (path traversal detected)"
            
            if "\\\\" in cmd and not cmd.startswith("\\\\"):
                return "Error: Command blocked by safety guard (UNC path detected)"

            cwd_path = Path(cwd).resolve()

            win_paths = re.findall(r"[A-Za-z]:\\[^\\\"']+", cmd)
            posix_paths = re.findall(r"(?:^|[\s|>])(/[^\s\"'>]+)", cmd)

            for raw in win_paths + posix_paths:
                try:
                    p = Path(raw.strip()).resolve()
                except (ValueError, OSError) as e:
                    logger.debug("Path resolution skipped: {}", e)
                    continue
                if p.is_absolute() and cwd_path not in p.parents and p != cwd_path:
                    return "Error: Command blocked by safety guard (path outside working dir)"

        return None

    def _validate_command_structure(self, command: str) -> list[str]:
        """Validate command structure and return warnings for dangerous constructs."""
        warnings = []
        for pattern, desc in self.DANGEROUS_CONSTRUCTS:
            if re.search(pattern, command):
                warnings.append(f"Potentially dangerous construct: {desc}")
        return warnings

    async def _terminate_process_gracefully(self, process: asyncio.subprocess.Process) -> None:
        """Terminate process gracefully, then forcefully if needed."""
        try:
            process.terminate()
            await asyncio.wait_for(process.wait(), timeout=3.0)
            logger.debug("Process {} terminated gracefully", process.pid)
        except asyncio.TimeoutError:
            logger.warning("Process {} did not terminate, sending SIGKILL", process.pid)
            try:
                process.kill()
                await asyncio.wait_for(process.wait(), timeout=2.0)
            except asyncio.TimeoutError:
                logger.error("Process {} became zombie after kill", process.pid)
