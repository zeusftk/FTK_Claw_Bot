"""MCP client: connects to MCP servers and wraps their tools as native clawbot tools."""

import asyncio
from contextlib import AsyncExitStack
from typing import Any

import httpx
from loguru import logger

from clawbot.agent.tools.base import Tool
from clawbot.agent.tools.registry import ToolRegistry


class MCPToolWrapper(Tool):
    """Wraps a single MCP server tool as a clawbot Tool."""

    def __init__(self, session, server_name: str, tool_def, tool_timeout: int = 30):
        self._session = session
        self._original_name = tool_def.name
        self._name = f"mcp_{server_name}_{tool_def.name}"
        self._description = tool_def.description or tool_def.name
        self._parameters = tool_def.inputSchema or {"type": "object", "properties": {}}
        self._tool_timeout = tool_timeout

    @property
    def name(self) -> str:
        return self._name

    @property
    def description(self) -> str:
        return self._description

    @property
    def parameters(self) -> dict[str, Any]:
        return self._parameters

    async def execute(self, **kwargs: Any) -> str:
        from mcp import types
        try:
            result = await asyncio.wait_for(
                self._session.call_tool(self._original_name, arguments=kwargs),
                timeout=self._tool_timeout,
            )
        except asyncio.TimeoutError:
            logger.warning("MCP tool '{}' timed out after {}s", self._name, self._tool_timeout)
            return f"(MCP tool call timed out after {self._tool_timeout}s)"
        parts = []
        for block in result.content:
            if isinstance(block, types.TextContent):
                parts.append(block.text)
            else:
                parts.append(str(block))
        return "\n".join(parts) or "(no output)"


async def _connect_single_mcp_server(
    name: str,
    cfg: Any,
    registry: ToolRegistry,
    attempt_stack: AsyncExitStack,
) -> bool:
    """Connect to a single MCP server and register its tools.

    Returns True on success, False on failure.
    """
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client

    try:
        if cfg.command:
            params = StdioServerParameters(
                command=cfg.command, args=cfg.args, env=cfg.env or None
            )
            read, write = await attempt_stack.enter_async_context(stdio_client(params))
        elif cfg.url:
            from mcp.client.streamable_http import streamable_http_client
            http_client = await attempt_stack.enter_async_context(
                httpx.AsyncClient(
                    headers=cfg.headers or None,
                    follow_redirects=True,
                    timeout=None,
                )
            )
            read, write, _ = await attempt_stack.enter_async_context(
                streamable_http_client(cfg.url, http_client=http_client)
            )
        else:
            logger.warning("MCP server '{}': no command or url configured, skipping", name)
            return False

        session = await attempt_stack.enter_async_context(ClientSession(read, write))
        await session.initialize()

        tools = await session.list_tools()
        for tool_def in tools.tools:
            wrapper = MCPToolWrapper(session, name, tool_def, tool_timeout=cfg.tool_timeout)
            registry.register(wrapper)
            logger.debug("MCP: registered tool '{}' from server '{}'", wrapper.name, name)

        logger.info("MCP server '{}': connected, {} tools registered", name, len(tools.tools))
        return True

    except Exception as e:
        logger.error("MCP server '{}': connection failed: {}", name, e)
        return False


async def connect_mcp_servers(
    mcp_servers: dict,
    registry: ToolRegistry,
    stack: AsyncExitStack,
    max_retries: int = 3,
    retry_delay: float = 5.0,
) -> None:
    """Connect to configured MCP servers and register their tools.

    Each server is attempted up to max_retries times. Failed connections
    are logged but do not prevent other servers from being connected.
    """
    for name, cfg in mcp_servers.items():
        for attempt in range(max_retries):
            attempt_stack = AsyncExitStack()
            try:
                success = await _connect_single_mcp_server(name, cfg, registry, attempt_stack)
                if success:
                    transfer_stack_resources(attempt_stack, stack)
                    break
                else:
                    await attempt_stack.aclose()
                    break

            except Exception as e:
                await attempt_stack.aclose()
                if attempt < max_retries - 1:
                    logger.warning(
                        "MCP server '{}': attempt {}/{} failed: {}, retrying in {}s",
                        name, attempt + 1, max_retries, e, retry_delay
                    )
                    await asyncio.sleep(retry_delay)
                else:
                    logger.error("MCP server '{}': failed after {} attempts: {}", name, max_retries, e)


def transfer_stack_resources(source: AsyncExitStack, target: AsyncExitStack) -> None:
    """Transfer all registered callbacks from source stack to target stack.

    
    This allows resources created in a temporary stack to be managed by
    a longer-lived stack.
    """
    if not source._exit_callbacks:
        return
    for callback in source._exit_callbacks:
        target.push(callback)
    source._exit_callbacks.clear()
