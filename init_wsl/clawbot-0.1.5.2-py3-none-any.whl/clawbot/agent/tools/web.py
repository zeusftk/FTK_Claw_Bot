"""Web tools: web_search, web_fetch, and web_bridge."""

import asyncio
import base64
import html
import json
import os
import re
import shutil
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import httpx

from clawbot.agent.tools.base import Tool

# Shared constants
USER_AGENT = "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_7_2) AppleWebKit/537.36"
MAX_REDIRECTS = 5  # Limit redirects to prevent DoS attacks


def _strip_tags(text: str) -> str:
    """Remove HTML tags and decode entities."""
    text = re.sub(r'<script[\s\S]*?</script>', '', text, flags=re.I)
    text = re.sub(r'<style[\s\S]*?</style>', '', text, flags=re.I)
    text = re.sub(r'<[^>]+>', '', text)
    return html.unescape(text).strip()


def _normalize(text: str) -> str:
    """Normalize whitespace."""
    text = re.sub(r'[ \t]+', ' ', text)
    return re.sub(r'\n{3,}', '\n\n', text).strip()


def _validate_url(url: str) -> tuple[bool, str]:
    """Validate URL: must be http(s) with valid domain."""
    try:
        p = urlparse(url)
        if p.scheme not in ('http', 'https'):
            return False, f"Only http/https allowed, got '{p.scheme or 'none'}'"
        if not p.netloc:
            return False, "Missing domain"
        return True, ""
    except Exception as e:
        return False, str(e)


class WebSearchTool(Tool):
    """Search the web using available providers.

    Priority:
    1. Brave Search API (if API key configured)
    2. Available web-search skills (dynamically detected)
    3. Return unavailable message
    """

    name = "web_search"
    description = "Search the web. Returns titles, URLs, and snippets."
    parameters = {
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "Search query"},
            "count": {"type": "integer", "description": "Results (1-10)", "minimum": 1, "maximum": 10}
        },
        "required": ["query"]
    }

    # Skills that provide web search capability
    SEARCH_SKILLS = ["iflow-websearch"]

    # Keywords for fuzzy matching web-search skills
    # Note: "search" alone is too broad (matches "research", etc.), use more specific terms
    SEARCH_KEYWORDS = [
        "web-search", "websearch", "web search",
        "ddg", "duckduckgo", "brave-search", "google-search",
        "websearchtool", "search-engine", "web-query"
    ]

    def __init__(self, api_key: str | None = None, max_results: int = 5, workspace: Path | None = None):
        self._init_api_key = api_key
        self.max_results = max_results
        self._workspace = workspace
        self._available_skill: str | None = None
        self._skill_checked = False
        self._all_search_skills: list[str] = []  # All found web-search skills
        self._unavailable_skills: list[dict] = []  # Skills found but requirements not met

    @property
    def api_key(self) -> str:
        """Resolve API key at call time so env/config changes are picked up."""
        return self._init_api_key or os.environ.get("BRAVE_API_KEY", "")

    def _find_all_search_skills(self) -> list[str]:
        """Dynamically discover all web-search skills from skills directories."""
        search_skills = set(self.SEARCH_SKILLS)  # Start with known skills

        # Scan builtin skills directory
        builtin_skills_dir = Path(__file__).parent.parent / "skills"
        self._scan_skills_dir(builtin_skills_dir, search_skills)

        # Scan workspace skills directory
        if self._workspace:
            workspace_skills_dir = self._workspace / "skills"
            self._scan_skills_dir(workspace_skills_dir, search_skills)

        return list(search_skills)

    def _scan_skills_dir(self, skills_dir: Path, search_skills: set) -> None:
        """Scan a skills directory for web-search capable skills using fuzzy matching."""
        if not skills_dir.exists():
            return

        for skill_dir in skills_dir.iterdir():
            if not skill_dir.is_dir():
                continue

            skill_file = skill_dir / "SKILL.md"
            if not skill_file.exists():
                continue

            try:
                content = skill_file.read_text(encoding="utf-8")
                meta = self._parse_skill_metadata(content)

                # 1. Check explicit provides field
                provides = meta.get("provides", [])
                if isinstance(provides, str):
                    provides = [provides]
                if "web-search" in provides or "web_search" in provides:
                    search_skills.add(skill_dir.name)
                    continue

                # 2. Fuzzy match: check name, slug, description for search keywords
                skill_name = meta.get("name", skill_dir.name)
                slug = meta.get("slug", "")
                description = meta.get("description", "")

                # Combine all text fields for matching
                combined_text = f"{skill_name} {slug} {description} {skill_dir.name}".lower()

                for keyword in self.SEARCH_KEYWORDS:
                    if keyword.lower() in combined_text:
                        search_skills.add(skill_dir.name)
                        break
            except Exception:
                pass

    def _find_available_search_skill(self) -> str | None:
        """Find an available web-search skill by checking requirements."""
        if self._skill_checked:
            return self._available_skill

        self._skill_checked = True
        self._all_search_skills = self._find_all_search_skills()

        for skill_name in self._all_search_skills:
            available, missing = self._check_skill_available_with_details(skill_name)
            if available:
                self._available_skill = skill_name
                return skill_name
            else:
                # Record unavailable skill with missing requirements
                self._unavailable_skills.append({
                    "name": skill_name,
                    "missing": missing
                })

        return None

    def _check_skill_available(self, skill_name: str) -> bool:
        """Check if a skill's requirements are met."""
        available, _ = self._check_skill_available_with_details(skill_name)
        return available

    def _check_skill_available_with_details(self, skill_name: str) -> tuple[bool, dict]:
        """Check if a skill's requirements are met, return missing details."""
        missing = {"bins": [], "env": []}

        # Check builtin skills directory first
        builtin_skills_dir = Path(__file__).parent.parent / "skills"
        skill_file = builtin_skills_dir / skill_name / "SKILL.md"

        # If not found in builtin, check workspace skills
        if not skill_file.exists() and self._workspace:
            skill_file = self._workspace / "skills" / skill_name / "SKILL.md"

        if not skill_file.exists():
            missing["bins"].append(f"skill not found: {skill_name}")
            return False, missing

        try:
            content = skill_file.read_text(encoding="utf-8")
            meta = self._parse_skill_metadata(content)
            return self._check_requirements_with_details(meta)
        except Exception as e:
            missing["bins"].append(f"error reading skill: {e}")
            return False, missing

    def _parse_skill_metadata(self, content: str) -> dict:
        """Parse skill metadata from frontmatter."""
        if not content.startswith("---"):
            return {}
        match = re.match(r"^---\n(.*?)\n---", content, re.DOTALL)
        if not match:
            return {}

        metadata = {}
        for line in match.group(1).split("\n"):
            if ":" in line:
                key, value = line.split(":", 1)
                metadata[key.strip()] = value.strip().strip('"\'')

        # Parse clawbot/openclaw metadata JSON
        if "metadata" in metadata:
            try:
                data = json.loads(metadata["metadata"])
                result = data.get("clawbot", data.get("openclaw", {}))
                # Also preserve top-level fields for fuzzy matching
                for key in ["name", "slug", "description"]:
                    if key in metadata and key not in result:
                        result[key] = metadata[key]
                return result
            except (json.JSONDecodeError, TypeError):
                pass

        return metadata

    def _check_requirements(self, skill_meta: dict) -> bool:
        """Check if skill requirements (bins, env) are met."""
        available, _ = self._check_requirements_with_details(skill_meta)
        return available

    def _check_requirements_with_details(self, skill_meta: dict) -> tuple[bool, dict]:
        """Check if skill requirements (bins, env) are met, return missing details."""
        missing = {"bins": [], "env": []}
        requires = skill_meta.get("requires", {})

        for b in requires.get("bins", []):
            if not shutil.which(b):
                missing["bins"].append(b)

        for env in requires.get("env", []):
            if not os.environ.get(env):
                missing["env"].append(env)

        return (len(missing["bins"]) == 0 and len(missing["env"]) == 0), missing

    def is_available(self) -> bool:
        """Check if any search provider is available."""
        return bool(self.api_key) or self._find_available_search_skill() is not None

    async def execute(self, query: str, count: int | None = None, **kwargs: Any) -> str:
        # Priority 1: Brave Search API
        if self.api_key:
            return await self._search_brave(query, count)

        # Priority 2: Available search skill
        skill_name = self._find_available_search_skill()
        if skill_name:
            return await self._search_via_skill(skill_name, query)

        # Priority 3: Not available - provide detailed info for agent analysis
        msg_parts = ["Web search is currently unavailable.\n"]

        # List found but unavailable skills
        if self._unavailable_skills:
            msg_parts.append("Found web-search skills with missing requirements:")
            for skill in self._unavailable_skills:
                missing_parts = []
                if skill["missing"].get("bins"):
                    missing_parts.append(f"missing binaries: {', '.join(skill['missing']['bins'])}")
                if skill["missing"].get("env"):
                    missing_parts.append(f"missing env vars: {', '.join(skill['missing']['env'])}")
                msg_parts.append(f"  - {skill['name']}: {'; '.join(missing_parts)}")
            msg_parts.append("")

        msg_parts.extend([
            "To enable web search, configure one of the following:",
            "1. Brave Search API: Set tools.web.search.apiKey in ~/.clawbot/config.json "
            "or export BRAVE_API_KEY environment variable",
            "2. Install a web-search skill with required dependencies (e.g., iflow-websearch)"
        ])

        return "\n".join(msg_parts)

    async def _search_brave(self, query: str, count: int | None = None) -> str:
        """Search using Brave Search API."""
        try:
            n = min(max(count or self.max_results, 1), 10)
            async with httpx.AsyncClient() as client:
                r = await client.get(
                    "https://api.search.brave.com/res/v1/web/search",
                    params={"q": query, "count": n},
                    headers={"Accept": "application/json", "X-Subscription-Token": self.api_key},
                    timeout=10.0
                )
                r.raise_for_status()

            results = r.json().get("web", {}).get("results", [])
            if not results:
                return f"No results for: {query}"

            lines = [f"Results for: {query}\n"]
            for i, item in enumerate(results[:n], 1):
                lines.append(f"{i}. {item.get('title', '')}\n   {item.get('url', '')}")
                if desc := item.get("description"):
                    lines.append(f"   {desc}")
            return "\n".join(lines)
        except Exception as e:
            return f"Brave Search error: {e}"

    async def _search_via_skill(self, skill_name: str, query: str) -> str:
        """Execute search using a skill's method."""
        if skill_name == "iflow-websearch":
            return await self._search_iflow(query)

        return f"Unknown search skill: {skill_name}"

    async def _search_iflow(self, query: str) -> str:
        """Search using iFlow CLI (iflow-websearch skill)."""
        try:
            # Create temp output file
            with tempfile.NamedTemporaryFile(mode='w', suffix='.md', delete=False) as f:
                output_path = f.name

            # Build iflow command
            cmd = [
                "iflow", "-m", "glm-5",
                f"搜索: {query}",
                "-y", "-o", output_path
            ]

            # Execute iflow
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=60.0)

            # Read result
            try:
                with open(output_path, 'r', encoding='utf-8') as f:
                    result = f.read()
                os.unlink(output_path)
            except FileNotFoundError:
                result = stdout.decode('utf-8') if stdout else "No output from iflow"

            if proc.returncode != 0:
                error_msg = stderr.decode('utf-8') if stderr else "Unknown error"
                return f"iFlow search failed: {error_msg}\n\n{result}"

            return f"[iFlow Search Results]\n\n{result}"
        except asyncio.TimeoutError:
            return "iFlow search timed out (60s)"
        except Exception as e:
            return f"iFlow search error: {e}"


class WebFetchTool(Tool):
    """Fetch and extract content from a URL using Readability."""
    
    name = "web_fetch"
    description = "Fetch URL and extract readable content (HTML →markdown/text)."
    parameters = {
        "type": "object",
        "properties": {
            "url": {"type": "string", "description": "URL to fetch"},
            "extractMode": {"type": "string", "enum": ["markdown", "text"], "default": "markdown"},
            "maxChars": {"type": "integer", "minimum": 100}
        },
        "required": ["url"]
    }
    
    def __init__(self, max_chars: int = 50000):
        self.max_chars = max_chars
    
    async def execute(self, url: str, extractMode: str = "markdown", maxChars: int | None = None, **kwargs: Any) -> str:
        from readability import Document

        max_chars = maxChars or self.max_chars

        # Validate URL before fetching
        is_valid, error_msg = _validate_url(url)
        if not is_valid:
            return json.dumps({"error": f"URL validation failed: {error_msg}", "url": url}, ensure_ascii=False)

        try:
            async with httpx.AsyncClient(
                follow_redirects=True,
                max_redirects=MAX_REDIRECTS,
                timeout=30.0
            ) as client:
                r = await client.get(url, headers={"User-Agent": USER_AGENT})
                r.raise_for_status()
            
            ctype = r.headers.get("content-type", "")
            
            # JSON
            if "application/json" in ctype:
                text, extractor = json.dumps(r.json(), indent=2, ensure_ascii=False), "json"
            # HTML
            elif "text/html" in ctype or r.text[:256].lower().startswith(("<!doctype", "<html")):
                doc = Document(r.text)
                content = self._to_markdown(doc.summary()) if extractMode == "markdown" else _strip_tags(doc.summary())
                text = f"# {doc.title()}\n\n{content}" if doc.title() else content
                extractor = "readability"
            else:
                text, extractor = r.text, "raw"
            
            truncated = len(text) > max_chars
            if truncated:
                text = text[:max_chars]
            
            return json.dumps({"url": url, "finalUrl": str(r.url), "status": r.status_code,
                              "extractor": extractor, "truncated": truncated, "length": len(text), "text": text}, ensure_ascii=False)
        except Exception as e:
            return json.dumps({"error": str(e), "url": url}, ensure_ascii=False)
    
    def _to_markdown(self, html: str) -> str:
        """Convert HTML to markdown."""
        # Convert links, headings, lists before stripping tags
        text = re.sub(r'<a\s+[^>]*href=["\']([^"\']+)["\'][^>]*>([\s\S]*?)</a>',
                      lambda m: f'[{_strip_tags(m[2])}]({m[1]})', html, flags=re.I)
        text = re.sub(r'<h([1-6])[^>]*>([\s\S]*?)</h\1>',
                      lambda m: f'\n{"#" * int(m[1])} {_strip_tags(m[2])}\n', text, flags=re.I)
        text = re.sub(r'<li[^>]*>([\s\S]*?)</li>', lambda m: f'\n- {_strip_tags(m[1])}', text, flags=re.I)
        text = re.sub(r'</(p|div|section|article)>', '\n\n', text, flags=re.I)
        text = re.sub(r'<(br|hr)\s*/?>', '\n', text, flags=re.I)
        return _normalize(_strip_tags(text))


class WebBridgeTool(Tool):
    """Web automation tool via Windows bridge connection."""
    
    name = "web_bridge"
    description = """Control web browser via Windows bridge.

This tool allows you to automate web browsing through Playwright running on Windows.
Requires FTK_Claw_Bot to be running on the Windows host.

Actions available:
- start: Start browser (headless: true/false)
- stop: Stop browser
- navigate: Navigate to URL
- click: Click element by selector
- fill: Fill form field
- scroll: Scroll page
- screenshot: Capture screenshot
- get_content: Get page HTML
- get_url: Get current URL
- get_title: Get page title
- extract_elements: Extract interactive elements
- extract_data: Extract data by selectors
- get_cookies: Get browser cookies
- set_cookies: Set browser cookies
- login: Login (form/cookie/qr)
- press: Press keyboard key
- type: Type text
- evaluate: Execute JavaScript
- wait_for_selector: Wait for element
- go_back: Navigate back
- go_forward: Navigate forward
- refresh: Refresh page"""

    parameters = {
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "enum": [
                    "start", "stop", "navigate", "click", "fill", "scroll",
                    "screenshot", "get_content", "get_url", "get_title",
                    "extract_elements", "extract_data", "get_cookies", "set_cookies",
                    "login", "press", "type", "evaluate", "wait_for_selector",
                    "go_back", "go_forward", "refresh", "get_status"
                ],
                "description": "The web action to perform"
            },
            "params": {
                "type": "object",
                "description": "Parameters for the action",
                "properties": {
                    "headless": {"type": "boolean", "description": "Run browser headless"},
                    "url": {"type": "string", "description": "URL to navigate to"},
                    "selector": {"type": "string", "description": "CSS selector"},
                    "value": {"type": "string", "description": "Value to fill"},
                    "direction": {"type": "string", "enum": ["up", "down"]},
                    "amount": {"type": "integer", "description": "Scroll amount"},
                    "timeout": {"type": "integer", "description": "Timeout in ms"},
                    "cookies": {"type": "array", "description": "Cookies to set"},
                    "selectors": {"type": "array", "description": "Data selectors"},
                    "config": {"type": "object", "description": "Extract config"},
                    "key": {"type": "string", "description": "Key to press"},
                    "text": {"type": "string", "description": "Text to type"},
                    "script": {"type": "string", "description": "JavaScript to execute"},
                    "type": {"type": "string", "description": "Login type"},
                    "full_page": {"type": "boolean", "description": "Full page screenshot"},
                    "wait_until": {"type": "string", "description": "Navigation wait condition"}
                }
            }
        },
        "required": ["action"]
    }
    
    _client: Any = None
    
    def __init__(self, host: str | None = None, port: int = 9527, auto_connect: bool = True):
        self._host = host
        self._port = port
        self._auto_connect = auto_connect
        self._config_path = self._find_config_path()
    
    def _find_config_path(self) -> Path | None:
        config_paths = [
            Path.home() / ".clawbot" / "config.json",
        ]
        for path in config_paths:
            if path.exists():
                return path
        return None
    
    def _reload_port_from_config(self) -> int:
        if self._config_path and self._config_path.exists():
            try:
                data = json.loads(self._config_path.read_text())
                port = data.get("tools", {}).get("windowsBridge", {}).get("port")
                if port and port != self._port:
                    self._port = port
                    WebBridgeTool._client = None
            except (json.JSONDecodeError, KeyError):
                pass
        return self._port
    
    def _get_client(self) -> Any:
        from clawbot.agent.tools.windows_gui import WindowsBridgeClient
        self._reload_port_from_config()
        if WebBridgeTool._client is None:
            WebBridgeTool._client = WindowsBridgeClient(host=self._host, port=self._port)
        return WebBridgeTool._client
    
    async def execute(self, **kwargs: Any) -> str:
        action = kwargs.get("action")
        params = kwargs.get("params", {})
        
        client = self._get_client()
        
        if action == "get_status":
            if client.is_connected:
                return f"Connected to Windows bridge at {client.host}:{client.port}"
            return "Not connected to Windows bridge"
        
        if not client.is_connected:
            if not await client.connect(send_identify=True):
                return "Failed to connect to Windows bridge. Is FTK_Claw_Bot running?"
        
        ipc_action = f"web_{action}"
        result = await client.send_request(ipc_action, params)
        return self._format_result(result, action, params)
    
    def _format_result(self, result: dict | None, action: str, params: dict) -> str:
        if result is None:
            return f"No response from Windows bridge for action: {action}"
        
        if isinstance(result, dict):
            if result.get("success") == False:
                error = result.get("error", result.get("message", "Unknown error"))
                return f"Action {action} failed: {error}"
            
            if action == "navigate":
                return f"Navigated to: {result.get('url', params.get('url', 'unknown'))}"
            elif action == "screenshot":
                if result.get("data"):
                    return self._save_screenshot(result["data"])
                return "Screenshot captured but no data returned"
            elif action == "extract_elements":
                elements = result.get("elements", [])
                summary = result.get("summary", {})
                return f"Extracted {summary.get('total', len(elements))} elements ({summary.get('interactive', 0)} interactive)"
            elif action == "get_url":
                return f"Current URL: {result.get('url', 'unknown')}"
            elif action == "get_title":
                return f"Page title: {result.get('title', 'unknown')}"
            elif action == "get_content":
                content = result.get("content", "")
                return f"Page content ({len(content)} chars): {content[:500]}..."
            elif action == "get_cookies":
                cookies = result.get("cookies", [])
                return f"Got {len(cookies)} cookies"
            elif action in ("start", "stop"):
                return f"Browser {action}ed: {result.get('success', False)}"
            else:
                return f"Action {action} completed: {json.dumps(result, ensure_ascii=False)[:200]}"
        
        return f"Action {action} result: {result}"
    
    def _save_screenshot(self, base64_data: str) -> str:
        import tempfile
        img_data = base64.b64decode(base64_data)
        temp_dir = tempfile.gettempdir()
        filepath = os.path.join(temp_dir, f"web_screenshot_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png")
        with open(filepath, "wb") as f:
            f.write(img_data)
        return f"Screenshot saved to: {filepath}"
