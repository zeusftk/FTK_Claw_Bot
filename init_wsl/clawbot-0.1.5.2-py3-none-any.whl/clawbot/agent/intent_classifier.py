"""
Intent Classifier - 意图分类器

对用户消息进行意图分类，使用 TaskCategory 与 UnifiedTaskRouter 保持一致。

TaskCategory 分类：
- CONVERSATION: 纯对话，LLM 直接响应
- OPENWORK_EXECUTION: 需要 OpenWork 执行
- LOCAL_TOOL: 本地工具快速执行
- SYSTEM_COMMAND: 系统命令
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from loguru import logger

from clawbot.core.routing_constants import (
    EXECUTION_THRESHOLD,
    CONVERSATION_THRESHOLD,
    RoutingHelper,
    TaskCategory,
)


@dataclass
class IntentResult:
    """意图分类结果"""
    category: TaskCategory
    confidence: float = 1.0
    task_type: str | None = None
    reasoning: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)
    
    @property
    def intent(self) -> TaskCategory:
        """向后兼容：返回 category"""
        return self.category
    
    @property
    def should_route_to_openwork(self) -> bool:
        """判断是否应该路由到 OpenWork"""
        return self.category == TaskCategory.OPENWORK_EXECUTION


class IntentClassifier:
    """
    意图分类器
    
    使用 TaskCategory 分类，与 UnifiedTaskRouter 保持一致。
    共享常量和辅助方法来自 routing_constants 模块。
    
    功能：
    1. 分析用户消息意图
    2. 判断是否需要路由到 OpenWork
    3. 识别任务类型
    """
    
    # 阈值常量 - 从共享模块导入
    EXECUTION_THRESHOLD = EXECUTION_THRESHOLD
    CONVERSATION_THRESHOLD = CONVERSATION_THRESHOLD
    
    def __init__(
        self,
        openwork_enabled: bool = True,
        execution_threshold: float | None = None,
        conversation_threshold: float | None = None,
    ):
        self.openwork_enabled = openwork_enabled
        self.execution_threshold = execution_threshold or self.EXECUTION_THRESHOLD
        self.conversation_threshold = conversation_threshold or self.CONVERSATION_THRESHOLD
        
        self._stats = {
            "total_classified": 0,
            "by_category": {cat.value: 0 for cat in TaskCategory},
        }
    
    def classify(self, message: str, context: dict[str, Any] | None = None) -> IntentResult:
        """
        分类用户消息意图
        
        Args:
            message: 用户消息
            context: 额外上下文（channel, sender_id 等）
            
        Returns:
            IntentResult 分类结果
        """
        self._stats["total_classified"] += 1
        
        message_lower = message.lower().strip()
        
        if not message_lower:
            result = IntentResult(
                category=TaskCategory.CONVERSATION,
                confidence=0.0,
                reasoning="Empty message",
            )
            self._stats["by_category"][result.category.value] += 1
            return result
        
        # 使用共享的辅助方法
        if RoutingHelper.is_system_command(message_lower):
            result = IntentResult(
                category=TaskCategory.SYSTEM_COMMAND,
                confidence=1.0,
                reasoning="System command detected",
            )
            self._stats["by_category"][result.category.value] += 1
            return result
        
        execution_score = self._calculate_execution_score(message_lower)
        conversation_score = self._calculate_conversation_score(message_lower)
        
        if execution_score > self.execution_threshold:
            task_type = RoutingHelper.detect_task_type(message_lower)
            category = TaskCategory.OPENWORK_EXECUTION if self.openwork_enabled else TaskCategory.LOCAL_TOOL
            result = IntentResult(
                category=category,
                confidence=min(execution_score, 1.0),
                task_type=task_type,
                reasoning=f"Execution task detected (score: {execution_score:.2f}, type: {task_type})",
            )
        elif conversation_score > self.conversation_threshold:
            result = IntentResult(
                category=TaskCategory.CONVERSATION,
                confidence=min(conversation_score, 1.0),
                reasoning=f"Conversation detected (score: {conversation_score:.2f})",
            )
        else:
            result = IntentResult(
                category=TaskCategory.LOCAL_TOOL,
                confidence=0.5,
                reasoning=f"Default routing (exec: {execution_score:.2f}, conv: {conversation_score:.2f})",
            )
        
        self._stats["by_category"][result.category.value] += 1
        return result
    
    def _calculate_execution_score(self, message: str) -> float:
        """计算执行意图分数 - 使用共享方法"""
        return RoutingHelper.calculate_execution_score(message, include_code_patterns=True)
    
    def _calculate_conversation_score(self, message: str) -> float:
        """计算对话意图分数 - 使用共享方法"""
        return RoutingHelper.calculate_conversation_score(message, include_question_patterns=True)
    
    def get_stats(self) -> dict[str, Any]:
        """获取统计信息"""
        return {
            **self._stats,
            "openwork_enabled": self.openwork_enabled,
            "execution_threshold": self.execution_threshold,
            "conversation_threshold": self.conversation_threshold,
        }
    
    def update_thresholds(
        self,
        execution: float | None = None,
        conversation: float | None = None,
    ) -> None:
        """更新阈值"""
        if execution is not None:
            self.execution_threshold = execution
        if conversation is not None:
            self.conversation_threshold = conversation
        logger.info(
            f"IntentClassifier thresholds updated: execution={self.execution_threshold}, "
            f"conversation={self.conversation_threshold}"
        )


IntentType = TaskCategory