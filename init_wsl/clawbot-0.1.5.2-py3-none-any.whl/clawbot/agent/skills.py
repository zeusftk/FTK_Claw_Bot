"""Skills loader for agent capabilities."""

import json
import os
import re
import shutil
from pathlib import Path

# Default builtin skills directory (relative to this file)
BUILTIN_SKILLS_DIR = Path(__file__).parent.parent / "skills"

# Default priority for skills
DEFAULT_PRIORITY = 1


class SkillsLoader:
    """
    Loader for agent skills.
    
    Skills are markdown files (SKILL.md) that teach the agent how to use
    specific tools or perform certain tasks.
    
    Skills can have priorities configured in config.json:
    {
        "skills": {
            "enabled": ["github", "weather"],
            "priorities": {"github": 5, "weather": 2}
        }
    }
    Higher priority values mean the skill should be executed first.
    """
    
    def __init__(self, workspace: Path, builtin_skills_dir: Path | None = None, config: dict | None = None):
        self.workspace = workspace
        self.workspace_skills = workspace / "skills"
        self.builtin_skills = builtin_skills_dir or BUILTIN_SKILLS_DIR
        self._config = config or {}
        self._skill_priorities = self._config.get("skills", {}).get("priorities", {})
        self._enabled_skills = self._config.get("skills", {}).get("enabled", None)
    
    def get_skill_priority(self, skill_name: str) -> int:
        """Get priority for a skill. Higher values = higher priority."""
        return self._skill_priorities.get(skill_name, DEFAULT_PRIORITY)
    
    def list_skills(self, filter_unavailable: bool = True, sort_by_priority: bool = True) -> list[dict[str, str]]:
        """
        List all available skills.
        
        Args:
            filter_unavailable: If True, filter out skills with unmet requirements.
            sort_by_priority: If True, sort by priority (highest first).
        
        Returns:
            List of skill info dicts with 'name', 'path', 'source', 'priority'.
        """
        skills = []
        
        # Workspace skills (highest priority location, but priority value is configurable)
        if self.workspace_skills.exists():
            for skill_dir in self.workspace_skills.iterdir():
                if skill_dir.is_dir():
                    skill_file = skill_dir / "SKILL.md"
                    if skill_file.exists():
                        skills.append({
                            "name": skill_dir.name, 
                            "path": str(skill_file), 
                            "source": "workspace",
                            "priority": self.get_skill_priority(skill_dir.name)
                        })
        
        # Built-in skills
        if self.builtin_skills and self.builtin_skills.exists():
            for skill_dir in self.builtin_skills.iterdir():
                if skill_dir.is_dir():
                    skill_file = skill_dir / "SKILL.md"
                    if skill_file.exists() and not any(s["name"] == skill_dir.name for s in skills):
                        skills.append({
                            "name": skill_dir.name, 
                            "path": str(skill_file), 
                            "source": "builtin",
                            "priority": self.get_skill_priority(skill_dir.name)
                        })
        
        # Filter by enabled list if configured
        if self._enabled_skills is not None:
            skills = [s for s in skills if s["name"] in self._enabled_skills]
        
        # Filter by requirements
        if filter_unavailable:
            skills = [s for s in skills if self._check_requirements(self._get_skill_meta(s["name"]))]
        
        # Sort by priority (highest first)
        if sort_by_priority:
            skills.sort(key=lambda s: s.get("priority", DEFAULT_PRIORITY), reverse=True)
        
        return skills
    
    def load_skill(self, name: str) -> str | None:
        """
        Load a skill by name.
        
        Args:
            name: Skill name (directory name).
        
        Returns:
            Skill content or None if not found.
        """
        # Check workspace first
        workspace_skill = self.workspace_skills / name / "SKILL.md"
        if workspace_skill.exists():
            return workspace_skill.read_text(encoding="utf-8")
        
        # Check built-in
        if self.builtin_skills:
            builtin_skill = self.builtin_skills / name / "SKILL.md"
            if builtin_skill.exists():
                return builtin_skill.read_text(encoding="utf-8")
        
        return None
    
    def load_skills_for_context(self, skill_names: list[str], sort_by_priority: bool = True) -> str:
        """
        Load specific skills for inclusion in agent context.
        
        Args:
            skill_names: List of skill names to load.
            sort_by_priority: If True, sort by priority (highest first).
        
        Returns:
            Formatted skills content.
        """
        # Sort by priority if requested
        if sort_by_priority:
            skill_names = sorted(skill_names, key=lambda n: self.get_skill_priority(n), reverse=True)
        
        parts = []
        for name in skill_names:
            content = self.load_skill(name)
            if content:
                content = self._strip_frontmatter(content)
                priority = self.get_skill_priority(name)
                priority_hint = f" (priority: {priority})" if priority != DEFAULT_PRIORITY else ""
                parts.append(f"### Skill: {name}{priority_hint}\n\n{content}")
        
        return "\n\n---\n\n".join(parts) if parts else ""
    
    def build_skills_summary(self) -> str:
        """
        Build a summary of all skills (name, description, path, availability, priority).
        
        This is used for progressive loading - the agent can read the full
        skill content using read_file when needed.
        
        Returns:
            XML-formatted skills summary.
        """
        all_skills = self.list_skills(filter_unavailable=False, sort_by_priority=True)
        if not all_skills:
            return ""
        
        def escape_xml(s: str) -> str:
            return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        
        lines = ["<skills>"]
        # 添加优先级说明
        lines.append("  <!-- Skills are sorted by priority (highest first). Higher priority skills should be considered/loaded first. -->")
        lines.append("  <!-- Priority range: 1-1000. Default is 1. Skills with higher priority values are more important. -->")
        
        for s in all_skills:
            name = escape_xml(s["name"])
            path = s["path"]
            priority = s.get("priority", DEFAULT_PRIORITY)
            desc = escape_xml(self._get_skill_description(s["name"]))
            skill_meta = self._get_skill_meta(s["name"])
            available = self._check_requirements(skill_meta)
            
            lines.append(f"  <skill available=\"{str(available).lower()}\" priority=\"{priority}\">")
            lines.append(f"    <name>{name}</name>")
            lines.append(f"    <description>{desc}</description>")
            lines.append(f"    <location>{path}</location>")
            
            # Show missing requirements for unavailable skills
            if not available:
                missing = self._get_missing_requirements(skill_meta)
                if missing:
                    lines.append(f"    <requires>{escape_xml(missing)}</requires>")
            
            lines.append(f"  </skill>")
        lines.append("</skills>")
        
        return "\n".join(lines)
    
    def _get_missing_requirements(self, skill_meta: dict) -> str:
        """Get a description of missing requirements."""
        missing = []
        requires = skill_meta.get("requires", {})
        for b in requires.get("bins", []):
            if not shutil.which(b):
                missing.append(f"CLI: {b}")
        for env in requires.get("env", []):
            if not os.environ.get(env):
                missing.append(f"ENV: {env}")
        return ", ".join(missing)
    
    def _get_skill_description(self, name: str) -> str:
        """Get the description of a skill from its frontmatter."""
        meta = self.get_skill_metadata(name)
        if meta and meta.get("description"):
            return meta["description"]
        return name
    
    def _get_skill_meta(self, name: str) -> dict:
        """Get clawbot metadata for a skill (from frontmatter)."""
        meta = self.get_skill_metadata(name)
        if not meta:
            return {}
        metadata_str = meta.get("metadata", "")
        return self._parse_clawbot_metadata(metadata_str) if metadata_str else {}
    
    def _strip_frontmatter(self, content: str) -> str:
        """Remove YAML frontmatter from markdown content."""
        if content.startswith("---"):
            match = re.match(r"^---\n.*?\n---\n", content, re.DOTALL)
            if match:
                return content[match.end():].strip()
        return content
    
    def _parse_clawbot_metadata(self, raw: str) -> dict:
        """Parse skill metadata JSON from frontmatter (supports clawbot and openclaw keys)."""
        try:
            data = json.loads(raw)
            return data.get("clawbot", data.get("openclaw", {})) if isinstance(data, dict) else {}
        except (json.JSONDecodeError, TypeError):
            return {}
    
    def _check_requirements(self, skill_meta: dict) -> bool:
        """Check if skill requirements are met (bins, env vars)."""
        requires = skill_meta.get("requires", {})
        for b in requires.get("bins", []):
            if not shutil.which(b):
                return False
        for env in requires.get("env", []):
            if not os.environ.get(env):
                return False
        return True
    
    def get_always_skills(self) -> list[str]:
        """Get skills marked as always=true that meet requirements, sorted by priority."""
        result = []
        for s in self.list_skills(filter_unavailable=True, sort_by_priority=False):
            meta = self.get_skill_metadata(s["name"])
            if not meta:
                continue
            skill_meta = self._get_skill_meta(s["name"])
            if skill_meta.get("always") or meta.get("always"):
                result.append(s["name"])
        
        # Sort by priority (highest first)
        result.sort(key=lambda n: self.get_skill_priority(n), reverse=True)
        return result
    
    def get_skill_metadata(self, name: str) -> dict | None:
        """
        Get metadata from a skill's frontmatter.
        
        Args:
            name: Skill name.
        
        Returns:
            Metadata dict or None.
        """
        content = self.load_skill(name)
        if not content:
            return None
        
        if content.startswith("---"):
            match = re.match(r"^---\n(.*?)\n---", content, re.DOTALL)
            if match:
                # Simple YAML parsing
                metadata = {}
                for line in match.group(1).split("\n"):
                    if ":" in line:
                        key, value = line.split(":", 1)
                        metadata[key.strip()] = value.strip().strip('"\'')
                return metadata
        
        return None
