"""
clawbot 服务模块

提供通用的服务管理工具，用于管理外部 CLI 服务的生命周期。

核心组件:
- BaseExternalService: 外部服务抽象基类（标准化接入接口）
- OpenWorkService: OpenWork 服务封装（唯一后端）
- OpenWorkServiceManager: OpenWork 服务管理器（生命周期管理）
- UnattendedProgrammingService: 无人值守编程服务（记忆、进化）
- ServiceRunner: 外部进程服务运行器
- HealthChecker: 健康检查工具
- ServiceStatus: 服务状态枚举
- ServiceCapabilities: 服务能力声明
- ServiceHealth: 服务健康状态

使用示例:
    from clawbot.services import OpenWorkService, UnattendedProgrammingService

    openwork = OpenWorkService(base_url="http://localhost:7777")
    service = UnattendedProgrammingService(
        openwork=openwork,
        workspace=Path("/path/to/workspace"),
    )
    
    await service.start()
    result = await service.execute("Generate hello world")
    print(result.output)
"""

from .base import (
    BaseExternalService,
    ServiceCapabilities,
    ServiceHealth,
    ServiceStatus,
)
from .health import HealthChecker
from .openwork_service import OpenWorkService
from .openwork_manager import (
    OpenWorkServiceManager,
    ServiceStats,
    check_openwork_available,
)
from .runner import ServiceRunner
from .unattended_programming import ExecutionResult, UnattendedProgrammingService

__all__ = [
    "BaseExternalService",
    "OpenWorkService",
    "OpenWorkServiceManager",
    "UnattendedProgrammingService",
    "ExecutionResult",
    "ServiceCapabilities",
    "ServiceHealth",
    "ServiceStats",
    "ServiceStatus",
    "ServiceRunner",
    "HealthChecker",
    "check_openwork_available",
]
