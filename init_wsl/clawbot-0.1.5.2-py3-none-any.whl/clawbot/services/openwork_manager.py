"""
OpenWork Service Manager - OpenWork 服务管理器

职责：
1. 服务生命周期管理
2. 自动启动/重启
3. 健康检查
4. 状态监控

使用内置的 clawbot.openwork_server 模块启动服务。
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

import aiohttp
from loguru import logger

from .base import ServiceHealth, ServiceStatus


@dataclass
class ServiceStats:
    """服务统计"""
    status: ServiceStatus
    uptime_seconds: float = 0.0
    total_requests: int = 0
    successful_requests: int = 0
    failed_requests: int = 0
    last_error: str | None = None
    restart_count: int = 0


class OpenWorkServiceManager:
    """
    OpenWork 服务管理器
    
    使用内置的 clawbot.openwork_server 模块启动 HTTP API 服务。
    
    职责：
    1. 服务生命周期管理
    2. 自动启动/重启
    3. 健康检查
    4. 状态监控
    
    可被 Guardian 服务监控和自动恢复。
    """
    
    DEFAULT_PORT = 7777
    DEFAULT_HOST = "127.0.0.1"
    DEFAULT_TIMEOUT = 30
    HEALTH_CHECK_INTERVAL = 10

    def __init__(
        self,
        port: int = DEFAULT_PORT,
        host: str = DEFAULT_HOST,
        workspace: Path | None = None,
        auto_start: bool = True,
        auto_restart: bool = True,
        approval_mode: str = "auto",
        startup_timeout: int = DEFAULT_TIMEOUT,
        fallback_to_local: bool = True,
    ):
        self.port = port
        self.host = host
        self.workspace = workspace
        self.auto_start = auto_start
        self.auto_restart = auto_restart
        self.approval_mode = approval_mode
        self.startup_timeout = startup_timeout
        self.fallback_to_local = fallback_to_local

        self._base_url = f"http://{host}:{port}"
        self._status = ServiceStatus.STOPPED
        self._health_check_task: asyncio.Task | None = None
        self._session: aiohttp.ClientSession | None = None
        self._started_at: datetime | None = None
        self._stats = ServiceStats(status=ServiceStatus.STOPPED)
        self._server: Any = None
        self._server_task: asyncio.Task | None = None
        self._runner: Any = None
    
    @property
    def status(self) -> ServiceStatus:
        """获取当前状态"""
        return self._status
    
    @property
    def base_url(self) -> str:
        """获取服务 URL"""
        return self._base_url
    
    @property
    def is_running(self) -> bool:
        """检查是否运行中 - 供 Guardian 使用"""
        return self._status == ServiceStatus.RUNNING
    
    def _is_installed(self) -> bool:
        """检查内置模块是否可用"""
        try:
            from clawbot.openwork_server import create_app
            return True
        except ImportError:
            return False
    
    async def start(self) -> bool:
        """启动 OpenWork 服务"""
        if self._status == ServiceStatus.RUNNING:
            health = await self.health_check()
            if health.healthy:
                return True
        
        if not self._is_installed():
            logger.warning("OpenWork server module not available")
            self._status = ServiceStatus.NOT_INSTALLED
            self._stats.status = ServiceStatus.NOT_INSTALLED
            return False
        
        logger.info(f"Starting OpenWork service at {self._base_url}")
        self._status = ServiceStatus.STARTING
        self._stats.status = ServiceStatus.STARTING
        
        try:
            from clawbot.openwork_server import (
                create_app,
                resolve_server_config,
                CliArgs,
                run_server,
            )
            from clawbot.openwork_server.types import ApprovalMode
            
            workspaces = [str(self.workspace)] if self.workspace else []
            
            approval_mode = ApprovalMode.AUTO
            if self.approval_mode == "manual":
                approval_mode = ApprovalMode.MANUAL
            
            cli_args = CliArgs(
                host=self.host,
                port=self.port,
                approval_mode=approval_mode,
                workspaces=workspaces,
            )
            
            config = await resolve_server_config(cli_args)
            self._server = create_app(config)
            
            self._server_task = asyncio.create_task(run_server(self._server))
            
            ready = await self._wait_for_ready()
            
            if ready:
                self._status = ServiceStatus.RUNNING
                self._stats.status = ServiceStatus.RUNNING
                self._started_at = datetime.now()
                self._start_health_monitor()
                logger.info(f"OpenWork service started successfully at {self._base_url}")
                return True
            else:
                self._status = ServiceStatus.ERROR
                self._stats.status = ServiceStatus.ERROR
                self._stats.last_error = "Service failed to start within timeout"
                logger.error("OpenWork service failed to start within timeout")
                return False
                
        except Exception as e:
            logger.error(f"Failed to start OpenWork service: {e}")
            self._status = ServiceStatus.ERROR
            self._stats.status = ServiceStatus.ERROR
            self._stats.last_error = str(e)
            return False
    
    async def stop(self) -> None:
        """停止服务"""
        if self._status == ServiceStatus.STOPPED:
            return
        
        logger.info("Stopping OpenWork service...")
        self._status = ServiceStatus.STOPPING
        self._stats.status = ServiceStatus.STOPPING
        
        if self._health_check_task:
            self._health_check_task.cancel()
            try:
                await self._health_check_task
            except asyncio.CancelledError:
                pass
            self._health_check_task = None
        
        if self._server_task:
            self._server_task.cancel()
            try:
                await self._server_task
            except asyncio.CancelledError:
                pass
            self._server_task = None
        
        if self._session:
            await self._session.close()
            self._session = None
        
        self._server = None
        self._status = ServiceStatus.STOPPED
        self._stats.status = ServiceStatus.STOPPED
        self._started_at = None
        logger.info("OpenWork service stopped")
    
    def stop_sync(self) -> None:
        """同步停止服务 - 供 Guardian 调用"""
        if self._status == ServiceStatus.STOPPED:
            return
        
        logger.info("Stopping OpenWork service (sync)...")
        self._status = ServiceStatus.STOPPING
        self._stats.status = ServiceStatus.STOPPING
        
        if self._health_check_task:
            self._health_check_task.cancel()
            self._health_check_task = None
        
        if self._server_task:
            self._server_task.cancel()
            self._server_task = None
        
        self._server = None
        self._status = ServiceStatus.STOPPED
        self._stats.status = ServiceStatus.STOPPED
        self._started_at = None
        logger.info("OpenWork service stopped (sync)")
    
    async def restart(self) -> bool:
        """重启服务"""
        await self.stop()
        self._stats.restart_count += 1
        return await self.start()
    
    async def health_check(self) -> ServiceHealth:
        """健康检查"""
        start_time = time.monotonic()
        
        try:
            async with self._get_session() as session:
                async with session.get(
                    f"{self._base_url}/health",
                    timeout=aiohttp.ClientTimeout(total=5),
                ) as resp:
                    latency = (time.monotonic() - start_time) * 1000
                    healthy = resp.status == 200
                    
                    return ServiceHealth(
                        healthy=healthy,
                        status=ServiceStatus.RUNNING if healthy else ServiceStatus.ERROR,
                        latency_ms=latency,
                        last_check=datetime.now(),
                    )
        except Exception as e:
            return ServiceHealth(
                healthy=False,
                status=ServiceStatus.ERROR,
                latency_ms=(time.monotonic() - start_time) * 1000,
                last_check=datetime.now(),
                error_message=str(e),
            )
    
    async def is_healthy(self) -> bool:
        """检查是否健康"""
        health = await self.health_check()
        return health.healthy
    
    async def ensure_running(self) -> bool:
        """确保服务运行"""
        if self._status == ServiceStatus.RUNNING:
            if await self.is_healthy():
                return True
        
        if self.auto_start:
            return await self.start()
        
        return False
    
    async def execute(
        self,
        task: str,
        task_type: str | None = None,
        workspace: Path | str | None = None,
        timeout: int = 300,
    ) -> dict[str, Any]:
        """
        通过 OpenWork 服务执行任务
        
        Args:
            task: 任务描述
            task_type: 任务类型 (programming, configuration, search, debugging, installation)
            workspace: 工作空间路径
            timeout: 超时时间（秒）
            
        Returns:
            执行结果字典，包含 success, output, error 等字段
        """
        if not await self.ensure_running():
            return {
                "success": False,
                "error": "OpenWork service is not available",
            }
        
        try:
            # 使用 /tasks API 提交任务
            url = f"{self._base_url}/tasks"
            payload = {
                "task": task,
                "task_type": task_type,
                "workspace": str(workspace) if workspace else None,
                "timeout": timeout,
            }
            
            async with self._get_session() as session:
                async with session.post(
                    url,
                    json=payload,
                    timeout=aiohttp.ClientTimeout(total=timeout + 10),
                ) as resp:
                    if resp.status == 200:
                        result = await resp.json()
                        return {
                            "success": True,
                            "output": result.get("output", ""),
                            "task_id": result.get("task_id"),
                            "data": result,
                        }
                    else:
                        text = await resp.text()
                        return {
                            "success": False,
                            "error": f"Task execution failed: {resp.status} - {text}",
                        }
                        
        except asyncio.TimeoutError:
            return {
                "success": False,
                "error": f"Task execution timed out after {timeout} seconds",
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }
    
    def get_stats(self) -> ServiceStats:
        """获取服务统计"""
        if self._started_at and self._status == ServiceStatus.RUNNING:
            self._stats.uptime_seconds = (datetime.now() - self._started_at).total_seconds()
        return self._stats
    
    def get_status_info(self) -> dict[str, Any]:
        """获取状态信息"""
        return {
            "status": self._status.value,
            "base_url": self._base_url,
            "host": self.host,
            "port": self.port,
            "workspace": str(self.workspace) if self.workspace else None,
            "auto_start": self.auto_start,
            "auto_restart": self.auto_restart,
            "is_installed": self._is_installed(),
            "uptime_seconds": self._stats.uptime_seconds,
            "restart_count": self._stats.restart_count,
        }
    
    async def _wait_for_ready(self, timeout: int | None = None) -> bool:
        """等待服务就绪"""
        timeout = timeout or self.startup_timeout
        
        for _ in range(timeout * 2):
            await asyncio.sleep(0.5)
            try:
                async with self._get_session() as session:
                    async with session.get(
                        f"{self._base_url}/health",
                        timeout=aiohttp.ClientTimeout(total=2),
                    ) as resp:
                        if resp.status == 200:
                            return True
            except Exception:
                pass
        
        return False
    
    def _get_session(self) -> aiohttp.ClientSession:
        """获取或创建 HTTP session"""
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession()
        return self._session
    
    def _start_health_monitor(self):
        """启动健康监控"""
        async def monitor():
            consecutive_failures = 0
            max_failures = 3
            
            while self._status == ServiceStatus.RUNNING:
                await asyncio.sleep(self.HEALTH_CHECK_INTERVAL)
                
                health = await self.health_check()
                if not health.healthy:
                    consecutive_failures += 1
                    logger.warning(
                        f"OpenWork service unhealthy (attempt {consecutive_failures}/{max_failures}): "
                        f"{health.error_message}"
                    )
                    
                    if consecutive_failures >= max_failures and self.auto_restart:
                        logger.info("Attempting to restart OpenWork service...")
                        await self.restart()
                        consecutive_failures = 0
                else:
                    consecutive_failures = 0
        
        self._health_check_task = asyncio.create_task(monitor())


async def check_openwork_available(port: int = 7777, host: str = "127.0.0.1") -> bool:
    """检查 OpenWork 服务是否可用"""
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                f"http://{host}:{port}/health",
                timeout=aiohttp.ClientTimeout(total=5),
            ) as resp:
                return resp.status == 200
    except Exception:
        return False
