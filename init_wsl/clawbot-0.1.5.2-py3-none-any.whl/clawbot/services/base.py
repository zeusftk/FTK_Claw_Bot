"""
BaseExternalService - 外部服务抽象基类

提供标准化的服务接入接口，支持：
- 生命周期管理（ensure, start, stop）
- 健康检查
- 能力声明
- 代码执行
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Any, Callable


class ServiceStatus(Enum):
    """服务状态枚举"""
    STOPPED = "stopped"
    STARTING = "starting"
    RUNNING = "running"
    STOPPING = "stopping"
    ERROR = "error"
    NOT_INSTALLED = "not_installed"


@dataclass
class ServiceCapabilities:
    """服务能力声明"""
    code_execution: bool = False
    file_management: bool = False
    skill_management: bool = False
    plugin_management: bool = False
    mcp_support: bool = False
    scheduling: bool = False
    multi_tenant: bool = False
    memory_integration: bool = False
    self_evolution: bool = False


@dataclass
class ServiceHealth:
    """服务健康状态"""
    healthy: bool
    status: ServiceStatus
    latency_ms: float = 0.0
    last_check: datetime | None = None
    error_message: str | None = None
    details: dict[str, Any] | None = None


class BaseExternalService(ABC):
    """
    外部服务抽象基类
    
    所有外部服务（OpenWork、OpenCode、MCP 等）必须实现此接口。
    提供标准化的服务接入方式：
    1. 生命周期管理：ensure(), start(), stop()
    2. 健康检查：health_check()
    3. 能力声明：_detect_capabilities(), supports()
    4. 代码执行：execute_code()
    
    Example:
        class MyService(BaseExternalService):
            def _detect_capabilities(self) -> ServiceCapabilities:
                return ServiceCapabilities(code_execution=True)
            
            async def ensure(self) -> bool:
                # 实现确保服务可用逻辑
                pass
            
            # ... 其他抽象方法实现
    """

    def __init__(
        self,
        name: str,
        config: dict[str, Any],
        on_status_change: Callable[[ServiceStatus], None] | None = None,
    ):
        self.name = name
        self.config = config
        self._on_status_change = on_status_change
        self._status = ServiceStatus.STOPPED
        self._capabilities = self._detect_capabilities()

    @property
    def status(self) -> ServiceStatus:
        """获取当前状态"""
        return self._status

    @status.setter
    def status(self, value: ServiceStatus):
        """设置状态并触发回调"""
        old_status = self._status
        self._status = value
        if old_status != value and self._on_status_change:
            self._on_status_change(value)

    @property
    def capabilities(self) -> ServiceCapabilities:
        """获取服务能力"""
        return self._capabilities

    # ========== 生命周期管理（必须实现） ==========

    @abstractmethod
    async def ensure(self) -> bool:
        """
        确保服务可用，如未运行则尝试启动
        
        Returns:
            True if service is available
        """
        pass

    @abstractmethod
    async def start(self) -> bool:
        """
        启动服务
        
        Returns:
            True if service started successfully
        """
        pass

    @abstractmethod
    async def stop(self) -> None:
        """停止服务"""
        pass

    @abstractmethod
    async def health_check(self) -> ServiceHealth:
        """
        执行健康检查
        
        Returns:
            ServiceHealth with check results
        """
        pass

    # ========== 能力检测（必须实现）==========

    @abstractmethod
    def _detect_capabilities(self) -> ServiceCapabilities:
        """
        检测服务支持的能力
        
        Returns:
            ServiceCapabilities describing what this service supports
        """
        pass

    def supports(self, capability: str) -> bool:
        """
        检查是否支持特定能力
        
        Args:
            capability: 能力名称（如 'code_execution', 'skill_management'）
        
        Returns:
            True if capability is supported
        """
        return getattr(self._capabilities, capability, False)

    # ========== 代码执行（可选） ==========

    async def execute_code(
        self,
        task: str,
        workspace: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        执行代码任务（如果服务支持）
        
        Args:
            task: 任务描述
            workspace: 工作空间路径
            context: 额外上下文
        
        Returns:
            执行结果字典
            
        Raises:
            NotImplementedError: if code_execution is not supported
        """
        if not self.supports("code_execution"):
            raise NotImplementedError(f"{self.name} does not support code execution")
        return await self._execute_code_impl(task, workspace, context)

    @abstractmethod
    async def _execute_code_impl(
        self,
        task: str,
        workspace: str | None,
        context: dict[str, Any] | None,
    ) -> dict[str, Any]:
        """
        代码执行的具体实现
        
        Args:
            task: 任务描述
            workspace: 工作空间路径
            context: 额外上下文
        
        Returns:
            执行结果字典
        """
        pass

    # ========== 技能管理（可选） ==========

    async def list_skills(self) -> list[dict[str, Any]]:
        """
        列出技能（如果服务支持）
        
        Returns:
            技能列表
            
        Raises:
            NotImplementedError: if skill_management is not supported
        """
        if not self.supports("skill_management"):
            raise NotImplementedError(f"{self.name} does not support skill management")
        return await self._list_skills_impl()

    @abstractmethod
    async def _list_skills_impl(self) -> list[dict[str, Any]]:
        """技能列表的具体实现"""
        pass

    async def install_skill(self, name: str, source: str | None = None) -> bool:
        """
        安装技能（如果服务支持）
        
        Args:
            name: 技能名称
            source: 技能来源（如 'hub:skill-name'）
        
        Returns:
            True if installation succeeded
        """
        if not self.supports("skill_management"):
            raise NotImplementedError(f"{self.name} does not support skill management")
        return await self._install_skill_impl(name, source)

    @abstractmethod
    async def _install_skill_impl(self, name: str, source: str | None) -> bool:
        """安装技能的具体实现"""
        pass

    # ========== 状态获取（必须实现）==========

    @abstractmethod
    def get_status(self) -> dict[str, Any]:
        """
        获取服务状态信息
        
        Returns:
            状态字典，包含 name, status, capabilities 等
        """
        pass
