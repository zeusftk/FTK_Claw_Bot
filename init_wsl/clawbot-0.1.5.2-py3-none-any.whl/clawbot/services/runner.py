"""外部进程服务运行器"""

import asyncio
from loguru import logger
import shutil
import subprocess
from pathlib import Path
from typing import Any, Callable

import aiohttp



class ServiceRunner:
    """外部进程服务运行器
    
    用于管理外部 CLI 服务的生命周期，支持自动启动、健康检查和优雅停止。
    
    Attributes:
        name: 服务名称
        command: 启动命令列表
        workspace: 工作空间目录
        health_check_url: 健康检查 URL
        port: 服务端口
        on_ready: 服务就绪回调
        on_stop: 服务停止回调

    Example:
        runner = ServiceRunner(
            name="openwork",
            command=["openwork", "start", "--port", "7777"],
            workspace=Path("/workspace/openworks"),
            health_check_url="http://localhost:7777",
            port=7777,
        )

        # 确保服务运行（检查状态，如未运行则启动）
        if await runner.ensure():
            print("Service is ready")

        # 获取状态
        status = runner.get_status()

        # 停止服务
        await runner.stop()
    """

    def __init__(
        self,
        name: str,
        command: list[str],
        workspace: Path,
        health_check_url: str | None = None,
        port: int | None = None,
        on_ready: Callable[[], None] | None = None,
        on_stop: Callable[[], None] | None = None,
    ):
        self.name = name
        self.command = command
        self.workspace = workspace
        self.health_check_url = health_check_url
        self.port = port
        self.on_ready = on_ready
        self.on_stop = on_stop

        self._process: subprocess.Popen | None = None
        self._running = False
        self._start_time: float | None = None

    @staticmethod
    def is_installed(command: str) -> bool:
        """检查命令是否可用
        
        Args:
            command: 命令名称

        Returns:
            True if command is available in PATH
        """
        return shutil.which(command) is not None

    async def ensure(self) -> bool:
        """确保服务运行，如未运行则启动

        Returns:
            True if service is running or successfully started
        """
        if self._running:
            return True

        if self.health_check_url:
            if await self._check_health():
                self._running = True
                return True

        return await self.start()

    async def start(self) -> bool:
        """启动服务

        Returns:
            True if service started successfully
        """
        self.workspace.mkdir(parents=True, exist_ok=True)

        try:
            logger.info(f"Starting service '{self.name}': {' '.join(self.command)}")

            self._process = subprocess.Popen(
                self.command,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
                cwd=str(self.workspace),
            )

            if self.health_check_url:
                for i in range(60):
                    await asyncio.sleep(0.5)
                    if await self._check_health():
                        self._running = True
                        self._start_time = asyncio.get_running_loop().time()
                        logger.info(f"Service '{self.name}' is ready")
                        if self.on_ready:
                            self.on_ready()
                        return True

                logger.error(f"Service '{self.name}' failed to become ready within timeout")
                await self.stop()
                return False

            self._running = True
            self._start_time = asyncio.get_running_loop().time()
            logger.info(f"Service '{self.name}' started (no health check)")
            if self.on_ready:
                self.on_ready()
            return True

        except Exception as e:
            logger.error(f"Failed to start service '{self.name}': {e}")
            return False

    async def stop(self) -> None:
        """停止服务"""
        if not self._running and not self._process:
            return

        logger.info(f"Stopping service '{self.name}'...")

        if self._process:
            self._process.terminate()
            try:
                self._process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                logger.warning(f"Service '{self.name}' did not stop gracefully, killing...")
                self._process.kill()
                self._process.wait()
            self._process = None

        self._running = False
        self._start_time = None
        logger.info(f"Service '{self.name}' stopped")

        if self.on_stop:
            self.on_stop()

    async def _check_health(self) -> bool:
        """健康检查
        
        Returns:
            True if service is healthy
        """
        if not self.health_check_url:
            return True

        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    f"{self.health_check_url}/health",
                    timeout=aiohttp.ClientTimeout(total=5)
                ) as resp:
                    return resp.status == 200
        except Exception:
            return False

    def get_status(self) -> dict[str, Any]:
        """获取服务状态
        
        Returns:
            Dictionary with service status information
        """
        uptime = None
        if self._start_time:
            uptime = asyncio.get_running_loop().time() - self._start_time

        return {
            "name": self.name,
            "status": "running" if self._running else "stopped",
            "healthy": self._running,
            "uptime": uptime,
            "command": " ".join(self.command),
            "workspace": str(self.workspace),
            "port": self.port,
            "health_check_url": self.health_check_url,
        }
