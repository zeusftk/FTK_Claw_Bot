"""
OpenWork Service - 唯一后端服务

封装 OpenWork Server 的完整 API 能力：
- 代码执行（opencode/*）
- 技能管理（Skills、Plugins、MCP）
- 命令管理（Commands）
- 自动化（AgentLab）
- 文件交换（Inbox/Artifacts）
- 审批管理（Approvals）
- Token 管理（多租户）
"""

from __future__ import annotations

import asyncio
import shutil
import time
from typing import Any

import aiohttp
from loguru import logger

from clawbot.constants import OPENWORK_SERVER_DEFAULT_URL

from .base import BaseExternalService, ServiceCapabilities, ServiceHealth, ServiceStatus


class OpenWorkService(BaseExternalService):
    """
    OpenWork 服务封装 - 唯一后端

    实现完整的 OpenWork Server API 封装，提供：
    1. 代码执行（通过 /opencode/* 代理）
    2. 技能管理（Skills、Plugins、MCP）
    3. 命令管理（Commands）
    4. 自动化（AgentLab）
    5. 文件交换（Inbox/Artifacts）
    6. 审批管理（Approvals）
    7. Token 管理（多租户）

    Example:
        service = OpenWorkService(
            base_url=OPENWORK_SERVER_DEFAULT_URL,
            token="your-token",
        )

        if await service.ensure():
            result = await service.execute_code("Generate hello world")
    """

    def __init__(
        self,
        base_url: str = OPENWORK_SERVER_DEFAULT_URL,
        token: str | None = None,
        workspace_id: str | None = None,
        **kwargs,
    ):
        config = {
            "base_url": base_url,
            "token": token,
            "workspace_id": workspace_id,
            **kwargs,
        }
        super().__init__("openwork", config)

        self.base_url = base_url.rstrip("/")
        self.token = token
        self.workspace_id = workspace_id
        self._session: aiohttp.ClientSession | None = None
        self._process: asyncio.subprocess.Process | None = None

    def _detect_capabilities(self) -> ServiceCapabilities:
        """OpenWork 支持的能力"""
        return ServiceCapabilities(
            code_execution=True,
            file_management=True,
            skill_management=True,
            plugin_management=True,
            mcp_support=True,
            scheduling=True,
            multi_tenant=True,
            memory_integration=True,
            self_evolution=True,
        )

    # ========== 生命周期 ==========

    async def ensure(self) -> bool:
        """
        确保服务可用

        检查服务是否运行，如未运行则返回 False（不自动启动）。

        Returns:
            True if service is available
        """
        if self.status == ServiceStatus.RUNNING:
            return True

        health = await self.health_check()
        if health.healthy:
            self.status = ServiceStatus.RUNNING
            return True

        logger.error("OpenWork Server is not running. Please start it manually: openwork start --port 7777")
        return False

    async def start(self) -> bool:
        """
        启动 OpenWork 服务

        尝试启动 openwork CLI 服务

        Returns:
            True if service started successfully
        """
        try:
            self.status = ServiceStatus.STARTING

            if not await self._is_installed():
                logger.error("OpenWork is not installed. Please install it first.")
                self.status = ServiceStatus.ERROR
                return False

            logger.info(f"Starting OpenWork service at {self.base_url}")

            self._process = await asyncio.create_subprocess_exec(
                "openwork", "start",
                "--port", "7777",
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.PIPE,
            )

            for _ in range(60):
                await asyncio.sleep(0.5)
                health = await self.health_check()
                if health.healthy:
                    self.status = ServiceStatus.RUNNING
                    logger.info(f"OpenWork started at {self.base_url}")
                    return True

            self.status = ServiceStatus.ERROR
            logger.error("OpenWork failed to start within timeout")
            return False

        except Exception as e:
            logger.error(f"Failed to start OpenWork: {e}")
            self.status = ServiceStatus.ERROR
            return False

    async def stop(self) -> None:
        """停止服务"""
        if self._process:
            self._process.terminate()
            try:
                await asyncio.wait_for(self._process.wait(), timeout=10)
            except asyncio.TimeoutError:
                self._process.kill()
            self._process = None

        if self._session:
            await self._session.close()
            self._session = None

        self.status = ServiceStatus.STOPPED
        logger.info("OpenWork stopped")

    async def health_check(self) -> ServiceHealth:
        """
        健康检查

        Returns:
            ServiceHealth with check results
        """
        start = time.monotonic()
        try:
            async with self._get_session() as session:
                async with session.get(
                    f"{self.base_url}/health",
                    timeout=aiohttp.ClientTimeout(total=5),
                ) as resp:
                    latency = (time.monotonic() - start) * 1000
                    healthy = resp.status == 200

                    return ServiceHealth(
                        status=ServiceStatus.RUNNING if healthy else ServiceStatus.ERROR,
                        healthy=healthy,
                        latency_ms=latency,
                        last_check=start,
                    )
        except Exception as e:
            return ServiceHealth(
                status=ServiceStatus.ERROR,
                healthy=False,
                latency_ms=(time.monotonic() - start) * 1000,
                last_check=start,
                error_message=str(e),
            )

    # ========== 代码执行 ==========

    async def _execute_code_impl(
        self,
        task: str,
        workspace: str | None,
        context: dict[str, Any] | None,
    ) -> dict[str, Any]:
        """
        通过 /opencode/* 代理执行代码

        Args:
            task: 任务描述
            workspace: 工作空间路径
            context: 额外上下文

        Returns:
            执行结果
        """
        if not await self.ensure():
            raise RuntimeError("OpenWork Server is not available. Please start it first.")

        url = f"{self.base_url}/opencode/agents/default/messages"

        payload = {
            "content": task,
            "context": context or {},
        }

        if workspace:
            payload["workspace"] = workspace

        async with self._get_session() as session:
            async with session.post(url, json=payload) as resp:
                if resp.status == 200:
                    return await resp.json()
                else:
                    text = await resp.text()
                    raise RuntimeError(f"Code execution failed: {resp.status} - {text}")

    # ========== 技能管理 ==========

    async def _list_skills_impl(self) -> list[dict[str, Any]]:
        """列出技能"""
        if not await self.ensure():
            return []

        url = self._workspace_url("/skills")
        async with self._get_session() as session:
            async with session.get(url) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return data.get("skills", [])
                return []

    async def _install_skill_impl(self, name: str, source: str | None) -> bool:
        """安装技能"""
        if not await self.ensure():
            return False

        if source and source.startswith("hub:"):
            url = self._workspace_url(f"/skills/hub/{name}")
        else:
            url = self._workspace_url("/skills")

        async with self._get_session() as session:
            async with session.post(url, json={"name": name}) as resp:
                return resp.status == 200

    async def list_plugins(self) -> list[dict[str, Any]]:
        """列出插件"""
        if not await self.ensure():
            return []

        url = self._workspace_url("/plugins")
        async with self._get_session() as session:
            async with session.get(url) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return data.get("plugins", [])
                return []

    async def install_plugin(self, spec: str) -> bool:
        """安装插件"""
        if not await self.ensure():
            return False

        url = self._workspace_url("/plugins")
        async with self._get_session() as session:
            async with session.post(url, json={"spec": spec}) as resp:
                return resp.status == 200

    async def list_mcp(self) -> list[dict[str, Any]]:
        """列出 MCP 服务"""
        if not await self.ensure():
            return []

        url = self._workspace_url("/mcp")
        async with self._get_session() as session:
            async with session.get(url) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return data.get("mcps", [])
                return []

    async def add_mcp(self, name: str, config: dict[str, Any]) -> bool:
        """添加 MCP 服务"""
        if not await self.ensure():
            return False

        url = self._workspace_url("/mcp")
        async with self._get_session() as session:
            async with session.post(url, json={"name": name, "config": config}) as resp:
                return resp.status == 200

    # ========== 命令管理 ==========

    async def list_commands(self) -> list[dict[str, Any]]:
        """列出自定义命令"""
        if not await self.ensure():
            return []

        url = self._workspace_url("/commands")
        async with self._get_session() as session:
            async with session.get(url) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return data.get("commands", [])
                return []

    async def create_command(
        self,
        name: str,
        template: str,
        description: str | None = None,
    ) -> bool:
        """创建自定义命令"""
        if not await self.ensure():
            return False

        url = self._workspace_url("/commands")
        payload = {"name": name, "template": template}
        if description:
            payload["description"] = description

        async with self._get_session() as session:
            async with session.post(url, json=payload) as resp:
                return resp.status == 200

    # ========== 自动化 ==========

    async def list_automations(self) -> list[dict[str, Any]]:
        """列出自动化任务"""
        if not await self.ensure():
            return []

        url = self._workspace_url("/agentlab/automations")
        async with self._get_session() as session:
            async with session.get(url) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return data.get("automations", [])
                return []

    async def run_automation(self, automation_id: str) -> dict[str, Any]:
        """运行自动化任务"""
        if not await self.ensure():
            return {"error": "OpenWork not available"}

        url = self._workspace_url(f"/agentlab/automations/{automation_id}/run")
        async with self._get_session() as session:
            async with session.post(url) as resp:
                return await resp.json()

    # ========== 文件交换 ==========

    async def upload_file(
        self,
        file_path: str,
        content: bytes,
        target_path: str | None = None,
    ) -> bool:
        """上传文件到 Inbox"""
        if not await self.ensure():
            return False

        url = self._workspace_url("/inbox")
        data = aiohttp.FormData()
        data.add_field("file", content, filename=file_path)
        if target_path:
            data.add_field("path", target_path)

        async with self._get_session() as session:
            async with session.post(url, data=data) as resp:
                return resp.status == 200

    async def list_artifacts(self) -> list[dict[str, Any]]:
        """列出 Artifacts"""
        if not await self.ensure():
            return []

        url = self._workspace_url("/artifacts")
        async with self._get_session() as session:
            async with session.get(url) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return data.get("artifacts", [])
                return []

    # ========== 审批管理 ==========

    async def list_approvals(self) -> list[dict[str, Any]]:
        """列出待审批请求"""
        if not await self.ensure():
            return []

        url = f"{self.base_url}/approvals"
        async with self._get_session() as session:
            async with session.get(url) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return data.get("approvals", [])
                return []

    async def respond_approval(self, approval_id: str, allow: bool) -> bool:
        """响应审批请求"""
        if not await self.ensure():
            return False

        url = f"{self.base_url}/approvals/{approval_id}"
        async with self._get_session() as session:
            async with session.post(url, json={"reply": "allow" if allow else "deny"}) as resp:
                return resp.status == 200

    # ========== Token 管理 ==========

    async def list_tokens(self) -> list[dict[str, Any]]:
        """列出所有 Token"""
        if not await self.ensure():
            return []

        url = f"{self.base_url}/tokens"
        async with self._get_session() as session:
            async with session.get(url) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return data.get("tokens", [])
                return []

    async def create_token(self, scope: str, label: str | None = None) -> dict[str, Any] | None:
        """创建新 Token"""
        if not await self.ensure():
            return None

        url = f"{self.base_url}/tokens"
        payload = {"scope": scope}
        if label:
            payload["label"] = label

        async with self._get_session() as session:
            async with session.post(url, json=payload) as resp:
                if resp.status == 200:
                    return await resp.json()
                return None

    # ========== 辅助方法 ==========

    def _get_session(self) -> aiohttp.ClientSession:
        """获取或创建 HTTP session"""
        if self._session is None or self._session.closed:
            headers = {}
            if self.token:
                headers["Authorization"] = f"Bearer {self.token}"
            self._session = aiohttp.ClientSession(headers=headers)
        return self._session

    def _workspace_url(self, path: str) -> str:
        """构建 workspace URL"""
        if self.workspace_id:
            return f"{self.base_url}/w/{self.workspace_id}{path}"
        return f"{self.base_url}/workspace/default{path}"

    async def _is_installed(self) -> bool:
        """检查 OpenWork 是否已安装"""
        return shutil.which("openwork") is not None

    def get_status(self) -> dict[str, Any]:
        """获取服务状态信息"""
        return {
            "name": self.name,
            "status": self.status.name,
            "base_url": self.base_url,
            "workspace_id": self.workspace_id,
            "capabilities": {
                "code_execution": self.supports("code_execution"),
                "skill_management": self.supports("skill_management"),
                "plugin_management": self.supports("plugin_management"),
                "mcp_support": self.supports("mcp_support"),
                "scheduling": self.supports("scheduling"),
                "multi_tenant": self.supports("multi_tenant"),
                "memory_integration": self.supports("memory_integration"),
                "self_evolution": self.supports("self_evolution"),
            },
        }
