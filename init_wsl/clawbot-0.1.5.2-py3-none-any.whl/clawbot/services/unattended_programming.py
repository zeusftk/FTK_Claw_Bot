"""
Unattended Programming Service - 整合记忆与自我进化

核心能力：
1. 全自动化：从需求到代码
2. 智能决策：基于历史模式
3. 记忆系统：决策记录、成功案例
4. 自我进化：持续优化决策能力
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from loguru import logger

from clawbot.openwork.memory import OpenWorkMemoryBridge
from clawbot.openwork.pattern_extractor import PatternExtractor
from clawbot.openwork.self_enhancer import SelfEnhancer

from .openwork_service import OpenWorkService


@dataclass
class ExecutionResult:
    """执行结果"""
    success: bool
    output: str
    execution_time_ms: float
    decision_record_id: str | None = None
    metadata: dict[str, Any] | None = None


class UnattendedProgrammingService:
    """
    无人值守编程服务
    
    核心能力：
    1. 全自动化：从需求到代码
    2. 智能决策：基于历史模式
    3. 记忆系统：决策记录、成功案例
    4. 自我进化：持续优化决策能力
        
    Example:
        service = UnattendedProgrammingService(
            openwork=OpenWorkService(),
            workspace=Path("/path/to/workspace"),
        )
        
        await service.start()
        result = await service.execute("Generate hello world")
        print(result.output)
    """

    def __init__(
        self,
        openwork: OpenWorkService,
        workspace: Path,
        enable_evolution: bool = True,
        evolution_interval_hours: int = 24,
    ):
        self.openwork = openwork
        self.workspace = workspace

        self.memory = OpenWorkMemoryBridge(workspace=workspace)
        self.pattern_extractor = PatternExtractor(memory_bridge=self.memory)
        self.enhancer = SelfEnhancer(
            memory_bridge=self.memory,
            pattern_extractor=self.pattern_extractor,
        )

        self.evolution_scheduler = None
        if enable_evolution:
            from clawbot.openwork.self_enhancer import EnhancementScheduler
            self.evolution_scheduler = EnhancementScheduler(
                self_enhancer=self.enhancer,
                interval_hours=evolution_interval_hours,
            )

    async def start(self):
        """启动服务"""
        if self.evolution_scheduler:
            await self.evolution_scheduler.start()
            logger.info("Evolution scheduler started")

    async def stop(self):
        """停止服务"""
        if self.evolution_scheduler:
            await self.evolution_scheduler.stop()

    async def execute(
        self,
        task: str,
        workspace_path: str | None = None,
        context: dict[str, Any] | None = None,
        user_id: str | None = None,
    ) -> ExecutionResult:
        """
        执行编程任务
        
        流程：
        1. 搜索相似历史决策
        2. 获取决策级别建议
        3. 执行任务
        4. 记录决策
        5. 归档成功案例
        """
        start_time = time.time()

        similar_decisions = await self.memory.search_similar_decisions(task)
        decision_level = self._determine_decision_level(task, similar_decisions)

        try:
            result = await self.openwork.execute_code(task, workspace_path, context)
            success = True
            output = result.get("output", "Task completed")
        except Exception as e:
            success = False
            output = f"Error: {str(e)}"
            result = {}

        execution_time = (time.time() - start_time) * 1000

        decision_record_id = await self.memory.record_decision({
            "project_id": workspace_path or "default",
            "event_type": "code_execution",
            "event_details": {
                "task": task[:200],
                "context": context,
            },
            "decision_level": decision_level,
            "decision_answer": "execute" if success else "failed",
            "was_auto_resolved": True,
            "outcome": output[:500],
            "success": success,
        })

        if success and result.get("quality_score", 0) > 0.8:
            await self.memory.archive_success_case(
                idea=task,
                result={
                    "summary": output[:500],
                    "workspace_snapshot": workspace_path or "",
                },
                quality_score=result.get("quality_score", 0.8),
                decisions=[{"record_id": decision_record_id}],
            )

        return ExecutionResult(
            success=success,
            output=output,
            execution_time_ms=execution_time,
            decision_record_id=decision_record_id,
            metadata={"decision_level": decision_level},
        )

    def _determine_decision_level(
        self,
        task: str,
        similar_decisions: list[dict],
    ) -> str:
        """确定决策级别"""
        return self.enhancer.get_decision_level("code_execution")

    async def update_rating(
        self,
        record_id: str,
        user_rating: int,
        lessons_learned: str | None = None,
    ):
        """更新用户评分"""
        await self.memory.update_decision_outcome(
            record_id=record_id,
            outcome="user_rated",
            success=user_rating >= 3,
            user_rating=user_rating,
        )

    async def trigger_evolution(self) -> dict[str, Any]:
        """手动触发自我进化"""
        if not self.evolution_scheduler:
            return {"error": "Evolution not enabled"}

        result = await self.evolution_scheduler.trigger_enhancement()

        return {
            "timestamp": result.timestamp.isoformat(),
            "adjustments": result.adjustments,
            "new_rules": result.new_rules,
            "prompt_updates": result.prompt_updates,
            "recommendations": result.recommendations,
        }

    def get_stats(self) -> dict[str, Any]:
        """获取统计信息"""
        return {
            "memory": {
                "decisions_file": str(self.memory.decisions_file),
                "cases_file": str(self.memory.cases_file),
            },
            "enhancer": self.enhancer.get_stats(),
            "evolution": self.evolution_scheduler.get_status() if self.evolution_scheduler else None,
        }
