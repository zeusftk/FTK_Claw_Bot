"""健康检查工具"""

import asyncio
from loguru import logger
import time
from typing import Any, Callable, Coroutine

import aiohttp



class HealthChecker:
    """健康检查工具
    
    用于检查 HTTP 服务的健康状态，支持自定义检查逻辑和批量检查。
    
    Attributes:
        timeout: 默认超时时间（秒）
        retries: 默认重试次数

    Example:
        checker = HealthChecker(timeout=5.0, retries=3)

        # 检查单个服务
        healthy, info = await checker.check_http("http://localhost:7777/health")

        # 批量检查
        services = {
            "openwork": "http://localhost:7777/health",
            "embedding": "http://localhost:8765/health",
        }
        results = await checker.check_many(services)

        # 使用自定义检查函数
        async def custom_check() -> tuple[bool, str]:
            # 自定义检查逻辑
            return True, "OK"

        healthy, info = await checker.check_custom(custom_check)
    """

    def __init__(self, timeout: float = 5.0, retries: int = 1):
        self.timeout = timeout
        self.retries = retries

    async def check_http(
        self,
        url: str,
        method: str = "GET",
        expected_status: int = 200,
        timeout: float | None = None,
    ) -> tuple[bool, dict[str, Any]]:
        """检查 HTTP 服务健康状况
        
        Args:
            url: 健康检查 URL
            method: HTTP 方法
            expected_status: 期望的 HTTP 状态码
            timeout: 超时时间（秒），None 使用默认值
        
        Returns:
            Tuple of (is_healthy, info_dict)
        """
        timeout = timeout or self.timeout

        for attempt in range(self.retries):
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.request(
                        method=method,
                        url=url,
                        timeout=aiohttp.ClientTimeout(total=timeout),
                    ) as resp:
                        is_healthy = resp.status == expected_status
                        info = {
                            "url": url,
                            "status_code": resp.status,
                            "expected_status": expected_status,
                            "attempt": attempt + 1,
                        }

                        if is_healthy:
                            return True, info

                        return False, info

            except asyncio.TimeoutError:
                if attempt < self.retries - 1:
                    await asyncio.sleep(0.5 * (attempt + 1))
                    continue

                return False, {
                    "url": url,
                    "error": "timeout",
                    "timeout": timeout,
                    "attempts": self.retries,
                }

            except Exception as e:
                if attempt < self.retries - 1:
                    await asyncio.sleep(0.5 * (attempt + 1))
                    continue

                return False, {
                    "url": url,
                    "error": str(e),
                    "error_type": type(e).__name__,
                    "attempts": self.retries,
                }

        return False, {"url": url, "error": "unknown"}

    async def check_custom(
        self,
        check_fn: Callable[[], Coroutine[Any, Any, tuple[bool, str]]],
    ) -> tuple[bool, dict[str, Any]]:
        """使用自定义检查函数
        
        Args:
            check_fn: 异步检查函数，返回 (is_healthy, message)

        Returns:
            Tuple of (is_healthy, info_dict)
        """
        try:
            is_healthy, message = await check_fn()
            return is_healthy, {
                "healthy": is_healthy,
                "message": message,
            }
        except Exception as e:
            return False, {
                "healthy": False,
                "error": str(e),
                "error_type": type(e).__name__,
            }

    async def check_many(
        self,
        services: dict[str, str],
        timeout: float | None = None,
    ) -> dict[str, tuple[bool, dict[str, Any]]]:
        """批量检查多个服务
        
        Args:
            services: 服务名称到 URL 的映射
            timeout: 超时时间（秒）
        
        Returns:
            服务名称到检查结果的映射
        """
        results = {}

        async def check_one(name: str, url: str):
            results[name] = await self.check_http(url, timeout=timeout)

        await asyncio.gather(
            *[check_one(name, url) for name, url in services.items()]
        )

        return results

    async def wait_for_healthy(
        self,
        url: str,
        timeout: float = 30.0,
        interval: float = 0.5,
    ) -> bool:
        """等待服务变为健康状态
        
        Args:
            url: 健康检查 URL
            timeout: 最大等待时间（秒）
            interval: 检查间隔（秒）

        Returns:
            True if service became healthy within timeout
        """
        start_time = time.monotonic()

        while time.monotonic() - start_time < timeout:
            healthy, _ = await self.check_http(url, timeout=min(interval, 5.0))
            if healthy:
                return True
            await asyncio.sleep(interval)

        return False
