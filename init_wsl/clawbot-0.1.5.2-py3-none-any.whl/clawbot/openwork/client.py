"""
OpenWork Client - HTTP/SSE client for OpenWork Orchestrator communication.

This module provides the HTTP POST and SSE (Server-Sent Events) client
for communicating with OpenWork Orchestrator.
"""

import asyncio
import json
from loguru import logger
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import AsyncIterator, Callable

import aiohttp



class EventType(Enum):
    PROGRESS = "progress"
    TODO_UPDATE = "todo_update"
    PERMISSION_REQUEST = "permission_request"
    ERROR = "error"
    COMPLETED = "completed"
    FILE_CHANGE = "file_change"


@dataclass
class SSEEvent:
    type: EventType
    session_id: str
    data: dict
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class PermissionRequest:
    permission_id: str
    session_id: str
    type: str
    message: str
    details: dict


@dataclass
class TaskResult:
    session_id: str
    project_id: str
    status: str
    result: dict
    duration: float
    files_changed: list[str]
    todos_completed: int
    todos_total: int


@dataclass
class QualityScore:
    code_quality: float
    test_coverage: float
    user_rating: float | None
    efficiency: float

    @property
    def overall(self) -> float:
        weights = [0.3, 0.2, 0.3, 0.2]
        scores = [self.code_quality, self.test_coverage, self.user_rating or 0, self.efficiency]
        return sum(w * s for w, s in zip(weights, scores))


class OpenWorkClient:
    """OpenWork Orchestrator HTTP/SSE client."""

    def __init__(
        self,
        base_url: str = "http://localhost:7777",
        on_permission_request: Callable[[PermissionRequest], asyncio.Future] | None = None,
        on_progress: Callable[[SSEEvent], None] | None = None,
        on_error: Callable[[SSEEvent], None] | None = None,
        on_completed: Callable[[TaskResult], None] | None = None,
        on_quality_score: Callable[[str, QualityScore], None] | None = None,
        on_user_rating_request: Callable[[str], asyncio.Future] | None = None,
    ):
        self.base_url = base_url
        self._on_permission_request = on_permission_request
        self._on_progress = on_progress
        self._on_error = on_error
        self._on_completed = on_completed
        self._on_quality_score = on_quality_score
        self._on_user_rating_request = on_user_rating_request
        self._session: aiohttp.ClientSession | None = None
        self._sse_task: asyncio.Task | None = None
        self._running = False
        self._project_map: dict[str, str] = {}

    async def __aenter__(self):
        self._session = aiohttp.ClientSession()
        return self

    async def __aexit__(self, *args):
        self._running = False
        if self._sse_task:
            self._sse_task.cancel()
            try:
                await self._sse_task
            except asyncio.CancelledError:
                pass
        if self._session:
            await self._session.close()

    async def create_session(self, title: str, cwd: str) -> dict:
        """Create a new session."""
        async with self._session.post(
            f"{self.base_url}/session",
            json={"title": title, "cwd": cwd}
        ) as resp:
            resp.raise_for_status()
            return await resp.json()

    async def send_message(self, session_id: str, text: str) -> dict:
        """Send a message/task to the session."""
        async with self._session.post(
            f"{self.base_url}/session/{session_id}/message",
            json={"parts": [{"type": "text", "text": text}]}
        ) as resp:
            resp.raise_for_status()
            return await resp.json()

    async def respond_permission(
        self,
        session_id: str,
        permission_id: str,
        response: str,
        remember: bool = False
    ) -> bool:
        """Respond to a permission request."""
        try:
            async with self._session.post(
                f"{self.base_url}/session/{session_id}/permissions/{permission_id}",
                json={"response": response, "remember": remember}
            ) as resp:
                return resp.status == 200
        except Exception as e:
            logger.error(f"Failed to respond to permission: {e}")
            return False

    async def get_session(self, session_id: str) -> dict:
        """Get session status."""
        async with self._session.get(
            f"{self.base_url}/session/{session_id}"
        ) as resp:
            resp.raise_for_status()
            return await resp.json()

    async def subscribe_events(self) -> AsyncIterator[SSEEvent]:
        """Subscribe to SSE event stream."""
        self._running = True
        async with self._session.get(
            f"{self.base_url}/events",
            headers={"Accept": "text/event-stream"}
        ) as resp:
            resp.raise_for_status()
            buffer = ""
            async for chunk in resp.content:
                if not self._running:
                    break
                buffer += chunk.decode("utf-8")

                while "\n\n" in buffer:
                    event_data, buffer = buffer.split("\n\n", 1)
                    event = self._parse_sse_event(event_data)
                    if event:
                        yield event

    def _parse_sse_event(self, event_data: str) -> SSEEvent | None:
        """Parse SSE event."""
        lines = event_data.strip().split("\n")
        event_type = None
        data = {}

        for line in lines:
            if line.startswith("event:"):
                event_type = line[6:].strip()
            elif line.startswith("data:"):
                try:
                    data = json.loads(line[5:].strip())
                except json.JSONDecodeError:
                    pass

        if event_type and data:
            try:
                return SSEEvent(
                    type=EventType(event_type),
                    session_id=data.get("session_id", ""),
                    data=data,
                )
            except ValueError:
                logger.warning(f"Unknown event type: {event_type}")
                return None
        return None

    async def start_event_listener(self):
        """Start the event listener."""
        async for event in self.subscribe_events():
            await self._handle_event(event)

    async def _handle_event(self, event: SSEEvent):
        """Handle an event."""
        if event.type == EventType.PROGRESS and self._on_progress:
            self._on_progress(event)

        elif event.type == EventType.PERMISSION_REQUEST:
            if self._on_permission_request:
                request = PermissionRequest(
                    permission_id=event.data["permission_id"],
                    session_id=event.session_id,
                    type=event.data["type"],
                    message=event.data["message"],
                    details=event.data.get("details", {}),
                )
                response = await self._on_permission_request(request)
                if response:
                    await self.respond_permission(
                        event.session_id,
                        request.permission_id,
                        response,
                    )

        elif event.type == EventType.ERROR and self._on_error:
            self._on_error(event)

        elif event.type == EventType.COMPLETED and self._on_completed:
            result = TaskResult(
                session_id=event.session_id,
                project_id=self._project_map.get(event.session_id, ""),
                status="completed",
                result=event.data.get("result", {}),
                duration=event.data.get("duration", 0),
                files_changed=event.data.get("files_changed", []),
                todos_completed=event.data.get("todos_completed", 0),
                todos_total=event.data.get("todos_total", 0),
            )
            self._on_completed(result)

            if self._on_quality_score:
                quality = await self._calculate_quality(result)
                self._on_quality_score(result.project_id, quality)

                if self._on_user_rating_request and quality.user_rating is None:
                    user_rating = await self._on_user_rating_request(result.project_id)
                    if user_rating:
                        quality.user_rating = user_rating

    async def _calculate_quality(self, result: TaskResult) -> QualityScore:
        """Calculate quality score."""
        return QualityScore(
            code_quality=self._analyze_code_quality(result),
            test_coverage=self._check_test_coverage(result),
            user_rating=None,
            efficiency=self._calculate_efficiency(result),
        )

    def _analyze_code_quality(self, result: TaskResult) -> float:
        """Analyze code quality."""
        if not result.files_changed:
            return 0.5
        return 0.8

    def _check_test_coverage(self, result: TaskResult) -> float:
        """Check test coverage."""
        if result.todos_completed == 0:
            return 0.5
        return result.todos_completed / max(result.todos_total, 1)

    def _calculate_efficiency(self, result: TaskResult) -> float:
        """Calculate efficiency."""
        if result.duration <= 0:
            return 0.5
        if result.duration < 60:
            return 1.0
        if result.duration < 300:
            return 0.8
        if result.duration < 600:
            return 0.6
        return 0.4

    def register_project(self, session_id: str, project_id: str):
        """Register a session-project mapping."""
        self._project_map[session_id] = project_id

    def unregister_project(self, session_id: str):
        """Unregister a session-project mapping."""
        self._project_map.pop(session_id, None)
