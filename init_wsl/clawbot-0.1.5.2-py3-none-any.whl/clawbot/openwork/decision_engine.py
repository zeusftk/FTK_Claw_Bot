"""
AI PM Decision Engine - Graded decision engine for permission handling.

This module provides the AI PM decision engine that evaluates permission
requests and determines whether they can be auto-approved or require
human intervention.
"""

import json
from loguru import logger
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from clawbot.openwork.memory import OpenWorkMemoryBridge



class DecisionLevel(Enum):
    AUTO_SAFE = "auto_safe"
    AUTO_RESOLVE = "auto_resolve"
    REQUIRE_HUMAN = "require_human"


@dataclass
class Decision:
    level: DecisionLevel
    answer: str | None
    summary: str | None
    confidence: float
    reasoning: str


class AIPMDecisionEngine:
    """AI PM graded decision engine."""

    AUTO_SAFE_OPERATIONS = frozenset([
        "file_read",
        "file_create",
        "file_modify",
        "command_safe",
        "http_request",
        "directory_create",
        "git_status",
        "git_log",
        "npm_install",
        "pip_install",
    ])

    REQUIRE_HUMAN_OPERATIONS = frozenset([
        "file_delete",
        "directory_delete",
        "command_dangerous",
        "database_drop",
        "database_truncate",
        "external_service_config",
        "credential_access",
        "production_deploy",
    ])

    DANGEROUS_PATTERNS = [
        "rm -rf",
        "rm -r",
        "rmdir",
        "drop table",
        "truncate",
        "delete from",
        "format",
        "fdisk",
        "mkfs",
        "shutdown",
        "reboot",
        "poweroff",
        "chmod 777",
        "chown -R",
        "> /dev/",
        "dd if=",
        "curl | bash",
        "wget | bash",
        "password",
        "secret",
        "token",
        "api_key",
        "private_key",
    ]

    SYSTEM_PROMPT = """你是一个资深技术总监。你的下属（Opencode）在写代码时遇到了权限请求。

请判断决策级别：

**Level 1 (auto_safe)**: 完全安全的操作
- 创建新文件
- 修改现有文件
- 读取文件
- 执行安全命令 (npm, pip, git status)

**Level 2 (auto_resolve)**: AI PM 可以批准的操作
- 安装新依赖
- 修改配置文件
- 执行构建命令

**Level 3 (require_human)**: 必须人类确认
- 删除文件
- 执行危险命令 (rm -rf, drop table)
- 涉及外部服务配置
- 需要账号密码

请输出 JSON 格式:
{
  "level": "auto_safe|auto_resolve|require_human",
  "summary": "简短说明",
  "confidence": 0.0-1.0,
  "reasoning": "决策理由"
}"""

    def __init__(
        self,
        llm_provider: Any = None,
        memory_store: "OpenWorkMemoryBridge | None" = None,
        auto_safe_operations: list[str] | None = None,
        require_human_operations: list[str] | None = None,
    ):
        self.llm_provider = llm_provider
        self.memory_store = memory_store

        self.auto_safe_operations = (
            frozenset(auto_safe_operations)
            if auto_safe_operations
            else self.AUTO_SAFE_OPERATIONS
        )

        self.require_human_operations = (
            frozenset(require_human_operations)
            if require_human_operations
            else self.REQUIRE_HUMAN_OPERATIONS
        )

    async def evaluate(
        self,
        user_idea: str,
        event_details: dict,
        project_context: dict,
    ) -> Decision:
        """Evaluate the decision level."""
        operation_type = event_details.get("type", "")
        message = event_details.get("message", "")
        details = event_details.get("details", {})

        if self._contains_dangerous_patterns(message) or self._contains_dangerous_patterns(str(details)):
            return Decision(
                level=DecisionLevel.REQUIRE_HUMAN,
                answer=None,
                summary="检测到危险操作模式",
                confidence=0.95,
                reasoning="操作包含危险命令或敏感信息",
            )

        if operation_type in self.auto_safe_operations:
            return Decision(
                level=DecisionLevel.AUTO_SAFE,
                answer="allow",
                summary=f"安全操作: {operation_type}",
                confidence=0.95,
                reasoning="操作类型在自动批准列表中",
            )

        if operation_type in self.require_human_operations:
            return Decision(
                level=DecisionLevel.REQUIRE_HUMAN,
                answer=None,
                summary=f"高风险操作: {operation_type}",
                confidence=0.90,
                reasoning="操作类型需要人工确认",
            )

        if self.memory_store:
            similar = await self.memory_store.search_similar_decisions(message)
            if similar and similar[0].get("success_rate", 0) > 0.8:
                return Decision(
                    level=DecisionLevel(similar[0].get("decision_level", "require_human")),
                    answer="allow",
                    summary="基于历史成功案例",
                    confidence=similar[0]["success_rate"],
                    reasoning="历史记录显示此操作可以自动批准",
                )

        if self.llm_provider:
            return await self._llm_evaluate(user_idea, event_details, project_context)

        return Decision(
            level=DecisionLevel.REQUIRE_HUMAN,
            answer=None,
            summary="无法自动判断",
            confidence=0.5,
            reasoning="缺少足够信息，需要人工确认",
        )

    def _contains_dangerous_patterns(self, text: str) -> bool:
        """Check if text contains dangerous patterns."""
        text_lower = text.lower()
        return any(pattern in text_lower for pattern in self.DANGEROUS_PATTERNS)

    async def _llm_evaluate(
        self,
        user_idea: str,
        event_details: dict,
        project_context: dict,
    ) -> Decision:
        """Use LLM to evaluate."""
        prompt = f"""
用户原始需求: {user_idea}

当前权限请求:
- 类型: {event_details.get('type')}
- 消息: {event_details.get('message')}
- 详情: {event_details.get('details')}

项目上下文:
- 工作目录: {project_context.get('workspace')}

请判断决策级别:
"""

        try:
            response = await self.llm_provider.chat(
                messages=[
                    {"role": "system", "content": self.SYSTEM_PROMPT},
                    {"role": "user", "content": prompt},
                ],
                response_format={"type": "json_object"},
            )

            result = json.loads(response.content)

            level_str = result.get("level", "require_human")
            try:
                level = DecisionLevel(level_str)
            except ValueError:
                level = DecisionLevel.REQUIRE_HUMAN

            return Decision(
                level=level,
                answer="allow" if level != DecisionLevel.REQUIRE_HUMAN else None,
                summary=result.get("summary"),
                confidence=result.get("confidence", 0.5),
                reasoning=result.get("reasoning"),
            )
        except Exception as e:
            logger.error(f"LLM evaluation failed: {e}")
            return Decision(
                level=DecisionLevel.REQUIRE_HUMAN,
                answer=None,
                summary="LLM 评估失败",
                confidence=0.5,
                reasoning=f"评估过程出错: {str(e)}",
            )

    def add_auto_safe_operation(self, operation: str):
        """Add an operation to the auto-safe list."""
        self.auto_safe_operations = self.auto_safe_operations | {operation}

    def add_require_human_operation(self, operation: str):
        """Add an operation to the require-human list."""
        self.require_human_operations = self.require_human_operations | {operation}
