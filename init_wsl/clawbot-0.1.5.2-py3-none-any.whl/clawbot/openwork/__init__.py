"""
OpenWork Integration Module

This module provides integration with OpenWork Orchestrator for
unattended autonomous programming through Opencode.

Architecture:
    Layer 1: clawbot (Python) - HTTP POST / SSE
    Layer 2: OpenWork Orchestrator (Node.js)
    Layer 3: Opencode (LLM Engine)

Components:
    - OpenWorkClient: HTTP/SSE client for communication
    - OpenWorkOrchestrator: Task orchestration
    - AIPMDecisionEngine: Graded decision engine
    - OpenWorkMemoryBridge: Memory integration
    - PatternExtractor: Pattern extraction from history
    - SelfEnhancer: Self-enhancement system
    - LogVisualizer: Log visualization
    - OpenWorkIntegration: AgentLoop integration
    - IdeaProcessor: Idea processing and analysis
    - ProgressReporter: Progress reporting
    - FeedbackCollector: Feedback collection
    - TaskRouter: Task routing
    - SessionManager: Session management
    - UnattendedProgrammingManager: Unified manager
    - OpenWorkSandbox: Security sandbox for path/operation control
    - ApprovalHandler: Operation approval management

Security:
    - All OpenWork operations are sandboxed to workspace/openwork/ by default
    - Delete operations require user confirmation
    - Protected paths (.git, credentials, etc.) cannot be modified
    - Cross-task operations are tracked and controlled
"""

from clawbot.openwork.client import (
    EventType,
    OpenWorkClient,
    PermissionRequest,
    QualityScore,
    SSEEvent,
    TaskResult,
)
from clawbot.openwork.decision_engine import (
    AIPMDecisionEngine,
    Decision,
    DecisionLevel,
)
from clawbot.openwork.feedback_collector import (
    Feedback,
    FeedbackCollector,
    FeedbackRequest,
    FeedbackResult,
    FeedbackStatus,
    FeedbackType,
)
from clawbot.openwork.idea_processor import (
    ComplexityLevel,
    Feature,
    IdeaProcessor,
    ProcessedIdea,
    RiskLevel,
    TaskType,
    TechnicalSuggestion,
)
from clawbot.openwork.integration import (
    OpenWorkIntegration,
    create_openwork_integration,
)
from clawbot.openwork.log_visualizer import (
    LogEntry,
    LogVisualizer,
)
from clawbot.openwork.memory import (
    CodeSnippet,
    DecisionRecord,
    ErrorPattern,
    OpenWorkMemoryBridge,
    ProjectContext,
    SuccessCase,
)
from clawbot.openwork.orchestrator import (
    ActiveProject,
    OpenWorkOrchestrator,
    ProjectStatus,
)
from clawbot.openwork.pattern_extractor import (
    DecisionPattern,
    PatternExtractor,
)
from clawbot.openwork.progress_reporter import (
    ProgressEvent,
    ProgressEventType,
    ProgressReporter,
    SessionProgress,
    TodoItem,
    ToolCallInfo,
)
from clawbot.openwork.self_enhancer import (
    EnhancementResult,
    EnhancementScheduler,
    SelfEnhancer,
)
from clawbot.openwork.session_manager import (
    Session,
    SessionConfig,
    SessionManager,
    SessionStatus,
)
from clawbot.openwork.task_router import (
    ExecutionResult,
    ExecutionStrategy,
    ExecutionTarget,
    RouteDecision,
    TaskRouter,
)
from clawbot.openwork.unattended_programming_manager import (
    Project,
    UnattendedProgrammingManager,
)
from clawbot.openwork.unattended_programming_manager import (
    ProjectStatus as UPMProjectStatus,
)
from clawbot.openwork.sandbox import (
    OpenWorkSandbox,
    OperationVerdict,
    OperationCheckResult,
    SecurityError,
)
from clawbot.openwork.approval_handler import (
    ApprovalHandler,
    ApprovalRequest,
    ApprovalResponse,
    ApprovalStatus,
    create_user_confirmation_prompt,
    format_delete_confirmation,
)
from clawbot.openwork.agent_constraints import (
    AgentConstraints,
    ConstraintLevel,
    get_constraint_template,
    CONSTRAINT_TEMPLATES,
)

__all__ = [
    "OpenWorkClient",
    "EventType",
    "SSEEvent",
    "PermissionRequest",
    "TaskResult",
    "QualityScore",
    "OpenWorkOrchestrator",
    "ProjectStatus",
    "ActiveProject",
    "AIPMDecisionEngine",
    "DecisionLevel",
    "Decision",
    "OpenWorkMemoryBridge",
    "DecisionRecord",
    "SuccessCase",
    "ProjectContext",
    "CodeSnippet",
    "ErrorPattern",
    "PatternExtractor",
    "DecisionPattern",
    "SelfEnhancer",
    "EnhancementResult",
    "EnhancementScheduler",
    "LogVisualizer",
    "LogEntry",
    "OpenWorkIntegration",
    "create_openwork_integration",
    "IdeaProcessor",
    "ProcessedIdea",
    "Feature",
    "TechnicalSuggestion",
    "ComplexityLevel",
    "RiskLevel",
    "TaskType",
    "ProgressReporter",
    "ProgressEvent",
    "ProgressEventType",
    "ToolCallInfo",
    "TodoItem",
    "SessionProgress",
    "FeedbackCollector",
    "Feedback",
    "FeedbackType",
    "FeedbackStatus",
    "FeedbackRequest",
    "FeedbackResult",
    "TaskRouter",
    "RouteDecision",
    "ExecutionStrategy",
    "ExecutionTarget",
    "ExecutionResult",
    "SessionManager",
    "Session",
    "SessionStatus",
    "SessionConfig",
    "UnattendedProgrammingManager",
    "Project",
    "UPMProjectStatus",
    # Sandbox & Security
    "OpenWorkSandbox",
    "OperationVerdict",
    "OperationCheckResult",
    "SecurityError",
    # Approval
    "ApprovalHandler",
    "ApprovalRequest",
    "ApprovalResponse",
    "ApprovalStatus",
    "create_user_confirmation_prompt",
    "format_delete_confirmation",
    # Agent Constraints
    "AgentConstraints",
    "ConstraintLevel",
    "get_constraint_template",
    "CONSTRAINT_TEMPLATES",
]
