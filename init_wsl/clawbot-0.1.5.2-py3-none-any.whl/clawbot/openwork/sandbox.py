"""
OpenWork Sandbox - 安全沙箱管理

职责：
1. 路径边界检查
2. 操作分类与审批
3. 任务目录隔离
4. 保护文件/目录检查

使用方式：
    sandbox = OpenWorkSandbox(config, workspace_path)

    # 检查操作是否允许
    result = sandbox.check_operation("file_delete", "/path/to/file")

    # 验证路径是否在边界内
    sandbox.assert_within_boundary(path)
"""

from __future__ import annotations

import fnmatch
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any

from loguru import logger


class OperationVerdict(str, Enum):
    """操作判定结果"""
    ALLOWED = "allowed"           # 自动允许
    NEEDS_CONFIRM = "needs_confirm"  # 需要确认
    FORBIDDEN = "forbidden"       # 禁止


@dataclass
class OperationCheckResult:
    """操作检查结果"""
    verdict: OperationVerdict
    operation: str
    path: str | None = None
    reason: str | None = None
    details: dict[str, Any] | None = None


class OpenWorkSandbox:
    """
    OpenWork 安全沙箱

    实现 OpenWork 操作的安全边界控制：
    1. 路径边界：所有操作限制在 openwork 目录内
    2. 任务隔离：每个任务有独立目录
    3. 操作分类：安全/需确认/禁止
    4. 保护文件：禁止删除关键文件

    Example:
        sandbox = OpenWorkSandbox(config.tools.openwork, workspace)

        # 检查删除操作
        result = sandbox.check_operation("file_delete", "/path/to/file")
        if result.verdict == OperationVerdict.NEEDS_CONFIRM:
            # 请求用户确认
            pass
    """

    # 安全命令白名单
    SAFE_COMMANDS = {
        "ls", "dir", "cat", "head", "tail", "grep", "find", "wc",
        "echo", "pwd", "whoami", "which", "whereis",
        "git status", "git log", "git diff", "git branch",
        "npm list", "pip list", "python --version",
    }

    # 危险命令黑名单
    DANGEROUS_COMMAND_PATTERNS = [
        "rm ", "rm -", "del ", "rmdir",
        "sudo ", "su ",
        "chmod", "chown",
        "mkfs", "format",
        "dd if=",
        "> /dev/",  # 设备写入
        "curl | sh", "wget | sh",  # 远程执行
        "eval ", "exec ",
    ]

    def __init__(
        self,
        config: Any,  # OpenWorkConfig
        workspace: Path,
        current_task_id: str | None = None,
    ):
        """
        初始化沙箱

        Args:
            config: OpenWorkConfig 实例
            workspace: 主工作空间路径
            current_task_id: 当前任务 ID（可选）
        """
        self.config = config
        self.workspace = workspace.resolve()
        self.current_task_id = current_task_id

        # 计算边界路径
        self.work_dir = config.get_work_dir(self.workspace)
        self.tasks_dir = self.work_dir / "tasks"
        self.shared_dir = self.work_dir / "shared"
        self.archive_dir = self.work_dir / "archive"

        # 当前任务目录
        self.current_task_dir: Path | None = None
        if current_task_id:
            self.current_task_dir = config.get_task_dir(self.workspace, current_task_id)

    def ensure_directories(self) -> None:
        """确保沙箱目录存在"""
        self.work_dir.mkdir(parents=True, exist_ok=True)
        self.tasks_dir.mkdir(parents=True, exist_ok=True)
        self.shared_dir.mkdir(parents=True, exist_ok=True)
        self.archive_dir.mkdir(parents=True, exist_ok=True)

        # 创建边界标记文件
        sandbox_marker = self.work_dir / ".sandbox_root"
        if not sandbox_marker.exists():
            sandbox_marker.write_text("# OpenWork Sandbox Root\n# Do not delete this file\n")

    # ==================== 路径边界检查 ====================

    def is_within_sandbox(self, path: Path | str) -> bool:
        """
        检查路径是否在沙箱内

        Args:
            path: 要检查的路径

        Returns:
            True 如果路径在沙箱内
        """
        path = Path(path).resolve()
        sandbox_root = self.work_dir.resolve()

        try:
            path.relative_to(sandbox_root)
            return True
        except ValueError:
            return False

    def is_within_current_task(self, path: Path | str) -> bool:
        """
        检查路径是否在当前任务目录内

        Args:
            path: 要检查的路径

        Returns:
            True 如果路径在当前任务目录内
        """
        if not self.current_task_dir:
            return False

        path = Path(path).resolve()
        task_root = self.current_task_dir.resolve()

        try:
            path.relative_to(task_root)
            return True
        except ValueError:
            return False

    def assert_within_sandbox(self, path: Path | str) -> None:
        """
        断言路径在沙箱内，否则抛出异常

        Args:
            path: 要检查的路径

        Raises:
            SecurityError: 如果路径逃逸出沙箱
        """
        if not self.is_within_sandbox(path):
            raise SecurityError(
                f"Path escapes sandbox boundary: {path}\n"
                f"Sandbox root: {self.work_dir}"
            )

    def assert_within_current_task(self, path: Path | str) -> None:
        """
        断言路径在当前任务目录内

        Args:
            path: 要检查的路径

        Raises:
            SecurityError: 如果路径不在当前任务目录内
        """
        if not self.is_within_current_task(path):
            raise SecurityError(
                f"Path is outside current task directory: {path}\n"
                f"Current task: {self.current_task_id}\n"
                f"Task directory: {self.current_task_dir}"
            )

    # ==================== 保护文件检查 ====================

    def is_protected(self, path: Path | str) -> bool:
        """
        检查路径是否受保护

        Args:
            path: 要检查的路径

        Returns:
            True 如果路径受保护
        """
        path_str = str(path)

        # 使用 config 的方法检查
        if hasattr(self.config, 'is_protected_path'):
            return self.config.is_protected_path(path_str)

        # 本地检查
        path_lower = path_str.lower()
        for pattern in self.config.sandbox.protected_patterns:
            if fnmatch.fnmatch(path_lower, pattern.lower()):
                return True
            # Also check basename
            basename = path_lower.split("/")[-1].split("\\")[-1]
            if fnmatch.fnmatch(basename, pattern.lower()):
                return True
        return False

    def is_shared_resource(self, path: Path | str) -> bool:
        """
        检查路径是否是共享资源

        Args:
            path: 要检查的路径

        Returns:
            True 如果是共享资源
        """
        path = Path(path).resolve()
        shared_root = self.shared_dir.resolve()

        try:
            path.relative_to(shared_root)
            return True
        except ValueError:
            return False

    # ==================== 操作分类 ====================

    def check_operation(
        self,
        operation: str,
        path: Path | str | None = None,
        command: str | None = None,
        extra_context: dict[str, Any] | None = None,
    ) -> OperationCheckResult:
        """
        检查操作是否允许

        Args:
            operation: 操作类型
            path: 涉及的路径（可选）
            command: 要执行的命令（可选）
            extra_context: 额外上下文

        Returns:
            OperationCheckResult 包含判定结果
        """
        extra_context = extra_context or {}

        # 1. 检查是否是禁止操作
        if self._is_forbidden_operation(operation, path, command):
            return OperationCheckResult(
                verdict=OperationVerdict.FORBIDDEN,
                operation=operation,
                path=str(path) if path else None,
                reason=self._get_forbidden_reason(operation, path, command),
                details=extra_context,
            )

        # 2. 检查是否需要确认
        if self._needs_confirmation(operation, path, command):
            return OperationCheckResult(
                verdict=OperationVerdict.NEEDS_CONFIRM,
                operation=operation,
                path=str(path) if path else None,
                reason=self._get_confirm_reason(operation, path, command),
                details=extra_context,
            )

        # 3. 允许操作
        return OperationCheckResult(
            verdict=OperationVerdict.ALLOWED,
            operation=operation,
            path=str(path) if path else None,
            details=extra_context,
        )

    def _is_forbidden_operation(
        self,
        operation: str,
        path: Path | str | None,
        command: str | None,
    ) -> bool:
        """检查是否是禁止操作"""
        # 检查操作类型
        if operation in self.config.sandbox.forbidden_operations:
            return True

        # 检查路径逃逸
        if path and self.config.sandbox.enforce_isolation:
            if not self.is_within_sandbox(path):
                # 检查是否允许项目访问
                if not self.config.sandbox.allow_project_access:
                    return True
                # 项目访问需要检查是否在 workspace 内
                try:
                    Path(path).resolve().relative_to(self.workspace)
                except ValueError:
                    return True

        # 检查保护文件
        if path and operation in ("file_delete", "file_modify", "dir_delete"):
            if self.is_protected(path):
                return True

        # 检查危险命令
        if command:
            for pattern in self.DANGEROUS_COMMAND_PATTERNS:
                if pattern.lower() in command.lower():
                    if "file_delete" in self.config.sandbox.forbidden_operations:
                        return True

        # 检查删除共享资源
        if path and operation in ("file_delete", "dir_delete"):
            if self.is_shared_resource(path):
                return True

        return False

    def _needs_confirmation(
        self,
        operation: str,
        path: Path | str | None,
        command: str | None,
    ) -> bool:
        """检查是否需要确认"""
        # 检查操作类型
        if operation in self.config.sandbox.confirm_operations:
            return True

        # 删除操作总是需要确认
        if operation in ("file_delete", "dir_delete"):
            if self.config.sandbox.require_delete_confirmation:
                return True

        # 跨任务操作需要确认
        if path and self.config.sandbox.require_cross_task_confirmation:
            if self.current_task_dir and not self.is_within_current_task(path):
                # 检查是否在其他任务目录内
                path_obj = Path(path).resolve()
                try:
                    relative = path_obj.relative_to(self.tasks_dir)
                    # 如果路径在其他任务目录内
                    parts = relative.parts
                    if len(parts) >= 1 and parts[0] != self.current_task_id:
                        return True
                except ValueError:
                    pass

        # 项目目录访问需要确认
        if path and self.config.sandbox.allow_project_access:
            if not self.is_within_sandbox(path):
                try:
                    Path(path).resolve().relative_to(self.workspace)
                    return True  # 在 workspace 内但在沙箱外，需要确认
                except ValueError:
                    pass

        return False

    def _get_forbidden_reason(
        self,
        operation: str,
        path: Path | str | None,
        command: str | None,
    ) -> str:
        """获取禁止原因"""
        if path and not self.is_within_sandbox(path):
            return f"Path '{path}' is outside the OpenWork sandbox boundary"
        if path and self.is_protected(path):
            return f"Path '{path}' is protected and cannot be modified/deleted"
        if path and self.is_shared_resource(path):
            return f"Path '{path}' is a shared resource and cannot be deleted"
        if command:
            return f"Command '{command}' is classified as dangerous"
        return f"Operation '{operation}' is forbidden by security policy"

    def _get_confirm_reason(
        self,
        operation: str,
        path: Path | str | None,
        command: str | None,
    ) -> str:
        """获取需要确认的原因"""
        if operation in ("file_delete", "dir_delete"):
            return f"Delete operation on '{path}' requires confirmation"
        if path and not self.is_within_current_task(path):
            return f"Cross-task operation on '{path}' requires confirmation"
        if path and not self.is_within_sandbox(path):
            return f"Access to project path '{path}' requires confirmation"
        return f"Operation '{operation}' requires confirmation"

    # ==================== 命令检查 ====================

    def is_safe_command(self, command: str) -> bool:
        """
        检查命令是否安全

        Args:
            command: 要检查的命令

        Returns:
            True 如果命令是安全的
        """
        command_lower = command.strip().lower()

        # 检查是否在安全命令白名单中
        for safe_cmd in self.SAFE_COMMANDS:
            if command_lower.startswith(safe_cmd.lower()):
                return True

        # 检查是否包含危险模式
        for pattern in self.DANGEROUS_COMMAND_PATTERNS:
            if pattern.lower() in command_lower:
                return False

        # 未知命令默认需要确认
        return False

    def classify_command(self, command: str) -> str:
        """
        分类命令

        Args:
            command: 要分类的命令

        Returns:
            "safe", "confirm", 或 "dangerous"
        """
        command_lower = command.strip().lower()

        # 检查危险模式
        for pattern in self.DANGEROUS_COMMAND_PATTERNS:
            if pattern.lower() in command_lower:
                return "dangerous"

        # 检查安全命令
        for safe_cmd in self.SAFE_COMMANDS:
            if command_lower.startswith(safe_cmd.lower()):
                return "safe"

        # 未知命令需要确认
        return "confirm"

    # ==================== 任务目录管理 ====================

    def create_task_directory(self, task_id: str) -> Path:
        """
        为任务创建工作目录

        Args:
            task_id: 任务 ID

        Returns:
            任务目录路径
        """
        task_dir = self.config.get_task_dir(self.workspace, task_id)
        task_dir.mkdir(parents=True, exist_ok=True)

        # 创建标准子目录
        (task_dir / "src").mkdir(exist_ok=True)
        (task_dir / "docs").mkdir(exist_ok=True)
        (task_dir / "tests").mkdir(exist_ok=True)

        # 创建任务元数据文件
        import json
        from datetime import datetime

        metadata = {
            "task_id": task_id,
            "created_at": datetime.now().isoformat(),
            "status": "active",
        }
        (task_dir / ".task.json").write_text(json.dumps(metadata, indent=2))

        logger.info(f"Created task directory: {task_dir}")
        return task_dir

    def archive_task_directory(self, task_id: str) -> Path | None:
        """
        归档任务目录

        Args:
            task_id: 任务 ID

        Returns:
            归档后的路径，如果目录不存在则返回 None
        """
        task_dir = self.config.get_task_dir(self.workspace, task_id)
        if not task_dir.exists():
            return None

        # 移动到归档目录
        archive_path = self.archive_dir / task_id
        task_dir.rename(archive_path)

        logger.info(f"Archived task directory: {task_id}")
        return archive_path

    def get_task_info(self, task_id: str) -> dict | None:
        """
        获取任务信息

        Args:
            task_id: 任务 ID

        Returns:
            任务元数据，如果不存在则返回 None
        """
        import json

        task_dir = self.config.get_task_dir(self.workspace, task_id)
        metadata_file = task_dir / ".task.json"

        if not metadata_file.exists():
            return None

        try:
            return json.loads(metadata_file.read_text())
        except Exception:
            return None


class SecurityError(Exception):
    """安全错误"""
    pass
