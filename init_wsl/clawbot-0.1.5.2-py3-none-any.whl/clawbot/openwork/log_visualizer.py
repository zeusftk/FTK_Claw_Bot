"""
Log Visualizer - Real-time log visualization.

This module provides the log visualizer that displays execution
progress, decisions, and file changes in real-time.
"""

from loguru import logger
from dataclasses import dataclass
from datetime import datetime
from typing import TYPE_CHECKING, Callable

if TYPE_CHECKING:
    from clawbot.openwork.client import SSEEvent
    from clawbot.openwork.orchestrator import ActiveProject



@dataclass
class LogEntry:
    timestamp: datetime
    session_id: str
    event_type: str
    message: str
    details: dict
    icon: str = "📌"


class LogVisualizer:
    """Log visualizer - real-time log display."""

    ICONS = {
        "progress": "💡",
        "todo_update": "📋",
        "permission_request": "⚙️",
        "error": "❌",
        "completed": "🎉",
        "file_change": "📁",
        "warning": "⚠️",
        "info": "ℹ️",
    }

    STAGE_ICONS = {
        "需求分析": "🔍",
        "方案设计": "🏗️",
        "编码实现": "💻",
        "测试验证": "🧪",
        "部署发布": "🚀",
    }

    def __init__(
        self,
        output_mode: str = "cli",
        websocket_push: Callable[[dict], None] | None = None,
        buffer_size: int = 1000,
    ):
        self.mode = output_mode
        self.websocket_push = websocket_push
        self.buffer_size = buffer_size
        self.buffer: list[LogEntry] = []
        self._current_stage: str = ""
        self._stage_logs: list[LogEntry] = []

    def emit(self, event: "SSEEvent"):
        """Emit a log entry."""
        event_type = event.type.value if hasattr(event.type, "value") else str(event.type)

        entry = LogEntry(
            timestamp=event.timestamp,
            session_id=event.session_id,
            event_type=event_type,
            message=event.data.get("message", ""),
            details=event.data,
            icon=self.ICONS.get(event_type, "📌"),
        )

        self.buffer.append(entry)
        if len(self.buffer) > self.buffer_size:
            self.buffer = self.buffer[-self.buffer_size:]

        stage = event.data.get("stage", "")
        if stage and stage != self._current_stage:
            self._flush_stage()
            self._current_stage = stage
            self._print_stage_header(stage)

        self._stage_logs.append(entry)

        if self.mode == "cli":
            self._render_cli(entry)
        elif self.mode == "websocket" and self.websocket_push:
            self._push_websocket(entry)

    def _print_stage_header(self, stage: str):
        """Print stage header."""
        icon = self.STAGE_ICONS.get(stage, "📋")
        print(f"\n{icon} 阶段: {stage}")
        print("├── ", end="")

    def _render_cli(self, entry: LogEntry):
        """Render to CLI."""
        timestamp = entry.timestamp.strftime("%H:%M:%S")
        indent = "│  " if len(self._stage_logs) > 1 else ""

        print(f"{indent}[{timestamp}] {entry.icon} {entry.message}")

        if entry.event_type == "file_change":
            details = entry.details
            path = details.get("path", "unknown")
            operation = details.get("operation", "modify")
            lines_added = details.get("lines_added", 0)
            lines_removed = details.get("lines_removed", 0)
            print(f"{indent}    📄 {path} ({operation}, +{lines_added}/-{lines_removed})")

        elif entry.event_type == "permission_request":
            details = entry.details
            perm_type = details.get("type", "unknown")
            print(f"{indent}    🔐 类型: {perm_type}")

    def _push_websocket(self, entry: LogEntry):
        """Push to WebSocket."""
        self.websocket_push({
            "type": "log",
            "data": {
                "timestamp": entry.timestamp.isoformat(),
                "session_id": entry.session_id,
                "event_type": entry.event_type,
                "message": entry.message,
                "icon": entry.icon,
                "details": entry.details,
            }
        })

    def _flush_stage(self):
        """Flush stage logs."""
        self._stage_logs.clear()

    def render_summary(self, project: "ActiveProject"):
        """Render project summary."""
        print("\n" + "=" * 50)
        print(f"📋 项目：{project.original_idea[:50]}")
        print(f"📁 工作目录：{project.workspace}")
        print(f"⏱️ 创建时间：{project.created_at.strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"📊 状态：{project.status.value}")

        if project.todos:
            print("\n📝 任务列表:")
            for todo in project.todos:
                status = todo.get("status", "pending")
                text = todo.get("text", "")
                status_icon = "✅" if status == "completed" else "⏳" if status == "in_progress" else "⏸️"
                print(f"  {status_icon} {text}")

        if project.events:
            completed = sum(1 for e in project.events if e.get("type") == "completed")
            errors = sum(1 for e in project.events if e.get("type") == "error")
            permissions = sum(1 for e in project.events if e.get("type") == "permission_request")
            print("\n📊 统计:")
            print(f"  - 完成事件：{completed}")
            print(f"  - 错误事件：{errors}")
            print(f"  - 权限请求：{permissions}")

        print("=" * 50)

    def render_progress_bar(self, progress: float, width: int = 30):
        """Render a progress bar."""
        filled = int(width * progress / 100)
        empty = width - filled
        bar = "█" * filled + "░" * empty
        print(f"\r[{bar}] {progress:.0f}%", end="", flush=True)

    def get_recent_logs(self, count: int = 10) -> list[LogEntry]:
        """Get recent logs."""
        return self.buffer[-count:]

    def get_logs_by_session(self, session_id: str) -> list[LogEntry]:
        """Get logs for a session."""
        return [e for e in self.buffer if e.session_id == session_id]

    def clear_buffer(self):
        """Clear the buffer."""
        self.buffer.clear()
        self._stage_logs.clear()
        self._current_stage = ""

    def set_websocket_push(self, callback: Callable[[dict], None]):
        """Set WebSocket push callback."""
        self.websocket_push = callback
        if self.mode != "websocket":
            self.mode = "websocket"
