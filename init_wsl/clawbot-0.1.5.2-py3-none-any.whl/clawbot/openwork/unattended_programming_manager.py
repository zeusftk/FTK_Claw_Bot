"""
Unattended Programming Manager - 无人值守编程管理器

整合所有组件，提供统一的无人值守编程接口。

v2.0 更新：
- 集成 clawbotMaster 统一控制器
- 集成 HybridEvolutionEngine 混合进化引擎
- 集成增强版 MemoryManager、ProgressMonitor、FeedbackProcessor
"""

from __future__ import annotations

import asyncio
from loguru import logger
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable

if TYPE_CHECKING:
    from clawbot.openwork.feedback_collector import Feedback
    from clawbot.openwork.idea_processor import ProcessedIdea
    from clawbot.openwork.progress_reporter import ProgressEvent
    from clawbot.openwork.task_router import ExecutionResult, RouteDecision
    from clawbot.services.openwork_service import OpenWorkService



class ProjectStatus(Enum):
    IDLE = "idle"
    ANALYZING = "analyzing"
    PENDING_CONFIRMATION = "pending_confirmation"
    RUNNING = "running"
    WAITING_FEEDBACK = "waiting_feedback"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class Project:
    project_id: str
    user_id: str
    original_idea: str
    status: ProjectStatus = ProjectStatus.IDLE
    workspace: Path | None = None
    processed_idea: ProcessedIdea | None = None
    session_id: str | None = None
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    started_at: datetime | None = None
    completed_at: datetime | None = None
    result: ExecutionResult | None = None
    feedback: Feedback | None = None
    route_decision: RouteDecision | None = None
    execution_result: ExecutionResult | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    idea: str = ""

    @property
    def duration_seconds(self) -> float:
        if self.started_at and self.completed_at:
            return (self.completed_at - self.started_at).total_seconds()
        return 0.0

    @property
    def is_active(self) -> bool:
        return self.status in [
            ProjectStatus.ANALYZING,
            ProjectStatus.PENDING_CONFIRMATION,
            ProjectStatus.RUNNING,
        ]


class UnattendedProgrammingManager:
    """
    无人值守编程管理器

    整合所有组件，提供统一的无人值守编程接口：
    1. 需求分析与方案制定
    2. 任务路由与执行
    3. 进度监控与报告
    4. 反馈收集与自我进化

    v2.0 更新：
    - 支持使用 clawbotMaster 作为统一控制器
    - 支持使用 HybridEvolutionEngine 进行混合进化
    - 支持增强版 MemoryManager、ProgressMonitor、FeedbackProcessor
    """

    def __init__(
        self,
        workspace: Path,
        openwork_service: "OpenWorkService | None" = None,
        llm_provider: Any = None,
        on_progress: Callable[[ProgressEvent], None] | None = None,
        on_completed: Callable[[Project], None] | None = None,
        on_feedback_request: Callable[[str, str], None] | None = None,
        enable_evolution: bool = True,
        evolution_interval_hours: int = 24,
        use_enhanced_components: bool = True,
    ):
        self.workspace = workspace
        self.openwork = openwork_service
        self.llm_provider = llm_provider
        self._on_progress = on_progress
        self._on_completed = on_completed
        self._on_feedback_request = on_feedback_request
        self._use_enhanced = use_enhanced_components

        self._init_components(enable_evolution, evolution_interval_hours)

        self._projects: dict[str, Project] = {}
        self._running = False

        self._ensure_workspace()

    def _init_components(
        self,
        enable_evolution: bool,
        evolution_interval_hours: int,
    ) -> None:
        """初始化组件"""
        from clawbot.openwork.idea_processor import IdeaProcessor
        from clawbot.openwork.session_manager import SessionManager
        from clawbot.openwork.task_router import TaskRouter

        if self._use_enhanced:
            try:
                from clawbot.feedback.processor import FeedbackProcessor
                from clawbot.memory.manager import MemoryManager
                from clawbot.progress.monitor import ProgressMonitor

                self.memory = MemoryManager(workspace=self.workspace / "memory")
                self.progress_monitor = ProgressMonitor(
                    on_milestone=self._handle_milestone,
                    on_anomaly=self._handle_anomaly,
                )
                self.feedback_processor = FeedbackProcessor(
                    memory=self.memory.bridge,
                    on_feedback_processed=self._handle_feedback_processed,
                )
                self.feedback_collector = self.feedback_processor

                logger.info("Using enhanced components")
            except ImportError as e:
                logger.warning(f"Enhanced components not available, using defaults: {e}")
                self._init_default_components()
        else:
            self._init_default_components()

        self.idea_processor = IdeaProcessor(
            llm_provider=self.llm_provider,
            workspace=self.workspace,
        )

        self.progress_reporter = self._get_progress_reporter()

        self.task_router = TaskRouter(
            openwork_service=self.openwork,
            default_workspace=self.workspace,
        )

        self.session_manager = SessionManager(
            openwork_service=self.openwork,
            workspace_root=self.workspace / "sessions",
        )

        if enable_evolution:
            self._init_evolution(evolution_interval_hours)
        else:
            self._evolution_scheduler = None
            self.evolution_engine = None

    def _init_default_components(self) -> None:
        """初始化默认组件"""
        from clawbot.openwork.feedback_collector import FeedbackCollector
        from clawbot.openwork.memory import OpenWorkMemoryBridge
        from clawbot.openwork.pattern_extractor import PatternExtractor
        from clawbot.openwork.self_enhancer import SelfEnhancer

        self.memory = OpenWorkMemoryBridge(workspace=self.workspace / "memory")
        self.feedback_collector = FeedbackCollector(
            memory_bridge=self.memory,
            on_feedback_collected=self._handle_feedback_collected,
        )
        self.pattern_extractor = PatternExtractor(memory_bridge=self.memory)
        self.self_enhancer = SelfEnhancer(
            memory_bridge=self.memory,
            pattern_extractor=self.pattern_extractor,
        )
        self.progress_monitor = None
        self.feedback_processor = None

    def _get_progress_reporter(self):
        """获取进度报告器"""
        from clawbot.openwork.progress_reporter import ProgressReporter

        return ProgressReporter(
            base_url=self.openwork.base_url if self.openwork else "http://localhost:7777",
            on_progress=self._handle_progress_event,
        )

    def _init_evolution(self, interval_hours: int) -> None:
        """初始化进化系统"""
        try:
            from clawbot.evolution.hybrid_engine import HybridEvolutionEngine
            from clawbot.evolution.scheduler import EvolutionScheduler

            feedback_processor = getattr(self, 'feedback_processor', None)

            self.evolution_engine = HybridEvolutionEngine(
                memory=self.memory,
                llm=self.llm_provider,
                feedback_processor=feedback_processor,
            )

            self._evolution_scheduler = EvolutionScheduler(
                engine=self.evolution_engine,
                interval_hours=interval_hours,
            )

            logger.info("Using HybridEvolutionEngine")
        except ImportError:
            from clawbot.openwork.self_enhancer import EnhancementScheduler

            self.evolution_engine = None
            self._evolution_scheduler = EnhancementScheduler(
                self_enhancer=self.self_enhancer,
                interval_hours=interval_hours,
            )
            logger.info("Using legacy SelfEnhancer")

    def _ensure_workspace(self) -> None:
        self.workspace.mkdir(parents=True, exist_ok=True)
        (self.workspace / "memory").mkdir(parents=True, exist_ok=True)
        (self.workspace / "sessions").mkdir(parents=True, exist_ok=True)

    async def start(self) -> None:
        if self._running:
            return

        self._running = True

        await self.session_manager.start()

        if self._evolution_scheduler:
            await self._evolution_scheduler.start()

        logger.info("UnattendedProgrammingManager started")

    async def stop(self) -> None:
        if not self._running:
            return

        self._running = False

        if self._evolution_scheduler:
            await self._evolution_scheduler.stop()

        await self.session_manager.stop()
        await self.progress_reporter.stop_listening()

        logger.info("UnattendedProgrammingManager stopped")

    async def submit_idea(
        self,
        idea: str,
        user_id: str = "default",
        workspace: Path | None = None,
    ) -> Project:
        """
        提交用户想法，开始无人值守编程流程

        Args:
            idea: 用户原始想法
            user_id: 用户 ID
            workspace: 工作目录

        Returns:
            Project 项目对象
        """
        import uuid

        project_id = f"proj-{uuid.uuid4().hex[:8]}"
        ws = workspace or self.workspace / user_id / project_id


        project = Project(
            project_id=project_id,
            user_id=user_id,
            original_idea=idea,
            status=ProjectStatus.IDLE,
            workspace=ws,
        )

        self._projects[project_id] = project

        logger.info(f"Project created: {project_id} for user {user_id}")

        try:
            project.status = ProjectStatus.ANALYZING
            project.updated_at = datetime.now()

            processed = await self.idea_processor.process(idea, user_id)
            project.processed_idea = processed

            logger.info(f"Idea processed: {project_id}, type: {processed.task_type.value}")

            if processed.clarifications_needed:
                if self._on_feedback_request:
                    clarification = await self.idea_processor.clarify(
                        idea,
                        processed.clarifications_needed,
                    )
                    self._on_feedback_request(project_id, clarification)

                    project.status = ProjectStatus.PENDING_CONFIRMATION
                    project.updated_at = datetime.now()
                    return project

            route_decision = await self.task_router.route(processed)

            if route_decision.requires_confirmation:
                if self._on_feedback_request:
                    self._on_feedback_request(
                        project_id,
                        route_decision.confirmation_message or "需要确认执行",
                    )
                project.status = ProjectStatus.PENDING_CONFIRMATION
                project.updated_at = datetime.now()
                return project

            project.status = ProjectStatus.RUNNING
            project.started_at = datetime.now()
            project.updated_at = datetime.now()

            await self.progress_reporter.start_listening()

            result = await self.task_router.execute(route_decision, idea, ws)

            project.result = result
            project.session_id = result.session_id

            if result.success:
                project.status = ProjectStatus.WAITING_FEEDBACK
                project.completed_at = datetime.now()

                await self._request_feedback(project)
            else:
                project.status = ProjectStatus.FAILED
                project.completed_at = datetime.now()

            project.updated_at = datetime.now()

            if self._on_completed:
                self._on_completed(project)

            return project

        except Exception as e:
            logger.error(f"Project execution failed: {project_id} - {e}")
            project.status = ProjectStatus.FAILED
            project.completed_at = datetime.now()
            project.updated_at = datetime.now()
            project.metadata["error"] = str(e)

            if self._on_completed:
                self._on_completed(project)

            return project

    async def _request_feedback(self, project: Project) -> None:
        """请求用户反馈"""
        feedback = await self.feedback_collector.collect(
            project.project_id,
            project.user_id,
            timeout=300.0,
        )

        if feedback:
            project.feedback = feedback
            await self._process_feedback(project, feedback)

    async def _process_feedback(self, project: Project, feedback: Feedback) -> None:
        """处理反馈"""
        result = await self.feedback_collector.process_feedback(feedback)

        if feedback.rating and feedback.rating >= 4:
            await self.memory.archive_success_case(
                idea=project.original_idea,
                result={
                    "summary": project.result.output[:500] if project.result else "",
                    "workspace_snapshot": str(project.workspace),
                },
                quality_score=feedback.rating,
                decisions=[{"project_id": project.project_id}],
            )

        project.status = ProjectStatus.COMPLETED
        project.updated_at = datetime.now()

        logger.info(
            f"Project completed: {project.project_id}, "
            f"rating: {feedback.rating}, "
            f"patterns: {result.patterns_extracted}, "
            f"rules: {result.rules_updated}"
        )

    def confirm_project(self, project_id: str, approved: bool = True) -> Project | None:
        """确认项目执行"""
        project = self._projects.get(project_id)
        if not project:
            return None

        if project.status != ProjectStatus.PENDING_CONFIRMATION:
            return project

        if approved:
            asyncio.create_task(self._execute_approved_project(project))
        else:
            project.status = ProjectStatus.CANCELLED
            project.updated_at = datetime.now()

        return project

    async def _execute_approved_project(self, project: Project) -> None:
        """执行已确认的项目"""
        try:
            project.status = ProjectStatus.RUNNING
            project.started_at = datetime.now()
            project.updated_at = datetime.now()

            await self.progress_reporter.start_listening()

            route_decision = await self.task_router.route(project.processed_idea)
            result = await self.task_router.execute(
                route_decision,
                project.original_idea,
                project.workspace,
            )

            project.result = result
            project.session_id = result.session_id

            if result.success:
                project.status = ProjectStatus.WAITING_FEEDBACK
                project.completed_at = datetime.now()
                await self._request_feedback(project)
            else:
                project.status = ProjectStatus.FAILED
                project.completed_at = datetime.now()

            project.updated_at = datetime.now()

            if self._on_completed:
                self._on_completed(project)

        except Exception as e:
            logger.error(f"Approved project execution failed: {project.project_id} - {e}")
            project.status = ProjectStatus.FAILED
            project.completed_at = datetime.now()
            project.updated_at = datetime.now()
            project.metadata["error"] = str(e)

    async def provide_feedback(
        self,
        project_id: str,
        rating: int,
        comment: str | None = None,
    ) -> bool:
        """提供反馈"""
        project = self._projects.get(project_id)
        if not project:
            return False

        if project.status != ProjectStatus.WAITING_FEEDBACK:
            return False

        feedback = await self.feedback_collector.submit_direct(
            project_id=project.project_id,
            user_id=project.user_id,
            rating=rating,
            comment=comment,
        )

        project.feedback = feedback

        asyncio.create_task(self._process_feedback(project, feedback))

        return True

    def get_project(self, project_id: str) -> Project | None:
        """获取项目"""
        return self._projects.get(project_id)

    def get_user_projects(
        self,
        user_id: str,
        status: ProjectStatus | None = None,
    ) -> list[Project]:
        """获取用户的项目列表"""
        projects = [
            p for p in self._projects.values()
            if p.user_id == user_id
        ]

        if status:
            projects = [p for p in projects if p.status == status]

        return sorted(projects, key=lambda x: x.created_at, reverse=True)

    def get_active_project(self, user_id: str) -> Project | None:
        """获取用户的活跃项目"""
        for project in self._projects.values():
            if project.user_id == user_id and project.is_active:
                return project
        return None

    def _handle_progress_event(self, event: ProgressEvent) -> None:
        """处理进度事件"""
        if self._on_progress:
            try:
                self._on_progress(event)
            except Exception as e:
                logger.error(f"Progress callback error: {e}")

    def _handle_feedback_collected(self, feedback: Feedback) -> None:
        """处理反馈收集事件"""
        logger.info(f"Feedback collected: {feedback.feedback_id}, rating: {feedback.rating}")

    def _handle_milestone(self, milestone: Any) -> None:
        """处理里程碑事件"""
        logger.info(f"Milestone reached: {milestone.name} ({milestone.progress_percent}%)")

    def _handle_anomaly(self, anomaly: Any) -> None:
        """处理异常事件"""
        logger.warning(f"Anomaly detected: {anomaly.anomaly_type} - {anomaly.message}")

    def _handle_feedback_processed(self, processed_feedback: Any) -> None:
        """处理反馈处理完成事件"""
        sentiment_str = "N/A"
        if processed_feedback.sentiment:
            sentiment_str = processed_feedback.sentiment.sentiment
        suggestions_count = len(processed_feedback.suggestions) if processed_feedback.suggestions else 0
        logger.info(
            f"Feedback processed: sentiment={sentiment_str}, "
            f"suggestions={suggestions_count}"
        )

    async def trigger_evolution(self) -> dict[str, Any]:
        """手动触发自我进化"""
        if not self._evolution_scheduler:
            return {"error": "Evolution not enabled"}

        result = await self._evolution_scheduler.trigger_enhancement()

        return {
            "timestamp": result.timestamp.isoformat(),
            "adjustments": result.adjustments,
            "new_rules": result.new_rules,
            "prompt_updates": result.prompt_updates,
            "recommendations": result.recommendations,
        }

    async def get_stats(self) -> dict[str, Any]:
        """获取统计信息"""
        memory_stats = await self.memory.get_stats()

        projects_by_status = {}
        for project in self._projects.values():
            status = project.status.value
            projects_by_status[status] = projects_by_status.get(status, 0) + 1

        return {
            "running": self._running,
            "total_projects": len(self._projects),
            "projects_by_status": projects_by_status,
            "memory": memory_stats,
            "router": self.task_router.get_stats(),
            "sessions": self.session_manager.get_stats(),
            "feedback": self.feedback_collector.get_stats(),
        }
