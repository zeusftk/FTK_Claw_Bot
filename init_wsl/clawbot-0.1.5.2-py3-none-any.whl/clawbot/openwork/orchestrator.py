"""
OpenWork Orchestrator - Task orchestration for OpenWork integration.

This module provides the main orchestrator that manages OpenWork
sessions, handles permission requests, and coordinates with the
decision engine and memory system.
"""

import asyncio
import atexit
import shutil
import subprocess
import uuid
import weakref
from contextlib import AsyncExitStack
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Any, Awaitable, Protocol, runtime_checkable

import aiohttp
from loguru import logger

from clawbot.constants import OPENWORK_DEFAULT_URL
from clawbot.openwork.client import (
    OpenWorkClient,
    PermissionRequest,
    SSEEvent,
)

if TYPE_CHECKING:
    from clawbot.openwork.decision_engine import AIPMDecisionEngine
    from clawbot.openwork.log_visualizer import LogVisualizer
    from clawbot.openwork.memory import OpenWorkMemoryBridge



# ---------------------------------------------------------------------------
# Protocol definitions
# ---------------------------------------------------------------------------

@runtime_checkable
class SendMessageProtocol(Protocol):
    """Protocol for send_message callback."""

    def __call__(self, user_id: str, content: str) -> Awaitable[None] | None:
        ...


class ProjectStatus(Enum):
    IDLE = "idle"
    RUNNING = "running"
    WAITING_PERMISSION = "waiting_permission"
    WAITING_USER = "waiting_user"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class ActiveProject:
    project_id: str
    user_id: str
    session_id: str
    workspace: Path
    original_idea: str
    status: ProjectStatus
    created_at: datetime
    events: list[dict] = field(default_factory=list)
    todos: list[dict] = field(default_factory=list)


class OpenWorkOrchestrator:
    """OpenWork orchestrator - manages OpenWork Orchestrator connection."""

    def __init__(
        self,
        openwork_url: str = OPENWORK_DEFAULT_URL,
        decision_engine: "AIPMDecisionEngine | None" = None,
        memory_store: "OpenWorkMemoryBridge | None" = None,
        log_visualizer: "LogVisualizer | None" = None,
        send_message: SendMessageProtocol | None = None,
        default_workspace: Path | None = None,
    ):
        self.openwork_url = openwork_url
        self.decision_engine = decision_engine
        self.memory_store = memory_store
        self.log_visualizer = log_visualizer
        self.send_message = send_message or print
        self.default_workspace = default_workspace or Path.home() / "clawbot-workspace"

        self.projects: dict[str, ActiveProject] = {}
        self._client: OpenWorkClient | None = None
        self._listener_task: asyncio.Task | None = None
        self._permission_futures: dict[str, asyncio.Future] = {}
        self._running = False
        self._service_process: subprocess.Popen | None = None
        self._service_workspace: Path | None = None
        self._exit_stack: AsyncExitStack | None = None
        self._stderr_reader: asyncio.Task | None = None

        self._finalizer = weakref.finalize(self, self._cleanup_process, self)
        atexit.register(self._atexit_cleanup)

    async def start(self):
        """Start the orchestrator."""
        self._running = True
        self._client = OpenWorkClient(
            base_url=self.openwork_url,
            on_permission_request=self._handle_permission_request,
            on_progress=self._handle_progress,
            on_error=self._handle_error,
        )
        self._exit_stack = AsyncExitStack()
        await self._exit_stack.__aenter__()
        await self._exit_stack.enter_async_context(self._client)

        self._listener_task = asyncio.create_task(
            self._run_event_listener()
        )
        logger.info(f"OpenWork Orchestrator started, connected to {self.openwork_url}")

    async def stop(self):
        """Stop the orchestrator."""
        self._running = False
        if self._listener_task:
            self._listener_task.cancel()
            try:
                await self._listener_task
            except asyncio.CancelledError:
                pass
        if self._exit_stack:
            await self._exit_stack.aclose()
            self._exit_stack = None
        self._client = None
        logger.info("OpenWork Orchestrator stopped")

    async def _run_event_listener(self):
        """Run the event listener loop."""
        while self._running:
            try:
                await self._client.start_event_listener()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Event listener error: {e}")
                if self._running:
                    await asyncio.sleep(5)

    async def start_project(
        self,
        user_idea: str,
        user_id: str,
        workspace: Path | None = None,
    ) -> str:
        """Start a new project."""
        project_id = f"proj-{uuid.uuid4().hex[:8]}"
        ws = workspace or self._get_default_workspace(user_id)
        ws.mkdir(parents=True, exist_ok=True)

        try:
            session = await self._client.create_session(
                title=user_idea[:50],
                cwd=str(ws),
            )
        except Exception as e:
            logger.error(f"Failed to create session: {e}")
            raise

        project = ActiveProject(
            project_id=project_id,
            user_id=user_id,
            session_id=session["id"],
            workspace=ws,
            original_idea=user_idea,
            status=ProjectStatus.IDLE,
            created_at=datetime.now(),
        )

        self.projects[project_id] = project
        self._client.register_project(session["id"], project_id)

        await self._client.send_message(session["id"], user_idea)
        project.status = ProjectStatus.RUNNING

        self.send_message(
            user_id,
            f"🚀 项目已启动: {project_id}\n"
            f"📁 工作目录: {ws}\n"
            f"⏳ 正在执行..."
        )

        logger.info(f"Project started: {project_id} for user {user_id}")
        return project_id

    async def _handle_permission_request(
        self,
        request: PermissionRequest
    ) -> str:
        """Handle a permission request - core graded decision logic."""
        project = self._find_project_by_session(request.session_id)
        if not project:
            logger.warning(f"No project found for session {request.session_id}")
            return "deny"

        project.status = ProjectStatus.WAITING_PERMISSION

        self.send_message(
            project.user_id,
            "⚙️ 遇到权限请求，正在由 AI PM 评估..."
        )

        if self.decision_engine:
            decision = await self.decision_engine.evaluate(
                user_idea=project.original_idea,
                event_details={
                    "type": request.type,
                    "message": request.message,
                    "details": request.details,
                },
                project_context={
                    "workspace": str(project.workspace),
                    "events": project.events[-10:],
                }
            )

            if decision.level in ["auto_safe", "auto_resolve"]:
                self.send_message(
                    project.user_id,
                    f"✅ 已自动批准: {decision.summary or request.message}"
                )

                if self.memory_store:
                    await self.memory_store.record_decision({
                        "project_id": project.project_id,
                        "event_type": "permission_request",
                        "event_details": {
                            "type": request.type,
                            "message": request.message,
                        },
                        "decision_level": decision.level,
                        "was_auto_resolved": True,
                    })

                project.status = ProjectStatus.RUNNING
                logger.info(f"Auto-approved permission for project {project.project_id}")
                return "allow"

        project.status = ProjectStatus.WAITING_USER

        human_msg = f"""⚠️ 需要您决策:

{request.message}

详情: {request.details}

请回复 "允许" 或 "拒绝"."""

        self.send_message(project.user_id, human_msg)

        future = asyncio.Future()
        self._permission_futures[request.permission_id] = future

        try:
            response = await asyncio.wait_for(future, timeout=300)
            project.status = ProjectStatus.RUNNING
            logger.info(f"User responded to permission: {response}")
            return response
        except asyncio.TimeoutError:
            project.status = ProjectStatus.RUNNING
            logger.warning(f"Permission request timed out for project {project.project_id}")
            return "deny"

    def respond_to_permission(
        self,
        permission_id: str,
        response: str
    ):
        """User responds to a permission request."""
        if permission_id in self._permission_futures:
            self._permission_futures[permission_id].set_result(response)
            del self._permission_futures[permission_id]

    async def _handle_progress(self, event: SSEEvent):
        """Handle a progress event."""
        project = self._find_project_by_session(event.session_id)
        if project:
            project.events.append(event.data)

            if "todos" in event.data:
                project.todos = event.data["todos"]

            if self.log_visualizer:
                self.log_visualizer.emit(event)

            if event.data.get("is_milestone"):
                self.send_message(
                    project.user_id,
                    f"💡 进度更新: {event.data.get('message', '')}"
                )

    async def _handle_error(self, event: SSEEvent):
        """Handle an error event."""
        project = self._find_project_by_session(event.session_id)
        if project:
            project.status = ProjectStatus.FAILED
            self.send_message(
                project.user_id,
                f"❌ 执行出错: {event.data.get('error', 'Unknown error')}"
            )
            logger.error(f"Project {project.project_id} failed: {event.data}")

    def _find_project_by_session(self, session_id: str) -> ActiveProject | None:
        """Find a project by session ID."""
        for project in self.projects.values():
            if project.session_id == session_id:
                return project
        return None

    def _find_project_by_user(self, user_id: str) -> ActiveProject | None:
        """Find the most recent active project for a user."""
        user_projects = [
            p for p in self.projects.values()
            if p.user_id == user_id and p.status in [
                ProjectStatus.RUNNING,
                ProjectStatus.WAITING_PERMISSION,
                ProjectStatus.WAITING_USER,
            ]
        ]
        if user_projects:
            return max(user_projects, key=lambda p: p.created_at)
        return None

    def _get_default_workspace(self, user_id: str) -> Path:
        """Get the default workspace for a user."""
        return self.default_workspace / user_id

    def get_project(self, project_id: str) -> ActiveProject | None:
        """Get a project by ID."""
        return self.projects.get(project_id)

    def get_user_active_project(self, user_id: str) -> ActiveProject | None:
        """Get the active project for a user."""
        return self._find_project_by_user(user_id)

    @staticmethod
    def is_installed() -> bool:
        """Check if clawbot is installed (required for openwork-server)."""
        return shutil.which("clawbot") is not None

    @staticmethod
    async def check_health(url: str | None = None, timeout: float = 5.0) -> bool:
        """Check if the OpenWork service is healthy.

        Args:
            url: Service URL. If None, uses default localhost:7777
            timeout: Request timeout in seconds

        Returns:
            True if service is healthy, False otherwise
        """
        check_url = url or "http://localhost:7777"
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    f"{check_url}/health",
                    timeout=aiohttp.ClientTimeout(total=timeout)
                ) as resp:
                    return resp.status == 200
        except (aiohttp.ClientError, asyncio.TimeoutError) as e:
            logger.debug("Health check failed: %s", e)
            return False

    async def ensure_service(
        self,
        workspace: Path | None = None,
        port: int = 7777,
        auto_start: bool = True,
    ) -> bool:
        """Ensure the OpenWork service is running, start if needed.

        Args:
            workspace: Service workspace directory. If None, uses default.
            port: Service port
            auto_start: Whether to auto-start the service if not running

        Returns:
            True if service is available, False otherwise
        """
        if workspace:
            self._service_workspace = workspace
        else:
            self._service_workspace = self.default_workspace / "openworks"

        self._service_workspace.mkdir(parents=True, exist_ok=True)

        url = f"http://localhost:{port}"
        if await self.check_health(url):
            logger.info(f"OpenWork service is already running at {url}")
            self.openwork_url = url
            return True

        if not auto_start:
            logger.info("OpenWork service is not running and auto_start is disabled")
            return False

        if not self.is_installed():
            logger.warning("OpenWork is not installed, cannot auto-start service")
            return False

        logger.info(f"Starting OpenWork service: port={port}, workspace={self._service_workspace}")
        return await self._start_service(self._service_workspace, port)

    async def _start_service(self, workspace: Path, port: int) -> bool:
        try:
            # 使用 clawbot 内置的 openwork-server
            self._service_process = subprocess.Popen(
                [
                    "clawbot", "openwork-server",
                    "--workspace", str(workspace),
                    "--port", str(port),
                    "--approval", "auto",
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
            )

            self._stderr_reader = asyncio.create_task(
                self._read_stderr(self._service_process)
            )

            url = f"http://localhost:{port}"
            for _ in range(60):
                await asyncio.sleep(0.5)
                if await self.check_health(url):
                    self.openwork_url = url
                    logger.info(f"OpenWork service started successfully at {url}")
                    return True

            logger.error("OpenWork service failed to start within timeout")
            if self._service_process:
                self._service_process.terminate()
                try:
                    self._service_process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    self._service_process.kill()
                    self._service_process.wait()
                self._service_process = None
            return False

        except Exception as e:
            logger.error(f"Failed to start OpenWork service: {e}")
            if self._service_process:
                try:
                    self._service_process.terminate()
                    self._service_process.wait(timeout=5)
                except (subprocess.TimeoutExpired, OSError) as e:
                    logger.debug("Process cleanup error ignored: %s", e)
                self._service_process = None
            return False

    async def _read_stderr(self, process: subprocess.Popen) -> None:
        """Read stderr to prevent pipe buffer from filling."""
        while process.poll() is None:
            if process.stderr:
                try:
                    line = process.stderr.readline()
                    if line:
                        logger.debug("OpenWork stderr: %s", line.decode().strip())
                except OSError:
                    break
            await asyncio.sleep(0.1)

    async def stop_service(self) -> None:
        """Stop the OpenWork service process."""
        if self._stderr_reader:
            self._stderr_reader.cancel()
            try:
                await self._stderr_reader
            except asyncio.CancelledError:
                pass
            self._stderr_reader = None

        if self._service_process:
            logger.info("Stopping OpenWork service...")
            self._service_process.terminate()
            try:
                self._service_process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self._service_process.kill()
                self._service_process.wait()
            self._service_process = None
            logger.info("OpenWork service stopped")

    def get_service_status(self) -> dict[str, Any]:
        """Get the service status information.

        Returns:
            Dictionary with service status details
        """
        return {
            "name": "openwork",
            "installed": self.is_installed(),
            "running": self._service_process is not None,
            "url": self.openwork_url,
            "workspace": str(self._service_workspace) if self._service_workspace else None,
            "projects": len(self.projects),
        }

    @staticmethod
    def _cleanup_process(self_ref: "OpenWorkOrchestrator") -> None:
        """Cleanup function called by weakref finalizer."""
        process = self_ref._service_process
        if process is not None:
            try:
                process.terminate()
                process.wait(timeout=5)
            except (subprocess.TimeoutExpired, OSError) as e:
                logger.debug("Process cleanup error in finalizer: %s", e)
                try:
                    process.kill()
                    process.wait()
                except OSError as e:
                    logger.debug("Process kill error in finalizer: %s", e)
            self_ref._service_process = None

    def _atexit_cleanup(self) -> None:
        """Cleanup function registered with atexit."""
        if self._service_process is not None:
            try:
                self._service_process.terminate()
                self._service_process.wait(timeout=5)
            except (subprocess.TimeoutExpired, OSError) as e:
                logger.debug("Process cleanup error in atexit: %s", e)
                try:
                    self._service_process.kill()
                    self._service_process.wait()
                except OSError as e:
                    logger.debug("Process kill error in atexit: %s", e)
            self._service_process = None
