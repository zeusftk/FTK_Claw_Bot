"""
OpenWork Approval Handler - 操作审批处理器

职责：
1. 处理需要确认的操作
2. 生成用户友好的确认请求
3. 记录审批历史
4. 支持多种确认渠道

使用方式：
    handler = ApprovalHandler(config, sandbox)

    # 请求审批
    request = handler.request_approval(
        operation="file_delete",
        path="/path/to/file",
        reason="Delete temporary file",
    )

    # 等待用户响应
    result = await handler.wait_for_response(request.id)
"""

from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Callable

from loguru import logger

from .sandbox import OperationVerdict


class ApprovalStatus(str, Enum):
    """审批状态"""
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    TIMEOUT = "timeout"
    CANCELLED = "cancelled"


@dataclass
class ApprovalRequest:
    """审批请求"""
    id: str
    operation: str
    path: str | None
    reason: str
    details: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.now)
    status: ApprovalStatus = ApprovalStatus.PENDING
    responded_at: datetime | None = None
    response_reason: str | None = None
    responder: str | None = None


@dataclass
class ApprovalResponse:
    """审批响应"""
    request_id: str
    approved: bool
    reason: str | None = None
    responder: str | None = None


class ApprovalHandler:
    """
    操作审批处理器

    处理需要用户确认的操作，包括：
    1. 文件删除
    2. 跨任务操作
    3. 危险命令
    4. 项目目录访问

    Example:
        handler = ApprovalHandler(sandbox, approval_callback)

        # 检查并请求审批
        result = await handler.check_and_request(
            operation="file_delete",
            path="/path/to/file",
        )
    """

    def __init__(
        self,
        sandbox: Any,  # OpenWorkSandbox
        approval_timeout: int = 300,  # 5 分钟
        history_file: Path | None = None,
        approval_callback: Callable[[ApprovalRequest], None] | None = None,
    ):
        """
        初始化审批处理器

        Args:
            sandbox: OpenWorkSandbox 实例
            approval_timeout: 审批超时时间（秒）
            history_file: 审批历史文件路径
            approval_callback: 审批请求回调函数（用于通知用户）
        """
        self.sandbox = sandbox
        self.approval_timeout = approval_timeout
        self.history_file = history_file
        self.approval_callback = approval_callback

        self._pending: dict[str, ApprovalRequest] = {}
        self._futures: dict[str, asyncio.Future] = {}
        self._history: list[ApprovalRequest] = []

    def request_approval(
        self,
        operation: str,
        path: str | None = None,
        reason: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> ApprovalRequest:
        """
        创建审批请求

        Args:
            operation: 操作类型
            path: 涉及的路径
            reason: 操作原因
            details: 额外详情

        Returns:
            ApprovalRequest 实例
        """
        import uuid

        request_id = str(uuid.uuid4())[:8]

        # 生成操作描述
        if not reason:
            reason = self._generate_reason(operation, path)

        request = ApprovalRequest(
            id=request_id,
            operation=operation,
            path=path,
            reason=reason,
            details=details or {},
        )

        self._pending[request_id] = request
        logger.info(f"Created approval request: {request_id} - {operation}")

        # 触发回调
        if self.approval_callback:
            try:
                self.approval_callback(request)
            except Exception as e:
                logger.error(f"Approval callback failed: {e}")

        return request

    async def wait_for_response(
        self,
        request_id: str,
        timeout: int | None = None,
    ) -> ApprovalResponse:
        """
        等待审批响应

        Args:
            request_id: 请求 ID
            timeout: 超时时间（秒），默认使用实例配置

        Returns:
            ApprovalResponse 实例
        """
        timeout = timeout or self.approval_timeout

        if request_id not in self._pending:
            raise ValueError(f"Unknown approval request: {request_id}")

        # 创建 Future
        future: asyncio.Future[ApprovalResponse] = asyncio.Future()
        self._futures[request_id] = future

        try:
            # 等待响应或超时
            response = await asyncio.wait_for(future, timeout=timeout)
            return response
        except asyncio.TimeoutError:
            # 超时处理
            request = self._pending.get(request_id)
            if request:
                request.status = ApprovalStatus.TIMEOUT
                request.responded_at = datetime.now()
                self._record_history(request)

            return ApprovalResponse(
                request_id=request_id,
                approved=False,
                reason="Approval request timed out",
            )
        finally:
            self._futures.pop(request_id, None)
            self._pending.pop(request_id, None)

    def respond(
        self,
        request_id: str,
        approved: bool,
        reason: str | None = None,
        responder: str | None = None,
    ) -> ApprovalResponse:
        """
        响应审批请求

        Args:
            request_id: 请求 ID
            approved: 是否批准
            reason: 响应原因
            responder: 响应者标识

        Returns:
            ApprovalResponse 实例
        """
        request = self._pending.get(request_id)
        if not request:
            raise ValueError(f"Unknown approval request: {request_id}")

        # 更新请求状态
        request.status = ApprovalStatus.APPROVED if approved else ApprovalStatus.REJECTED
        request.responded_at = datetime.now()
        request.response_reason = reason
        request.responder = responder

        # 从待处理中移除
        self._pending.pop(request_id, None)

        # 记录历史
        self._record_history(request)

        # 创建响应
        response = ApprovalResponse(
            request_id=request_id,
            approved=approved,
            reason=reason,
            responder=responder,
        )

        # 完成 Future
        future = self._futures.get(request_id)
        if future and not future.done():
            future.set_result(response)

        logger.info(
            f"Approval response: {request_id} - "
            f"{'APPROVED' if approved else 'REJECTED'}"
        )

        return response

    async def check_and_request(
        self,
        operation: str,
        path: str | None = None,
        command: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> tuple[bool, str]:
        """
        检查操作并请求审批（如果需要）

        Args:
            operation: 操作类型
            path: 涉及的路径
            command: 要执行的命令
            details: 额外详情

        Returns:
            (是否允许, 原因)
        """
        from .sandbox import OperationCheckResult

        # 先用沙箱检查
        result: OperationCheckResult = self.sandbox.check_operation(
            operation=operation,
            path=path,
            command=command,
            extra_context=details,
        )

        if result.verdict == OperationVerdict.FORBIDDEN:
            return False, result.reason or "Operation is forbidden"

        if result.verdict == OperationVerdict.ALLOWED:
            return True, "Operation allowed"

        # 需要确认
        request = self.request_approval(
            operation=operation,
            path=path,
            reason=result.reason,
            details=details,
        )

        # 等待响应
        response = await self.wait_for_response(request.id)

        return response.approved, response.reason or ""

    def cancel(self, request_id: str) -> bool:
        """
        取消审批请求

        Args:
            request_id: 请求 ID

        Returns:
            是否成功取消
        """
        request = self._pending.get(request_id)
        if not request:
            return False

        request.status = ApprovalStatus.CANCELLED
        request.responded_at = datetime.now()

        # 完成 Future
        future = self._futures.get(request_id)
        if future and not future.done():
            future.set_result(ApprovalResponse(
                request_id=request_id,
                approved=False,
                reason="Request cancelled",
            ))

        self._pending.pop(request_id, None)
        self._futures.pop(request_id, None)

        return True

    def list_pending(self) -> list[ApprovalRequest]:
        """列出所有待处理请求"""
        return list(self._pending.values())

    def get_pending(self, request_id: str) -> ApprovalRequest | None:
        """获取待处理请求"""
        return self._pending.get(request_id)

    def _generate_reason(self, operation: str, path: str | None) -> str:
        """生成操作原因描述"""
        reasons = {
            "file_delete": f"Delete file: {path}",
            "dir_delete": f"Delete directory: {path}",
            "file_move": f"Move file: {path}",
            "file_rename": f"Rename file: {path}",
            "command_dangerous": "Execute dangerous command",
            "cross_task_edit": f"Edit file outside current task: {path}",
            "project_access": f"Access project path: {path}",
        }
        return reasons.get(operation, f"Operation: {operation}")

    def _record_history(self, request: ApprovalRequest) -> None:
        """记录审批历史"""
        self._history.append(request)

        # 持久化到文件
        if self.history_file:
            try:
                self._save_history()
            except Exception as e:
                logger.error(f"Failed to save approval history: {e}")

    def _save_history(self) -> None:
        """保存审批历史到文件"""
        if not self.history_file:
            return

        history_data = []
        for req in self._history[-100:]:  # 只保存最近 100 条
            history_data.append({
                "id": req.id,
                "operation": req.operation,
                "path": req.path,
                "reason": req.reason,
                "status": req.status.value,
                "created_at": req.created_at.isoformat(),
                "responded_at": req.responded_at.isoformat() if req.responded_at else None,
                "response_reason": req.response_reason,
                "responder": req.responder,
            })

        self.history_file.parent.mkdir(parents=True, exist_ok=True)
        self.history_file.write_text(json.dumps(history_data, indent=2, ensure_ascii=False))


def create_user_confirmation_prompt(request: ApprovalRequest) -> str:
    """
    创建用户确认提示

    Args:
        request: 审批请求

    Returns:
        格式化的提示字符串
    """
    prompt_parts = [
        "⚠️  **需要确认操作**",
        "",
        f"**操作类型**: {request.operation}",
    ]

    if request.path:
        prompt_parts.append(f"**涉及路径**: `{request.path}`")

    prompt_parts.append(f"**原因**: {request.reason}")

    if request.details:
        prompt_parts.append("")
        prompt_parts.append("**详情**:")
        for key, value in request.details.items():
            prompt_parts.append(f"  - {key}: {value}")

    prompt_parts.extend([
        "",
        "---",
        "请确认是否允许此操作？",
        "- 回复 `y` 或 `yes` 允许",
        "- 回复 `n` 或 `no` 拒绝",
        "- 回复 `d` 或 `details` 查看更多信息",
    ])

    return "\n".join(prompt_parts)


def format_delete_confirmation(
    path: str,
    file_type: str = "file",
    size: str | None = None,
    is_directory: bool = False,
) -> str:
    """
    格式化删除确认提示

    Args:
        path: 文件路径
        file_type: 文件类型描述
        size: 文件大小
        is_directory: 是否是目录

    Returns:
        格式化的确认提示
    """
    lines = [
        "🗑️  **确认删除**",
        "",
        f"**{'目录' if is_directory else '文件'}**: `{path}`",
    ]

    if file_type:
        lines.append(f"**类型**: {file_type}")

    if size:
        lines.append(f"**大小**: {size}")

    lines.extend([
        "",
        "⚠️  此操作不可逆！",
        "",
        "确认删除？",
    ])

    return "\n".join(lines)
