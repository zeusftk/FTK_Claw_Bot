"""
Idea Processor - 智能需求处理器

解析用户 idea，生成结构化需求，评估复杂度和风险。
"""

import json
from loguru import logger
import re
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from clawbot.providers.base import LLMProvider



class ComplexityLevel(Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    VERY_HIGH = "very_high"


class RiskLevel(Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class TaskType(Enum):
    NEW_PROJECT = "new_project"
    FEATURE_ADDITION = "feature_addition"
    BUG_FIX = "bug_fix"
    REFACTORING = "refactoring"
    DOCUMENTATION = "documentation"
    TESTING = "testing"
    DEPLOYMENT = "deployment"
    INTEGRATION = "integration"
    UNKNOWN = "unknown"


@dataclass
class Feature:
    name: str
    description: str
    priority: str
    estimated_complexity: ComplexityLevel


@dataclass
class TechnicalSuggestion:
    technology: str
    reason: str
    confidence: float


@dataclass
class ProcessedIdea:
    idea_id: str
    original_idea: str
    summary: str
    task_type: TaskType
    complexity: ComplexityLevel
    risk: RiskLevel
    features: list[Feature]
    technical_suggestions: list[TechnicalSuggestion]
    clarifications_needed: list[str]
    estimated_steps: int
    created_at: datetime
    metadata: dict[str, Any] = field(default_factory=dict)


SYSTEM_PROMPT = """你是一个资深技术架构师。你的任务是解析用户的需求想法，生成结构化的需求文档。

请分析用户的 idea，输出 JSON 格式：

```json
{
  "summary": "一句话总结需求",
  "task_type": "new_project|feature_addition|bug_fix|refactoring|documentation|testing|deployment|integration|unknown",
  "complexity": "low|medium|high|very_high",
  "risk": "low|medium|high|critical",
  "features": [
    {
      "name": "功能名称",
      "description": "功能描述",
      "priority": "must_have|should_have|nice_to_have",
      "estimated_complexity": "low|medium|high"
    }
  ],
  "technical_suggestions": [
    {
      "technology": "技术名称",
      "reason": "推荐理由",
      "confidence": 0.0-1.0
    }
  ],
  "clarifications_needed": [
    "需要澄清的问题1",
    "需要澄清的问题2"
  ],
  "estimated_steps": 预估步骤数量
}
```

分析要点：
1. 识别核心功能和次要功能
2. 评估技术复杂度
3. 识别潜在风险
4. 提出技术方案建议
5. 列出需要澄清的问题"""


class IdeaProcessor:
    """
    智能需求处理器

    功能：
    1. 解析自然语言需求
    2. 提取关键功能点
    3. 生成技术方案建议
    4. 评估复杂度和风险
    5. 识别需要澄清的问题
    """

    COMPLEXITY_KEYWORDS = {
        ComplexityLevel.LOW: [
            "简单", "小", "快速", "修复", "调整", "修改", "更新",
            "simple", "small", "quick", "fix", "tweak", "update",
        ],
        ComplexityLevel.MEDIUM: [
            "功能", "添加", "实现", "创建", "开发", "编写",
            "feature", "add", "implement", "create", "develop", "write",
        ],
        ComplexityLevel.HIGH: [
            "系统", "架构", "集成", "重构", "迁移", "优化",
            "system", "architecture", "integrate", "refactor", "migrate", "optimize",
        ],
        ComplexityLevel.VERY_HIGH: [
            "平台", "框架", "分布式", "微服务", "大规模", "复杂",
            "platform", "framework", "distributed", "microservice", "large-scale", "complex",
        ],
    }

    RISK_KEYWORDS = {
        RiskLevel.LOW: [
            "文档", "注释", "格式化", "样式",
            "docs", "comment", "format", "style",
        ],
        RiskLevel.MEDIUM: [
            "数据库", "API", "接口", "配置",
            "database", "api", "interface", "config",
        ],
        RiskLevel.HIGH: [
            "认证", "授权", "支付", "安全", "加密",
            "auth", "payment", "security", "encrypt",
        ],
        RiskLevel.CRITICAL: [
            "生产", "部署", "迁移", "删除", "权限",
            "production", "deploy", "migrate", "delete", "permission",
        ],
    }

    TASK_TYPE_KEYWORDS = {
        TaskType.NEW_PROJECT: [
            "新项目", "创建项目", "从零开始", "新建",
            "new project", "create project", "from scratch", "scaffold",
        ],
        TaskType.FEATURE_ADDITION: [
            "添加功能", "新功能", "增加", "扩展",
            "add feature", "new feature", "extend", "enhance",
        ],
        TaskType.BUG_FIX: [
            "修复", "bug", "错误", "问题", "异常",
            "fix", "bug", "error", "issue", "exception",
        ],
        TaskType.REFACTORING: [
            "重构", "优化", "改进", "清理",
            "refactor", "optimize", "improve", "clean",
        ],
        TaskType.DOCUMENTATION: [
            "文档", "readme", "说明", "注释",
            "docs", "readme", "documentation", "comment",
        ],
        TaskType.TESTING: [
            "测试", "单元测试", "集成测试", "覆盖率",
            "test", "unit test", "integration test", "coverage",
        ],
        TaskType.DEPLOYMENT: [
            "部署", "发布", "上线", "CI/CD",
            "deploy", "release", "publish", "ci/cd",
        ],
        TaskType.INTEGRATION: [
            "集成", "对接", "接入", "API",
            "integrate", "connect", "api", "webhook",
        ],
    }

    def __init__(
        self,
        llm_provider: "LLMProvider | None" = None,
        workspace: Any = None,
    ):
        self.llm_provider = llm_provider
        self.workspace = workspace

    async def process(self, idea: str, user_id: str = "default") -> ProcessedIdea:
        """
        处理用户 idea，返回结构化需求

        Args:
            idea: 用户原始想法
            user_id: 用户 ID

        Returns:
            ProcessedIdea 结构化需求
        """
        import uuid

        idea_id = f"idea-{uuid.uuid4().hex[:8]}"

        if self.llm_provider:
            try:
                return await self._process_with_llm(idea_id, idea, user_id)
            except Exception as e:
                logger.error(f"LLM processing failed: {e}, falling back to rule-based")

        return self._process_with_rules(idea_id, idea, user_id)

    async def _process_with_llm(
        self,
        idea_id: str,
        idea: str,
        user_id: str,
    ) -> ProcessedIdea:
        """使用 LLM 处理需求"""
        response = await self.llm_provider.chat(
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": f"请分析以下需求：\n\n{idea}"},
            ],
            response_format={"type": "json_object"},
        )

        result = json.loads(response.content)

        return ProcessedIdea(
            idea_id=idea_id,
            original_idea=idea,
            summary=result.get("summary", idea[:100]),
            task_type=TaskType(result.get("task_type", "unknown")),
            complexity=ComplexityLevel(result.get("complexity", "medium")),
            risk=RiskLevel(result.get("risk", "medium")),
            features=[
                Feature(
                    name=f.get("name", "Unknown"),
                    description=f.get("description", ""),
                    priority=f.get("priority", "should_have"),
                    estimated_complexity=ComplexityLevel(f.get("estimated_complexity", "medium")),
                )
                for f in result.get("features", [])
            ],
            technical_suggestions=[
                TechnicalSuggestion(
                    technology=s.get("technology", ""),
                    reason=s.get("reason", ""),
                    confidence=s.get("confidence", 0.5),
                )
                for s in result.get("technical_suggestions", [])
            ],
            clarifications_needed=result.get("clarifications_needed", []),
            estimated_steps=result.get("estimated_steps", 5),
            created_at=datetime.now(),
            metadata={"user_id": user_id, "processing_method": "llm"},
        )

    def _process_with_rules(
        self,
        idea_id: str,
        idea: str,
        user_id: str,
    ) -> ProcessedIdea:
        """使用规则处理需求（降级方案）"""
        idea_lower = idea.lower()

        task_type = self._detect_task_type(idea_lower)
        complexity = self._detect_complexity(idea_lower)
        risk = self._detect_risk(idea_lower)

        features = self._extract_features(idea)
        suggestions = self._generate_suggestions(idea_lower, task_type)
        clarifications = self._generate_clarifications(idea, task_type)

        estimated_steps = self._estimate_steps(complexity, len(features))

        return ProcessedIdea(
            idea_id=idea_id,
            original_idea=idea,
            summary=idea[:100] + ("..." if len(idea) > 100 else ""),
            task_type=task_type,
            complexity=complexity,
            risk=risk,
            features=features,
            technical_suggestions=suggestions,
            clarifications_needed=clarifications,
            estimated_steps=estimated_steps,
            created_at=datetime.now(),
            metadata={"user_id": user_id, "processing_method": "rules"},
        )

    def _detect_task_type(self, text: str) -> TaskType:
        """检测任务类型"""
        scores = {t: 0 for t in TaskType}

        for task_type, keywords in self.TASK_TYPE_KEYWORDS.items():
            for keyword in keywords:
                if keyword in text:
                    scores[task_type] += 1

        max_score = max(scores.values())
        if max_score == 0:
            return TaskType.UNKNOWN

        for task_type, score in scores.items():
            if score == max_score:
                return task_type

        return TaskType.UNKNOWN

    def _detect_complexity(self, text: str) -> ComplexityLevel:
        """检测复杂度"""
        scores = {c: 0 for c in ComplexityLevel}

        for level, keywords in self.COMPLEXITY_KEYWORDS.items():
            for keyword in keywords:
                if keyword in text:
                    scores[level] += 1

        if sum(scores.values()) == 0:
            return ComplexityLevel.MEDIUM

        max_level = ComplexityLevel.MEDIUM
        max_score = 0
        for level, score in scores.items():
            if score > max_score:
                max_score = score
                max_level = level

        return max_level

    def _detect_risk(self, text: str) -> RiskLevel:
        """检测风险等级"""
        scores = {r: 0 for r in RiskLevel}

        for level, keywords in self.RISK_KEYWORDS.items():
            for keyword in keywords:
                if keyword in text:
                    scores[level] += 1

        if sum(scores.values()) == 0:
            return RiskLevel.LOW

        max_level = RiskLevel.LOW
        max_score = 0
        for level, score in scores.items():
            if score > max_score:
                max_score = score
                max_level = level

        return max_level

    def _extract_features(self, idea: str) -> list[Feature]:
        """提取功能点"""
        features = []

        sentences = re.split(r'[。!?！？\n]', idea)

        for sentence in sentences:
            sentence = sentence.strip()
            if not sentence or len(sentence) < 5:
                continue

            action_keywords = [
                "实现", "添加", "创建", "开发", "支持", "提供",
                "implement", "add", "create", "develop", "support", "provide",
            ]

            is_feature = any(kw in sentence.lower() for kw in action_keywords)

            if is_feature:
                features.append(Feature(
                    name=sentence[:50],
                    description=sentence,
                    priority="should_have",
                    estimated_complexity=ComplexityLevel.MEDIUM,
                ))

        if not features and len(idea) > 10:
            features.append(Feature(
                name="核心功能",
                description=idea[:200],
                priority="must_have",
                estimated_complexity=ComplexityLevel.MEDIUM,
            ))

        return features[:10]

    def _generate_suggestions(
        self,
        text: str,
        task_type: TaskType,
    ) -> list[TechnicalSuggestion]:
        """生成技术建议"""
        suggestions = []

        tech_patterns = {
            "web": [("React", "现代前端框架", 0.8), ("Vue", "渐进式框架", 0.75)],
            "api": [("FastAPI", "高性能 Python API 框架", 0.85), ("Express", "Node.js Web 框架", 0.75)],
            "database": [("PostgreSQL", "可靠的关系型数据库", 0.8), ("MongoDB", "灵活的文档数据库", 0.7)],
            "mobile": [("React Native", "跨平台移动开发", 0.75), ("Flutter", "高性能跨平台框架", 0.8)],
            "test": [("pytest", "Python 测试框架", 0.85), ("Jest", "JavaScript 测试框架", 0.8)],
        }

        for pattern, techs in tech_patterns.items():
            if pattern in text:
                for tech, reason, confidence in techs:
                    suggestions.append(TechnicalSuggestion(
                        technology=tech,
                        reason=reason,
                        confidence=confidence,
                    ))

        if task_type == TaskType.NEW_PROJECT:
            suggestions.append(TechnicalSuggestion(
                technology="Git",
                reason="版本控制是项目的基础",
                confidence=0.95,
            ))

        return suggestions[:5]

    def _generate_clarifications(
        self,
        idea: str,
        task_type: TaskType,
    ) -> list[str]:
        """生成需要澄清的问题"""
        clarifications = []

        if task_type == TaskType.NEW_PROJECT:
            if "技术" not in idea and "technology" not in idea.lower():
                clarifications.append("您希望使用什么技术栈？")
            if "时间" not in idea and "deadline" not in idea.lower():
                clarifications.append("项目的预期完成时间是什么时候？")

        elif task_type == TaskType.FEATURE_ADDITION:
            clarifications.append("这个功能需要与现有系统哪些部分集成？")

        elif task_type == TaskType.BUG_FIX:
            clarifications.append("请描述问题的复现步骤")
            clarifications.append("问题的影响范围是什么？")

        if len(idea) < 50:
            clarifications.append("能否提供更详细的需求描述？")

        return clarifications[:5]

    def _estimate_steps(self, complexity: ComplexityLevel, feature_count: int) -> int:
        """预估步骤数量"""
        base_steps = {
            ComplexityLevel.LOW: 3,
            ComplexityLevel.MEDIUM: 5,
            ComplexityLevel.HIGH: 10,
            ComplexityLevel.VERY_HIGH: 20,
        }

        base = base_steps.get(complexity, 5)
        return base + min(feature_count * 2, 10)

    async def clarify(self, idea: str, questions: list[str]) -> str:
        """
        向用户澄清需求

        Args:
            idea: 原始想法
            questions: 需要澄清的问题

        Returns:
            格式化的澄清请求
        """
        if not questions:
            return ""

        formatted = f"关于您的需求「{idea[:50]}...」，我需要确认以下几点：\n\n"
        for i, q in enumerate(questions, 1):
            formatted += f"{i}. {q}\n"

        formatted += "\n请提供更多信息，以便我更好地为您制定方案。"
        return formatted

    def get_stats(self) -> dict[str, Any]:
        """获取处理器统计信息"""
        return {
            "llm_enabled": self.llm_provider is not None,
            "task_types_supported": len(TaskType),
            "complexity_levels": len(ComplexityLevel),
            "risk_levels": len(RiskLevel),
        }
