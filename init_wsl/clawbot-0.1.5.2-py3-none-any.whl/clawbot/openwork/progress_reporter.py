"""
Progress Reporter - 进度报告器
实时监听 SSE 流，向用户报告任务进度。"""

import asyncio
import json
from loguru import logger
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable

import aiohttp



class ProgressEventType(Enum):
    SESSION_START = "session_start"
    SESSION_STATUS = "session.status"
    SESSION_IDLE = "session.idle"
    MESSAGE_UPDATED = "message.updated"
    MESSAGE_PART_UPDATED = "message.part.updated"
    PERMISSION_ASKED = "permission.asked"
    TOOL_CALL = "tool_call"
    ERROR = "error"
    COMPLETED = "completed"
    MILESTONE = "milestone"
    TODO_UPDATE = "todo_update"


@dataclass
class ProgressEvent:
    event_type: ProgressEventType
    session_id: str
    timestamp: datetime
    message: str
    details: dict[str, Any] = field(default_factory=dict)
    progress_percent: float | None = None
    is_milestone: bool = False


@dataclass
class ToolCallInfo:
    tool_name: str
    status: str
    title: str
    input_summary: str
    output_summary: str | None = None


@dataclass
class TodoItem:
    content: str
    status: str
    priority: str = "medium"


@dataclass
class SessionProgress:
    session_id: str
    status: str
    started_at: datetime
    last_updated: datetime
    todos: list[TodoItem]
    completed_todos: int
    total_todos: int
    tool_calls: list[ToolCallInfo]
    errors: list[str]
    messages: list[str]


class ProgressReporter:
    """
    进度报告器

    功能：
    1. 监听 SSE 事件流
    2. 解析进度事件
    3. 格式化进度报告
    4. 里程碑通知
    5. 错误告警
    """

    TOOL_LABELS = {
        "bash": "终端命令",
        "read": "读取文件",
        "write": "写入文件",
        "edit": "编辑文件",
        "patch": "补丁修改",
        "multiedit": "批量编辑",
        "grep": "搜索内容",
        "glob": "查找文件",
        "task": "子任务",
        "webfetch": "网络请求",
    }

    MILESTONE_PATTERNS = [
        "完成", "成功", "创建完成", "实现完成", "测试通过",
        "completed", "success", "done", "finished",
    ]

    def __init__(
        self,
        base_url: str = "http://localhost:7777",
        on_progress: Callable[[ProgressEvent], None] | None = None,
        on_milestone: Callable[[ProgressEvent], None] | None = None,
        on_error: Callable[[ProgressEvent], None] | None = None,
        on_tool_call: Callable[[ToolCallInfo], None] | None = None,
        on_todo_update: Callable[[list[TodoItem]], None] | None = None,
    ):
        self.base_url = base_url.rstrip("/")
        self._on_progress = on_progress
        self._on_milestone = on_milestone
        self._on_error = on_error
        self._on_tool_call = on_tool_call
        self._on_todo_update = on_todo_update

        self._session: aiohttp.ClientSession | None = None
        self._running = False
        self._listener_task: asyncio.Task | None = None
        self._session_progress: dict[str, SessionProgress] = {}
        self._abort_controller: asyncio.Event | None = None

    async def start_listening(self, session_id: str | None = None) -> None:
        """
        开始监听 SSE 流

        Args:
            session_id: 可选的会话 ID 过滤
        """
        if self._running:
            logger.warning("ProgressReporter is already running")
            return

        self._running = True
        self._abort_controller = asyncio.Event()

        self._session = aiohttp.ClientSession()

        self._listener_task = asyncio.create_task(
            self._run_event_listener(session_id)
        )

        logger.info(f"ProgressReporter started, listening to {self.base_url}/events")

    async def stop_listening(self) -> None:
        """停止监听"""
        self._running = False

        if self._abort_controller:
            self._abort_controller.set()

        if self._listener_task:
            self._listener_task.cancel()
            try:
                await self._listener_task
            except asyncio.CancelledError:
                pass
            self._listener_task = None

        if self._session:
            await self._session.close()
            self._session = None

        logger.info("ProgressReporter stopped")

    async def _run_event_listener(self, session_filter: str | None) -> None:
        """运行事件监听器"""
        while self._running:
            try:
                await self._connect_and_listen(session_filter)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"SSE connection error: {e}")
                if self._running:
                    await asyncio.sleep(5)

    async def _connect_and_listen(self, session_filter: str | None) -> None:
        """连接并监听 SSE 流"""
        if not self._session:
            return

        url = f"{self.base_url}/events"
        headers = {"Accept": "text/event-stream"}

        async with self._session.get(url, headers=headers) as response:
            response.raise_for_status()

            buffer = ""
            async for chunk in response.content:
                if not self._running:
                    break

                buffer += chunk.decode("utf-8")

                while "\n\n" in buffer:
                    event_data, buffer = buffer.split("\n\n", 1)
                    event = self._parse_sse_event(event_data)
                    if event:
                        if session_filter and event.session_id != session_filter:
                            continue
                        await self._handle_event(event)

    def _parse_sse_event(self, event_data: str) -> ProgressEvent | None:
        """解析 SSE 事件"""
        lines = event_data.strip().split("\n")
        event_type_str = None
        data = {}

        for line in lines:
            if line.startswith("event:"):
                event_type_str = line[6:].strip()
            elif line.startswith("data:"):
                try:
                    data = json.loads(line[5:].strip())
                except json.JSONDecodeError:
                    pass

        if not event_type_str or not data:
            return None

        try:
            event_type = self._map_event_type(event_type_str)
        except ValueError:
            logger.debug(f"Unknown event type: {event_type_str}")
            return None

        session_id = data.get("sessionID", data.get("session_id", ""))

        return ProgressEvent(
            event_type=event_type,
            session_id=session_id,
            timestamp=datetime.now(),
            message=self._extract_message(event_type, data),
            details=data,
            is_milestone=self._is_milestone(event_type, data),
        )

    def _map_event_type(self, event_type_str: str) -> ProgressEventType:
        """映射事件类型字符串到枚举"""
        mapping = {
            "session.status": ProgressEventType.SESSION_STATUS,
            "session.idle": ProgressEventType.SESSION_IDLE,
            "message.updated": ProgressEventType.MESSAGE_UPDATED,
            "message.part.updated": ProgressEventType.MESSAGE_PART_UPDATED,
            "permission.asked": ProgressEventType.PERMISSION_ASKED,
            "error": ProgressEventType.ERROR,
            "completed": ProgressEventType.COMPLETED,
        }

        if event_type_str in mapping:
            return mapping[event_type_str]

        raise ValueError(f"Unknown event type: {event_type_str}")

    def _extract_message(self, event_type: ProgressEventType, data: dict) -> str:
        """提取事件消息"""
        if event_type == ProgressEventType.SESSION_STATUS:
            status = data.get("status", {})
            status_type = status.get("type", "unknown")
            return f"会话状态: {status_type}"

        elif event_type == ProgressEventType.SESSION_IDLE:
            return "会话空闲，等待输入"

        elif event_type == ProgressEventType.MESSAGE_UPDATED:
            return "消息已更新"

        elif event_type == ProgressEventType.MESSAGE_PART_UPDATED:
            part = data.get("part", {})
            tool = part.get("tool", "unknown")
            status = part.get("state", {}).get("status", "unknown")
            return f"工具调用: {self.TOOL_LABELS.get(tool, tool)} - {status}"

        elif event_type == ProgressEventType.PERMISSION_ASKED:
            return "需要权限确认"

        elif event_type == ProgressEventType.ERROR:
            return f"错误: {data.get('error', 'Unknown error')}"

        elif event_type == ProgressEventType.COMPLETED:
            return "任务完成"

        return ""

    def _is_milestone(self, event_type: ProgressEventType, data: dict) -> bool:
        """判断是否为里程碑事件"""
        if event_type == ProgressEventType.COMPLETED:
            return True

        if event_type == ProgressEventType.SESSION_IDLE:
            return True

        message = self._extract_message(event_type, data).lower()
        for pattern in self.MILESTONE_PATTERNS:
            if pattern in message:
                return True

        return False

    async def _handle_event(self, event: ProgressEvent) -> None:
        """处理事件"""
        self._update_session_progress(event)

        if self._on_progress:
            try:
                self._on_progress(event)
            except Exception as e:
                logger.error(f"Progress callback error: {e}")

        if event.is_milestone and self._on_milestone:
            try:
                self._on_milestone(event)
            except Exception as e:
                logger.error(f"Milestone callback error: {e}")

        if event.event_type == ProgressEventType.ERROR and self._on_error:
            try:
                self._on_error(event)
            except Exception as e:
                logger.error(f"Error callback error: {e}")

        if event.event_type == ProgressEventType.MESSAGE_PART_UPDATED:
            tool_info = self._extract_tool_info(event.details)
            if tool_info and self._on_tool_call:
                try:
                    self._on_tool_call(tool_info)
                except Exception as e:
                    logger.error(f"Tool call callback error: {e}")

        if event.event_type == ProgressEventType.TODO_UPDATE:
            todos = self._extract_todos(event.details)
            if todos and self._on_todo_update:
                try:
                    self._on_todo_update(todos)
                except Exception as e:
                    logger.error(f"Todo update callback error: {e}")

    def _update_session_progress(self, event: ProgressEvent) -> None:
        """更新会话进度"""
        session_id = event.session_id
        if not session_id:
            return

        if session_id not in self._session_progress:
            self._session_progress[session_id] = SessionProgress(
                session_id=session_id,
                status="running",
                started_at=datetime.now(),
                last_updated=datetime.now(),
                todos=[],
                completed_todos=0,
                total_todos=0,
                tool_calls=[],
                errors=[],
                messages=[],
            )

        progress = self._session_progress[session_id]
        progress.last_updated = datetime.now()

        if event.event_type == ProgressEventType.SESSION_STATUS:
            status = event.details.get("status", {})
            progress.status = status.get("type", "unknown")

        elif event.event_type == ProgressEventType.SESSION_IDLE:
            progress.status = "idle"

        elif event.event_type == ProgressEventType.ERROR:
            error_msg = event.details.get("error", "Unknown error")
            progress.errors.append(error_msg)

        elif event.event_type == ProgressEventType.MESSAGE_PART_UPDATED:
            tool_info = self._extract_tool_info(event.details)
            if tool_info:
                progress.tool_calls.append(tool_info)

        progress.messages.append(event.message)

    def _extract_tool_info(self, data: dict) -> ToolCallInfo | None:
        """提取工具调用信息"""
        part = data.get("part", {})
        if not part or part.get("type") != "tool":
            return None

        tool_name = part.get("tool", "unknown")
        state = part.get("state", {})
        status = state.get("status", "unknown")
        title = state.get("title", "")
        input_data = state.get("input", {})
        output = state.get("output", "")

        input_summary = self._summarize_input(input_data)
        output_summary = output[:200] if output else None

        return ToolCallInfo(
            tool_name=self.TOOL_LABELS.get(tool_name, tool_name),
            status=status,
            title=title or input_summary[:100],
            input_summary=input_summary,
            output_summary=output_summary,
        )

    def _summarize_input(self, input_data: dict) -> str:
        """总结输入数据"""
        if not input_data:
            return ""

        if "file_path" in input_data:
            return f"文件: {input_data['file_path']}"
        if "command" in input_data:
            return f"命令: {input_data['command'][:50]}"
        if "pattern" in input_data:
            return f"模式: {input_data['pattern']}"

        return json.dumps(input_data, ensure_ascii=False)[:100]

    def _extract_todos(self, data: dict) -> list[TodoItem] | None:
        """提取 Todo 列表"""
        todos_data = data.get("todos", [])
        if not todos_data:
            return None

        todos = []
        for item in todos_data:
            if isinstance(item, dict):
                todos.append(TodoItem(
                    content=item.get("content", ""),
                    status=item.get("status", "pending"),
                    priority=item.get("priority", "medium"),
                ))

        return todos

    def get_session_progress(self, session_id: str) -> SessionProgress | None:
        """获取会话进度"""
        return self._session_progress.get(session_id)

    def get_progress_percent(self, session_id: str) -> float:
        """获取进度百分比"""
        progress = self._session_progress.get(session_id)
        if not progress:
            return 0.0

        if progress.total_todos == 0:
            if progress.status == "idle":
                return 100.0
            if progress.status == "running":
                return 50.0
            return 0.0

        return (progress.completed_todos / progress.total_todos) * 100

    def format_progress_report(self, session_id: str) -> str:
        """格式化进度报告"""
        progress = self._session_progress.get(session_id)
        if not progress:
            return "未找到会话进度"

        lines = [
            "📊 会话进度报告",
            "━━━━━━━━━━━━━━━━━━━━━━━━━━",
            f"会话 ID: {session_id}",
            f"状态: {progress.status}",
            f"开始时间: {progress.started_at.strftime('%H:%M:%S')}",
            "",
        ]

        if progress.total_todos > 0:
            percent = self.get_progress_percent(session_id)
            lines.append(f"进度: {percent:.1f}% ({progress.completed_todos}/{progress.total_todos})")
            lines.append("")
            lines.append("📋 任务列表:")
            for i, todo in enumerate(progress.todos[:10], 1):
                status_icon = "✅" if todo.status == "completed" else "⏳"
                lines.append(f"  {status_icon} {i}. {todo.content[:50]}")

        if progress.tool_calls:
            lines.append("")
            lines.append("🔧 最近操作:")
            for tool in progress.tool_calls[-5:]:
                lines.append(f"  •{tool.tool_name}: {tool.status}")

        if progress.errors:
            lines.append("")
            lines.append("❌ 错误:")
            for error in progress.errors[-3:]:
                lines.append(f"  •{error[:100]}")

        return "\n".join(lines)

    def on_progress(self, callback: Callable[[ProgressEvent], None]) -> None:
        """注册进度回调"""
        self._on_progress = callback

    def on_milestone(self, callback: Callable[[ProgressEvent], None]) -> None:
        """注册里程碑回调"""
        self._on_milestone = callback

    def on_error(self, callback: Callable[[ProgressEvent], None]) -> None:
        """注册错误回调"""
        self._on_error = callback

    def on_tool_call(self, callback: Callable[[ToolCallInfo], None]) -> None:
        """注册工具调用回调"""
        self._on_tool_call = callback

    def on_todo_update(self, callback: Callable[[list[TodoItem]], None]) -> None:
        """注册 Todo 更新回调"""
        self._on_todo_update = callback

    def get_stats(self) -> dict[str, Any]:
        """获取统计信息"""
        return {
            "running": self._running,
            "base_url": self.base_url,
            "active_sessions": len(self._session_progress),
            "sessions": {
                sid: {
                    "status": p.status,
                    "progress": self.get_progress_percent(sid),
                    "tool_calls": len(p.tool_calls),
                    "errors": len(p.errors),
                }
                for sid, p in self._session_progress.items()
            },
        }
