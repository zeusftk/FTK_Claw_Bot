"""
OpenWork Agent Constraints - Agent 行为约束

这是弹性规则的实现，通过注入到 Agent 的系统提示中，指导其行为。

包含：
1. 操作边界约束
2. 删除操作警告
3. 跨任务操作提示
4. 安全最佳实践

使用方式：
    constraints = AgentConstraints(config)
    system_prompt = constraints.get_system_prompt()
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass
class ConstraintLevel:
    """约束级别"""
    CRITICAL = "critical"   # 必须遵守
    WARNING = "warning"     # 强烈建议
    HINT = "hint"           # 提示性


class AgentConstraints:
    """
    Agent 行为约束

    生成注入到 Agent 系统提示中的约束指令。

    Example:
        constraints = AgentConstraints(config, task_id="task-123")
        system_prompt = constraints.get_system_prompt()
    """

    def __init__(
        self,
        config: Any,  # OpenWorkConfig
        task_id: str | None = None,
        workspace: Path | None = None,
    ):
        self.config = config
        self.task_id = task_id
        self.workspace = workspace

    def get_system_prompt(self) -> str:
        """
        获取完整的系统约束提示

        Returns:
            格式化的系统提示字符串
        """
        sections = [
            self._get_boundary_section(),
            self._get_operation_rules_section(),
            self._get_delete_rules_section(),
            self._get_best_practices_section(),
        ]

        return "\n\n".join(filter(None, sections))

    def _get_boundary_section(self) -> str:
        """获取边界约束部分"""
        work_dir = self.config.sandbox.work_dir

        lines = [
            "## 🛡️ OpenWork 操作边界",
            "",
            f"所有文件操作必须在 **`{work_dir}/`** 目录下进行。",
        ]

        if self.task_id:
            lines.extend([
                "",
                f"当前任务 ID: `{self.task_id}`",
                f"任务目录: `{work_dir}/tasks/{self.task_id}/`",
                "",
                "**规则**:",
                f"1. 新创建的文件应放在 `{work_dir}/tasks/{self.task_id}/` 目录下",
                "2. 不要修改或删除其他任务的文件",
                "3. 共享资源放在 `shared/` 目录下",
            ])

        lines.extend([
            "",
            "**禁止访问的路径**:",
            "- 项目根目录的 `.git/` 目录",
            "- 任何 `.env`、`credentials`、`secrets` 文件",
            "- `*.key`、`*.pem` 等密钥文件",
            "- 系统目录（`/etc/`、`/usr/`、`C:\\Windows\\` 等）",
        ])

        return "\n".join(lines)

    def _get_operation_rules_section(self) -> str:
        """获取操作规则部分"""
        safe_ops = self.config.sandbox.safe_operations
        confirm_ops = self.config.sandbox.confirm_operations
        forbidden_ops = self.config.sandbox.forbidden_operations

        lines = [
            "## 📋 操作分类规则",
            "",
            "### ✅ 自动允许的操作",
            "以下操作无需确认即可执行：",
        ]

        for op in safe_ops:
            lines.append(f"- `{op}`")

        lines.extend([
            "",
            "### ⚠️ 需要确认的操作",
            "以下操作需要用户确认：",
        ])

        for op in confirm_ops:
            lines.append(f"- `{op}`")

        lines.extend([
            "",
            "### 🚫 禁止的操作",
            "以下操作将被拒绝：",
        ])

        for op in forbidden_ops:
            lines.append(f"- `{op}`")

        return "\n".join(lines)

    def _get_delete_rules_section(self) -> str:
        """获取删除操作规则部分"""
        protected = self.config.sandbox.protected_patterns

        lines = [
            "## 🗑️ 删除操作规则",
            "",
            "⚠️ **删除操作是不可逆的，请务必谨慎！**",
            "",
            "### 删除前必须确认",
            "在执行任何删除操作之前，请：",
            "1. 确认文件确实需要删除",
            "2. 检查是否有其他文件依赖它",
            "3. 向用户展示要删除的文件列表",
            "4. 等待用户确认后再执行",
            "",
            "### 受保护的文件/目录",
            "以下文件和目录不能删除：",
        ]

        for pattern in protected:
            lines.append(f"- `{pattern}`")

        lines.extend([
            "",
            "### 删除确认格式",
            "```",
            "🗑️ 即将删除以下文件：",
            "  - path/to/file1.py",
            "  - path/to/file2.py",
            "",
            "原因: [删除原因]",
            "",
            "请确认是否继续？(y/n)",
            "```",
        ])

        return "\n".join(lines)

    def _get_best_practices_section(self) -> str:
        """获取最佳实践部分"""
        lines = [
            "## 💡 安全最佳实践",
            "",
            "### 文件操作",
            "1. **先备份后修改**: 修改重要文件前，先创建备份",
            "2. **增量修改**: 避免一次性修改大量文件",
            "3. **保持原子性**: 每个操作应该是独立可回滚的",
            "",
            "### 命令执行",
            "1. **避免危险命令**: 不要使用 `rm -rf`、`sudo` 等危险命令",
            "2. **检查命令输出**: 执行命令后检查输出，确认结果",
            "3. **超时处理**: 长时间运行的命令需要设置超时",
            "",
            "### 错误处理",
            "1. **优雅失败**: 操作失败时，不要继续执行后续操作",
            "2. **记录日志**: 记录所有操作和错误，便于排查",
            "3. **恢复机制**: 提供回滚或恢复方案",
            "",
            "### 沟通",
            "1. **透明操作**: 告知用户正在执行的操作",
            "2. **进度更新**: 长时间操作提供进度更新",
            "3. **风险提示**: 危险操作前明确提示风险",
        ]

        return "\n".join(lines)

    def get_operation_hint(self, operation: str, path: str | None = None) -> str:
        """
        获取特定操作的提示

        Args:
            operation: 操作类型
            path: 涉及的路径

        Returns:
            操作提示字符串
        """
        hints = {
            "file_delete": (
                "⚠️ 删除操作不可逆！请确认：\n"
                "1. 文件是否确实不再需要\n"
                "2. 是否有其他文件引用此文件\n"
                "3. 是否需要先备份"
            ),
            "dir_delete": (
                "⚠️ 目录删除将删除目录下的所有内容！\n"
                "请先列出目录内容，确认后再删除。"
            ),
            "file_move": (
                "💡 移动文件前请确认：\n"
                "1. 目标路径是否正确\n"
                "2. 是否需要更新引用"
            ),
            "cross_task_edit": (
                "⚠️ 即将修改其他任务的文件！\n"
                "这可能会影响其他正在进行的任务。"
            ),
        }

        hint = hints.get(operation, "")

        if path and self.config.is_protected_path(path):
            hint += (
                "\n\n🚫 **此路径受保护，无法修改或删除！**"
            )

        return hint


# 预定义的约束模板
CONSTRAINT_TEMPLATES = {
    "strict": """
## 🔒 严格模式约束

所有操作必须在以下边界内：
- 工作目录: `{work_dir}`
- 当前任务目录: `{task_dir}`

任何越界操作将被拒绝。
""",

    "moderate": """
## 📐 标准模式约束

- 默认工作目录: `{work_dir}`
- 项目访问需要确认
- 删除操作需要确认
""",

    "relaxed": """
## 📝 宽松模式约束

- 建议在 `{work_dir}` 目录下工作
- 危险操作仍需确认
- 请自觉遵守安全最佳实践
""",
}


def get_constraint_template(mode: str, work_dir: str, task_dir: str | None = None) -> str:
    """
    获取约束模板

    Args:
        mode: 约束模式 (strict/moderate/relaxed)
        work_dir: 工作目录
        task_dir: 任务目录

    Returns:
        格式化的约束字符串
    """
    template = CONSTRAINT_TEMPLATES.get(mode, CONSTRAINT_TEMPLATES["moderate"])
    return template.format(work_dir=work_dir, task_dir=task_dir or work_dir)
