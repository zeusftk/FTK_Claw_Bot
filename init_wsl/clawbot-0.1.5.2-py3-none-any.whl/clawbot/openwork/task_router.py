"""
Task Router - 任务路由器

智能路由任务到合适的执行引擎。
"""

import asyncio
from loguru import logger
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from clawbot.openwork.idea_processor import ProcessedIdea
    from clawbot.openwork.orchestrator import OpenWorkOrchestrator
    from clawbot.services.openwork_service import OpenWorkService



class ExecutionStrategy(Enum):
    DIRECT = "direct"
    INTERACTIVE = "interactive"
    STAGED = "staged"
    DELEGATED = "delegated"


class ExecutionTarget(Enum):
    OPENWORK_SERVER = "openwork_server"
    OPENCODE_ROUTER = "opencode_router"
    LOCAL_AGENT = "local_agent"


@dataclass
class RouteDecision:
    task_id: str
    target: ExecutionTarget
    strategy: ExecutionStrategy
    priority: str
    estimated_duration: int
    requires_confirmation: bool
    confirmation_message: str | None = None
    context: dict[str, Any] = field(default_factory=dict)


@dataclass
class ExecutionResult:
    task_id: str
    success: bool
    output: str
    session_id: str | None = None
    duration_ms: float = 0
    files_changed: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


class TaskRouter:
    """
    任务路由器

    功能：
    1. 分析任务类型
    2. 选择执行策略
    3. 路由到 OpenWork Server
    4. 处理降级逻辑
    5. 管理任务优先级
    """

    STRATEGY_RULES = {
        "new_project": ExecutionStrategy.STAGED,
        "feature_addition": ExecutionStrategy.INTERACTIVE,
        "bug_fix": ExecutionStrategy.DIRECT,
        "refactoring": ExecutionStrategy.STAGED,
        "documentation": ExecutionStrategy.DIRECT,
        "testing": ExecutionStrategy.DIRECT,
        "deployment": ExecutionStrategy.STAGED,
        "integration": ExecutionStrategy.INTERACTIVE,
        "unknown": ExecutionStrategy.INTERACTIVE,
    }

    PRIORITY_RULES = {
        "bug_fix": "high",
        "deployment": "high",
        "security": "critical",
        "feature_addition": "medium",
        "new_project": "medium",
        "refactoring": "low",
        "documentation": "low",
        "testing": "medium",
        "integration": "medium",
        "unknown": "medium",
    }

    DURATION_ESTIMATES = {
        "new_project": 1800,
        "feature_addition": 600,
        "bug_fix": 300,
        "refactoring": 900,
        "documentation": 180,
        "testing": 300,
        "deployment": 600,
        "integration": 900,
        "unknown": 600,
    }

    CONFIRMATION_REQUIRED = {
        "new_project": True,
        "deployment": True,
        "refactoring": True,
        "integration": True,
    }

    def __init__(
        self,
        openwork_service: "OpenWorkService | None" = None,
        orchestrator: "OpenWorkOrchestrator | None" = None,
        default_workspace: Path | None = None,
        auto_confirm: bool = False,
    ):
        self.openwork = openwork_service
        self.orchestrator = orchestrator
        self.default_workspace = default_workspace or Path.home() / "clawbot-workspace"
        self.auto_confirm = auto_confirm

        self._pending_tasks: dict[str, RouteDecision] = {}
        self._execution_futures: dict[str, asyncio.Future] = {}
        self._task_results: dict[str, ExecutionResult] = {}

    async def route(self, processed_idea: "ProcessedIdea") -> RouteDecision:
        """
        路由任务

        Args:
            processed_idea: 处理后的需求

        Returns:
            RouteDecision 路由决策
        """
        import uuid

        task_id = f"task-{uuid.uuid4().hex[:8]}"
        task_type = processed_idea.task_type.value

        target = self._select_target(processed_idea)
        strategy = self._select_strategy(task_type)
        priority = self._determine_priority(task_type, processed_idea)
        duration = self._estimate_duration(task_type, processed_idea)
        requires_confirmation = self._requires_confirmation(task_type)

        confirmation_message = None
        if requires_confirmation and not self.auto_confirm:
            confirmation_message = self._generate_confirmation_message(processed_idea)

        decision = RouteDecision(
            task_id=task_id,
            target=target,
            strategy=strategy,
            priority=priority,
            estimated_duration=duration,
            requires_confirmation=requires_confirmation,
            confirmation_message=confirmation_message,
            context={
                "idea_id": processed_idea.idea_id,
                "task_type": task_type,
                "complexity": processed_idea.complexity.value,
                "risk": processed_idea.risk.value,
            },
        )

        self._pending_tasks[task_id] = decision
        logger.info(f"Routed task {task_id}: {target.value} / {strategy.value} / {priority}")

        return decision

    async def execute(self, decision: RouteDecision, idea: str, workspace: Path | None = None) -> ExecutionResult:
        """
        执行任务

        Args:
            decision: 路由决策
            idea: 原始需求
            workspace: 工作目录

        Returns:
            ExecutionResult 执行结果
        """
        start_time = asyncio.get_event_loop().time()

        ws = workspace or self.default_workspace / decision.task_id

        try:
            if decision.target == ExecutionTarget.OPENWORK_SERVER:
                result = await self._execute_on_openwork(decision, idea, ws)
            elif decision.target == ExecutionTarget.OPENCODE_ROUTER:
                result = await self._execute_on_router(decision, idea, ws)
            else:
                result = await self._execute_locally(decision, idea, ws)

            result.duration_ms = (asyncio.get_event_loop().time() - start_time) * 1000
            self._task_results[decision.task_id] = result

            return result

        except Exception as e:
            logger.error(f"Task execution failed: {decision.task_id} - {e}")
            result = ExecutionResult(
                task_id=decision.task_id,
                success=False,
                output=f"Execution failed: {str(e)}",
                errors=[str(e)],
                duration_ms=(asyncio.get_event_loop().time() - start_time) * 1000,
            )
            self._task_results[decision.task_id] = result
            return result

    async def _execute_on_openwork(
        self,
        decision: RouteDecision,
        idea: str,
        workspace: Path,
    ) -> ExecutionResult:
        """在 OpenWork Server 上执行"""
        if not self.openwork:
            raise RuntimeError("OpenWork service not configured")

        if not await self.openwork.ensure():
            raise RuntimeError("OpenWork server is not available")

        if decision.strategy == ExecutionStrategy.STAGED:
            return await self._execute_staged(decision, idea, workspace)
        elif decision.strategy == ExecutionStrategy.INTERACTIVE:
            return await self._execute_interactive(decision, idea, workspace)
        else:
            return await self._execute_direct(decision, idea, workspace)

    async def _execute_direct(
        self,
        decision: RouteDecision,
        idea: str,
        workspace: Path,
    ) -> ExecutionResult:
        """直接执行"""
        result = await self.openwork.execute_code(
            task=idea,
            workspace=str(workspace),
            context=decision.context,
        )

        return ExecutionResult(
            task_id=decision.task_id,
            success=True,
            output=result.get("output", "Task completed"),
            session_id=result.get("session_id"),
            files_changed=result.get("files_changed", []),
            metadata=result,
        )

    async def _execute_interactive(
        self,
        decision: RouteDecision,
        idea: str,
        workspace: Path,
    ) -> ExecutionResult:
        """交互式执行"""
        return await self._execute_direct(decision, idea, workspace)

    async def _execute_staged(
        self,
        decision: RouteDecision,
        idea: str,
        workspace: Path,
    ) -> ExecutionResult:
        """分阶段执行"""
        stages = self._plan_stages(decision, idea)

        results = []
        for stage in stages:
            stage_result = await self.openwork.execute_code(
                task=stage["prompt"],
                workspace=str(workspace),
                context={**decision.context, "stage": stage["name"]},
            )
            results.append(stage_result)

        combined_output = "\n".join(
            r.get("output", "") for r in results
        )

        all_files = []
        for r in results:
            all_files.extend(r.get("files_changed", []))

        return ExecutionResult(
            task_id=decision.task_id,
            success=True,
            output=combined_output,
            session_id=results[-1].get("session_id") if results else None,
            files_changed=list(set(all_files)),
            metadata={"stages": len(stages), "results": results},
        )

    async def _execute_on_router(
        self,
        decision: RouteDecision,
        idea: str,
        workspace: Path,
    ) -> ExecutionResult:
        """在 OpenCode Router 上执行"""
        if self.orchestrator:
            project_id = await self.orchestrator.start_project(
                user_idea=idea,
                user_id="system",
                workspace=workspace,
            )

            return ExecutionResult(
                task_id=decision.task_id,
                success=True,
                output=f"Project started: {project_id}",
                session_id=project_id,
            )

        raise RuntimeError("Orchestrator not configured")

    async def _execute_locally(
        self,
        decision: RouteDecision,
        idea: str,
        workspace: Path,
    ) -> ExecutionResult:
        """
        本地执行 - 使用本地 LLM 提供者作为降级方案

        当 OpenWork Server 和 OpenCode Router 都不可用时，
        使用本地配置的 LLM 提供者直接执行任务。
        """
        import time
        from clawbot.config.loader import load_config
        from clawbot.providers import create_provider

        start_time = time.monotonic()

        try:
            # 加载配置
            config = load_config()
            if not config:
                raise RuntimeError("Failed to load configuration")

            # 创建本地 LLM 提供者
            provider = create_provider(config)
            if not provider:
                raise RuntimeError("No LLM provider configured")

            # 构建提示
            system_prompt = """You are a helpful AI assistant that helps with coding tasks.
Execute the requested task and provide clear, actionable output.

When working with files:
- Read files before modifying
- Make minimal, focused changes
- Explain what you're doing

Report any issues or limitations encountered."""

            user_prompt = f"""Task: {idea}

Workspace: {workspace}

Please execute this task. If you need more information, ask specific questions."""

            # 调用 LLM
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ]

            response = await provider.chat(
                messages=messages,
                model=config.model,
                temperature=0.1,
                max_tokens=4096,
            )

            output = response.get("content", "") or response.get("message", {}).get("content", "")

            duration_ms = (time.monotonic() - start_time) * 1000

            logger.info(
                "Local execution completed: task_id={}, duration_ms={:.0f}",
                decision.task_id,
                duration_ms,
            )

            return ExecutionResult(
                task_id=decision.task_id,
                success=True,
                output=output,
                duration_ms=duration_ms,
                metadata={"method": "local_llm", "model": config.model},
            )

        except Exception as e:
            duration_ms = (time.monotonic() - start_time) * 1000
            logger.error("Local execution failed: {}", e)

            return ExecutionResult(
                task_id=decision.task_id,
                success=False,
                output=f"Local execution failed: {e}",
                duration_ms=duration_ms,
                errors=[str(e)],
                metadata={"method": "local_llm", "error": str(e)},
            )

    def _select_target(self, processed_idea: "ProcessedIdea") -> ExecutionTarget:
        """选择执行目标"""
        if self.openwork and self.openwork.status.name == "RUNNING":
            return ExecutionTarget.OPENWORK_SERVER

        if self.orchestrator:
            return ExecutionTarget.OPENCODE_ROUTER

        return ExecutionTarget.LOCAL_AGENT

    def _select_strategy(self, task_type: str) -> ExecutionStrategy:
        """选择执行策略"""
        return self.STRATEGY_RULES.get(task_type, ExecutionStrategy.INTERACTIVE)

    def _determine_priority(self, task_type: str, processed_idea: "ProcessedIdea") -> str:
        """确定优先级"""
        base_priority = self.PRIORITY_RULES.get(task_type, "medium")

        if processed_idea.risk.value in ["high", "critical"]:
            if base_priority in ["low", "medium"]:
                return "high"

        return base_priority

    def _estimate_duration(self, task_type: str, processed_idea: "ProcessedIdea") -> int:
        """预估执行时间"""
        base_duration = self.DURATION_ESTIMATES.get(task_type, 600)

        complexity_multiplier = {
            "low": 0.5,
            "medium": 1.0,
            "high": 1.5,
            "very_high": 2.0,
        }

        multiplier = complexity_multiplier.get(processed_idea.complexity.value, 1.0)

        return int(base_duration * multiplier)

    def _requires_confirmation(self, task_type: str) -> bool:
        """是否需要确认"""
        return self.CONFIRMATION_REQUIRED.get(task_type, False)

    def _generate_confirmation_message(self, processed_idea: "ProcessedIdea") -> str:
        """生成确认消息"""
        lines = [
            "⚠️ 此任务需要确认：",
            "",
            f"📋 任务类型: {processed_idea.task_type.value}",
            f"📊 复杂度: {processed_idea.complexity.value}",
            f"⚠️ 风险等级: {processed_idea.risk.value}",
            "",
            "📝 摘要:",
            f"  {processed_idea.summary}",
            "",
            "🔧 主要功能:",
        ]

        for feature in processed_idea.features[:5]:
            lines.append(f"  •{feature.name}")

        lines.extend([
            "",
            "请回复 '确认' 或 '取消'",
        ])

        return "\n".join(lines)

    def _plan_stages(self, decision: RouteDecision, idea: str) -> list[dict]:
        """规划执行阶段"""
        stages = [
            {
                "name": "analysis",
                "prompt": f"分析以下需求，制定实现计划：\n\n{idea}",
            },
            {
                "name": "implementation",
                "prompt": f"根据分析结果，实现核心功能：\n\n{idea}",
            },
            {
                "name": "testing",
                "prompt": "为已实现的功能编写测试用例并运行测试",
            },
            {
                "name": "review",
                "prompt": "审查代码质量，检查潜在问题",
            },
        ]

        return stages

    def get_task_status(self, task_id: str) -> dict[str, Any] | None:
        """获取任务状态"""
        if task_id in self._task_results:
            result = self._task_results[task_id]
            return {
                "task_id": task_id,
                "status": "completed",
                "success": result.success,
                "output": result.output[:200],
            }

        if task_id in self._pending_tasks:
            decision = self._pending_tasks[task_id]
            return {
                "task_id": task_id,
                "status": "pending",
                "target": decision.target.value,
                "strategy": decision.strategy.value,
            }

        return None

    def get_stats(self) -> dict[str, Any]:
        """获取统计信息"""
        completed = len(self._task_results)
        successful = sum(1 for r in self._task_results.values() if r.success)

        return {
            "pending_tasks": len(self._pending_tasks),
            "completed_tasks": completed,
            "successful_tasks": successful,
            "success_rate": successful / completed if completed > 0 else 0,
            "openwork_available": self.openwork is not None,
            "orchestrator_available": self.orchestrator is not None,
        }
