"""
Feedback Collector - 反馈收集器

收集用户评价，触发自我进化。
"""

import asyncio
import json
from loguru import logger
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable

if TYPE_CHECKING:
    from clawbot.openwork.memory import OpenWorkMemoryBridge
    from clawbot.openwork.pattern_extractor import PatternExtractor
    from clawbot.openwork.self_enhancer import SelfEnhancer



class FeedbackType(Enum):
    RATING = "rating"
    COMMENT = "comment"
    APPROVAL = "approval"
    REJECTION = "rejection"
    SUGGESTION = "suggestion"


class FeedbackStatus(Enum):
    PENDING = "pending"
    COLLECTED = "collected"
    PROCESSED = "processed"


@dataclass
class Feedback:
    feedback_id: str
    project_id: str
    user_id: str
    feedback_type: FeedbackType
    rating: int | None = None
    comment: str | None = None
    lessons_learned: list[str] = field(default_factory=list)
    suggestions: list[str] = field(default_factory=list)
    status: FeedbackStatus = FeedbackStatus.PENDING
    created_at: datetime = field(default_factory=datetime.now)
    processed_at: datetime | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class FeedbackRequest:
    request_id: str
    project_id: str
    user_id: str
    message: str
    options: list[str]
    created_at: datetime = field(default_factory=datetime.now)


@dataclass
class FeedbackResult:
    feedback: Feedback
    enhancement_triggered: bool
    patterns_extracted: int
    rules_updated: int


class FeedbackCollector:
    """
    反馈收集器

    功能:
    1. 收集用户评分
    2. 提取经验教训
    3. 触发模式提取
    4. 更新决策阈值
    5. 管理反馈请求生命周期
    """

    RATING_PROMPTS = {
        1: "非常不满意 - 任务失败或结果严重偏离预期",
        2: "不满意 - 存在明显问题需要修复",
        3: "一般 - 基本完成任务但有改进空间",
        4: "满意 - 任务完成质量良好",
        5: "非常满意 - 超出预期，完美完成任务",
    }

    LESSON_TEMPLATES = {
        "success": [
            "技术选型合理",
            "执行步骤清晰",
            "错误处理完善",
            "代码质量高",
            "测试覆盖充分",
        ],
        "failure": [
            "需求理解偏差",
            "技术方案不当",
            "执行步骤遗漏",
            "错误处理不足",
            "测试覆盖不够",
        ],
    }

    def __init__(
        self,
        memory_bridge: "OpenWorkMemoryBridge | None" = None,
        pattern_extractor: "PatternExtractor | None" = None,
        self_enhancer: "SelfEnhancer | None" = None,
        workspace: Path | None = None,
        on_feedback_collected: Callable[[Feedback], None] | None = None,
    ):
        self.memory = memory_bridge
        self.extractor = pattern_extractor
        self.enhancer = self_enhancer
        self.workspace = workspace or Path.home() / "clawbot-workspace" / "feedback"
        self._on_feedback_collected = on_feedback_collected

        self._pending_requests: dict[str, FeedbackRequest] = {}
        self._feedback_futures: dict[str, asyncio.Future] = {}
        self._feedbacks: dict[str, Feedback] = {}

        self._ensure_workspace()

    def _ensure_workspace(self) -> None:
        """确保工作目录存在"""
        self.workspace.mkdir(parents=True, exist_ok=True)
        self._feedbacks_file = self.workspace / "feedbacks.jsonl"
        if not self._feedbacks_file.exists():
            self._feedbacks_file.touch()

    async def create_request(
        self,
        project_id: str,
        user_id: str,
        message: str | None = None,
        options: list[str] | None = None,
    ) -> FeedbackRequest:
        """
        创建反馈请求

        Args:
            project_id: 项目 ID
            user_id: 用户 ID
            message: 自定义消息
            options: 自定义选项

        Returns:
            FeedbackRequest 反馈请求
        """
        request_id = f"fb-req-{uuid.uuid4().hex[:8]}"

        default_message = "任务已完成，请对结果进行评价。"
        default_options = [
            "⭐ 非常满意",
            "👍 满意",
            "👌 一般",
            "👎 不满意",
            "💔 非常不满意",
        ]

        request = FeedbackRequest(
            request_id=request_id,
            project_id=project_id,
            user_id=user_id,
            message=message or default_message,
            options=options or default_options,
        )

        self._pending_requests[request_id] = request

        future = asyncio.Future()
        self._feedback_futures[request_id] = future

        logger.info(f"Created feedback request: {request_id} for project {project_id}")
        return request

    async def collect(
        self,
        project_id: str,
        user_id: str,
        timeout: float = 300.0,
    ) -> Feedback | None:
        """
        收集用户反馈

        Args:
            project_id: 项目 ID
            user_id: 用户 ID
            timeout: 超时时间（秒�?

        Returns:
            Feedback 用户反馈，超时返回 None
        """
        request = await self.create_request(project_id, user_id)

        try:
            future = self._feedback_futures.get(request.request_id)
            if future:
                return await asyncio.wait_for(future, timeout=timeout)
        except asyncio.TimeoutError:
            logger.warning(f"Feedback request timed out: {request.request_id}")
            self._pending_requests.pop(request.request_id, None)
            self._feedback_futures.pop(request.request_id, None)
            return None

        return None

    async def submit(
        self,
        request_id: str,
        rating: int,
        comment: str | None = None,
    ) -> Feedback | None:
        """
        提交反馈

        Args:
            request_id: 请求 ID
            rating: 评分 (1-5)
            comment: 评论

        Returns:
            Feedback 反馈对象
        """
        request = self._pending_requests.get(request_id)
        if not request:
            logger.warning(f"Unknown feedback request: {request_id}")
            return None

        feedback = Feedback(
            feedback_id=f"fb-{uuid.uuid4().hex[:8]}",
            project_id=request.project_id,
            user_id=request.user_id,
            feedback_type=FeedbackType.RATING,
            rating=max(1, min(5, rating)),
            comment=comment,
            status=FeedbackStatus.COLLECTED,
        )

        feedback.lessons_learned = self._extract_lessons(feedback)
        feedback.suggestions = self._generate_suggestions(feedback)

        self._feedbacks[feedback.feedback_id] = feedback
        self._pending_requests.pop(request_id, None)

        await self._save_feedback(feedback)

        future = self._feedback_futures.pop(request_id, None)
        if future and not future.done():
            future.set_result(feedback)

        if self._on_feedback_collected:
            try:
                self._on_feedback_collected(feedback)
            except Exception as e:
                logger.error(f"Feedback callback error: {e}")

        logger.info(f"Feedback collected: {feedback.feedback_id}, rating: {rating}")
        return feedback

    async def submit_direct(
        self,
        project_id: str,
        user_id: str,
        rating: int,
        comment: str | None = None,
    ) -> Feedback:
        """
        直接提交反馈（无需请求）

        Args:
            project_id: 项目 ID
            user_id: 用户 ID
            rating: 评分 (1-5)
            comment: 评论

        Returns:
            Feedback 反馈对象
        """
        feedback = Feedback(
            feedback_id=f"fb-{uuid.uuid4().hex[:8]}",
            project_id=project_id,
            user_id=user_id,
            feedback_type=FeedbackType.RATING,
            rating=max(1, min(5, rating)),
            comment=comment,
            status=FeedbackStatus.COLLECTED,
        )

        feedback.lessons_learned = self._extract_lessons(feedback)
        feedback.suggestions = self._generate_suggestions(feedback)

        self._feedbacks[feedback.feedback_id] = feedback
        await self._save_feedback(feedback)

        if self._on_feedback_collected:
            try:
                self._on_feedback_collected(feedback)
            except Exception as e:
                logger.error(f"Feedback callback error: {e}")

        logger.info(f"Direct feedback submitted: {feedback.feedback_id}, rating: {rating}")
        return feedback

    async def process_feedback(self, feedback: Feedback) -> FeedbackResult:
        """
        处理反馈，触发自我进化

        Args:
            feedback: 用户反馈

        Returns:
            FeedbackResult 处理结果
        """
        enhancement_triggered = False
        patterns_extracted = 0
        rules_updated = 0

        if self.memory:
            await self._record_to_memory(feedback)

        if feedback.rating and feedback.rating >= 4:
            if self.extractor:
                try:
                    patterns = await self.extractor.extract_patterns()
                    patterns_extracted = len(patterns)
                    logger.info(f"Extracted {patterns_extracted} patterns from feedback")
                except Exception as e:
                    logger.error(f"Pattern extraction failed: {e}")

        if feedback.rating and feedback.rating <= 2:
            if self.enhancer:
                try:
                    result = await self.enhancer.enhance()
                    rules_updated = len(result.new_rules)
                    enhancement_triggered = True
                    logger.info(f"Self-enhancement triggered, {rules_updated} rules updated")
                except Exception as e:
                    logger.error(f"Self-enhancement failed: {e}")

        feedback.status = FeedbackStatus.PROCESSED
        feedback.processed_at = datetime.now()

        await self._save_feedback(feedback)

        return FeedbackResult(
            feedback=feedback,
            enhancement_triggered=enhancement_triggered,
            patterns_extracted=patterns_extracted,
            rules_updated=rules_updated,
        )

    def _extract_lessons(self, feedback: Feedback) -> list[str]:
        """提取经验教训"""
        lessons = []

        if feedback.rating is None:
            return lessons

        if feedback.rating >= 4:
            template = self.LESSON_TEMPLATES["success"]
            if feedback.comment:
                lessons.append(f"成功经验: {feedback.comment[:100]}")
            else:
                lessons.append(template[0])
        else:
            template = self.LESSON_TEMPLATES["failure"]
            if feedback.comment:
                lessons.append(f"改进建议: {feedback.comment[:100]}")
            else:
                lessons.append(template[0])

        return lessons[:3]

    def _generate_suggestions(self, feedback: Feedback) -> list[str]:
        """生成改进建议"""
        suggestions = []

        if feedback.rating is None:
            return suggestions

        if feedback.rating <= 2:
            suggestions.append("建议重新评估技术方案")
            suggestions.append("建议增加测试覆盖")
            suggestions.append("建议优化错误处理")
        elif feedback.rating == 3:
            suggestions.append("建议优化代码结构")
            suggestions.append("建议完善文档")

        return suggestions[:3]

    async def _record_to_memory(self, feedback: Feedback) -> None:
        """记录到记忆系统"""
        if not self.memory:
            return

        try:
            await self.memory.record_decision({
                "project_id": feedback.project_id,
                "event_type": "user_feedback",
                "event_details": {
                    "rating": feedback.rating,
                    "comment": feedback.comment,
                    "lessons": feedback.lessons_learned,
                },
                "decision_level": "user_input",
                "decision_answer": f"rating_{feedback.rating}",
                "was_auto_resolved": False,
                "outcome": feedback.comment or f"Rating: {feedback.rating}",
                "success": feedback.rating is not None and feedback.rating >= 3,
                "user_rating": feedback.rating,
            })
        except Exception as e:
            logger.error(f"Failed to record feedback to memory: {e}")

    async def _save_feedback(self, feedback: Feedback) -> None:
        """保存反馈到文件"""
        try:
            data = {
                "feedback_id": feedback.feedback_id,
                "project_id": feedback.project_id,
                "user_id": feedback.user_id,
                "feedback_type": feedback.feedback_type.value,
                "rating": feedback.rating,
                "comment": feedback.comment,
                "lessons_learned": feedback.lessons_learned,
                "suggestions": feedback.suggestions,
                "status": feedback.status.value,
                "created_at": feedback.created_at.isoformat(),
                "processed_at": feedback.processed_at.isoformat() if feedback.processed_at else None,
                "metadata": feedback.metadata,
            }

            with open(self._feedbacks_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(data, ensure_ascii=False) + "\n")
        except Exception as e:
            logger.error(f"Failed to save feedback: {e}")

    def get_pending_requests(self, user_id: str | None = None) -> list[FeedbackRequest]:
        """获取待处理的反馈请求"""
        requests = list(self._pending_requests.values())
        if user_id:
            requests = [r for r in requests if r.user_id == user_id]
        return requests

    def get_feedback(self, feedback_id: str) -> Feedback | None:
        """获取反馈"""
        return self._feedbacks.get(feedback_id)

    def get_project_feedbacks(self, project_id: str) -> list[Feedback]:
        """获取项目的所有反馈"""
        return [f for f in self._feedbacks.values() if f.project_id == project_id]

    def format_feedback_request(self, request: FeedbackRequest) -> str:
        """格式化反馈请求消息"""
        lines = [
            f"📝 {request.message}",
            "",
        ]

        for i, option in enumerate(request.options, 1):
            lines.append(f"{i}. {option}")

        lines.append("")
        lines.append("请回复数字选择评分，或输入详细反馈。")

        return "\n".join(lines)

    def parse_rating_response(self, response: str) -> int | None:
        """解析评分响应"""
        response = response.strip()

        if response.isdigit():
            rating = int(response)
            if 1 <= rating <= 5:
                return 6 - rating

        rating_map = {
            "非常满意": 5,
            "满意": 4,
            "一般": 3,
            "不满意": 2,
            "非常不满意": 1,
            "⭐": 5,
            "👍": 4,
            "👌": 3,
            "👎": 2,
            "💔": 1,
            "excellent": 5,
            "good": 4,
            "okay": 3,
            "bad": 2,
            "terrible": 1,
        }

        response_lower = response.lower()
        for key, rating in rating_map.items():
            if key in response_lower:
                return rating

        return None

    def get_stats(self) -> dict[str, Any]:
        """获取统计信息"""
        total = len(self._feedbacks)
        ratings = [f.rating for f in self._feedbacks.values() if f.rating]
        avg_rating = sum(ratings) / len(ratings) if ratings else 0

        return {
            "total_feedbacks": total,
            "pending_requests": len(self._pending_requests),
            "average_rating": round(avg_rating, 2),
            "rating_distribution": {
                5: sum(1 for r in ratings if r == 5),
                4: sum(1 for r in ratings if r == 4),
                3: sum(1 for r in ratings if r == 3),
                2: sum(1 for r in ratings if r == 2),
                1: sum(1 for r in ratings if r == 1),
            },
        }
