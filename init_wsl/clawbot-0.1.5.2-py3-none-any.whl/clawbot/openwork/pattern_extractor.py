"""
Pattern Extractor - Extract patterns from historical decisions.

This module provides the pattern extractor that analyzes historical
decision records and extracts reusable patterns for self-enhancement.
"""

import json
from loguru import logger
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from clawbot.openwork.memory import OpenWorkMemoryBridge



@dataclass
class DecisionPattern:
    pattern_id: str
    pattern_type: str
    trigger_conditions: dict
    recommended_level: str
    confidence: float
    success_rate: float
    sample_count: int
    created_at: datetime
    last_updated: datetime


class PatternExtractor:
    """Pattern extractor - extracts reusable patterns from history."""

    CONTEXT_KEYWORDS = {
        "认证": "authentication",
        "登录": "login",
        "注册": "register",
        "API": "api",
        "数据库": "database",
        "测试": "testing",
        "重构": "refactor",
        "优化": "optimization",
        "文件": "file",
        "配置": "config",
    }

    def __init__(self, memory_bridge: "OpenWorkMemoryBridge"):
        self.memory = memory_bridge
        self.patterns_file = memory_bridge.workspace / "opencode_patterns.json"

    async def extract_patterns(self) -> list[DecisionPattern]:
        """Extract patterns from historical decisions."""
        all_decisions = await self.memory.get_all_decisions()

        if not all_decisions:
            logger.info("No decisions found for pattern extraction")
            return []

        patterns = []

        operation_patterns = await self._extract_operation_patterns(all_decisions)
        patterns.extend(operation_patterns)

        context_patterns = await self._extract_context_patterns(all_decisions)
        patterns.extend(context_patterns)

        event_patterns = await self._extract_event_patterns(all_decisions)
        patterns.extend(event_patterns)

        await self._save_patterns(patterns)

        logger.info(f"Extracted {len(patterns)} patterns from {len(all_decisions)} decisions")
        return patterns

    async def _extract_operation_patterns(
        self,
        decisions: list[dict],
    ) -> list[DecisionPattern]:
        """Extract operation type patterns."""
        operation_stats: dict[str, dict] = {}

        for dec in decisions:
            op_type = dec.get("event_type", "unknown")

            if op_type not in operation_stats:
                operation_stats[op_type] = {
                    "total": 0,
                    "auto_resolved": 0,
                    "success": 0,
                }

            operation_stats[op_type]["total"] += 1
            if dec.get("was_auto_resolved"):
                operation_stats[op_type]["auto_resolved"] += 1
            if dec.get("success"):
                operation_stats[op_type]["success"] += 1

        patterns = []
        now = datetime.now()

        for op_type, stats in operation_stats.items():
            if stats["total"] < 3:
                continue

            success_rate = stats["success"] / stats["total"] if stats["total"] > 0 else 0
            auto_rate = stats["auto_resolved"] / stats["total"] if stats["total"] > 0 else 0

            if success_rate > 0.8 and auto_rate > 0.5:
                patterns.append(DecisionPattern(
                    pattern_id=f"pat-{uuid.uuid4().hex[:8]}",
                    pattern_type="operation_type",
                    trigger_conditions={"event_type": op_type},
                    recommended_level="auto_resolve",
                    confidence=success_rate,
                    success_rate=success_rate,
                    sample_count=stats["total"],
                    created_at=now,
                    last_updated=now,
                ))

        return patterns

    async def _extract_context_patterns(
        self,
        decisions: list[dict],
    ) -> list[DecisionPattern]:
        """Extract context feature patterns."""
        keyword_stats: dict[str, dict] = {}

        for dec in decisions:
            details_str = json.dumps(dec.get("event_details", {}), ensure_ascii=False)

            for kw, tag in self.CONTEXT_KEYWORDS.items():
                if kw in details_str:
                    if tag not in keyword_stats:
                        keyword_stats[tag] = {"total": 0, "success": 0}
                    keyword_stats[tag]["total"] += 1
                    if dec.get("success"):
                        keyword_stats[tag]["success"] += 1

        patterns = []
        now = datetime.now()

        for tag, stats in keyword_stats.items():
            if stats["total"] < 3:
                continue

            success_rate = stats["success"] / stats["total"]

            if success_rate > 0.7:
                patterns.append(DecisionPattern(
                    pattern_id=f"pat-{uuid.uuid4().hex[:8]}",
                    pattern_type="context_feature",
                    trigger_conditions={"keyword": tag},
                    recommended_level="auto_resolve",
                    confidence=success_rate,
                    success_rate=success_rate,
                    sample_count=stats["total"],
                    created_at=now,
                    last_updated=now,
                ))

        return patterns

    async def _extract_event_patterns(
        self,
        decisions: list[dict],
    ) -> list[DecisionPattern]:
        """Extract event signature patterns."""
        return []

    async def _save_patterns(self, patterns: list[DecisionPattern]):
        """Save patterns to file."""
        data = []
        for p in patterns:
            p_dict = asdict(p)
            p_dict["created_at"] = p.created_at.isoformat()
            p_dict["last_updated"] = p.last_updated.isoformat()
            data.append(p_dict)

        with open(self.patterns_file, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    async def load_patterns(self) -> list[DecisionPattern]:
        """Load patterns from file."""
        if not self.patterns_file.exists():
            return []

        patterns = []
        with open(self.patterns_file, encoding="utf-8") as f:
            data = json.load(f)

        for p_dict in data:
            patterns.append(DecisionPattern(
                pattern_id=p_dict["pattern_id"],
                pattern_type=p_dict["pattern_type"],
                trigger_conditions=p_dict["trigger_conditions"],
                recommended_level=p_dict["recommended_level"],
                confidence=p_dict["confidence"],
                success_rate=p_dict["success_rate"],
                sample_count=p_dict["sample_count"],
                created_at=datetime.fromisoformat(p_dict["created_at"]),
                last_updated=datetime.fromisoformat(p_dict["last_updated"]),
            ))

        return patterns

    async def get_matching_pattern(
        self,
        event_type: str,
        event_details: dict,
    ) -> DecisionPattern | None:
        """Get matching pattern for an event."""
        patterns = await self.load_patterns()

        for p in patterns:
            if p.pattern_type == "operation_type":
                if p.trigger_conditions.get("event_type") == event_type:
                    if p.confidence > 0.8:
                        return p

        details_str = json.dumps(event_details, ensure_ascii=False).lower()
        for p in patterns:
            if p.pattern_type == "context_feature":
                keyword = p.trigger_conditions.get("keyword", "")
                if keyword and keyword in details_str:
                    if p.confidence > 0.7:
                        return p

        return None

    async def get_pattern_stats(self) -> dict:
        """Get pattern statistics."""
        patterns = await self.load_patterns()

        if not patterns:
            return {
                "total_patterns": 0,
                "by_type": {},
                "avg_confidence": 0,
                "avg_success_rate": 0,
            }

        by_type: dict[str, int] = {}
        total_confidence = 0
        total_success_rate = 0

        for p in patterns:
            by_type[p.pattern_type] = by_type.get(p.pattern_type, 0) + 1
            total_confidence += p.confidence
            total_success_rate += p.success_rate

        return {
            "total_patterns": len(patterns),
            "by_type": by_type,
            "avg_confidence": total_confidence / len(patterns),
            "avg_success_rate": total_success_rate / len(patterns),
        }
