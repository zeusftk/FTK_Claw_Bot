"""
UnifiedTaskRouter - 统一任务路由器

在 AgentLoop 层面决定执行路径：
- CONVERSATION: 纯对话，LLM 直接响应
- OPENWORK_EXECUTION: 需要 OpenWork 执行
- LOCAL_TOOL: 本地工具快速执行
- SYSTEM_COMMAND: 系统命令
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from loguru import logger

from clawbot.core.routing_constants import (
    EXECUTION_THRESHOLD,
    CONVERSATION_THRESHOLD,
    RoutingHelper,
    TaskCategory,
)


@dataclass
class RouteDecision:
    """路由决策结果"""
    category: TaskCategory
    handler: str
    confidence: float = 1.0
    task_type: str | None = None
    reasoning: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)


class UnifiedTaskRouter:
    """
    统一任务路由器

    职责：
    1. 分析用户请求意图
    2. 决定执行路径
    3. 协调各执行器

    与 IntentClassifier 保持一致，共享常量和辅助方法来自 routing_constants 模块。
    """

    # 阈值常量 - 从共享模块导入
    EXECUTION_THRESHOLD = EXECUTION_THRESHOLD
    CONVERSATION_THRESHOLD = CONVERSATION_THRESHOLD

    def __init__(
        self,
        openwork_enabled: bool = True,
        execution_threshold: float | None = None,
        conversation_threshold: float | None = None,
    ):
        self.openwork_enabled = openwork_enabled
        self.execution_threshold = execution_threshold or self.EXECUTION_THRESHOLD
        self.conversation_threshold = conversation_threshold or self.CONVERSATION_THRESHOLD

        self._stats = {
            "total_routed": 0,
            "by_category": {cat.value: 0 for cat in TaskCategory},
        }

    def route(self, message: str, context: dict[str, Any] | None = None) -> RouteDecision:
        """
        路由决策

        Args:
            message: 用户消息
            context: 额外上下文

        Returns:
            RouteDecision: 包含目标路由和执行参数
        """
        self._stats["total_routed"] += 1

        message_lower = message.lower().strip()

        if not message_lower:
            decision = RouteDecision(
                category=TaskCategory.CONVERSATION,
                handler="llm_direct",
                reasoning="Empty message",
            )
            self._stats["by_category"][decision.category.value] += 1
            return decision

        # 使用共享的辅助方法
        if RoutingHelper.is_system_command(message_lower):
            decision = RouteDecision(
                category=TaskCategory.SYSTEM_COMMAND,
                handler="system",
                reasoning="System command detected",
            )
            self._stats["by_category"][decision.category.value] += 1
            return decision

        execution_score = self._calculate_execution_score(message_lower)
        conversation_score = self._calculate_conversation_score(message_lower)

        if execution_score > self.execution_threshold:
            task_type = RoutingHelper.detect_task_type(message_lower)
            decision = RouteDecision(
                category=TaskCategory.OPENWORK_EXECUTION if self.openwork_enabled else TaskCategory.LOCAL_TOOL,
                handler="openwork" if self.openwork_enabled else "local_tools",
                confidence=min(execution_score, 1.0),
                task_type=task_type,
                reasoning=f"Execution task detected (score: {execution_score:.2f}, type: {task_type})",
            )
        elif conversation_score > self.conversation_threshold:
            decision = RouteDecision(
                category=TaskCategory.CONVERSATION,
                handler="llm_direct",
                confidence=min(conversation_score, 1.0),
                reasoning=f"Conversation detected (score: {conversation_score:.2f})",
            )
        else:
            decision = RouteDecision(
                category=TaskCategory.LOCAL_TOOL,
                handler="local_tools",
                confidence=0.5,
                reasoning=f"Default routing (exec: {execution_score:.2f}, conv: {conversation_score:.2f})",
            )

        self._stats["by_category"][decision.category.value] += 1
        return decision

    def route_with_context(self, message: str, context: dict[str, Any]) -> RouteDecision:
        """
        带上下文的路由决策

        考虑频道特性和用户偏好
        """
        base_decision = self.route(message, context)

        channel = context.get("channel", "")

        if channel == "cli":
            if base_decision.category == TaskCategory.LOCAL_TOOL:
                base_decision.confidence *= 1.1
        elif channel in ["telegram", "discord", "slack"]:
            if base_decision.category == TaskCategory.CONVERSATION:
                base_decision.confidence *= 1.1

        return base_decision

    def _calculate_execution_score(self, message: str) -> float:
        """计算执行意图分数 - 使用共享方法"""
        return RoutingHelper.calculate_execution_score(message, include_code_patterns=True)

    def _calculate_conversation_score(self, message: str) -> float:
        """计算对话意图分数 - 使用共享方法"""
        return RoutingHelper.calculate_conversation_score(message, include_question_patterns=True)

    def get_stats(self) -> dict[str, Any]:
        """获取路由统计"""
        return {
            **self._stats,
            "openwork_enabled": self.openwork_enabled,
            "execution_threshold": self.execution_threshold,
            "conversation_threshold": self.conversation_threshold,
        }

    def update_thresholds(
        self,
        execution: float | None = None,
        conversation: float | None = None,
    ) -> None:
        """更新阈值"""
        if execution is not None:
            self.execution_threshold = execution
        if conversation is not None:
            self.conversation_threshold = conversation
        logger.info(
            f"Thresholds updated: execution={self.execution_threshold}, "
            f"conversation={self.conversation_threshold}"
        )