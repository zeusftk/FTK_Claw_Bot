"""
ClawbotMaster - clawbot 统一控制器

统一调度入口，管理所有组件的协调工作。
"""

from __future__ import annotations

import asyncio
from loguru import logger
import uuid
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Protocol, runtime_checkable

from clawbot.core.state_machine import (
    InvalidStateTransition,
    Project,
    ProjectState,
    ProjectStateMachine,
)

if TYPE_CHECKING:
    from clawbot.openwork.progress_reporter import ProgressEvent



@runtime_checkable
class LLMProviderProtocol(Protocol):
    """LLM Provider 接口协议"""

    async def complete(
        self,
        messages: list[dict],
        *,
        model: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        **kwargs: Any,
    ) -> Any:
        """完成对话"""
        ...


@runtime_checkable
class OpenWorkServiceProtocol(Protocol):
    """OpenWork Service 接口协议"""

    @property
    def base_url(self) -> str:
        """获取服务基础 URL"""
        ...

    async def execute(
        self,
        task: str,
        workspace: Path,
        **kwargs: Any,
    ) -> Any:
        """执行任务"""
        ...


@dataclass
class SystemStatus:
    """系统状态"""
    running: bool
    projects_count: int
    active_projects_count: int
    memory_stats: dict[str, Any]
    evolution_stats: dict[str, Any] | None
    uptime_seconds: float
    last_evolution: datetime | None = None
    errors_count: int = 0


class ClawbotMaster:
    """
    clawbot 统一控制器

    职责：
    1. 统一调度入口 - 所有请求通过此入口
    2. 状态机管理 - 管理项目生命周期状态
    3. 进化触发器 - 控制自我进化的时机和条件
    4. 组件协调 - 协调各组件之间的交互
    """

    def __init__(
        self,
        workspace: Path,
        llm_provider: LLMProviderProtocol,
        openwork_service: OpenWorkServiceProtocol | None = None,
        enable_evolution: bool = True,
        evolution_interval_hours: int = 24,
        on_progress: Callable[["ProgressEvent"], None] | None = None,
        on_completed: Callable[[Project], None] | None = None,
        on_feedback_request: Callable[[str, str], None] | None = None,
    ):
        self.workspace = workspace
        self.llm = llm_provider
        self.openwork = openwork_service
        self._on_progress = on_progress
        self._on_completed = on_completed
        self._on_feedback_request = on_feedback_request

        self._state_machine = ProjectStateMachine()
        self._projects: dict[str, Project] = {}
        self._running = False
        self._started_at: datetime | None = None
        self._errors_count = 0

        self._ensure_workspace()

        self._init_components()

        self._evolution_scheduler: Any | None = None
        if enable_evolution:
            self._init_evolution_scheduler(evolution_interval_hours)

    def _ensure_workspace(self) -> None:
        """确保工作目录存在"""
        self.workspace.mkdir(parents=True, exist_ok=True)
        (self.workspace / "memory").mkdir(parents=True, exist_ok=True)
        (self.workspace / "sessions").mkdir(parents=True, exist_ok=True)
        (self.workspace / "projects").mkdir(parents=True, exist_ok=True)

    def _init_components(self) -> None:
        """初始化组件"""
        from clawbot.openwork.feedback_collector import FeedbackCollector
        from clawbot.openwork.idea_processor import IdeaProcessor
        from clawbot.openwork.memory import OpenWorkMemoryBridge
        from clawbot.openwork.progress_reporter import ProgressReporter
        from clawbot.openwork.task_router import TaskRouter

        self.memory = OpenWorkMemoryBridge(workspace=self.workspace / "memory")

        self.idea_processor = IdeaProcessor(
            llm_provider=self.llm,
            workspace=self.workspace,
        )

        self.task_router = TaskRouter(
            openwork_service=self.openwork,
            default_workspace=self.workspace,
        )

        self.progress_reporter = ProgressReporter(
            base_url=self.openwork.base_url if self.openwork else "http://localhost:7777",
            on_progress=self._handle_progress_event,
        )

        self.feedback_collector = FeedbackCollector(
            memory_bridge=self.memory,
            on_feedback_collected=self._handle_feedback_collected,
        )

    def _init_evolution_scheduler(self, interval_hours: int) -> None:
        """初始化进化调度器"""
        try:
            from clawbot.evolution.hybrid_engine import HybridEvolutionEngine
            from clawbot.evolution.scheduler import EvolutionScheduler

            self.evolution_engine = HybridEvolutionEngine(
                memory=self.memory,
                llm=self.llm,
                feedback_processor=self.feedback_collector,
            )

            self._evolution_scheduler = EvolutionScheduler(
                engine=self.evolution_engine,
                interval_hours=interval_hours,
            )
        except ImportError:
            logger.warning("Evolution module not available, evolution disabled")
            self.evolution_engine = None
            self._evolution_scheduler = None

    async def start(self) -> None:
        """启动系统"""
        if self._running:
            return

        self._running = True
        self._started_at = datetime.now()

        if self._evolution_scheduler:
            await self._evolution_scheduler.start()

        logger.info("ClawbotMaster started")

    async def stop(self) -> None:
        """停止系统"""
        if not self._running:
            return

        self._running = False

        if self._evolution_scheduler:
            await self._evolution_scheduler.stop()

        await self.progress_reporter.stop_listening()

        logger.info("ClawbotMaster stopped")

    async def submit_idea(
        self,
        idea: str,
        user_id: str = "default",
        workspace: Path | None = None,
    ) -> Project:
        """
        提交用户想法 - 统一入口

        流程：
        1. 创建项目
        2. 状态机进入 ANALYZING
        3. 调用 IdeaProcessor 解析
        4. 调用 MemoryManager 检索历史
        5. 调用 TaskRouter 路由
        6. 执行并监控
        7. 收集反馈
        8. 触发进化（如需要）
        """
        project = await self._create_project(idea, user_id, workspace)

        try:
            self._state_machine.transition(
                project, ProjectState.ANALYZING, "开始分析需求"
            )

            processed = await self.idea_processor.process(idea, user_id)
            project.processed_idea = processed

            logger.info(
                f"Project {project.project_id}: Idea processed, "
                f"type: {processed.task_type.value if hasattr(processed, 'task_type') else 'unknown'}"
            )

            similar = await self.memory.search_similar_decisions(idea)
            project.similar_cases = similar

            if processed.clarifications_needed if hasattr(processed, 'clarifications_needed') else []:
                if self._on_feedback_request:
                    clarification = await self.idea_processor.clarify(
                        idea,
                        processed.clarifications_needed,
                    )
                    self._on_feedback_request(project.project_id, clarification)

                self._state_machine.transition(
                    project, ProjectState.PENDING_CONFIRMATION, "需要澄清需求"
                )
                return project

            decision = await self.task_router.route(processed)
            project.route_decision = decision

            if decision.requires_confirmation:
                if self._on_feedback_request:
                    self._on_feedback_request(
                        project.project_id,
                        decision.confirmation_message or "需要确认执行",
                    )

                self._state_machine.transition(
                    project, ProjectState.PENDING_CONFIRMATION, "需要确认"
                )
                return project

            return await self._execute_project(project, decision)

        except Exception as e:
            logger.error(f"Project {project.project_id} failed: {e}")
            self._errors_count += 1

            try:
                self._state_machine.transition(
                    project, ProjectState.FAILED, str(e)
                )
            except InvalidStateTransition:
                project.state = ProjectState.FAILED
                project.updated_at = datetime.now()

            project.metadata["error"] = str(e)

            if self._on_completed:
                self._on_completed(project)

            return project

    async def _create_project(
        self,
        idea: str,
        user_id: str,
        workspace: Path | None,
    ) -> Project:
        """创建新项目"""
        project_id = f"proj-{uuid.uuid4().hex[:8]}"
        ws = workspace or self.workspace / "projects" / user_id / project_id

        project = Project(
            project_id=project_id,
            user_id=user_id,
            original_idea=idea,
            state=ProjectState.IDLE,
            workspace=ws,
        )

        self._projects[project_id] = project

        logger.info(f"Project created: {project_id} for user {user_id}")

        return project

    async def _execute_project(
        self,
        project: Project,
        decision: Any,
    ) -> Project:
        """执行项目"""
        self._state_machine.transition(
            project, ProjectState.RUNNING, "开始执行"
        )
        project.started_at = datetime.now()

        await self.progress_reporter.start_listening()

        result = await self.task_router.execute(
            decision, project.original_idea, project.workspace
        )

        project.result = result
        project.session_id = result.session_id if hasattr(result, 'session_id') else None

        if result.success:
            self._state_machine.transition(
                project, ProjectState.WAITING_FEEDBACK, "执行完成，等待反馈"
            )
            project.completed_at = datetime.now()

            await self._request_feedback(project)
        else:
            self._state_machine.transition(
                project, ProjectState.FAILED, "执行失败"
            )
            project.completed_at = datetime.now()

        if self._on_completed:
            self._on_completed(project)

        return project

    async def _request_feedback(self, project: Project) -> None:
        """请求用户反馈"""
        feedback = await self.feedback_collector.collect(
            project.project_id,
            project.user_id,
            timeout=300.0,
        )

        if feedback:
            project.feedback = feedback
            await self._process_feedback(project, feedback)

    async def _process_feedback(self, project: Project, feedback: Any) -> None:
        """处理反馈"""
        result = await self.feedback_collector.process_feedback(feedback)

        if feedback.rating and feedback.rating >= 4:
            await self.memory.archive_success_case(
                idea=project.original_idea,
                result={
                    "summary": project.result.output[:500] if project.result and hasattr(project.result, 'output') else "",
                    "workspace_snapshot": str(project.workspace),
                },
                quality_score=feedback.rating,
                decisions=[{"project_id": project.project_id}],
            )

        self._state_machine.transition(
            project, ProjectState.COMPLETED, "反馈处理完成"
        )

        if self.evolution_engine:
            await self.evolution_engine.process_feedback_immediate(feedback)

        logger.info(
            f"Project {project.project_id} completed: "
            f"rating: {feedback.rating}, "
            f"patterns: {result.patterns_extracted if hasattr(result, 'patterns_extracted') else 0}, "
            f"rules: {result.rules_updated if hasattr(result, 'rules_updated') else 0}"
        )

    async def confirm_project(self, project_id: str, approved: bool = True) -> Project | None:
        """确认项目执行"""
        project = self._projects.get(project_id)
        if not project:
            return None

        if project.state != ProjectState.PENDING_CONFIRMATION:
            return project

        if approved:
            await self._execute_approved_project(project)
        else:
            self._state_machine.transition(
                project, ProjectState.CANCELLED, "用户取消"
            )

        return project

    async def _execute_approved_project(self, project: Project) -> None:
        """执行已确认的项目"""
        try:
            decision = project.route_decision
            if not decision:
                decision = await self.task_router.route(project.processed_idea)

            await self._execute_project(project, decision)

        except Exception as e:
            logger.error(f"Approved project {project.project_id} failed: {e}")
            self._errors_count += 1

            self._state_machine.transition(
                project, ProjectState.FAILED, str(e)
            )
            project.metadata["error"] = str(e)

            if self._on_completed:
                self._on_completed(project)

    async def provide_feedback(
        self,
        project_id: str,
        rating: int,
        comment: str | None = None,
    ) -> bool:
        """提供反馈"""
        project = self._projects.get(project_id)
        if not project:
            return False

        if project.state != ProjectState.WAITING_FEEDBACK:
            return False

        feedback = await self.feedback_collector.submit_direct(
            project_id=project.project_id,
            user_id=project.user_id,
            rating=rating,
            comment=comment,
        )

        project.feedback = feedback

        asyncio.create_task(self._process_feedback(project, feedback))

        return True

    async def trigger_evolution(self) -> dict[str, Any]:
        """手动触发自我进化"""
        if not self.evolution_engine:
            return {"error": "Evolution not enabled"}

        result = await self.evolution_engine.evolve(deep_analysis=True)

        return {
            "timestamp": result.timestamp.isoformat() if hasattr(result, 'timestamp') else datetime.now().isoformat(),
            "applied": result.applied if hasattr(result, 'applied') else False,
            "adjustments": result.statistical.adjustments if hasattr(result, 'statistical') and hasattr(result.statistical, 'adjustments') else {},
            "new_rules": result.statistical.new_rules if hasattr(result, 'statistical') and hasattr(result.statistical, 'new_rules') else [],
        }

    def get_project(self, project_id: str) -> Project | None:
        """获取项目"""
        return self._projects.get(project_id)

    def get_user_projects(
        self,
        user_id: str,
        state: ProjectState | None = None,
    ) -> list[Project]:
        """获取用户的项目列表"""
        projects = [
            p for p in self._projects.values()
            if p.user_id == user_id
        ]

        if state:
            projects = [p for p in projects if p.state == state]

        return sorted(projects, key=lambda x: x.created_at, reverse=True)

    def get_active_project(self, user_id: str) -> Project | None:
        """获取用户的活跃项目"""
        for project in self._projects.values():
            if project.user_id == user_id and project.is_active:
                return project
        return None

    async def get_system_status(self) -> SystemStatus:
        """获取系统状态"""
        memory_stats = await self.memory.get_stats()

        evolution_stats = None
        last_evolution = None
        if self.evolution_engine:
            evolution_stats = self.evolution_engine.get_stats()

        active_count = sum(1 for p in self._projects.values() if p.is_active)

        uptime = 0.0
        if self._started_at:
            uptime = (datetime.now() - self._started_at).total_seconds()

        return SystemStatus(
            running=self._running,
            projects_count=len(self._projects),
            active_projects_count=active_count,
            memory_stats=memory_stats,
            evolution_stats=evolution_stats,
            uptime_seconds=uptime,
            last_evolution=last_evolution,
            errors_count=self._errors_count,
        )

    def _handle_progress_event(self, event: Any) -> None:
        """处理进度事件"""
        if self._on_progress:
            try:
                self._on_progress(event)
            except Exception as e:
                logger.error(f"Progress callback error: {e}")

    def _handle_feedback_collected(self, feedback: Any) -> None:
        """处理反馈收集事件"""
        logger.info(
            f"Feedback collected: {feedback.feedback_id if hasattr(feedback, 'feedback_id') else 'unknown'}, "
            f"rating: {feedback.rating if hasattr(feedback, 'rating') else 'unknown'}"
        )
