"""
clawbot Core Module

This module provides the core components for clawbot autonomous system:
- ClawbotMaster: Unified controller for all operations
- ProjectStateMachine: State machine for project lifecycle
- UnifiedTaskRouter: Unified task router for execution path decisions
"""

from clawbot.core.master import ClawbotMaster, SystemStatus
from clawbot.core.state_machine import (
    InvalidStateTransition,
    ProjectState,
    ProjectStateMachine,
)
from clawbot.core.task_router import (
    RouteDecision,
    TaskCategory,
    UnifiedTaskRouter,
)

__all__ = [
    "ClawbotMaster",
    "SystemStatus",
    "ProjectState",
    "ProjectStateMachine",
    "InvalidStateTransition",
    "TaskCategory",
    "RouteDecision",
    "UnifiedTaskRouter",
]
