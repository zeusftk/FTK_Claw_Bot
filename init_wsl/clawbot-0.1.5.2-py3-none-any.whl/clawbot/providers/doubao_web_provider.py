"""Doubao Web Provider - Browser-based authentication for Doubao AI.

Uses Playwright for browser automation to capture session cookies.
Supports streaming SSE responses from Doubao's Samantha API.
"""

from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, AsyncGenerator

import httpx
from loguru import logger

from clawbot.providers.base import LLMProvider, LLMResponse, ToolCallRequest

DOUBAO_API_BASE = "https://www.doubao.com"
DOUBAO_SAMANTHA_ENDPOINT = "/samantha/chat/completion"
DOUBAO_LOGIN_URL = "https://www.doubao.com/chat/"
DEFAULT_CDP_PORT = 9222
DEFAULT_TIMEOUT = 300
CREDENTIALS_PATH = "~/.clawbot/doubao_web_creds.json"


@dataclass
class DoubaoAuth:
    """Doubao authentication credentials."""

    sessionid: str
    ttwid: str | None = None
    user_agent: str = ""
    ms_token: str | None = None
    a_bogus: str | None = None
    fp: str | None = None
    tea_uuid: str | None = None
    device_id: str | None = None
    web_tab_id: str | None = None
    aid: str | None = None
    version_code: str | None = None
    pc_version: str | None = None
    region: str | None = None
    language: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "sessionid": self.sessionid,
            "ttwid": self.ttwid,
            "user_agent": self.user_agent,
            "ms_token": self.ms_token,
            "a_bogus": self.a_bogus,
            "fp": self.fp,
            "tea_uuid": self.tea_uuid,
            "device_id": self.device_id,
            "web_tab_id": self.web_tab_id,
            "aid": self.aid,
            "version_code": self.version_code,
            "pc_version": self.pc_version,
            "region": self.region,
            "language": self.language,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "DoubaoAuth":
        return cls(
            sessionid=data.get("sessionid", ""),
            ttwid=data.get("ttwid"),
            user_agent=data.get("user_agent", ""),
            ms_token=data.get("ms_token"),
            a_bogus=data.get("a_bogus"),
            fp=data.get("fp"),
            tea_uuid=data.get("tea_uuid"),
            device_id=data.get("device_id"),
            web_tab_id=data.get("web_tab_id"),
            aid=data.get("aid"),
            version_code=data.get("version_code"),
            pc_version=data.get("pc_version"),
            region=data.get("region"),
            language=data.get("language"),
        )


@dataclass
class DoubaoClientConfig:
    """Doubao API client configuration."""

    aid: str = "497858"
    device_platform: str = "web"
    language: str = "zh"
    pkg_type: str = "release_version"
    real_aid: str = "497858"
    region: str = "CN"
    samantha_web: str = "1"
    sys_region: str = "CN"
    use_olympus_account: str = "1"
    version_code: str = "20800"
    ms_token: str | None = None
    a_bogus: str | None = None
    fp: str | None = None
    tea_uuid: str | None = None
    device_id: str | None = None
    web_tab_id: str | None = None
    pc_version: str | None = None


class DoubaoWebClient:
    """Doubao Web API client."""

    def __init__(self, auth: DoubaoAuth | str, config: DoubaoClientConfig | None = None):
        if isinstance(auth, str):
            try:
                auth_data = json.loads(auth)
                if isinstance(auth_data, str):
                    self.auth = DoubaoAuth(sessionid=auth_data)
                else:
                    self.auth = DoubaoAuth.from_dict(auth_data)
            except json.JSONDecodeError:
                self.auth = DoubaoAuth(sessionid=auth)
        else:
            self.auth = auth

        dynamic_config: dict[str, Any] = {}
        if self.auth.ms_token:
            dynamic_config["ms_token"] = self.auth.ms_token
        if self.auth.a_bogus:
            dynamic_config["a_bogus"] = self.auth.a_bogus
        if self.auth.fp:
            dynamic_config["fp"] = self.auth.fp
        if self.auth.tea_uuid:
            dynamic_config["tea_uuid"] = self.auth.tea_uuid
        if self.auth.device_id:
            dynamic_config["device_id"] = self.auth.device_id
        if self.auth.web_tab_id:
            dynamic_config["web_tab_id"] = self.auth.web_tab_id
        if self.auth.aid:
            dynamic_config["aid"] = self.auth.aid
        if self.auth.version_code:
            dynamic_config["version_code"] = self.auth.version_code
        if self.auth.pc_version:
            dynamic_config["pc_version"] = self.auth.pc_version
        if self.auth.region:
            dynamic_config["region"] = self.auth.region
        if self.auth.language:
            dynamic_config["language"] = self.auth.language

        if config:
            base_config = {
                "aid": config.aid,
                "device_platform": config.device_platform,
                "language": config.language,
                "pkg_type": config.pkg_type,
                "real_aid": config.real_aid,
                "region": config.region,
                "samantha_web": config.samantha_web,
                "sys_region": config.sys_region,
                "use_olympus_account": config.use_olympus_account,
                "version_code": config.version_code,
            }
        else:
            base_config = {
                "aid": "497858",
                "device_platform": "web",
                "language": "zh",
                "pkg_type": "release_version",
                "real_aid": "497858",
                "region": "CN",
                "samantha_web": "1",
                "sys_region": "CN",
                "use_olympus_account": "1",
                "version_code": "20800",
            }

        self._config = {**base_config, **dynamic_config}

    def _get_headers(self) -> dict[str, str]:
        headers = {
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
            "User-Agent": self.auth.user_agent
            or "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Referer": "https://www.doubao.com/chat/",
            "Origin": "https://www.doubao.com",
            "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "keep-alive",
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "same-origin",
            "Agw-js-conv": "str",
        }

        cookie_parts = [f"sessionid={self.auth.sessionid}"]
        if self.auth.ttwid:
            try:
                from urllib.parse import unquote

                cookie_parts.append(f"ttwid={unquote(self.auth.ttwid)}")
            except Exception:
                cookie_parts.append(f"ttwid={self.auth.ttwid}")
        headers["Cookie"] = "; ".join(cookie_parts)

        return headers

    def _build_query_params(self) -> str:
        params = []
        for key, value in self._config.items():
            if value is not None and key not in ("ms_token", "a_bogus"):
                params.append(f"{key}={value}")

        if self._config.get("ms_token"):
            params.append(f"ms_token={self._config['ms_token']}")
        if self._config.get("a_bogus"):
            params.append(f"a_bogus={self._config['a_bogus']}")

        return "&".join(params)

    def _merge_messages_for_samantha(self, messages: list[dict[str, Any]]) -> str:
        """Merge messages into Samantha format."""
        parts = []
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            if isinstance(content, list):
                text_parts = []
                for item in content:
                    if isinstance(item, dict) and item.get("type") == "text":
                        text_parts.append(item.get("text", ""))
                    elif isinstance(item, str):
                        text_parts.append(item)
                content = " ".join(text_parts)
            parts.append(f"<|im_start|>{role}\n{content}\n")
        parts.append("<|im_end|>\n")
        return "".join(parts)

    async def chat_completions(
        self,
        messages: list[dict[str, Any]],
        model: str = "doubao-seed-2.0",
        stream: bool = True,
        on_chunk: Any | None = None,
    ) -> LLMResponse:
        """Send chat completion request."""
        query_params = self._build_query_params()
        url = f"{DOUBAO_API_BASE}{DOUBAO_SAMANTHA_ENDPOINT}?{query_params}"

        text = self._merge_messages_for_samantha(messages)
        body = {
            "messages": [
                {
                    "content": json.dumps({"text": text}),
                    "content_type": 2001,
                    "attachments": [],
                    "references": [],
                }
            ],
            "completion_option": {
                "is_regen": False,
                "with_suggest": True,
                "need_create_conversation": True,
                "launch_stage": 1,
                "is_replace": False,
                "is_delete": False,
                "message_from": 0,
                "event_id": "0",
            },
            "conversation_id": "0",
            "local_conversation_id": f"local_16{str(int(time.time() * 1000))[-14:]}",
            "local_message_id": str(uuid.uuid4()),
        }

        headers = self._get_headers()
        logger.debug(f"Doubao request URL: {url}")

        async with httpx.AsyncClient(timeout=60.0) as client:
            async with client.stream("POST", url, headers=headers, json=body) as response:
                if response.status_code != 200:
                    error_text = await response.aread()
                    raise DoubaoAPIError(
                        f"HTTP {response.status_code}: {error_text.decode('utf-8', 'ignore')}"
                    )

                return await self._consume_sse(response)

    async def _consume_sse(self, response: httpx.Response) -> LLMResponse:
        """Consume SSE stream and parse response."""
        content = ""
        tool_calls: list[ToolCallRequest] = []
        finish_reason = "stop"

        async for event in self._iter_sse(response):
            event_type = event.get("event")
            data = event.get("data", {})

            if event_type == "CHUNK_DELTA":
                if isinstance(data, dict) and data.get("text"):
                    content += data["text"]

            elif event_type == "STREAM_CHUNK":
                if isinstance(data, dict) and data.get("patch_op"):
                    for patch in data["patch_op"]:
                        if isinstance(patch, dict) and patch.get("patch_value", {}).get(
                            "tts_content"
                        ):
                            content += patch["patch_value"]["tts_content"]

            elif event_type == "STREAM_MSG_NOTIFY":
                if isinstance(data, dict) and data.get("content", {}).get("content_block"):
                    for block in data["content"]["content_block"]:
                        if isinstance(block, dict) and block.get("content", {}).get(
                            "text_block", {}
                        ).get("text"):
                            content += block["content"]["text_block"]["text"]

            elif event_type == "SSE_REPLY_END":
                pass

            elif event_type == "SSE_HEARTBEAT":
                pass

            elif event_type == "SSE_ACK":
                pass

            elif event_type == "STREAM_ERROR":
                error_code = data.get("error_code") if isinstance(data, dict) else None
                error_msg = (
                    data.get("error_msg", "Unknown error")
                    if isinstance(data, dict)
                    else "Unknown error"
                )
                if error_code == 710022004:
                    raise DoubaoRateLimitError(f"Rate limit: {error_msg}")
                raise DoubaoAPIError(f"API error: {error_msg} (code: {error_code})")

        return LLMResponse(
            content=content,
            tool_calls=tool_calls,
            finish_reason=finish_reason,
        )

    async def _iter_sse(self, response: httpx.Response) -> AsyncGenerator[dict[str, Any], None]:
        """Iterate SSE events from response."""
        current_event: dict[str, Any] = {}

        async for line in response.aiter_lines():
            if line == "":
                if current_event.get("event") and current_event.get("data"):
                    yield current_event
                current_event = {}
                continue

            single = self._parse_single_line_sse(line)
            if single:
                yield single
                current_event = {}
                continue

            samantha_result = self._parse_samantha_line(line)
            if samantha_result:
                yield samantha_result
                current_event = {}
                continue

            if line.startswith("id: "):
                current_event["id"] = line[4:].strip()
            elif line.startswith("event: "):
                current_event["event"] = line[7:].strip()
            elif line.startswith("data: "):
                data_str = line[6:].strip()
                try:
                    current_event["data"] = json.loads(data_str)
                except json.JSONDecodeError:
                    current_event["data"] = data_str

        if current_event.get("event") and current_event.get("data"):
            yield current_event

    def _parse_samantha_line(self, line: str) -> dict[str, Any] | None:
        """Parse samantha format line: raw JSON with event_type and event_data."""
        try:
            if line.startswith("data: "):
                line = line[6:].strip()

            raw = json.loads(line)
            if not isinstance(raw, dict):
                return None

            event_type = raw.get("event_type")
            if event_type is None:
                return None

            if event_type == 2003:
                return {"event": "SSE_REPLY_END", "data": raw}

            if event_type == 2005:
                event_data_str = raw.get("event_data")
                if event_data_str:
                    try:
                        result = json.loads(event_data_str)
                        code = result.get("code")
                        if code is not None and code != 0:
                            error_msg = result.get("message", "Unknown error")
                            return {
                                "event": "STREAM_ERROR",
                                "data": {"error_code": code, "error_msg": error_msg},
                            }
                    except (json.JSONDecodeError, TypeError, KeyError):
                        pass
                return None

            if event_type != 2001:
                return None

            event_data_str = raw.get("event_data")
            if not event_data_str:
                return None

            result = json.loads(event_data_str)

            code = result.get("code")
            if code is not None and code != 0:
                error_code = code
                error_msg = result.get("message", "Unknown error")
                return {
                    "event": "STREAM_ERROR",
                    "data": {"error_code": error_code, "error_msg": error_msg},
                }

            is_finish = result.get("is_finish", False)
            if is_finish:
                return None

            message = result.get("message", {})
            content_type = message.get("content_type")
            if content_type not in (2001, 2008):
                return None

            message_content = message.get("content")
            if not message_content:
                return None

            content = json.loads(message_content)
            if content.get("text"):
                return {"event": "CHUNK_DELTA", "data": {"text": content["text"]}}

        except (json.JSONDecodeError, TypeError, KeyError):
            pass
        return None

    def _parse_single_line_sse(self, line: str) -> dict[str, Any] | None:
        """Parse single-line SSE format: id: 123 event: XXX data: {...}"""
        import re

        match = re.match(r"id:\s*\d+\s+event:\s*(\S+)\s+data:\s*(.+)", line)
        if not match:
            return None
        event = match.group(1).strip()
        data_str = match.group(2).strip()
        try:
            data = json.loads(data_str)
        except json.JSONDecodeError:
            data = data_str
        return {"event": event, "data": data}


class DoubaoWebProvider(LLMProvider):
    """Doubao Web provider using browser-based authentication."""

    def __init__(self, default_model: str = "doubao-web/doubao-seed-2.0"):
        super().__init__(api_key=None, api_base=None)
        self.default_model = default_model
        self._auth: DoubaoAuth | None = None
        self._client: DoubaoWebClient | None = None
        self._creds_path = Path(CREDENTIALS_PATH).expanduser()
        self._load_credentials()

    def _load_credentials(self) -> None:
        """Load credentials from file."""
        if self._creds_path.exists():
            try:
                data = json.loads(self._creds_path.read_text())
                self._auth = DoubaoAuth.from_dict(data)
                self._client = DoubaoWebClient(self._auth)
                logger.debug(f"Loaded Doubao credentials from {self._creds_path}")
            except Exception as e:
                logger.warning(f"Failed to load Doubao credentials: {e}")

    def _save_credentials(self) -> None:
        """Save credentials to file."""
        if self._auth:
            self._creds_path.parent.mkdir(parents=True, exist_ok=True)
            self._creds_path.write_text(json.dumps(self._auth.to_dict(), indent=2))
            self._creds_path.chmod(0o600)
            logger.debug(f"Saved Doubao credentials to {self._creds_path}")

    @property
    def is_authenticated(self) -> bool:
        """Check if credentials are available."""
        return self._auth is not None and bool(self._auth.sessionid)

    @classmethod
    def get_auth_url(cls) -> str:
        """获取豆包登录 URL，用于外部浏览器打开——

        Returns:
            登录页面 URL
        """
        return DOUBAO_LOGIN_URL

    @classmethod
    def get_auth_instructions(cls) -> str:
        """获取授权说明文本——

        Returns:
            授权说明文本
        """
        return """
豆包 Web 授权说明:
1. 在浏览器中打开: https://www.doubao.com/chat/
2. 登录你的豆包账号
3. 登录成功后，打开浏览器开发者工具——(F12)
4. ——Application > Cookies 中找到——'sessionid' 的值
5. ——sessionid 提供给——clawbot 完成授权
"""

    async def login_with_credentials(
        self,
        sessionid: str,
        ttwid: str | None = None,
        user_agent: str | None = None,
    ) -> DoubaoAuth:
        """使用手动提供的凭证完成授权——

        Args:
            sessionid: 豆包 sessionid Cookie ——值
            ttwid: 可选的 ttwid Cookie ——值
            user_agent: 可选的 User-Agent

        Returns:
            DoubaoAuth 认证信息

        Raises:
            ValueError: sessionid 为空时抛出——
        """
        if not sessionid or not sessionid.strip():
            raise ValueError("sessionid 不能为空")

        self._auth = DoubaoAuth(
            sessionid=sessionid,
            ttwid=ttwid,
            user_agent=user_agent
            or "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        )
        self._client = DoubaoWebClient(self._auth)
        self._save_credentials()
        logger.info("Doubao credentials saved successfully")
        return self._auth

    async def chat(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        model: str | None = None,
        max_tokens: int = 8192,
        temperature: float = 0.7,
    ) -> LLMResponse:
        """Send chat completion request."""
        if not self._client:
            if self._auth:
                self._client = DoubaoWebClient(self._auth)
            else:
                raise DoubaoAuthError(
                    "Doubao credentials not found. Run 'clawbot doubao-login' to authenticate."
                )

        model_id = self._strip_model_prefix(model or self.default_model)

        try:
            return await self._client.chat_completions(messages, model=model_id)
        except DoubaoRateLimitError as e:
            return LLMResponse(
                content=f"Rate limit exceeded: {str(e)}",
                finish_reason="error",
            )
        except Exception as e:
            return LLMResponse(
                content=f"Error calling Doubao: {str(e)}",
                finish_reason="error",
            )

    def _strip_model_prefix(self, model: str) -> str:
        """Strip provider prefix from model name."""
        if model.startswith("doubao-web/"):
            return model.split("/", 1)[1]
        return model

    def get_default_model(self) -> str:
        return self.default_model


class DoubaoAuthError(Exception):
    """Doubao authentication error."""

    pass


class DoubaoAPIError(Exception):
    """Doubao API error."""

    pass


class DoubaoRateLimitError(Exception):
    """Doubao rate limit error."""

    pass


async def doubao_login(
    use_existing_chrome: bool = False,
    cdp_port: str = "9222",
    open_url: bool = True,
) -> DoubaoAuth:
    """Convenience function for Doubao login."""
    provider = DoubaoWebProvider()
    return await provider.login(
        use_existing_chrome=use_existing_chrome,
        cdp_port=cdp_port,
        open_url=open_url,
    )
