"""DeepSeek Web Provider - Browser-based authentication for DeepSeek AI.

Uses Playwright for browser automation to capture Bearer token and cookies.
Supports PoW (Proof of Work) challenge for API requests.
Supports streaming SSE responses with thinking mode.
"""

from __future__ import annotations

import base64
import hashlib
import json
import math
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import httpx
from loguru import logger

from clawbot.providers.base import LLMProvider, LLMResponse, ToolCallRequest

DEEPSEEK_API_BASE = "https://chat.deepseek.com"
DEEPSEEK_LOGIN_URL = "https://chat.deepseek.com"
DEEPSEEK_POW_ENDPOINT = "/api/v0/chat/create_pow_challenge"
DEEPSEEK_CHAT_ENDPOINT = "/api/v0/chat/completion"
DEEPSEEK_SESSION_ENDPOINT = "/api/v0/chat_session/create"
DEFAULT_CDP_PORT = 9222
DEFAULT_TIMEOUT = 300
CREDENTIALS_PATH = "~/.clawbot/deepseek_web_creds.json"


@dataclass
class DeepSeekAuth:
    """DeepSeek authentication credentials."""

    cookie: str
    bearer: str = ""
    user_agent: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "cookie": self.cookie,
            "bearer": self.bearer,
            "user_agent": self.user_agent,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "DeepSeekAuth":
        return cls(
            cookie=data.get("cookie", ""),
            bearer=data.get("bearer", ""),
            user_agent=data.get("user_agent", ""),
        )


@dataclass
class DeepSeekPowChallenge:
    """PoW challenge from DeepSeek API."""

    algorithm: str
    challenge: str
    difficulty: int
    salt: str
    signature: str
    expire_at: int | None = None


class DeepSeekWebClient:
    """DeepSeek Web API client with PoW support."""

    def __init__(self, auth: DeepSeekAuth | str):
        if isinstance(auth, str):
            try:
                auth_data = json.loads(auth)
                if isinstance(auth_data, str):
                    self.auth = DeepSeekAuth(cookie=auth_data)
                else:
                    self.auth = DeepSeekAuth.from_dict(auth_data)
            except json.JSONDecodeError:
                self.auth = DeepSeekAuth(cookie=auth)
        else:
            self.auth = auth

        self._wasm_module: Any = None

    def _get_headers(self, include_pow: str = "") -> dict[str, str]:
        headers = {
            "Cookie": self.auth.cookie,
            "User-Agent": self.auth.user_agent
            or "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Content-Type": "application/json",
            "Accept": "*/*",
            "Referer": "https://chat.deepseek.com/",
            "Origin": "https://chat.deepseek.com",
            "x-client-platform": "web",
            "x-client-version": "1.7.0",
            "x-app-version": "20241129.1",
            "x-client-locale": "zh_CN",
            "x-client-timezone-offset": "28800",
        }
        if self.auth.bearer:
            headers["Authorization"] = f"Bearer {self.auth.bearer}"
        if include_pow:
            headers["x-ds-pow-response"] = include_pow
        return headers

    async def create_pow_challenge(self, target_path: str) -> DeepSeekPowChallenge:
        """Create a PoW challenge for the target path."""
        url = f"{DEEPSEEK_API_BASE}{DEEPSEEK_POW_ENDPOINT}"
        logger.debug(f"Creating PoW challenge for {target_path}")

        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                url,
                headers=self._get_headers(),
                json={"target_path": target_path},
            )

            if response.status_code != 200:
                raise DeepSeekAPIError(
                    f"Failed to create PoW challenge: {response.status_code} - {response.text}"
                )

            data = response.json()
            challenge = (
                data.get("data", {}).get("biz_data", {}).get("challenge")
                or data.get("data", {}).get("challenge")
                or data.get("challenge")
            )
            if not challenge:
                raise DeepSeekAPIError("PoW challenge missing in response")

            return DeepSeekPowChallenge(
                algorithm=challenge.get("algorithm", "sha256"),
                challenge=challenge.get("challenge", ""),
                difficulty=challenge.get("difficulty", 5),
                salt=challenge.get("salt", ""),
                signature=challenge.get("signature", ""),
                expire_at=challenge.get("expire_at"),
            )

    async def solve_pow(self, challenge: DeepSeekPowChallenge) -> int:
        """Solve the PoW challenge."""
        algorithm = challenge.algorithm
        target = challenge.challenge
        salt = challenge.salt
        difficulty = challenge.difficulty
        expire_at = challenge.expire_at

        logger.debug(f"Solving PoW ({algorithm}, difficulty: {difficulty})")

        if algorithm == "sha256":
            return await self._solve_sha256(salt, target, difficulty)

        if algorithm == "DeepSeekHashV1":
            return await self._solve_deepseek_hash_v1(salt, target, difficulty, expire_at)

        raise DeepSeekAPIError(f"Unsupported PoW algorithm: {algorithm}")

    async def _solve_sha256(self, salt: str, target: str, difficulty: int) -> int:
        """Solve SHA256-based PoW."""
        start = time.time()
        nonce = 0
        target_difficulty = math.floor(math.log2(difficulty)) if difficulty > 1000 else difficulty

        while True:
            input_str = salt + target + str(nonce)
            hash_hex = hashlib.sha256(input_str.encode()).hexdigest()

            zero_bits = 0
            for char in hash_hex:
                val = int(char, 16)
                if val == 0:
                    zero_bits += 4
                else:
                    zero_bits += 4 - val.bit_length()
                    break

            if zero_bits >= target_difficulty:
                logger.debug(f"SHA256 PoW solved in {time.time() - start:.2f}s, nonce: {nonce}")
                return nonce

            nonce += 1
            if nonce > 1000000:
                raise DeepSeekAPIError("SHA256 PoW timeout")

    async def _solve_deepseek_hash_v1(
        self, salt: str, target: str, difficulty: int, expire_at: int | None
    ) -> int:
        """Solve DeepSeekHashV1 using WASM (simplified - falls back to SHA256 for now)."""
        logger.warning("DeepSeekHashV1 not fully implemented, using SHA256 fallback")
        return await self._solve_sha256(f"{salt}_{expire_at}_", target, difficulty)

    async def create_chat_session(self) -> str:
        """Create a new chat session."""
        url = f"{DEEPSEEK_API_BASE}{DEEPSEEK_SESSION_ENDPOINT}"

        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                url,
                headers=self._get_headers(),
                json={},
            )

            if response.status_code != 200:
                raise DeepSeekAPIError(
                    f"Failed to create session: {response.status_code} - {response.text}"
                )

            data = response.json()
            session_id = (
                data.get("data", {}).get("biz_data", {}).get("id")
                or data.get("data", {}).get("biz_data", {}).get("chat_session_id")
                or ""
            )
            logger.debug(f"Created chat session: {session_id}")
            return session_id

    async def chat_completions(
        self,
        messages: list[dict[str, Any]],
        session_id: str | None = None,
        model: str = "deepseek-chat",
        thinking_enabled: bool = True,
        search_enabled: bool = True,
    ) -> LLMResponse:
        """Send chat completion request with PoW."""
        if not session_id:
            session_id = await self.create_chat_session()

        challenge = await self.create_pow_challenge(DEEPSEEK_CHAT_ENDPOINT)
        answer = await self.solve_pow(challenge)

        pow_response = base64.b64encode(
            json.dumps(
                {
                    **{
                        "algorithm": challenge.algorithm,
                        "challenge": challenge.challenge,
                        "difficulty": challenge.difficulty,
                        "salt": challenge.salt,
                        "signature": challenge.signature,
                    },
                    "answer": answer,
                    "target_path": DEEPSEEK_CHAT_ENDPOINT,
                }
            ).encode()
        ).decode()

        last_message = messages[-1] if messages else {"content": ""}
        prompt = last_message.get("content", "")
        if isinstance(prompt, list):
            prompt = " ".join(
                item.get("text", "") if isinstance(item, dict) else str(item) for item in prompt
            )

        body = {
            "chat_session_id": session_id,
            "parent_message_id": None,
            "prompt": prompt,
            "ref_file_ids": [],
            "thinking_enabled": thinking_enabled,
            "search_enabled": search_enabled,
            "preempt": False,
        }

        url = f"{DEEPSEEK_API_BASE}{DEEPSEEK_CHAT_ENDPOINT}"
        logger.debug(f"Sending chat completion to {url}")

        async with httpx.AsyncClient(timeout=120.0) as client:
            async with client.stream(
                "POST", url, headers=self._get_headers(pow_response), json=body
            ) as response:
                if response.status_code != 200:
                    error_text = await response.aread()
                    raise DeepSeekAPIError(
                        f"HTTP {response.status_code}: {error_text.decode('utf-8', 'ignore')}"
                    )

                return await self._consume_sse(response)

    async def _consume_sse(self, response: httpx.Response) -> LLMResponse:
        """Consume SSE stream and parse response."""
        content = ""
        thinking_content = ""
        tool_calls: list[ToolCallRequest] = []
        finish_reason = "stop"

        current_mode = "text"
        current_tag_content = ""
        tool_call_buffer: dict[str, Any] = {}

        async for line in response.aiter_lines():
            if not line.startswith("data: "):
                continue

            data_str = line[6:].strip()
            if not data_str or data_str == "[DONE]":
                continue

            try:
                data = json.loads(data_str)
            except json.JSONDecodeError:
                continue

            if "choices" not in data:
                continue

            choices = data.get("choices", [])
            if not choices:
                continue

            delta = choices[0].get("delta", {})
            finish = choices[0].get("finish_reason")

            delta_content = delta.get("content", "")
            if delta_content:
                processed = self._process_thinking_tags(
                    delta_content,
                    current_mode,
                    current_tag_content,
                    tool_call_buffer,
                )
                current_mode = processed["mode"]
                current_tag_content = processed["tag_content"]
                tool_call_buffer = processed["tool_buffer"]
                content += processed["content"]
                thinking_content += processed["thinking"]

            if "tool_calls" in delta:
                for tc in delta["tool_calls"]:
                    idx = tc.get("index", len(tool_calls))
                    if idx >= len(tool_calls):
                        tool_id = tc.get("id") or f"call_{idx}"
                        fn_name = tc.get("function", {}).get("name") or ""
                        tool_calls.append(
                            ToolCallRequest(
                                id=tool_id,
                                name=fn_name,
                                arguments={},
                            )
                        )
                    fn = tc.get("function", {}) or {}
                    if fn and "arguments" in fn and fn["arguments"]:
                        try:
                            tool_calls[idx].arguments = json.loads(fn["arguments"])
                        except (json.JSONDecodeError, TypeError):
                            tool_calls[idx].arguments = {"raw": str(fn["arguments"])}

            if finish:
                finish_reason = finish

        return LLMResponse(
            content=content,
            tool_calls=tool_calls,
            finish_reason=finish_reason,
            reasoning_content=thinking_content if thinking_content else None,
        )

    def _process_thinking_tags(
        self,
        delta: str,
        current_mode: str,
        current_tag_content: str,
        tool_buffer: dict[str, Any],
    ) -> dict[str, Any]:
        """Process thinking and tool call tags."""
        content = ""
        thinking = ""

        for char in delta:
            current_tag_content += char

            if current_mode == "text":
                if current_tag_content.endswith("<"):
                    continue
                if current_tag_content.endswith("<t"):
                    continue
                if current_tag_content.endswith("<th"):
                    continue
                if re.search(r"<(think|thinking|thought)\s*$", current_tag_content, re.IGNORECASE):
                    match = re.search(
                        r"<(think|thinking|thought)\s*$", current_tag_content, re.IGNORECASE
                    )
                    if match:
                        content = current_tag_content[: -len(match.group(0))]
                        current_mode = "thinking"
                        current_tag_content = ""
                        continue
                if current_tag_content.endswith("<t"):
                    continue
                if current_tag_content.endswith("<tool"):
                    continue
                if re.search(r"<tool_call\s*$", current_tag_content, re.IGNORECASE):
                    match = re.search(r"<tool_call\s*$", current_tag_content, re.IGNORECASE)
                    if match:
                        content = current_tag_content[: -len(match.group(0))]
                        current_mode = "tool_call"
                        current_tag_content = ""
                        continue
                content += char

            elif current_mode == "thinking":
                if current_tag_content.endswith("</"):
                    continue
                if re.search(
                    r"</(think|thinking|thought)\s*>$", current_tag_content, re.IGNORECASE
                ):
                    match = re.search(
                        r"</(think|thinking|thought)\s*>$", current_tag_content, re.IGNORECASE
                    )
                    if match:
                        thinking = current_tag_content[: -len(match.group(0))]
                        current_mode = "text"
                        current_tag_content = ""
                        continue
                thinking += char

            elif current_mode == "tool_call":
                if current_tag_content.endswith("</"):
                    continue
                if current_tag_content.endswith("</tool_call"):
                    continue
                if re.search(r"</tool_call\s*>$", current_tag_content, re.IGNORECASE):
                    current_mode = "text"
                    current_tag_content = ""
                    continue

        return {
            "mode": current_mode,
            "tag_content": current_tag_content,
            "content": content,
            "thinking": thinking,
            "tool_buffer": tool_buffer,
        }


class DeepSeekWebProvider(LLMProvider):
    """DeepSeek Web provider using browser-based authentication."""

    def __init__(self, default_model: str = "deepseek-web/deepseek-chat"):
        super().__init__(api_key=None, api_base=None)
        self.default_model = default_model
        self._auth: DeepSeekAuth | None = None
        self._client: DeepSeekWebClient | None = None
        self._creds_path = Path(CREDENTIALS_PATH).expanduser()
        self._load_credentials()

    def _load_credentials(self) -> None:
        """Load credentials from file."""
        if self._creds_path.exists():
            try:
                data = json.loads(self._creds_path.read_text())
                self._auth = DeepSeekAuth.from_dict(data)
                self._client = DeepSeekWebClient(self._auth)
                logger.debug(f"Loaded DeepSeek credentials from {self._creds_path}")
            except Exception as e:
                logger.warning(f"Failed to load DeepSeek credentials: {e}")

    def _save_credentials(self) -> None:
        """Save credentials to file."""
        if self._auth:
            self._creds_path.parent.mkdir(parents=True, exist_ok=True)
            self._creds_path.write_text(json.dumps(self._auth.to_dict(), indent=2))
            self._creds_path.chmod(0o600)
            logger.debug(f"Saved DeepSeek credentials to {self._creds_path}")

    @property
    def is_authenticated(self) -> bool:
        """Check if credentials are available."""
        return self._auth is not None and bool(self._auth.cookie)

    @classmethod
    def get_auth_url(cls) -> str:
        """获取 DeepSeek 登录 URL，用于外部浏览器打开。

        Returns:
            登录页面 URL
        """
        return DEEPSEEK_LOGIN_URL

    @classmethod
    def get_auth_instructions(cls) -> str:
        """获取授权说明文本。

        Returns:
            授权说明文本
        """
        return """
DeepSeek Web 授权说明:
1. 在浏览器中打开: https://chat.deepseek.com
2. 登录你的 DeepSeek 账号
3. 登录成功后，打开浏览器开发者工具 (F12)
4. 切换到 Network 标签，筛选 XHR 请求
5. 发送一条消息，找到 /api/v0/ 请求
6. 在请求头中找到 'Authorization: Bearer xxx' 的值
7. 在 Application > Cookies 中复制所有 Cookie
8. 将 Bearer Token 和 Cookie 提供给 clawbot 完成授权
"""

    async def login_with_credentials(
        self,
        cookie: str,
        bearer: str = "",
        user_agent: str | None = None,
    ) -> DeepSeekAuth:
        """使用手动提供的凭证完成授权。

        Args:
            cookie: DeepSeek Cookie 字符。
            bearer: Bearer Token (可选但推荐)
            user_agent: 可选的 User-Agent

        Returns:
            DeepSeekAuth 认证信息

        Raises:
            ValueError: cookie 为空时抛。
        """
        if not cookie or not cookie.strip():
            raise ValueError("cookie 不能为空")

        self._auth = DeepSeekAuth(
            cookie=cookie,
            bearer=bearer,
            user_agent=user_agent
            or "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        )
        self._client = DeepSeekWebClient(self._auth)
        self._save_credentials()
        logger.info("DeepSeek credentials saved successfully")
        return self._auth

    async def chat(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        model: str | None = None,
        max_tokens: int = 8192,
        temperature: float = 0.7,
    ) -> LLMResponse:
        """Send chat completion request."""
        if not self._client:
            if self._auth:
                self._client = DeepSeekWebClient(self._auth)
            else:
                raise DeepSeekAuthError(
                    "DeepSeek credentials not found. Run 'clawbot deepseek-login' to authenticate."
                )

        model_id = self._strip_model_prefix(model or self.default_model)
        thinking_enabled = "reasoner" in model_id.lower() or "r1" in model_id.lower()

        try:
            return await self._client.chat_completions(
                messages,
                model=model_id,
                thinking_enabled=thinking_enabled,
            )
        except Exception as e:
            return LLMResponse(
                content=f"Error calling DeepSeek: {str(e)}",
                finish_reason="error",
            )

    def _strip_model_prefix(self, model: str) -> str:
        """Strip provider prefix from model name."""
        if model.startswith("deepseek-web/"):
            return model.split("/", 1)[1]
        return model

    def get_default_model(self) -> str:
        return self.default_model


class DeepSeekAuthError(Exception):
    """DeepSeek authentication error."""

    pass


class DeepSeekAPIError(Exception):
    """DeepSeek API error."""

    pass


async def deepseek_login(
    use_existing_chrome: bool = False,
    cdp_port: int = DEFAULT_CDP_PORT,
    open_url: bool = True,
) -> DeepSeekAuth:
    """Convenience function for DeepSeek login."""
    provider = DeepSeekWebProvider()
    return await provider.login(
        use_existing_chrome=use_existing_chrome,
        cdp_port=cdp_port,
        open_url=open_url,
    )
