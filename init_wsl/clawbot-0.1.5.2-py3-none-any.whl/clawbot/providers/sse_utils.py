"""SSE (Server-Sent Events) parsing utilities for streaming responses."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, AsyncGenerator

import httpx


@dataclass
class SSEEvent:
    """Represents a single SSE event."""

    data: str = ""
    event: str | None = None
    id: str | None = None
    retry: int | None = None


@dataclass
class SSEParserConfig:
    """Configuration for SSE parser."""

    done_marker: str = "[DONE]"
    ignore_empty: bool = True
    json_parse: bool = True


class SSEParser:
    """Parser for Server-Sent Events (SSE) streams."""

    def __init__(self, config: SSEParserConfig | None = None):
        self.config = config or SSEParserConfig()

    async def parse_stream(
        self,
        response: httpx.Response,
    ) -> AsyncGenerator[SSEEvent, None]:
        """
        Parse SSE stream from httpx response.

        Args:
            response: httpx async response with streaming enabled

        Yields:
            SSEEvent objects for each complete event
        """
        buffer: list[str] = []

        async for line in response.aiter_lines():
            if line == "":
                if buffer:
                    event = self._parse_buffer(buffer)
                    buffer = []
                    if event:
                        yield event
            else:
                buffer.append(line)

        if buffer:
            event = self._parse_buffer(buffer)
            if event:
                yield event

    async def parse_json_stream(
        self,
        response: httpx.Response,
    ) -> AsyncGenerator[dict[str, Any], None]:
        """
        Parse SSE stream and decode JSON data.

        Args:
            response: httpx async response with streaming enabled

        Yields:
            Parsed JSON objects from data fields
        """
        async for event in self.parse_stream(response):
            if not event.data:
                continue
            if event.data == self.config.done_marker:
                continue

            if self.config.json_parse:
                try:
                    yield json.loads(event.data)
                except json.JSONDecodeError:
                    continue
            else:
                yield {"raw": event.data}

    def _parse_buffer(self, buffer: list[str]) -> SSEEvent | None:
        """Parse buffered lines into an SSE event."""
        data_lines: list[str] = []
        event_type: str | None = None
        event_id: str | None = None
        retry: int | None = None

        for line in buffer:
            if line.startswith("data:"):
                data_lines.append(line[5:].strip())
            elif line.startswith("event:"):
                event_type = line[6:].strip()
            elif line.startswith("id:"):
                event_id = line[3:].strip()
            elif line.startswith("retry:"):
                try:
                    retry = int(line[6:].strip())
                except ValueError:
                    pass

        if not data_lines:
            return None

        data = "\n".join(data_lines)

        if self.config.ignore_empty and not data:
            return None

        return SSEEvent(
            data=data,
            event=event_type,
            id=event_id,
            retry=retry,
        )


async def iter_sse_json(
    response: httpx.Response,
    done_marker: str = "[DONE]",
) -> AsyncGenerator[dict[str, Any], None]:
    """
    Convenience function to iterate over SSE JSON data.

    Args:
        response: httpx async response with streaming enabled
        done_marker: Marker indicating end of stream

    Yields:
        Parsed JSON objects from SSE data fields
    """
    parser = SSEParser(SSEParserConfig(done_marker=done_marker))
    async for data in parser.parse_json_stream(response):
        yield data


async def iter_sse_lines(
    response: httpx.Response,
) -> AsyncGenerator[str, None]:
    """
    Convenience function to iterate over SSE data lines.

    Args:
        response: httpx async response with streaming enabled

    Yields:
        Raw data strings from SSE data fields
    """
    parser = SSEParser(SSEParserConfig(json_parse=False))
    async for event in parser.parse_stream(response):
        if event.data:
            yield event.data
