"""Secure secret management for clawbot."""

import os
import re


def get_secret(env_var: str, default: str | None = None) -> str | None:
    """Get secret from environment variable with fallback.

    Returns None if not configured, allowing distinction between
    "not configured" and "configured as empty string".
    """
    return os.environ.get(env_var, default)


def mask_sensitive(value: str, visible_chars: int = 4) -> str:
    """Mask sensitive value for logging.

    Args:
        value: The sensitive value to mask
        visible_chars: Number of characters to show at the start

    Returns:
        Masked value like "sk-a***"
    """
    if not value or len(value) <= visible_chars:
        return "***"
    return value[:visible_chars] + "*" * min(len(value) - visible_chars, 10)


class SecretStr(str):
    """String that masks its value when printed or logged.

    __str__ returns the actual value for proper string operations.
    Use display() to get the masked representation for logging.
    """

    def __new__(cls, value: str):
        return super().__new__(cls, value)

    def __repr__(self) -> str:
        return f"SecretStr('{mask_sensitive(self)}')"

    def __str__(self) -> str:
        # Keep original value for actual operations (comparison, concatenation, etc.)
        return super().__str__()

    def display(self) -> str:
        """Get masked representation for logging."""
        return mask_sensitive(self)


# Patterns for detecting sensitive information in logs
SENSITIVE_PATTERNS = [
    (r'(api[_-]?key["\s:=]+)["\']?([a-zA-Z0-9_-]{8,})["\']?', r'\1[REDACTED]'),
    (r'(token["\s:=]+)["\']?([a-zA-Z0-9_-]{8,})["\']?', r'\1[REDACTED]'),
    (r'(password["\s:=]+)["\']?([^\s"\']{4,})["\']?', r'\1[REDACTED]'),
    (r'(secret["\s:=]+)["\']?([a-zA-Z0-9_-]{8,})["\']?', r'\1[REDACTED]'),
    (r'(bearer\s+)([a-zA-Z0-9_-]{8,})', r'\1[REDACTED]'),
    (r'(authorization["\s:=]+["\']?)([a-zA-Z0-9_-]{8,})', r'\1[REDACTED]'),
]


def redact_sensitive(text: str) -> str:
    """Redact sensitive values from text for safe logging.

    Args:
        text: Text that may contain sensitive information

    Returns:
        Text with sensitive values replaced by [REDACTED]
    """
    result = text
    for pattern, replacement in SENSITIVE_PATTERNS:
        result = re.sub(pattern, replacement, result, flags=re.IGNORECASE)
    return result
