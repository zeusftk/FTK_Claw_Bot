"""Security configuration for clawbot."""

from pathlib import Path

DEFAULT_DENY_PATTERNS = [
    r"\brm\s+-[rf]{1,2}\b",
    r"\bdel\s+/[fq]\b",
    r"\brmdir\s+/s\b",
    r"(?:^|[;&|]\s*)format\b",
    r"\b(mkfs|diskpart|fdisk)\b",
    r"\bdd\s+if=",
    r">\s*/dev/sd",
    r">\s*/dev/null\s+2>&1\s*;\s*\S",
    r"\b(shutdown|reboot|poweroff|halt)\b",
    r":\(\)\s*\{.*\};\s*:",
    r"\b(sudo|doas|runas)\b",
    r"\b(chmod|chown)\s+[0-7]{3,4}\b",
    r">\s*/etc/",
    r"\b(curl|wget)\s+.*\|\s*(ba)?sh\b",
    r"\beval\s+",
    r"\bexec\s+",
    r"\b(reg\s+delete)\b",
    r"\b(net\s+(user|localgroup|share))\b",
    r"\b(powershell\s+-[ec])\b",
    r"\b(cmd\s+/c)\b",
    r"\b(wmic\s+)\b",
    r"\b(bcdedit)\b",
    r"\b(vssadmin)\b",
    r";\s*(rm|del|format|shutdown)\b",
    r"\|\s*(rm|del|format|shutdown)\b",
    r"\b(taskkill\s+/[fi])\b",
    r"\b(sc\s+(delete|stop|config))\b",
    r"\b(nohup\s+)\b",
    r"\b(setsid\s+)\b",
    r"\b(apt|yum|dnf|pacman|brew|choco|winget)\s+",
    r"\b(pip|npm|yarn|cargo|gem)\s+install\s+.*\|\s*(ba)?sh\b",
    r"\b(crontab\s+-[er])\b",
    r"\b(at\s+)",
    r"\b(sed\s+-i\s+)",
    r"\b(awk\s+.*-f\s+)",
    r"\b(perl\s+-[eE])\b",
    r"\b(python\s+-c\s+)",
    r"\b(ruby\s+-[eE])\b",
    r"\b(php\s+-r\s+)",
    r"\b(node\s+-e\s+)",
    r"\$\([^)]+\)",
    r"\$\{[^}]+\}",
    r"`[^`]+`",
    r"\bexport\s+[A-Za-z_]",
    r"\bunset\s+[A-Za-z_]",
    r"\benv\s+",
    r"\bprintenv\s+",
    r"\b(setenv\s+)",
    r">\s*~/.ssh/",
    r">\s*~/.bashrc",
    r">\s*~/.zshrc",
    r">\s*~/.profile",
    r">\s*/etc/passwd",
    r">\s*/etc/shadow",
    r">\s*/etc/sudoers",
    r">\s*/root/",
    r"\b(ssh\s+-)",
    r"\b(scp\s+)",
    r"\b(rsync\s+.*--rsh)",
    r"\b(nc\s+-[lp])",
    r"\b(netcat\s+)",
    r"\b(nmap\s+)",
    r"\b(iptables\s+)",
    r"\b(ip6tables\s+)",
    r"\b(route\s+)",
    r"\b(ifconfig\s+)",
]


def load_deny_patterns(config_path: Path | None = None) -> list[str]:
    """Load deny patterns from config file or use defaults.

    Args:
        config_path: Path to JSON config file with "deny_patterns" key

    Returns:
        List of regex patterns for dangerous commands
    """
    if config_path and config_path.exists():
        import json
        with open(config_path, encoding="utf-8") as f:
            data = json.load(f)
            return data.get("deny_patterns", DEFAULT_DENY_PATTERNS)
    return DEFAULT_DENY_PATTERNS
