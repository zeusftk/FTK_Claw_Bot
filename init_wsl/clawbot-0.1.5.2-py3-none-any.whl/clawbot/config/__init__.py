"""Configuration module for clawbot."""

from clawbot.config.loader import get_config_path, load_config
from clawbot.config.schema import Config

__all__ = ["Config", "load_config", "get_config_path"]
