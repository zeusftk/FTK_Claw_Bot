"""
Entry point for running clawbot as a module: python -m clawbot
"""

from clawbot.cli.commands import app

if __name__ == "__main__":
    app()
