"""CLI commands for clawbot."""

import asyncio
import os
import select
import signal
import sys
import time
from pathlib import Path

import typer
from loguru import logger
from prompt_toolkit import PromptSession
from prompt_toolkit.formatted_text import HTML
from prompt_toolkit.history import FileHistory
from prompt_toolkit.patch_stdout import patch_stdout
from rich.console import Console
from rich.markdown import Markdown
from rich.table import Table
from rich.text import Text

from clawbot import __logo__, __version__
from clawbot.config.schema import Config

app = typer.Typer(
    name="clawbot",
    help=f"{__logo__} clawbot - Personal AI Assistant",
    no_args_is_help=True,
)

console = Console()
EXIT_COMMANDS = {"exit", "quit", "/exit", "/quit", ":q"}

# ---------------------------------------------------------------------------
# CLI input: prompt_toolkit for editing, paste, history, and display
# ---------------------------------------------------------------------------

_PROMPT_SESSION: PromptSession | None = None
_SAVED_TERM_ATTRS = None  # original termios settings, restored on exit


def _flush_pending_tty_input() -> None:
    """Drop unread keypresses typed while the model was generating output."""
    try:
        fd = sys.stdin.fileno()
        if not os.isatty(fd):
            return
    except (OSError, ValueError):
        return

    try:
        import termios

        termios.tcflush(fd, termios.TCIFLUSH)
        return
    except (ImportError, OSError):
        pass

    try:
        while True:
            ready, _, _ = select.select([fd], [], [], 0)
            if not ready:
                break
            if not os.read(fd, 4096):
                break
    except (OSError, BlockingIOError):
        return


def _restore_terminal() -> None:
    """Restore terminal to its original state (echo, line buffering, etc.)."""
    if _SAVED_TERM_ATTRS is None:
        return
    try:
        import termios

        termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, _SAVED_TERM_ATTRS)
    except (ImportError, OSError):
        pass


def _init_prompt_session() -> None:
    """Create the prompt_toolkit session with persistent file history."""
    global _PROMPT_SESSION, _SAVED_TERM_ATTRS

    # Save terminal state so we can restore it on exit
    try:
        import termios

        _SAVED_TERM_ATTRS = termios.tcgetattr(sys.stdin.fileno())
    except (ImportError, OSError):
        pass

    history_file = Path.home() / ".clawbot" / "history" / "cli_history"
    history_file.parent.mkdir(parents=True, exist_ok=True)

    _PROMPT_SESSION = PromptSession(
        history=FileHistory(str(history_file)),
        enable_open_in_editor=False,
        multiline=False,  # Enter submits (single line mode)
    )


def _print_agent_response(response: str, render_markdown: bool) -> None:
    """Render assistant response with consistent terminal styling."""
    content = response or ""
    body = Markdown(content) if render_markdown else Text(content)
    console.print()
    console.print(f"[cyan]{__logo__} clawbot[/cyan]")
    console.print(body)
    console.print()


def _is_exit_command(command: str) -> bool:
    """Return True when input should end interactive chat."""
    return command.lower() in EXIT_COMMANDS


async def _read_interactive_input_async() -> str:
    """Read user input using prompt_toolkit (handles paste, history, display).

    prompt_toolkit natively handles:
    - Multiline paste (bracketed paste mode)
    - History navigation (up/down arrows)
    - Clean display (no ghost characters or artifacts)
    """
    if _PROMPT_SESSION is None:
        raise RuntimeError("Call _init_prompt_session() first")
    try:
        with patch_stdout():
            return await _PROMPT_SESSION.prompt_async(
                HTML("<b fg='ansiblue'>You:</b> "),
            )
    except EOFError as exc:
        raise KeyboardInterrupt from exc


def version_callback(value: bool):
    if value:
        console.print(f"{__logo__} clawbot v{__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(None, "--version", "-v", callback=version_callback, is_eager=True),
):
    """clawbot - Personal AI Assistant."""
    pass


# ============================================================================
# Onboard / Setup
# ============================================================================


@app.command()
def onboard():
    """Initialize clawbot configuration and workspace."""
    from clawbot.config.loader import get_config_path, load_config, save_config
    from clawbot.utils.helpers import get_workspace_path

    config_path = get_config_path()

    if config_path.exists():
        console.print(f"[yellow]Config already exists at {config_path}[/yellow]")
        console.print("  [bold]y[/bold] = overwrite with defaults (existing values will be lost)")
        console.print(
            "  [bold]N[/bold] = refresh config, keeping existing values and adding new fields"
        )
        if typer.confirm("Overwrite?"):
            config = Config()
            save_config(config)
            console.print(f"[green]✓[/green] Config reset to defaults at {config_path}")
        else:
            config = load_config()
            save_config(config)
            console.print(
                f"[green]✓[/green] Config refreshed at {config_path} (existing values preserved)"
            )
    else:
        save_config(Config())
        console.print(f"[green]✓[/green] Created config at {config_path}")

    # Create workspace
    workspace = get_workspace_path()

    if not workspace.exists():
        workspace.mkdir(parents=True, exist_ok=True)
        console.print(f"[green]✓[/green] Created workspace at {workspace}")

    # Create default bootstrap files
    _create_workspace_templates(workspace)

    console.print(f"\n{__logo__} clawbot is ready!")
    console.print("\nNext steps:")
    console.print("  1. Add your API key to [cyan]~/.clawbot/config.json[/cyan]")
    console.print("     Get one at: https://openrouter.ai/keys")
    console.print('  2. Chat: [cyan]clawbot agent -m "Hello!"[/cyan]')
    console.print(
        "\n[dim]Want Telegram/WhatsApp? See: https://github.com/HKUDS/clawbot#-chat-apps[/dim]"
    )


def _create_workspace_templates(workspace: Path):
    """Create default workspace template files from bundled templates."""
    from importlib.resources import files as pkg_files

    templates_dir = pkg_files("clawbot") / "templates"

    for item in templates_dir.iterdir():
        if not item.name.endswith(".md"):
            continue
        dest = workspace / item.name
        if not dest.exists():
            dest.write_text(item.read_text(encoding="utf-8"), encoding="utf-8")
            console.print(f"  [dim]Created {item.name}[/dim]")

    memory_dir = workspace / "memory"
    memory_dir.mkdir(exist_ok=True)

    memory_template = templates_dir / "memory" / "MEMORY.md"
    memory_file = memory_dir / "MEMORY.md"
    if not memory_file.exists():
        memory_file.write_text(memory_template.read_text(encoding="utf-8"), encoding="utf-8")
        console.print("  [dim]Created memory/MEMORY.md[/dim]")

    history_file = memory_dir / "HISTORY.md"
    if not history_file.exists():
        history_file.write_text("", encoding="utf-8")
        console.print("  [dim]Created memory/HISTORY.md[/dim]")

    (workspace / "skills").mkdir(exist_ok=True)


def _make_provider(config: Config):
    """Create the appropriate LLM provider from config."""
    from clawbot.providers.custom_provider import CustomProvider
    from clawbot.providers.deepseek_web_provider import DeepSeekWebProvider
    from clawbot.providers.doubao_web_provider import DoubaoWebProvider
    from clawbot.providers.litellm_provider import LiteLLMProvider
    from clawbot.providers.openai_codex_provider import OpenAICodexProvider
    from clawbot.providers.qwen_portal_provider import QwenPortalProvider

    model = config.agents.defaults.model
    provider_name = config.get_provider_name(model)
    p = config.get_provider(model)

    # OpenAI Codex (OAuth)
    if provider_name == "openai_codex" or model.startswith("openai-codex/"):
        return OpenAICodexProvider(default_model=model)

    # Qwen Portal (OAuth, direct)
    if provider_name == "qwen_portal" or model.startswith("qwen-portal/"):
        return QwenPortalProvider(default_model=model)

    # Doubao Web (OAuth, direct)
    if provider_name == "doubao_web" or model.startswith("doubao-web/"):
        return DoubaoWebProvider(default_model=model)

    # DeepSeek Web (OAuth, direct)
    if provider_name == "deepseek_web" or model.startswith("deepseek-web/"):
        return DeepSeekWebProvider(default_model=model)

    # Custom: direct OpenAI-compatible endpoint, bypasses LiteLLM
    if provider_name == "custom":
        return CustomProvider(
            api_key=p.api_key if p else "no-key",
            api_base=config.get_api_base(model) or "http://localhost:8000/v1",
            default_model=model,
        )

    from clawbot.providers.registry import find_by_name

    spec = find_by_name(provider_name)
    if not model.startswith("bedrock/") and not (p and p.api_key) and not (spec and spec.is_oauth):
        console.print("[red]Error: No API key configured.[/red]")
        console.print("Set one in ~/.clawbot/config.json under providers section")
        raise typer.Exit(1)

    return LiteLLMProvider(
        api_key=p.api_key if p else None,
        api_base=config.get_api_base(model),
        default_model=model,
        extra_headers=p.extra_headers if p else None,
        provider_name=provider_name,
    )


# ============================================================================
# Gateway / Server
# ============================================================================


@app.command()
def gateway(
    port: int | None = typer.Option(None, "--port", "-p", help="Gateway port"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Verbose output"),
    no_guardian: bool = typer.Option(False, "--no-guardian", help="Disable guardian service"),
    host: str | None = typer.Option(None, "--host", help="WebSocket server host"),
):
    """Start the clawbot gateway with WebSocket server."""
    from clawbot.agent.loop import AgentLoop
    from clawbot.bus.queue import MessageBus
    from clawbot.channels.manager import ChannelManager
    from clawbot.config.loader import get_data_dir, load_config
    from clawbot.cron.service import CronService
    from clawbot.cron.types import CronJob
    from clawbot.guardian.service import GuardianService
    from clawbot.heartbeat.service import HeartbeatService
    from clawbot.session.manager import SessionManager

    if verbose:
        from loguru import logger

        logging.basicConfig(level=logging.DEBUG)

    console.print(f"{__logo__} Starting clawbot gateway...")

    config = load_config()

    # Update gateway config with port/host from command line (if provided)
    if port is not None:
        config.gateway.port = port
    if host is not None:
        config.gateway.host = host

    bus = MessageBus()
    provider = _make_provider(config)
    session_manager = SessionManager(config.workspace_path)

    # Create cron service first (callback set after agent creation)
    cron_store_path = get_data_dir() / "cron" / "jobs.json"
    cron = CronService(cron_store_path)

    # Create agent with cron service
    agent = AgentLoop(
        bus=bus,
        provider=provider,
        workspace=config.workspace_path,
        model=config.agents.defaults.model,
        temperature=config.agents.defaults.temperature,
        max_tokens=config.agents.defaults.max_tokens,
        max_iterations=config.agents.defaults.max_tool_iterations,
        memory_window=config.agents.defaults.memory_window,
        brave_api_key=config.tools.web.search.api_key or None,
        exec_config=config.tools.exec,
        cron_service=cron,
        restrict_to_workspace=config.tools.restrict_to_workspace,
        session_manager=session_manager,
        mcp_servers=config.tools.mcp_servers,
        channels_config=config.channels,
        windows_bridge_config=config.tools.windows_bridge,
        skills_config=config.skills,
    )

    # Set cron callback (needs agent)
    async def on_cron_job(job: CronJob) -> str | None:
        """Execute a cron job through the agent."""
        response = await agent.process_direct(
            job.payload.message,
            session_key=f"cron:{job.id}",
            channel=job.payload.channel or "cli",
            chat_id=job.payload.to or "direct",
        )
        if job.payload.deliver and job.payload.to:
            from clawbot.bus.events import OutboundMessage

            await bus.publish_outbound(
                OutboundMessage(
                    channel=job.payload.channel or "cli",
                    chat_id=job.payload.to,
                    content=response or "",
                )
            )
        return response

    cron.on_job = on_cron_job

    # Create channel manager
    channels = ChannelManager(config, bus)

    def _pick_heartbeat_target() -> tuple[str, str]:
        """Pick a routable channel/chat target for heartbeat-triggered messages."""
        enabled = set(channels.enabled_channels)
        # Prefer the most recently updated non-internal session on an enabled channel.
        for item in session_manager.list_sessions():
            key = item.get("key") or ""
            if ":" not in key:
                continue
            channel, chat_id = key.split(":", 1)
            if channel in {"cli", "system"}:
                continue
            if channel in enabled and chat_id:
                return channel, chat_id
        # Fallback keeps prior behavior but remains explicit.
        return "cli", "direct"

    # Create heartbeat service
    async def on_heartbeat_execute(tasks: str) -> str:
        """Phase 2: execute heartbeat tasks through the full agent loop."""
        channel, chat_id = _pick_heartbeat_target()

        async def _silent(*_args, **_kwargs):
            pass

        return await agent.process_direct(
            tasks,
            session_key="heartbeat",
            channel=channel,
            chat_id=chat_id,
            on_progress=_silent,
        )

    async def on_heartbeat_notify(response: str) -> None:
        """Deliver a heartbeat response to the user's channel."""
        from clawbot.bus.events import OutboundMessage

        channel, chat_id = _pick_heartbeat_target()
        if channel == "cli":
            return  # No external channel available to deliver to
        await bus.publish_outbound(
            OutboundMessage(channel=channel, chat_id=chat_id, content=response)
        )

    hb_cfg = config.gateway.heartbeat
    heartbeat = HeartbeatService(
        workspace=config.workspace_path,
        provider=provider,
        model=agent.model,
        on_execute=on_heartbeat_execute,
        on_notify=on_heartbeat_notify,
        interval_s=hb_cfg.interval_s,
        enabled=hb_cfg.enabled,
    )

    # Create guardian service
    guardian = GuardianService(
        interval_s=5 * 60,
        min_interval_s=30,
        auto_recover=not no_guardian,
    )

    # Register services to monitor
    guardian.register("cron", cron)
    guardian.register("heartbeat", heartbeat)

    # Initialize OpenWork service manager if enabled
    openwork_config = config.tools.openwork if config.tools.openwork.enabled else None
    openwork_manager = None
    if openwork_config:
        from clawbot.services.openwork_manager import OpenWorkServiceManager
        openwork_manager = OpenWorkServiceManager(
            host=openwork_config.host,
            port=openwork_config.orchestrator_port,
            workspace=config.workspace_path / "openworks",
            auto_start=openwork_config.auto_start,
            auto_restart=openwork_config.auto_restart,
            approval_mode=openwork_config.approval_mode,
            startup_timeout=openwork_config.startup_timeout,
        )
        if openwork_manager._is_installed():
            guardian.register("openwork", openwork_manager)

    # Create and add WebSocket channel
    try:
        from clawbot.channels.websocket import WebSocketChannel

        websocket_channel = WebSocketChannel(config.gateway, bus)
        channels.channels["websocket"] = websocket_channel
        console.print(
            f"[green]✓[/green] WebSocket channel enabled (ws://{config.gateway.host}:{config.gateway.port}/ws)"
        )
    except (ImportError, OSError, RuntimeError) as e:
        import traceback

        logger.warning(f"WebSocket channel not available: {e}")
        logger.warning(f"Traceback: {traceback.format_exc()}")

    if channels.enabled_channels:
        console.print(f"[green]✓[/green] Channels enabled: {', '.join(channels.enabled_channels)}")
    else:
        console.print("[yellow]Warning: No channels enabled[/yellow]")

    cron_status = cron.status()
    if cron_status["jobs"] > 0:
        console.print(f"[green]✓[/green] Cron: {cron_status['jobs']} scheduled jobs")

    console.print(f"[green]✓[/green] Heartbeat: every {hb_cfg.interval_s}s")
    
    # Show OpenWork service status
    if openwork_manager:
        if openwork_manager._is_installed():
            console.print("[green]✓[/green] OpenWork: installed (will auto-start)")
        else:
            console.print("[dim]OpenWork: not installed[/dim]")

    async def run():
        # Initialize OpenWork service if installed
        if openwork_manager:
            if await openwork_manager.start():
                console.print(f"[green]✓[/green] OpenWork service ready at {openwork_manager.base_url}")
            else:
                console.print("[yellow]⚠[/yellow] OpenWork service failed to start")

        try:
            await cron.start()
            await heartbeat.start()
            await guardian.start()
            await asyncio.gather(
                agent.run(),
                channels.start_all(),
            )
        except KeyboardInterrupt:
            console.print("\nShutting down...")
            guardian.stop()
        finally:
            # Stop OpenWork service if we started it
            if openwork_manager:
                await openwork_manager.stop()
            await agent.close_mcp()
            heartbeat.stop()
            cron.stop()
            agent.stop()
            await channels.stop_all()

    asyncio.run(run())


# ============================================================================
# Agent Commands
# ============================================================================


@app.command()
def agent(
    message: str = typer.Option(None, "--message", "-m", help="Message to send to the agent"),
    session_id: str = typer.Option("cli:direct", "--session", "-s", help="Session ID"),
    markdown: bool = typer.Option(
        True, "--markdown/--no-markdown", help="Render assistant output as Markdown"
    ),
    logs: bool = typer.Option(
        False, "--logs/--no-logs", help="Show clawbot runtime logs during chat"
    ),
):
    """Interact with the agent directly."""
    from clawbot.agent.loop import AgentLoop
    from clawbot.bus.queue import MessageBus
    from clawbot.config.loader import get_data_dir, load_config
    from clawbot.cron.service import CronService

    config = load_config()

    bus = MessageBus()
    provider = _make_provider(config)

    # Create cron service for tool usage (no callback needed for CLI unless running)
    cron_store_path = get_data_dir() / "cron" / "jobs.json"
    cron = CronService(cron_store_path)

    if logs:
        logger.enable("clawbot")
    else:
        logger.disable("clawbot")

    agent_loop = AgentLoop(
        bus=bus,
        provider=provider,
        workspace=config.workspace_path,
        model=config.agents.defaults.model,
        temperature=config.agents.defaults.temperature,
        max_tokens=config.agents.defaults.max_tokens,
        max_iterations=config.agents.defaults.max_tool_iterations,
        memory_window=config.agents.defaults.memory_window,
        brave_api_key=config.tools.web.search.api_key or None,
        exec_config=config.tools.exec,
        cron_service=cron,
        restrict_to_workspace=config.tools.restrict_to_workspace,
        mcp_servers=config.tools.mcp_servers,
        channels_config=config.channels,
        windows_bridge_config=config.tools.windows_bridge,
        skills_config=config.skills,
    )

    # Show spinner when logs are off (no output to miss); skip when logs are on
    def _thinking_ctx():
        if logs:
            from contextlib import nullcontext

            return nullcontext()
        # Animated spinner is safe to use with prompt_toolkit input handling
        return console.status("[dim]clawbot is thinking...[/dim]", spinner="dots")

    async def _cli_progress(content: str, *, tool_hint: bool = False) -> None:
        ch = agent_loop.channels_config
        if ch and tool_hint and not ch.send_tool_hints:
            return
        if ch and not tool_hint and not ch.send_progress:
            return
        console.print(f"  [dim]✓ {content}[/dim]")

    if message:
        # Single message mode – direct call, no bus needed
        async def run_once():
            with _thinking_ctx():
                response = await agent_loop.process_direct(
                    message, session_id, on_progress=_cli_progress
                )
            _print_agent_response(response, render_markdown=markdown)
            await agent_loop.close_mcp()
            await asyncio.sleep(0.1)

        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            loop.run_until_complete(run_once())
        finally:
            try:
                loop.run_until_complete(loop.shutdown_asyncgens())
                loop.run_until_complete(loop.shutdown_default_executor())
            except (RuntimeError, OSError):
                pass
            loop.close()
    else:
        # Interactive mode – route through bus like other channels
        from clawbot.bus.events import InboundMessage

        _init_prompt_session()
        console.print(
            f"{__logo__} Interactive mode (type [bold]exit[/bold] or [bold]Ctrl+C[/bold] to quit)\n"
        )

        if ":" in session_id:
            cli_channel, cli_chat_id = session_id.split(":", 1)
        else:
            cli_channel, cli_chat_id = "cli", session_id

        def _exit_on_sigint(signum, frame):
            _restore_terminal()
            console.print("\nGoodbye!")
            os._exit(0)

        signal.signal(signal.SIGINT, _exit_on_sigint)

        async def run_interactive():
            bus_task = asyncio.create_task(agent_loop.run())
            turn_done = asyncio.Event()
            turn_done.set()
            turn_response: list[str] = []

            async def _consume_outbound():
                while True:
                    try:
                        msg = await asyncio.wait_for(bus.consume_outbound(), timeout=1.0)
                        if msg.metadata.get("_progress"):
                            is_tool_hint = msg.metadata.get("_tool_hint", False)
                            ch = agent_loop.channels_config
                            if ch and is_tool_hint and not ch.send_tool_hints:
                                pass
                            elif ch and not is_tool_hint and not ch.send_progress:
                                pass
                            else:
                                console.print(f"  [dim]✓ {msg.content}[/dim]")
                        elif not turn_done.is_set():
                            if msg.content:
                                turn_response.append(msg.content)
                            turn_done.set()
                        elif msg.content:
                            console.print()
                            _print_agent_response(msg.content, render_markdown=markdown)
                    except asyncio.TimeoutError:
                        continue
                    except asyncio.CancelledError:
                        break

            outbound_task = asyncio.create_task(_consume_outbound())

            try:
                while True:
                    try:
                        _flush_pending_tty_input()
                        user_input = await _read_interactive_input_async()
                        command = user_input.strip()
                        if not command:
                            continue

                        if _is_exit_command(command):
                            _restore_terminal()
                            console.print("\nGoodbye!")
                            break

                        turn_done.clear()
                        turn_response.clear()

                        await bus.publish_inbound(
                            InboundMessage(
                                channel=cli_channel,
                                sender_id="user",
                                chat_id=cli_chat_id,
                                content=user_input,
                            )
                        )

                        with _thinking_ctx():
                            await turn_done.wait()

                        if turn_response:
                            _print_agent_response(turn_response[0], render_markdown=markdown)
                    except KeyboardInterrupt:
                        _restore_terminal()
                        console.print("\nGoodbye!")
                        break
                    except EOFError:
                        _restore_terminal()
                        console.print("\nGoodbye!")
                        break
            finally:
                agent_loop.stop()
                outbound_task.cancel()
                await asyncio.gather(bus_task, outbound_task, return_exceptions=True)
                await agent_loop.close_mcp()

        asyncio.run(run_interactive())


# ============================================================================
# Channel Commands
# ============================================================================


channels_app = typer.Typer(help="Manage channels")
app.add_typer(channels_app, name="channels")


@channels_app.command("status")
def channels_status():
    """Show channel status."""
    from clawbot.config.loader import load_config

    config = load_config()

    table = Table(title="Channel Status")
    table.add_column("Channel", style="cyan")
    table.add_column("Enabled", style="green")
    table.add_column("Configuration", style="yellow")

    # WhatsApp
    wa = config.channels.whatsapp
    table.add_row("WhatsApp", "✓" if wa.enabled else "✗", wa.bridge_url)

    dc = config.channels.discord
    table.add_row("Discord", "✓" if dc.enabled else "✗", dc.gateway_url)

    # Feishu
    fs = config.channels.feishu
    fs_config = f"app_id: {fs.app_id[:10]}..." if fs.app_id else "[dim]not configured[/dim]"
    table.add_row("Feishu", "✓" if fs.enabled else "✗", fs_config)

    # Mochat
    mc = config.channels.mochat
    mc_base = mc.base_url or "[dim]not configured[/dim]"
    table.add_row("Mochat", "✓" if mc.enabled else "✗", mc_base)

    # Telegram
    tg = config.channels.telegram
    tg_config = f"token: {tg.token[:10]}..." if tg.token else "[dim]not configured[/dim]"
    table.add_row("Telegram", "✓" if tg.enabled else "✗", tg_config)

    # Slack
    slack = config.channels.slack
    slack_config = "socket" if slack.app_token and slack.bot_token else "[dim]not configured[/dim]"
    table.add_row("Slack", "✓" if slack.enabled else "✗", slack_config)

    # DingTalk
    dt = config.channels.dingtalk
    dt_config = (
        f"client_id: {dt.client_id[:10]}..." if dt.client_id else "[dim]not configured[/dim]"
    )
    table.add_row("DingTalk", "✓" if dt.enabled else "✗", dt_config)

    # QQ
    qq = config.channels.qq
    qq_config = f"app_id: {qq.app_id[:10]}..." if qq.app_id else "[dim]not configured[/dim]"
    table.add_row("QQ", "✓" if qq.enabled else "✗", qq_config)

    # Email
    em = config.channels.email
    em_config = em.imap_host if em.imap_host else "[dim]not configured[/dim]"
    table.add_row("Email", "✓" if em.enabled else "✗", em_config)

    console.print(table)


def _get_bridge_dir() -> Path:
    """Get the bridge directory, setting it up if needed."""
    import shutil
    import subprocess

    # User's bridge location
    user_bridge = Path.home() / ".clawbot" / "bridge"

    # Check if already built
    if (user_bridge / "dist" / "index.js").exists():
        return user_bridge

    # Check for npm
    if not shutil.which("npm"):
        console.print("[red]npm not found. Please install Node.js >= 18.[/red]")
        raise typer.Exit(1)

    # Find source bridge: first check package data, then source dir
    pkg_bridge = Path(__file__).parent.parent / "bridge"  # clawbot/bridge (installed)
    src_bridge = Path(__file__).parent.parent.parent / "bridge"  # repo root/bridge (dev)

    source = None
    if (pkg_bridge / "package.json").exists():
        source = pkg_bridge
    elif (src_bridge / "package.json").exists():
        source = src_bridge

    if not source:
        console.print("[red]Bridge source not found.[/red]")
        console.print("Try reinstalling: pip install --force-reinstall clawbot")
        raise typer.Exit(1)

    console.print(f"{__logo__} Setting up bridge...")

    # Copy to user directory
    user_bridge.parent.mkdir(parents=True, exist_ok=True)
    if user_bridge.exists():
        shutil.rmtree(user_bridge)
    shutil.copytree(source, user_bridge, ignore=shutil.ignore_patterns("node_modules", "dist"))

    # Install and build
    try:
        console.print("  Installing dependencies...")
        subprocess.run(["npm", "install"], cwd=user_bridge, check=True, capture_output=True)

        console.print("  Building...")
        subprocess.run(["npm", "run", "build"], cwd=user_bridge, check=True, capture_output=True)

        console.print("[green]✓[/green] Bridge ready\n")
    except subprocess.CalledProcessError as e:
        console.print(f"[red]Build failed: {e}[/red]")
        if e.stderr:
            console.print(f"[dim]{e.stderr.decode()[:500]}[/dim]")
        raise typer.Exit(1)

    return user_bridge


@channels_app.command("login")
def channels_login():
    """Link device via QR code."""
    import subprocess

    from clawbot.config.loader import load_config

    config = load_config()
    bridge_dir = _get_bridge_dir()

    console.print(f"{__logo__} Starting bridge...")
    console.print("Scan the QR code to connect.\n")

    env = {**os.environ}
    if config.channels.whatsapp.bridge_token:
        env["BRIDGE_TOKEN"] = config.channels.whatsapp.bridge_token

    try:
        subprocess.run(["npm", "start"], cwd=bridge_dir, check=True, env=env)
    except subprocess.CalledProcessError as e:
        console.print(f"[red]Bridge failed: {e}[/red]")
    except FileNotFoundError:
        console.print("[red]npm not found. Please install Node.js.[/red]")


# ============================================================================
# Cron Commands
# ============================================================================

cron_app = typer.Typer(help="Manage scheduled tasks")
app.add_typer(cron_app, name="cron")


@cron_app.command("list")
def cron_list(
    all: bool = typer.Option(False, "--all", "-a", help="Include disabled jobs"),
):
    """List scheduled jobs."""
    from clawbot.config.loader import get_data_dir
    from clawbot.cron.service import CronService

    store_path = get_data_dir() / "cron" / "jobs.json"
    service = CronService(store_path)

    jobs = service.list_jobs(include_disabled=all)

    if not jobs:
        console.print("No scheduled jobs.")
        return

    table = Table(title="Scheduled Jobs")
    table.add_column("ID", style="cyan")
    table.add_column("Name")
    table.add_column("Schedule")
    table.add_column("Status")
    table.add_column("Next Run")

    from datetime import datetime as _dt
    from zoneinfo import ZoneInfo

    for job in jobs:
        # Format schedule
        if job.schedule.kind == "every":
            sched = f"every {(job.schedule.every_ms or 0) // 1000}s"
        elif job.schedule.kind == "cron":
            sched = (
                f"{job.schedule.expr or ''} ({job.schedule.tz})"
                if job.schedule.tz
                else (job.schedule.expr or "")
            )
        else:
            sched = "one-time"

        # Format next run
        next_run = ""
        if job.state.next_run_at_ms:
            ts = job.state.next_run_at_ms / 1000
            try:
                tz = ZoneInfo(job.schedule.tz) if job.schedule.tz else None
                next_run = _dt.fromtimestamp(ts, tz).strftime("%Y-%m-%d %H:%M")
            except (ValueError, KeyError, OSError):
                next_run = time.strftime("%Y-%m-%d %H:%M", time.localtime(ts))

        status = "[green]enabled[/green]" if job.enabled else "[dim]disabled[/dim]"

        table.add_row(job.id, job.name, sched, status, next_run)

    console.print(table)


@cron_app.command("add")
def cron_add(
    name: str = typer.Option(..., "--name", "-n", help="Job name"),
    message: str = typer.Option(..., "--message", "-m", help="Message for agent"),
    every: int = typer.Option(None, "--every", "-e", help="Run every N seconds"),
    cron_expr: str = typer.Option(None, "--cron", "-c", help="Cron expression (e.g. '0 9 * * *')"),
    tz: str | None = typer.Option(
        None, "--tz", help="IANA timezone for cron (e.g. 'America/Vancouver')"
    ),
    at: str = typer.Option(None, "--at", help="Run once at time (ISO format)"),
    deliver: bool = typer.Option(False, "--deliver", "-d", help="Deliver response to channel"),
    to: str = typer.Option(None, "--to", help="Recipient for delivery"),
    channel: str = typer.Option(
        None, "--channel", help="Channel for delivery (e.g. 'telegram', 'whatsapp')"
    ),
):
    """Add a scheduled job."""
    from clawbot.config.loader import get_data_dir
    from clawbot.cron.service import CronService
    from clawbot.cron.types import CronSchedule

    if tz and not cron_expr:
        console.print("[red]Error: --tz can only be used with --cron[/red]")
        raise typer.Exit(1)

    # Determine schedule type
    if every:
        schedule = CronSchedule(kind="every", every_ms=every * 1000)
    elif cron_expr:
        schedule = CronSchedule(kind="cron", expr=cron_expr, tz=tz)
    elif at:
        import datetime

        dt = datetime.datetime.fromisoformat(at)
        schedule = CronSchedule(kind="at", at_ms=int(dt.timestamp() * 1000))
    else:
        console.print("[red]Error: Must specify --every, --cron, or --at[/red]")
        raise typer.Exit(1)

    store_path = get_data_dir() / "cron" / "jobs.json"
    service = CronService(store_path)

    try:
        job = service.add_job(
            name=name,
            schedule=schedule,
            message=message,
            deliver=deliver,
            to=to,
            channel=channel,
        )
    except ValueError as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1) from e

    console.print(f"[green]✓[/green] Added job '{job.name}' ({job.id})")


@cron_app.command("remove")
def cron_remove(
    job_id: str = typer.Argument(..., help="Job ID to remove"),
):
    """Remove a scheduled job."""
    from clawbot.config.loader import get_data_dir
    from clawbot.cron.service import CronService

    store_path = get_data_dir() / "cron" / "jobs.json"
    service = CronService(store_path)

    if service.remove_job(job_id):
        console.print(f"[green]✓[/green] Removed job {job_id}")
    else:
        console.print(f"[red]Job {job_id} not found[/red]")


@cron_app.command("enable")
def cron_enable(
    job_id: str = typer.Argument(..., help="Job ID"),
    disable: bool = typer.Option(False, "--disable", help="Disable instead of enable"),
):
    """Enable or disable a job."""
    from clawbot.config.loader import get_data_dir
    from clawbot.cron.service import CronService

    store_path = get_data_dir() / "cron" / "jobs.json"
    service = CronService(store_path)

    job = service.enable_job(job_id, enabled=not disable)
    if job:
        status = "disabled" if disable else "enabled"
        console.print(f"[green]✓[/green] Job '{job.name}' {status}")
    else:
        console.print(f"[red]Job {job_id} not found[/red]")


@cron_app.command("run")
def cron_run(
    job_id: str = typer.Argument(..., help="Job ID to run"),
    force: bool = typer.Option(False, "--force", "-f", help="Run even if disabled"),
):
    """Manually run a job."""
    from clawbot.agent.loop import AgentLoop
    from clawbot.bus.queue import MessageBus
    from clawbot.config.loader import get_data_dir, load_config
    from clawbot.cron.service import CronService
    from clawbot.cron.types import CronJob

    logger.disable("clawbot")

    config = load_config()
    provider = _make_provider(config)
    bus = MessageBus()
    agent_loop = AgentLoop(
        bus=bus,
        provider=provider,
        workspace=config.workspace_path,
        model=config.agents.defaults.model,
        temperature=config.agents.defaults.temperature,
        max_tokens=config.agents.defaults.max_tokens,
        max_iterations=config.agents.defaults.max_tool_iterations,
        memory_window=config.agents.defaults.memory_window,
        brave_api_key=config.tools.web.search.api_key or None,
        exec_config=config.tools.exec,
        restrict_to_workspace=config.tools.restrict_to_workspace,
        mcp_servers=config.tools.mcp_servers,
        channels_config=config.channels,
        windows_bridge_config=config.tools.windows_bridge,
        skills_config=config.skills,
    )

    store_path = get_data_dir() / "cron" / "jobs.json"
    service = CronService(store_path)

    result_holder = []

    async def on_job(job: CronJob) -> str | None:
        response = await agent_loop.process_direct(
            job.payload.message,
            session_key=f"cron:{job.id}",
            channel=job.payload.channel or "cli",
            chat_id=job.payload.to or "direct",
        )
        result_holder.append(response)
        return response

    service.on_job = on_job

    async def run():
        return await service.run_job(job_id, force=force)

    if asyncio.run(run()):
        console.print("[green]✓[/green] Job executed")
        if result_holder:
            _print_agent_response(result_holder[0], render_markdown=True)
    else:
        console.print(f"[red]Failed to run job {job_id}[/red]")


# ============================================================================
# Status Commands
# ============================================================================


@app.command()
def status(
    services: bool = typer.Option(False, "--services", "-s", help="Show all services status"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show detailed status"),
):
    """Show clawbot status."""
    from clawbot.config.loader import get_config_path, load_config

    config_path = get_config_path()
    config = load_config()
    workspace = config.workspace_path

    console.print(f"{__logo__} clawbot Status\n")

    console.print(
        f"Config: {config_path} {'[green]✓[/green]' if config_path.exists() else '[red]✗[/red]'}")
    console.print(
        f"Workspace: {workspace} {'[green]✓[/green]' if workspace.exists() else '[red]✗[/red]'}")

    if config_path.exists():
        from clawbot.providers.registry import PROVIDERS

        console.print(f"Model: {config.agents.defaults.model}")

        # Check API keys from registry
        for spec in PROVIDERS:
            p = getattr(config.providers, spec.name, None)
            if p is None:
                continue
            if spec.is_oauth:
                console.print(f"{spec.label}: [green]✓ (OAuth)[/green]")
            elif spec.is_local:
                # Local deployments show api_base instead of api_key
                if p.api_base:
                    console.print(f"{spec.label}: [green]✓ {p.api_base}[/green]")
                else:
                    console.print(f"{spec.label}: [dim]not set[/dim]")
            else:
                has_key = bool(p.api_key)
                console.print(
                    f"{spec.label}: {'[green]✓[/green]' if has_key else '[dim]not set[/dim]'}")

    # Show services status if requested
    if services or verbose:
        console.print("\n[bold]Services Status:[/bold]\n")

        table = Table()
        table.add_column("Service", style="cyan")
        table.add_column("Status", style="green")
        table.add_column("Details", style="yellow")

        # Gateway
        table.add_row(
            "Gateway",
            "[green]running[/green]",
            f"host={config.gateway.host}, port={config.gateway.port}"
        )

        # OpenWork
        if config.tools.openwork.enabled:
            from clawbot.openwork.orchestrator import OpenWorkOrchestrator

            is_installed = OpenWorkOrchestrator.is_installed()
            is_healthy = asyncio.run(
                OpenWorkOrchestrator.check_health(
                    f"http://localhost:{config.tools.openwork.orchestrator_port}"
                )
            ) if is_installed else False

            status_str = "[green]running[/green]" if is_healthy else "[yellow]stopped[/yellow]"
            details = f"port={config.tools.openwork.orchestrator_port}"
            if not is_installed:
                details += ", not installed"

            table.add_row("OpenWork", status_str, details)
        else:
            table.add_row("OpenWork", "[dim]disabled[/dim]", "enable in config")

        # Memory (Embedding)
        memory_status = "enabled" if config.memory.embedding_api.enabled else "disabled"
        memory_details = f"url={config.memory.embedding_api.base_url}" if config.memory.embedding_api.enabled else ""
        table.add_row(
            "Memory (Embedding)",
            f"[green]{memory_status}[/green]" if config.memory.embedding_api.enabled else f"[dim]{memory_status}[/dim]",
            memory_details
        )

        # MemOS
        memos_status = "enabled" if config.memory.memos.enabled else "disabled"
        table.add_row(
            "Memory (MemOS)",
            f"[green]{memos_status}[/green]" if config.memory.memos.enabled else f"[dim]{memos_status}[/dim]",
            ""
        )

        # Channels
        enabled_channels = []
        if config.channels.whatsapp.enabled:
            enabled_channels.append("WhatsApp")
        if config.channels.telegram.enabled:
            enabled_channels.append("Telegram")
        if config.channels.discord.enabled:
            enabled_channels.append("Discord")
        if config.channels.feishu.enabled:
            enabled_channels.append("Feishu")
        if config.channels.mochat.enabled:
            enabled_channels.append("Mochat")
        if config.channels.dingtalk.enabled:
            enabled_channels.append("DingTalk")
        if config.channels.email.enabled:
            enabled_channels.append("Email")
        if config.channels.slack.enabled:
            enabled_channels.append("Slack")
        if config.channels.qq.enabled:
            enabled_channels.append("QQ")

        if enabled_channels:
            table.add_row(
                "Channels",
                "[green]enabled[/green]",
                ", ".join(enabled_channels)
            )
        else:
            table.add_row("Channels", "[dim]disabled[/dim]", "no channels enabled")

        # Heartbeat
        hb_status = "enabled" if config.gateway.heartbeat.enabled else "disabled"
        hb_details = f"interval={config.gateway.heartbeat.interval_s}s" if config.gateway.heartbeat.enabled else ""
        table.add_row(
            "Heartbeat",
            f"[green]{hb_status}[/green]" if config.gateway.heartbeat.enabled else f"[dim]{hb_status}[/dim]",
            hb_details
        )

        console.print(table)


# ============================================================================
# OAuth Login
# ============================================================================

provider_app = typer.Typer(help="Manage providers")
app.add_typer(provider_app, name="provider")


_LOGIN_HANDLERS: dict[str, callable] = {}


def _register_login(name: str):
    def decorator(fn):
        _LOGIN_HANDLERS[name] = fn
        return fn

    return decorator


@provider_app.command("login")
def provider_login(
    provider: str = typer.Argument(
        ...,
        help="OAuth provider (e.g. 'openai-codex', 'github-copilot', 'doubao-web', 'deepseek-web')",
    ),
    show_url: bool = typer.Option(False, "--url", "-u", help="Show auth URL for external browser"),
    sessionid: str = typer.Option(None, "--sessionid", help="Doubao sessionid (manual auth)"),
    cookie: str = typer.Option(None, "--cookie", help="DeepSeek cookie (manual auth)"),
    bearer: str = typer.Option(None, "--bearer", help="DeepSeek bearer token (manual auth)"),
):
    """Authenticate with an OAuth provider."""
    from clawbot.providers.registry import PROVIDERS

    key = provider.replace("-", "_")
    spec = next((s for s in PROVIDERS if s.name == key and s.is_oauth), None)
    if not spec:
        names = ", ".join(s.name.replace("_", "-") for s in PROVIDERS if s.is_oauth)
        console.print(f"[red]Unknown OAuth provider: {provider}[/red]  Supported: {names}")
        raise typer.Exit(1)

    console.print(f"{__logo__} OAuth Login - {spec.label}\n")

    if show_url:
        _show_auth_url(spec.name)
        return

    if sessionid and spec.name == "doubao_web":
        _login_doubao_with_sessionid(sessionid)
        return

    if cookie and spec.name == "deepseek_web":
        _login_deepseek_with_credentials(cookie, bearer or "")
        return

    handler = _LOGIN_HANDLERS.get(spec.name)
    if not handler:
        console.print(f"[red]Login not implemented for {spec.label}[/red]")
        raise typer.Exit(1)

    handler()


def _show_auth_url(provider_name: str) -> None:
    """显示授权 URL 和说明。"""
    if provider_name == "doubao_web":
        from clawbot.providers.doubao_web_provider import DoubaoWebProvider

        console.print("[cyan]豆包登录 URL:[/cyan]")
        console.print(f"  {DoubaoWebProvider.get_auth_url()}")
        console.print(DoubaoWebProvider.get_auth_instructions())
    elif provider_name == "deepseek_web":
        from clawbot.providers.deepseek_web_provider import DeepSeekWebProvider

        console.print("[cyan]DeepSeek 登录 URL:[/cyan]")
        console.print(f"  {DeepSeekWebProvider.get_auth_url()}")
        console.print(DeepSeekWebProvider.get_auth_instructions())
    elif provider_name == "qwen_portal":
        from clawbot.providers.qwen_portal_provider import QWEN_OAUTH_BASE_URL

        console.print("[cyan]Qwen Portal 登录 URL:[/cyan]")
        console.print(f"  {QWEN_OAUTH_BASE_URL}")
        console.print("\n运行 'clawbot provider login qwen-portal' 进行 OAuth 登录")
    else:
        console.print(f"[yellow]Provider {provider_name} 不支持 URL 显示[/yellow]")


def _login_doubao_with_sessionid(sessionid: str) -> None:
    """使用 sessionid 手动授权豆包。"""

    async def do_login():
        from clawbot.providers.doubao_web_provider import DoubaoWebProvider

        provider_instance = DoubaoWebProvider()
        return await provider_instance.login_with_credentials(sessionid)

    try:
        asyncio.run(do_login())
        console.print("[green]✓ Authenticated with Doubao Web[/green]")
        console.print("[dim]Credentials saved to ~/.clawbot/doubao_web_creds.json[/dim]")
        console.print()
        console.print("[cyan]To use Doubao Web, update your config.json:[/cyan]")
        console.print("""[dim]{
  "agents": {
    "defaults": {
      "model": "doubao-web/doubao-seed-2.0"
    }
  }
}[/dim]""")
        console.print()
        console.print("[cyan]Or use with CLI:[/cyan]")
        console.print("[dim]  clawbot agent -m '你好' --model doubao-web/doubao-seed-2.0[/dim]")
    except ValueError as e:
        console.print(f"[red]Validation error: {e}[/red]")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]Authentication error: {e}[/red]")
        raise typer.Exit(1)


def _login_deepseek_with_credentials(cookie: str, bearer: str) -> None:
    """使用 cookie 和 bearer token 手动授权 DeepSeek。"""

    async def do_login():
        from clawbot.providers.deepseek_web_provider import DeepSeekWebProvider

        provider_instance = DeepSeekWebProvider()
        return await provider_instance.login_with_credentials(cookie, bearer)

    try:
        asyncio.run(do_login())
        console.print("[green]✓ Authenticated with DeepSeek Web[/green]")
        console.print("[dim]Credentials saved to ~/.clawbot/deepseek_web_creds.json[/dim]")
        console.print()
        console.print("[cyan]To use DeepSeek Web, update your config.json:[/cyan]")
        console.print("""[dim]{
  "agents": {
    "defaults": {
      "model": "deepseek-web/deepseek-chat"
    }
  }
}[/dim]""")
        console.print()
        console.print("[cyan]Or use with CLI:[/cyan]")
        console.print("[dim]  clawbot agent -m '你好' --model deepseek-web/deepseek-chat[/dim]")
    except ValueError as e:
        console.print(f"[red]Validation error: {e}[/red]")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]Authentication error: {e}[/red]")
        raise typer.Exit(1)


@_register_login("openai_codex")
def _login_openai_codex() -> None:
    try:
        from oauth_cli_kit import get_token, login_oauth_interactive

        token = None
        try:
            token = get_token()
        except (ImportError, ValueError, KeyError, OSError):
            pass
        if not (token and token.access):
            console.print("[cyan]Starting interactive OAuth login...[/cyan]\n")
            token = login_oauth_interactive(
                print_fn=lambda s: console.print(s),
                prompt_fn=lambda s: typer.prompt(s),
            )
        if not (token and token.access):
            console.print("[red]✗ Authentication failed[/red]")
            raise typer.Exit(1)
        console.print(
            f"[green]✓ Authenticated with OpenAI Codex[/green]  [dim]{token.account_id}[/dim]"
        )
    except ImportError:
        console.print("[red]oauth_cli_kit not installed. Run: pip install oauth-cli-kit[/red]")
        raise typer.Exit(1)


@_register_login("github_copilot")
def _login_github_copilot() -> None:
    console.print("[cyan]Starting GitHub Copilot device flow...[/cyan]\n")

    async def _trigger():
        from litellm import acompletion

        await acompletion(
            model="github_copilot/gpt-4o",
            messages=[{"role": "user", "content": "hi"}],
            max_tokens=1,
        )

    try:
        asyncio.run(_trigger())
        console.print("[green]✓ Authenticated with GitHub Copilot[/green]")
    except Exception as e:
        console.print(f"[red]Authentication error: {e}[/red]")
        raise typer.Exit(1)


@_register_login("qwen_portal")
def _login_qwen_portal() -> None:
    async def do_login():
        from clawbot.providers.qwen_portal_provider import QwenPortalProvider

        provider_instance = QwenPortalProvider()
        return await provider_instance.login(open_url=True, print_instructions=True)

    try:
        token = asyncio.run(do_login())
        console.print("[green]✓ Authenticated with Qwen Portal[/green]")
        if hasattr(token, "expires") and token.expires:
            console.print(
                f"[dim]Token expires: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(token.expires))}[/dim]"
            )
    except Exception as e:
        console.print(f"[red]Authentication error: {e}[/red]")
        raise typer.Exit(1)


@_register_login("doubao_web")
def _login_doubao_web() -> None:
    """Doubao Web 登录 - 显示授权 URL 和说明。"""
    from clawbot.providers.doubao_web_provider import DoubaoWebProvider

    console.print("[cyan]Doubao Web 授权登录[/cyan]")
    console.print()
    console.print(f"[green]登录 URL:[/green] {DoubaoWebProvider.get_auth_url()}")
    console.print()
    console.print(DoubaoWebProvider.get_auth_instructions())
    console.print("[cyan]获取到 sessionid 后，使用以下命令完成授权:[/cyan]")
    console.print("[dim]  clawbot provider login doubao-web --sessionid \"your_sessionid\"[/dim]")


@_register_login("deepseek_web")
def _login_deepseek_web() -> None:
    """DeepSeek Web 登录 - 显示授权 URL 和说明。"""
    from clawbot.providers.deepseek_web_provider import DeepSeekWebProvider

    console.print("[cyan]DeepSeek Web 授权登录[/cyan]")
    console.print()
    console.print(f"[green]登录 URL:[/green] {DeepSeekWebProvider.get_auth_url()}")
    console.print()
    console.print(DeepSeekWebProvider.get_auth_instructions())
    console.print("[cyan]获取到 Cookie 和 Bearer Token 后，使用以下命令完成授权:[/cyan]")
    console.print("[dim]  clawbot provider login deepseek-web --cookie \"d_id=xxx; ...\" --bearer \"your_token\"[/dim]")


# ============================================================================
# Project Commands (Unattended Programming)
# ============================================================================

project_app = typer.Typer(help="Manage unattended programming projects")
app.add_typer(project_app, name="project")


@project_app.command("start")
def project_start(
    idea: str = typer.Argument(..., help="Your project idea or requirement"),
    workspace: str | None = typer.Option(None, "--workspace", "-w", help="Workspace directory"),
    interactive: bool = typer.Option(True, "--interactive/--no-interactive", help="Interactive mode"),
):
    """Start a new unattended programming project."""
    from pathlib import Path

    from clawbot.config.loader import load_config

    config = load_config()
    workspace_path = Path(workspace) if workspace else config.workspace_path / "projects"

    async def run():
        from clawbot.openwork.unattended_programming_manager import UnattendedProgrammingManager

        manager = UnattendedProgrammingManager(workspace=workspace_path)

        console.print(f"\n[cyan]Processing idea:[/cyan] {idea[:100]}{'...' if len(idea) > 100 else ''}\n")

        with console.status("[dim]Analyzing and planning...[/dim]"):
            project = await manager.submit_idea(idea, user_id="cli_user", workspace=workspace_path)

        console.print(f"[green]✓[/green] Project created: {project.project_id}")
        console.print(f"  Status: {project.status.value}")
        console.print(f"  Complexity: {project.processed_idea.complexity.value if project.processed_idea else 'unknown'}")

        if project.processed_idea and project.processed_idea.features:
            console.print("\n[cyan]Extracted features:[/cyan]")
            for feature in project.processed_idea.features[:5]:
                console.print(f"  • {feature.name}: {feature.description[:50]}...")

        if interactive and project.status.value == "planning":
            console.print("\n[dim]Monitoring progress... (Ctrl+C to stop)[/dim]")
            try:
                async for progress in manager.monitor_progress(project.project_id):
                    console.print(f"  [{progress.status}] {progress.current_task or 'Processing...'}")
                    if progress.status in ["completed", "failed"]:
                        break
            except KeyboardInterrupt:
                console.print("\n[yellow]Monitoring stopped. Project continues in background.[/yellow]")
                console.print(f"Use 'clawbot project status {project.project_id}' to check progress.")

        return project

    try:
        project = asyncio.run(run())
        console.print(f"\n[green]Project ID:[/green] {project.project_id}")
        console.print(f"[dim]Use 'clawbot project status {project.project_id}' to check status[/dim]")
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)


@project_app.command("status")
def project_status(
    project_id: str = typer.Argument(..., help="Project ID"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show detailed status"),
):
    """View project status."""
    from clawbot.config.loader import load_config

    config = load_config()
    workspace_path = config.workspace_path / "projects"

    async def run():
        from clawbot.openwork.unattended_programming_manager import UnattendedProgrammingManager

        manager = UnattendedProgrammingManager(workspace=workspace_path)
        project = await manager.get_project(project_id)

        if not project:
            console.print(f"[red]Project not found: {project_id}[/red]")
            raise typer.Exit(1)

        console.print(f"\n[bold]Project: {project_id}[/bold]\n")
        console.print(f"Status: [cyan]{project.status.value}[/cyan]")
        console.print(f"Created: {project.created_at.strftime('%Y-%m-%d %H:%M:%S')}")

        if project.processed_idea:
            console.print("\n[cyan]Idea Analysis:[/cyan]")
            console.print(f"  Complexity: {project.processed_idea.complexity.value}")
            console.print(f"  Risk Level: {project.processed_idea.risk_level.value}")
            console.print(f"  Task Type: {project.processed_idea.task_type.value}")

            if verbose and project.processed_idea.features:
                console.print(f"\n[cyan]Features ({len(project.processed_idea.features)}):[/cyan]")
                for feature in project.processed_idea.features:
                    console.print(f"  • {feature.name}")
                    console.print(f"    {feature.description[:80]}...")

        if project.route_decision:
            console.print("\n[cyan]Execution Plan:[/cyan]")
            console.print(f"  Strategy: {project.route_decision.strategy.value}")
            console.print(f"  Target: {project.route_decision.target.value}")

        if project.execution_result:
            console.print("\n[cyan]Execution Result:[/cyan]")
            console.print(f"  Success: {'[green]✓[/green]' if project.execution_result.success else '[red]✗[/red]'}")
            if project.execution_result.error:
                console.print(f"  Error: [red]{project.execution_result.error}[/red]")

        if project.feedback:
            console.print("\n[cyan]Feedback:[/cyan]")
            console.print(f"  Rating: {project.feedback.rating}/5")
            if project.feedback.comment:
                console.print(f"  Comment: {project.feedback.comment}")

        return project

    asyncio.run(run())


@project_app.command("feedback")
def project_feedback(
    project_id: str = typer.Argument(..., help="Project ID"),
    rating: int = typer.Argument(..., help="Rating (1-5)"),
    comment: str = typer.Option("", "--comment", "-c", help="Feedback comment"),
):
    """Provide feedback for a completed project."""
    from clawbot.config.loader import load_config

    if rating < 1 or rating > 5:
        console.print("[red]Rating must be between 1 and 5[/red]")
        raise typer.Exit(1)

    config = load_config()
    workspace_path = config.workspace_path / "projects"

    async def run():
        from clawbot.openwork.unattended_programming_manager import UnattendedProgrammingManager

        manager = UnattendedProgrammingManager(workspace=workspace_path)

        result = await manager.submit_feedback(
            project_id=project_id,
            rating=rating,
            comment=comment,
            user_id="cli_user",
        )

        if result.get("success"):
            console.print(f"[green]✓[/green] Feedback submitted for project {project_id}")

            if result.get("evolution_triggered"):
                console.print("[dim]Self-evolution triggered based on feedback.[/dim]")

            actions = result.get("immediate_actions", [])
            if actions:
                console.print("\n[cyan]Immediate actions taken:[/cyan]")
                for action in actions:
                    console.print(f"  • {action.get('action')}: {action.get('operation')} - {action.get('reason')}")
        else:
            console.print(f"[red]Failed to submit feedback: {result.get('error')}[/red]")
            raise typer.Exit(1)

        return result

    asyncio.run(run())


@project_app.command("list")
def project_list(
    limit: int = typer.Option(10, "--limit", "-l", help="Maximum number of projects to show"),
    status_filter: str | None = typer.Option(None, "--status", "-s", help="Filter by status"),
):
    """List all projects."""
    from clawbot.config.loader import load_config

    config = load_config()
    workspace_path = config.workspace_path / "projects"

    async def run():
        from clawbot.openwork.unattended_programming_manager import UnattendedProgrammingManager

        manager = UnattendedProgrammingManager(workspace=workspace_path)
        projects = await manager.list_projects(limit=limit, status_filter=status_filter)

        if not projects:
            console.print("No projects found.")
            return

        table = Table(title="Projects")
        table.add_column("ID", style="cyan")
        table.add_column("Status", style="green")
        table.add_column("Created", style="yellow")
        table.add_column("Idea Preview")

        for project in projects:
            idea_preview = project.idea[:40] + "..." if len(project.idea) > 40 else project.idea
            table.add_row(
                project.project_id[:12] + "...",
                project.status.value,
                project.created_at.strftime("%m/%d %H:%M"),
                idea_preview,
            )

        console.print(table)

    asyncio.run(run())


# ============================================================================
# Evolution Commands
# ============================================================================

evolution_app = typer.Typer(help="Manage self-evolution")
app.add_typer(evolution_app, name="evolution")


@evolution_app.command("trigger")
def evolution_trigger(
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show detailed results"),
):
    """Trigger manual self-evolution."""
    from clawbot.config.loader import load_config

    config = load_config()

    async def run():
        from clawbot.openwork.memory import OpenWorkMemoryBridge
        from clawbot.openwork.pattern_extractor import PatternExtractor
        from clawbot.openwork.self_enhancer import SelfEnhancer

        memory = OpenWorkMemoryBridge(workspace=config.workspace_path)
        extractor = PatternExtractor(memory_bridge=memory)
        enhancer = SelfEnhancer(memory_bridge=memory, pattern_extractor=extractor)

        console.print("[cyan]Starting self-evolution process...[/cyan]\n")

        with console.status("[dim]Analyzing patterns and enhancing...[/dim]"):
            result = await enhancer.enhance()

        console.print("[green]✓[/green] Self-evolution complete!\n")

        console.print("[cyan]Summary:[/cyan]")
        console.print(f"  • Threshold adjustments: {len(result.adjustments)}")
        console.print(f"  • New rules: {len(result.new_rules)}")
        console.print(f"  • Feedback insights: {len(result.feedback_insights)}")
        console.print(f"  • Capability expansions: {len(result.capability_expansions)}")

        if verbose:
            if result.new_rules:
                console.print("\n[cyan]New Rules:[/cyan]")
                for rule in result.new_rules:
                    console.print(f"  • {rule.get('operation')} -> {rule.get('level')} (confidence: {rule.get('confidence', 0):.0%})")

            if result.capability_expansions:
                console.print("\n[cyan]Capability Expansions:[/cyan]")
                for exp in result.capability_expansions:
                    console.print(f"  • {exp.get('operation_type')}: {exp.get('previous_level')} -> {exp.get('new_level')}")
                    console.print(f"    {exp.get('reason')}")

            if result.recommendations:
                console.print("\n[cyan]Recommendations:[/cyan]")
                for rec in result.recommendations:
                    console.print(f"  {rec}")

        return result

    try:
        asyncio.run(run())
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)


@evolution_app.command("status")
def evolution_status():
    """Show self-evolution status and statistics."""
    from clawbot.config.loader import load_config

    config = load_config()

    async def run():
        from clawbot.openwork.memory import OpenWorkMemoryBridge
        from clawbot.openwork.pattern_extractor import PatternExtractor
        from clawbot.openwork.self_enhancer import SelfEnhancer

        memory = OpenWorkMemoryBridge(workspace=config.workspace_path)
        extractor = PatternExtractor(memory_bridge=memory)
        enhancer = SelfEnhancer(memory_bridge=memory, pattern_extractor=extractor)

        stats = enhancer.get_enhancement_stats()
        pattern_stats = await extractor.get_pattern_stats()

        console.print("\n[bold]Self-Evolution Status[/bold]\n")

        table = Table()
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="green")

        table.add_row("Auto-safe operations", str(stats["auto_safe_operations_count"]))
        table.add_row("Require-human operations", str(stats["require_human_operations_count"]))
        table.add_row("Feedback history", str(stats["feedback_history_count"]))
        table.add_row("Error learning", "enabled" if stats["error_learning_enabled"] else "disabled")
        table.add_row("Capability expansion", "enabled" if stats["capability_expansion_enabled"] else "disabled")

        console.print(table)

        console.print("\n[cyan]Thresholds:[/cyan]")
        for key, value in stats["thresholds"].items():
            console.print(f"  {key}: {value}")

        console.print("\n[cyan]Pattern Statistics:[/cyan]")
        console.print(f"  Total patterns: {pattern_stats['total_patterns']}")
        console.print(f"  Average confidence: {pattern_stats['avg_confidence']:.0%}")
        console.print(f"  Average success rate: {pattern_stats['avg_success_rate']:.0%}")

        if pattern_stats["by_type"]:
            console.print("\n  By type:")
            for ptype, count in pattern_stats["by_type"].items():
                console.print(f"    {ptype}: {count}")

    asyncio.run(run())


# ============================================================================
# Memory Commands
# ============================================================================

memory_app = typer.Typer(help="Manage memory and knowledge")
app.add_typer(memory_app, name="memory")


@memory_app.command("search")
def memory_search(
    query: str = typer.Argument(..., help="Search query"),
    limit: int = typer.Option(5, "--limit", "-l", help="Maximum results"),
    type_filter: str | None = typer.Option(None, "--type", "-t", help="Filter by type (decision, snippet, pattern)"),
):
    """Search memory for relevant information."""
    from clawbot.config.loader import load_config

    config = load_config()

    async def run():
        from clawbot.openwork.memory import OpenWorkMemoryBridge

        memory = OpenWorkMemoryBridge(workspace=config.workspace_path)

        console.print(f"\n[cyan]Searching for:[/cyan] {query}\n")

        with console.status("[dim]Searching...[/dim]"):
            snippets = await memory.search_code_snippets(query, limit=limit)

        if snippets:
            console.print(f"[green]Found {len(snippets)} code snippets:[/green]\n")
            for i, snippet in enumerate(snippets, 1):
                console.print(f"[cyan]{i}. {snippet.title}[/cyan]")
                console.print(f"   Language: {snippet.language}")
                console.print(f"   {snippet.code[:100]}...")
                console.print()
        else:
            console.print("[dim]No code snippets found.[/dim]")

        if not type_filter or type_filter == "decision":
            decisions = await memory.get_all_decisions()
            relevant = [d for d in decisions if query.lower() in str(d).lower()][:limit]

            if relevant:
                console.print(f"[green]Found {len(relevant)} related decisions:[/green]\n")
                for i, dec in enumerate(relevant, 1):
                    console.print(f"[cyan]{i}. {dec.get('event_type', 'unknown')}[/cyan]")
                    console.print(f"   Level: {dec.get('decision_level', 'unknown')}")
                    console.print(f"   Success: {dec.get('success', False)}")
                    console.print()

    asyncio.run(run())


@memory_app.command("stats")
def memory_stats():
    """Show memory statistics."""
    from clawbot.config.loader import load_config

    config = load_config()

    async def run():
        from clawbot.openwork.memory import OpenWorkMemoryBridge

        memory = OpenWorkMemoryBridge(workspace=config.workspace_path)
        stats = await memory.get_stats()

        console.print("\n[bold]Memory Statistics[/bold]\n")

        table = Table()
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="green")

        table.add_row("Total decisions", str(stats.get("total_decisions", 0)))
        table.add_row("Auto-resolved", str(stats.get("auto_resolved", 0)))
        table.add_row("Require human", str(stats.get("require_human", 0)))
        table.add_row("Success rate", f"{stats.get('success_rate', 0):.0%}")
        table.add_row("Code snippets", str(stats.get("code_snippets", 0)))
        table.add_row("Error patterns", str(stats.get("error_patterns", 0)))
        table.add_row("Project contexts", str(stats.get("project_contexts", 0)))

        console.print(table)

    asyncio.run(run())


@memory_app.command("patterns")
def memory_patterns():
    """Show learned patterns."""
    from clawbot.config.loader import load_config

    config = load_config()

    async def run():
        from clawbot.openwork.memory import OpenWorkMemoryBridge
        from clawbot.openwork.pattern_extractor import PatternExtractor

        memory = OpenWorkMemoryBridge(workspace=config.workspace_path)
        extractor = PatternExtractor(memory_bridge=memory)
        patterns = await extractor.load_patterns()

        if not patterns:
            console.print("No patterns learned yet.")
            return

        console.print(f"\n[bold]Learned Patterns ({len(patterns)})[/bold]\n")

        table = Table()
        table.add_column("ID", style="cyan")
        table.add_column("Type", style="yellow")
        table.add_column("Level", style="green")
        table.add_column("Confidence", style="magenta")
        table.add_column("Samples")

        for p in patterns[:20]:
            table.add_row(
                p.pattern_id[:12] + "...",
                p.pattern_type,
                p.recommended_level,
                f"{p.confidence:.0%}",
                str(p.sample_count),
            )

        console.print(table)

    asyncio.run(run())


if __name__ == "__main__":
    app()


# ============================================================================
# OpenWork Commands
# ============================================================================

openwork_app = typer.Typer(help="Manage OpenWork service")
app.add_typer(openwork_app, name="openwork")


@openwork_app.command("start")
def openwork_start(
    port: int = typer.Option(7777, "--port", "-p", help="Service port"),
    workspace: str | None = typer.Option(None, "--workspace", "-w", help="Workspace directory"),
):
    """Start OpenWork service."""
    from pathlib import Path

    from clawbot.config.loader import load_config
    from clawbot.constants import OPENWORK_SERVER_DEFAULT_PORT

    actual_port = port or OPENWORK_SERVER_DEFAULT_PORT
    config = load_config()
    workspace_path = Path(workspace) if workspace else config.workspace_path / "openwork"

    async def run():
        from clawbot.services.openwork_manager import OpenWorkServiceManager

        manager = OpenWorkServiceManager(
            port=actual_port,
            workspace=workspace_path,
            auto_start=True,
            auto_restart=True,
        )

        console.print(f"[cyan]Starting OpenWork service at port {actual_port}...[/cyan]")

        success = await manager.start()

        if success:
            console.print(f"[green]✓[/green] OpenWork service started at http://localhost:{actual_port}")
            console.print(f"[dim]Workspace: {workspace_path}[/dim]")
            console.print("\n[dim]Press Ctrl+C to stop[/dim]")

            try:
                while True:
                    await asyncio.sleep(1)
            except KeyboardInterrupt:
                console.print("\n[yellow]Stopping...[/yellow]")
                await manager.stop()
                console.print("[green]✓[/green] OpenWork service stopped")
        else:
            console.print("[red]✗ Failed to start OpenWork service[/red]")
            console.print("[dim]Make sure OpenWork is installed: pip install openwork-server[/dim]")
            raise typer.Exit(1)

    try:
        asyncio.run(run())
    except KeyboardInterrupt:
        pass


@openwork_app.command("stop")
def openwork_stop(
    port: int = typer.Option(7777, "--port", "-p", help="Service port"),
):
    """Stop OpenWork service."""
    from clawbot.constants import OPENWORK_SERVER_DEFAULT_PORT

    actual_port = port or OPENWORK_SERVER_DEFAULT_PORT

    async def run():
        from clawbot.services.openwork_manager import check_openwork_available

        if not await check_openwork_available(actual_port):
            console.print(f"[yellow]OpenWork service not running at port {actual_port}[/yellow]")
            return

        console.print(f"[cyan]Stopping OpenWork service at port {port}...[/cyan]")

        try:
            import aiohttp
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"http://localhost:{port}/shutdown",
                    timeout=aiohttp.ClientTimeout(total=10),
                ) as resp:
                    if resp.status == 200:
                        console.print("[green]✓[/green] OpenWork service stopped")
                    else:
                        console.print(f"[red]✗ Failed to stop: HTTP {resp.status}[/red]")
        except Exception as e:
            console.print(f"[red]✗ Error: {e}[/red]")

    asyncio.run(run())


@openwork_app.command("status")
def openwork_status(
    port: int = typer.Option(7777, "--port", "-p", help="Service port"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show detailed status"),
):
    """Check OpenWork service status."""
    async def run():
        import aiohttp

        from clawbot.services.openwork_manager import check_openwork_available

        available = await check_openwork_available(port)

        console.print("\n[bold]OpenWork Service Status[/bold]\n")

        table = Table()
        table.add_column("Property", style="cyan")
        table.add_column("Value", style="green")

        table.add_row("URL", f"http://localhost:{port}")
        table.add_row("Status", "[green]running[/green]" if available else "[red]stopped[/red]")

        if available and verbose:
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(
                        f"http://localhost:{port}/stats",
                        timeout=aiohttp.ClientTimeout(total=5),
                    ) as resp:
                        if resp.status == 200:
                            stats = await resp.json()
                            table.add_row("Uptime", f"{stats.get('uptime_seconds', 0):.0f}s")
                            table.add_row("Total Requests", str(stats.get('total_requests', 0)))
                            table.add_row("Successful", str(stats.get('successful_requests', 0)))
                            table.add_row("Failed", str(stats.get('failed_requests', 0)))
            except (aiohttp.ClientError, ValueError, KeyError):
                pass

        console.print(table)

        if not available:
            console.print("\n[dim]Start with: clawbot openwork start[/dim]")

    asyncio.run(run())


@openwork_app.command("health")
def openwork_health(
    port: int = typer.Option(7777, "--port", "-p", help="Service port"),
):
    """Check OpenWork service health."""
    async def run():
        from clawbot.services.openwork_manager import OpenWorkServiceManager

        manager = OpenWorkServiceManager(port=port)
        health = await manager.health_check()

        console.print("\n[bold]OpenWork Health Check[/bold]\n")

        table = Table()
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="green")

        table.add_row("Healthy", "[green]Yes[/green]" if health.healthy else "[red]No[/red]")
        table.add_row("Status", health.status.value)
        table.add_row("Latency", f"{health.latency_ms:.1f}ms")

        if health.error_message:
            table.add_row("Error", f"[red]{health.error_message}[/red]")

        console.print(table)

    asyncio.run(run())


@openwork_app.command("execute")
def openwork_execute(
    task: str = typer.Argument(..., help="Task to execute"),
    port: int = typer.Option(7777, "--port", "-p", help="Service port"),
    task_type: str | None = typer.Option(None, "--type", "-t", help="Task type (programming, configuration, search, debugging, installation)"),
    timeout: int = typer.Option(300, "--timeout", help="Execution timeout in seconds"),
):
    """Execute a task through OpenWork."""
    from clawbot.config.loader import load_config

    config = load_config()

    async def run():
        from clawbot.services.openwork_manager import OpenWorkServiceManager

        manager = OpenWorkServiceManager(port=port)

        if not await manager.ensure_running():
            console.print(f"[red]✗ OpenWork service not available at port {port}[/red]")
            console.print("[dim]Start with: clawbot openwork start[/dim]")
            raise typer.Exit(1)

        console.print(f"[cyan]Executing task:[/cyan] {task[:80]}{'...' if len(task) > 80 else ''}\n")

        with console.status("[dim]Processing...[/dim]"):
            result = await manager.execute(
                task=task,
                task_type=task_type,
                workspace=config.workspace_path,
                timeout=timeout,
            )

        if result.get("success"):
            console.print("[green]✓ Task completed[/green]\n")
            output = result.get("output", "")
            if output:
                console.print(Markdown(output) if len(output) > 100 else output)
        else:
            console.print("[red]✗ Task failed[/red]")
            console.print(f"[dim]{result.get('error', 'Unknown error')}[/dim]")
            raise typer.Exit(1)

    try:
        asyncio.run(run())
    except KeyboardInterrupt:
        console.print("\n[yellow]Task interrupted[/yellow]")


@openwork_app.command("router")
def openwork_router(
    message: str = typer.Argument(..., help="Message to analyze"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show detailed analysis"),
):
    """Analyze how a message would be routed."""
    from clawbot.config.loader import load_config
    from clawbot.core.task_router import UnifiedTaskRouter

    config = load_config()

    router = UnifiedTaskRouter(
        openwork_enabled=config.tools.openwork.enabled,
        execution_threshold=config.tools.openwork.router.execution_threshold if config.tools.openwork.enabled else 0.4,
        conversation_threshold=config.tools.openwork.router.conversation_threshold if config.tools.openwork.enabled else 0.5,
    )

    decision = router.route(message)

    console.print("\n[bold]Task Router Analysis[/bold]\n")

    table = Table()
    table.add_column("Property", style="cyan")
    table.add_column("Value", style="green")

    table.add_row("Message", message[:60] + "..." if len(message) > 60 else message)
    table.add_row("Category", decision.category.value)
    table.add_row("Handler", decision.handler)
    table.add_row("Confidence", f"{decision.confidence:.2f}")

    if decision.task_type:
        table.add_row("Task Type", decision.task_type)

    table.add_row("Reasoning", decision.reasoning)

    console.print(table)

    if verbose:
        stats = router.get_stats()
        console.print(f"\n[dim]Router Stats: {stats['total_routed']} total routed[/dim]")
        for cat, count in stats['by_category'].items():
            if count > 0:
                console.print(f"[dim]  {cat}: {count}[/dim]")


@openwork_app.command("server")
def openwork_server(
    port: int = typer.Option(7777, "--port", "-p", help="API server port"),
    host: str = typer.Option("127.0.0.1", "--host", help="API server host"),
    workspace: str | None = typer.Option(None, "--workspace", "-w", help="Workspace directory"),
    token: str | None = typer.Option(None, "--token", help="API authentication token"),
    approval_mode: str = typer.Option("auto", "--approval", "-a", help="Approval mode (auto, manual)"),
    read_only: bool = typer.Option(False, "--read-only", help="Run in read-only mode"),
    opencode_url: str | None = typer.Option(None, "--opencode-url", help="OpenCode server URL for proxy"),
):
    """Start OpenWork API Server.

    This starts the OpenWork HTTP API server that provides:
    - Task submission and monitoring (/tasks)
    - Remote workspace management (/remote/workspaces)
    - OpenCode proxy (/opencode/*)
    - Skills, plugins, MCP management
    - Session management with SSE events
    """
    from pathlib import Path

    from clawbot.config.loader import load_config

    config = load_config()
    workspace_path = Path(workspace) if workspace else config.workspace_path

    async def run():
        from clawbot.openwork_server.config import ServerConfig
        from clawbot.openwork_server.server import HTTPServer, run_server
        from clawbot.openwork_server.types import ApprovalConfig, ApprovalMode, WorkspaceInfo, WorkspaceType

        # 创建服务器配置
        server_config = ServerConfig(
            host=host,
            port=port,
            token=token or f"clawbot-{int(time.time())}",
            host_token=f"host-{int(time.time())}",
            approval=ApprovalConfig(
                mode=ApprovalMode(approval_mode),
                timeout_ms=30000,
            ),
            workspaces=[
                WorkspaceInfo(
                    id="default",
                    name="default",
                    path=str(workspace_path),
                    workspace_type=WorkspaceType.LOCAL,
                )
            ],
            authorized_roots=[str(workspace_path)],
            read_only=read_only,
            opencode_base_url=opencode_url,
        )

        console.print(f"\n{__logo__} [bold]OpenWork API Server[/bold]\n")
        console.print(f"[cyan]Host:[/cyan] {host}")
        console.print(f"[cyan]Port:[/cyan] {port}")
        console.print(f"[cyan]Workspace:[/cyan] {workspace_path}")
        console.print(f"[cyan]Approval Mode:[/cyan] {approval_mode}")
        console.print(f"[cyan]Read Only:[/cyan] {read_only}")
        console.print(f"[cyan]Host Token:[/cyan] {server_config.host_token}")
        if opencode_url:
            console.print(f"[cyan]OpenCode URL:[/cyan] {opencode_url}")

        console.print(f"\n[green]API Endpoints:[/green]")
        console.print(f"  Health:     http://localhost:{port}/health")
        console.print(f"  Tasks:      http://localhost:{port}/tasks")
        console.print(f"  Workspaces: http://localhost:{port}/remote/workspaces")
        console.print(f"  OpenCode:   http://localhost:{port}/opencode/execute")

        console.print(f"\n[dim]Press Ctrl+C to stop[/dim]\n")

        server = HTTPServer(server_config)

        try:
            await run_server(server)
        except KeyboardInterrupt:
            console.print("\n[yellow]Shutting down...[/yellow]")
        except Exception as e:
            console.print(f"\n[red]Server error: {e}[/red]")
            raise typer.Exit(1)

    try:
        asyncio.run(run())
    except KeyboardInterrupt:
        console.print("[green]✓[/green] Server stopped")
