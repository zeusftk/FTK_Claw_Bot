"""CLI module for clawbot."""
