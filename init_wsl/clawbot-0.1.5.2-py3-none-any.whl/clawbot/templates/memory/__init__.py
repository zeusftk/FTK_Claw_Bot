"""
Memory templates module - 记忆模板文件目录

包含记忆系统相关的模板文件：
- MEMORY.md: 长期记忆模板
"""

from pathlib import Path

MEMORY_TEMPLATES_DIR = Path(__file__).parent


def get_memory_template(filename: str) -> Path:
    """获取记忆模板文件路径"""
    return MEMORY_TEMPLATES_DIR / filename
