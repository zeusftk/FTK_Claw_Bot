"""
Templates module - 模板文件目录

包含 clawbot 工作区初始化所需的模板文件：
- AGENTS.md: Agent 指令模板
- SOUL.md: 人格设定模板
- USER.md: 用户档案模板
- TOOLS.md: 工具说明模板
- HEARTBEAT.md: 心跳任务模板
"""

from pathlib import Path

TEMPLATES_DIR = Path(__file__).parent


def get_template_path(filename: str) -> Path:
    """获取模板文件路径"""
    return TEMPLATES_DIR / filename


def get_memory_template_path(filename: str) -> Path:
    """获取 memory 子目录模板文件路径"""
    return TEMPLATES_DIR / "memory" / filename
