---
name: skill-creator
description: 创建或更新 AgentSkills。用于设计、构建或打包包含脚本、参考文档和资源的技能。
---

# Skill Creator 技能创建器

本技能提供创建高效技能的指导。

## 关于技能

技能是模块化、自包含的包，通过提供专业知识、工作流程和工具来扩展 Agent 的能力。可以将它们视为特定领域或任务的"入职指南"——它们将通用 Agent 转变为具备程序性知识的专业 Agent。

### 技能提供的内容

1. 专业工作流程 - 特定领域的多步骤流程
2. 工具集成 - 处理特定文件格式或 API 的说明
3. 领域专业知识 - 公司特定知识、数据模式、业务逻辑
4. 打包资源 - 用于复杂和重复任务的脚本、参考文档和资源

## 核心原则

### 简洁至上

上下文窗口是公共资源。技能与系统提示、对话历史、其他技能元数据和用户请求共享上下文窗口。

**默认假设：Agent 已经很聪明。** 只添加 Agent 不知道的内容。对每条信息提出质疑："Agent 真的需要这个解释吗？"和"这段内容值得占用 token 吗？"

优先使用简洁示例而非冗长解释。

### 设置适当的自由度

根据任务的脆弱性和可变性匹配具体程度：

**高自由度（文本指令）**：多种方法有效、决策依赖上下文、或启发式方法指导时使用。

**中自由度（伪代码或带参数脚本）**：存在首选模式、允许一定变化、或配置影响行为时使用。

**低自由度（特定脚本、少量参数）**：操作脆弱易出错、一致性关键、或必须遵循特定顺序时使用。

将 Agent 想象为探索路径：悬崖边的窄桥需要具体护栏（低自由度），而开阔田野允许多条路线（高自由度）。

### 技能结构

每个技能由必需的 SKILL.md 文件和可选的打包资源组成：

```
skill-name/
├── SKILL.md (必需)
│   ├── YAML frontmatter 元数据 (必需)
│   │   ├── name: (必需)
│   │   └── description: (必需)
│   └── Markdown 指令 (必需)
└── 打包资源 (可选)
    ├── scripts/          - 可执行代码 (Python/Bash等)
    ├── references/       - 按需加载到上下文的文档
    └── assets/           - 输出中使用的文件 (模板、图标、字体等)
```

#### SKILL.md (必需)

每个 SKILL.md 包含：

- **Frontmatter** (YAML)：包含 `name` 和 `description` 字段。这是 Agent 判断何时使用技能的唯一依据，因此清晰全面地描述技能内容和触发条件非常重要。
- **Body** (Markdown)：使用技能的指令和指导。仅在技能触发后加载。

#### 打包资源 (可选)

##### Scripts (`scripts/`)

用于需要确定性可靠性或重复编写的任务的可执行代码。

- **何时包含**：相同代码被重复编写或需要确定性可靠性时
- **示例**：`scripts/rotate_pdf.py` 用于 PDF 旋转任务
- **优点**：节省 token、确定性高、可不加载到上下文直接执行
- **注意**：脚本可能仍需被 Agent 读取以进行修补或环境适配

##### References (`references/`)

按需加载到上下文以指导 Agent 过程和思考的文档和参考资料。

- **何时包含**：Agent 工作时需要参考的文档
- **示例**：`references/finance.md` 财务模式、`references/mnda.md` 公司 NDA 模板、`references/policies.md` 公司政策、`references/api_docs.md` API 规范
- **用途**：数据库模式、API 文档、领域知识、公司政策、详细工作流程指南
- **优点**：保持 SKILL.md 精简，仅在 Agent 判断需要时加载
- **最佳实践**：如果文件较大（>10k 词），在 SKILL.md 中包含 grep 搜索模式
- **避免重复**：信息应只存在于 SKILL.md 或 references 文件中，不要两者都有。详细参考材料、模式和示例优先放入 references 文件

##### Assets (`assets/`)

不加载到上下文，而是在 Agent 输出中使用的文件。

- **何时包含**：技能需要在最终输出中使用的文件
- **示例**：`assets/logo.png` 品牌资源、`assets/slides.pptx` PPT 模板、`assets/frontend-template/` HTML/React 样板、`assets/font.ttf` 字体
- **用途**：模板、图片、图标、样板代码、字体、被复制或修改的示例文档
- **优点**：分离输出资源与文档，Agent 可使用文件而不加载到上下文

#### 不应包含的内容

技能只应包含直接支持其功能的必要文件。不要创建额外的文档或辅助文件，包括：

- README.md
- INSTALLATION_GUIDE.md
- QUICK_REFERENCE.md
- CHANGELOG.md
- 等等

技能只应包含 AI Agent 完成任务所需的信息。不应包含创建过程、设置测试程序、面向用户的文档等辅助内容。

### 渐进式披露设计原则

技能使用三级加载系统高效管理上下文：

1. **元数据 (name + description)** - 始终在上下文中（约100词）
2. **SKILL.md body** - 技能触发时加载（<5k词）
3. **打包资源** - Agent 按需使用（无限制，因为脚本可不加载到上下文直接执行）

#### 渐进式披露模式

保持 SKILL.md body 精简，控制在 500 行以内以减少上下文膨胀。接近此限制时拆分内容。拆分时，务必在 SKILL.md 中引用并清晰说明何时读取它们。

**关键原则**：当技能支持多种变体、框架或选项时，只在 SKILL.md 中保留核心工作流程和选择指导。将变体特定详情（模式、示例、配置）放入单独的参考文件。

**模式 1：带参考的高级指南**

```markdown
# PDF Processing

## Quick start

Extract text with pdfplumber:
[code example]

## Advanced features

- **Form filling**: See [FORMS.md](FORMS.md) for complete guide
- **API reference**: See [REFERENCE.md](REFERENCE.md) for all methods
- **Examples**: See [EXAMPLES.md](EXAMPLES.md) for common patterns
```

Agent 仅在需要时加载 FORMS.md、REFERENCE.md 或 EXAMPLES.md。

**模式 2：按领域组织**

对于多领域技能，按领域组织内容以避免加载无关上下文：

```
bigquery-skill/
├── SKILL.md (overview and navigation)
└── reference/
    ├── finance.md (revenue, billing metrics)
    ├── sales.md (opportunities, pipeline)
    ├── product.md (API usage, features)
    └── marketing.md (campaigns, attribution)
```

用户询问销售指标时，Agent 只读取 sales.md。

**模式 3：条件详情**

显示基本内容，链接到高级内容：

```markdown
# DOCX Processing

## Creating documents

Use docx-js for new documents. See [DOCX-JS.md](DOCX-JS.md).

## Editing documents

For simple edits, modify the XML directly.

**For tracked changes**: See [REDLINING.md](REDLINING.md)
**For OOXML details**: See [OOXML.md](OOXML.md)
```

Agent 仅在用户需要这些功能时读取 REDLINING.md 或 OOXML.md。

**重要指南**：

- **避免深层嵌套引用** - 引用文件应直接从 SKILL.md 链接，保持一级深度
- **结构化较长参考文件** - 超过 100 行的文件，在顶部包含目录以便 Agent 预览时看到完整范围

## 技能创建流程

技能创建包含以下步骤：

1. 通过具体示例理解技能
2. 规划可复用技能内容（脚本、参考文档、资源）
3. 初始化技能（运行 init_skill.py）
4. 编辑技能（实现资源并编写 SKILL.md）
5. 打包技能（运行 package_skill.py）
6. 基于实际使用迭代

按顺序执行这些步骤，仅在明确不适用时跳过。

### 技能命名

- 只使用小写字母、数字和连字符；将用户提供的标题标准化为连字符格式（如 "Plan Mode" -> `plan-mode`）
- 生成名称时，控制在 64 字符以内（字母、数字、连字符）
- 优先使用描述动作的简短动词短语
- 为提高清晰度或触发准确性，可按工具命名空间（如 `gh-address-comments`、`linear-address-issue`）
- 技能文件夹名称与技能名称完全一致

### 步骤 1：通过具体示例理解技能

仅在技能使用模式已清晰理解时跳过此步骤。即使处理现有技能，此步骤仍有价值。

创建有效技能需要清晰理解具体使用示例。可通过用户直接提供的示例或经用户反馈验证的生成示例获得理解。

例如，构建 image-editor 技能时，相关问题包括：

- "image-editor 技能应支持什么功能？编辑、旋转，还有其他吗？"
- "能举例说明这个技能会如何使用吗？"
- "我可以想象用户会问'去除这张图片的红眼'或'旋转这张图片'。还有其他使用场景吗？"
- "用户说什么应该触发这个技能？"

为避免让用户不知所措，单条消息中不要问太多问题。从最重要的问题开始，根据需要跟进以提高效果。

当清晰了解技能应支持的功能时，结束此步骤。

### 步骤 2：规划可复用技能内容

要将具体示例转化为有效技能，分析每个示例：

1. 考虑如何从头执行该示例
2. 识别重复执行这些工作流程时有用的脚本、参考文档和资源

示例：构建 `pdf-editor` 技能处理"帮我旋转这个 PDF"等请求时，分析显示：

1. 旋转 PDF 每次都需要重写相同代码
2. 在技能中存储 `scripts/rotate_pdf.py` 脚本会有帮助

示例：设计 `frontend-webapp-builder` 技能处理"给我建个待办应用"或"建个仪表板追踪我的步数"等请求时，分析显示：

1. 编写前端 webapp 每次都需要相同的 HTML/React 样板
2. 在技能中存储包含样板 HTML/React 项目文件的 `assets/hello-world/` 模板会有帮助

示例：构建 `big-query` 技能处理"今天有多少用户登录？"等请求时，分析显示：

1. 查询 BigQuery 每次都需要重新发现表模式和关系
2. 在技能中存储记录表模式的 `references/schema.md` 文件会有帮助

分析每个具体示例，创建要包含的可复用资源列表：脚本、参考文档和资源。

### 步骤 3：初始化技能

此时，开始实际创建技能。

仅在开发的技能已存在且需要迭代或打包时跳过此步骤。这种情况下，继续下一步。

从头创建新技能时，始终运行 `init_skill.py` 脚本。该脚本便捷地生成新的模板技能目录，自动包含技能所需的所有内容，使技能创建过程更高效可靠。

用法：

```bash
scripts/init_skill.py <skill-name> --path <output-directory> [--resources scripts,references,assets] [--examples]
```

示例：

```bash
scripts/init_skill.py my-skill --path skills/public
scripts/init_skill.py my-skill --path skills/public --resources scripts,references
scripts/init_skill.py my-skill --path skills/public --resources scripts --examples
```

脚本功能：

- 在指定路径创建技能目录
- 生成带有正确 frontmatter 和 TODO 占位符的 SKILL.md 模板
- 根据 `--resources` 可选创建资源目录
- 设置 `--examples` 时可选添加示例文件

初始化后，根据需要自定义 SKILL.md 并添加资源。如果使用了 `--examples`，替换或删除占位文件。

### 步骤 4：编辑技能

编辑（新生成或现有）技能时，记住技能是为另一个 Agent 实例创建的。包含对该 Agent 有益且非显而易见的信息。考虑哪些程序性知识、领域特定详情或可复用资源能帮助另一个 Agent 实例更有效地执行这些任务。

#### 学习已验证的设计模式

根据技能需求查阅这些有用的指南：

- **多步骤流程**：参见 references/workflows.md 了解顺序工作流程和条件逻辑
- **特定输出格式或质量标准**：参见 references/output-patterns.md 了解模板和示例模式

这些文件包含有效技能设计的最佳实践。

#### 从可复用技能内容开始

开始实现时，从上面识别的可复用资源开始：`scripts/`、`references/` 和 `assets/` 文件。注意此步骤可能需要用户输入。例如，实现 `brand-guidelines` 技能时，用户可能需要提供存储在 `assets/` 的品牌资源或模板，或存储在 `references/` 的文档。

添加的脚本必须实际运行测试以确保没有 bug 且输出符合预期。如果有许多类似脚本，只需测试代表性样本以确保它们都能工作，同时平衡完成时间。

如果使用了 `--examples`，删除技能不需要的占位文件。只创建实际需要的资源目录。

#### 更新 SKILL.md

**写作指南**：始终使用祈使/不定式形式。

##### Frontmatter

编写包含 `name` 和 `description` 的 YAML frontmatter：

- `name`：技能名称
- `description`：这是技能的主要触发机制，帮助 Agent 理解何时使用技能
  - 包含技能功能和具体触发条件/上下文
  - 所有"何时使用"信息放在这里，不要放在 body 中。body 仅在触发后加载，所以 body 中的"何时使用此技能"部分对 Agent 没有帮助
  - `docx` 技能的 description 示例："Comprehensive document creation, editing, and analysis with support for tracked changes, comments, formatting preservation, and text extraction. Use when the agent needs to work with professional documents (.docx files) for: (1) Creating new documents, (2) Modifying or editing content, (3) Working with tracked changes, (4) Adding comments, or any other document tasks"

不要在 YAML frontmatter 中包含其他字段。

##### Body

编写使用技能及其打包资源的指令。

### 步骤 5：打包技能

技能开发完成后，必须打包为可分发的 .skill 文件与用户共享。打包过程会先自动验证技能以确保满足所有要求：

```bash
scripts/package_skill.py <path/to/skill-folder>
```

可选指定输出目录：

```bash
scripts/package_skill.py <path/to/skill-folder> ./dist
```

打包脚本将：

1. **自动验证**技能，检查：

   - YAML frontmatter 格式和必需字段
   - 技能命名约定和目录结构
   - description 完整性和质量
   - 文件组织和资源引用

2. **打包**技能（如果验证通过），创建以技能命名的 .skill 文件（如 `my-skill.skill`），包含所有文件并保持正确的目录结构以便分发。.skill 文件是扩展名为 .skill 的 zip 文件。

如果验证失败，脚本将报告错误并退出而不创建包。修复任何验证错误后再次运行打包命令。

### 步骤 6：迭代

测试技能后，用户可能请求改进。这通常发生在使用技能后不久，此时对技能表现有新鲜上下文。

**迭代工作流程**：

1. 在实际任务中使用技能
2. 注意困难或低效之处
3. 识别应如何更新 SKILL.md 或打包资源
4. 实现更改并再次测试
