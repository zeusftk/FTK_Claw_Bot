---
name: memory
description: 基于 grep 检索的双层记忆系统。
always: true
---

# Memory 记忆系统

## 结构

- `memory/MEMORY.md` → 长期记忆（偏好、项目上下文、关系）。始终加载到上下文中。
- `memory/HISTORY.md` → 追加式事件日志。不加载到上下文。使用 grep 搜索。

## 搜索历史事件

```bash
grep -i "keyword" memory/HISTORY.md
```

使用 `exec` 工具运行 grep。组合模式：`grep -iE "meeting|deadline" memory/HISTORY.md`

## 更新 MEMORY.md 的时机

使用 `edit_file` 或 `write_file` 立即写入重要信息：
- 用户偏好（"我喜欢深色模式"）
- 项目上下文（"API 使用 OAuth2"）
- 人物关系（"Alice 是项目负责人"）

## 自动整合

会话变大时，旧对话会自动摘要并追加到 HISTORY.md。长期信息会被提取到 MEMORY.md。无需手动管理。
