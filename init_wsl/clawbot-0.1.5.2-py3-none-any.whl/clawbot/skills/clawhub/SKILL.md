---
name: clawhub
description: 从 ClawHub 公共技能仓库搜索和安装 Agent 技能。
homepage: https://clawhub.ai
metadata: {"clawbot":{"emoji":"🦞"}}
---

# ClawHub

AI Agent 的公共技能仓库，支持自然语言向量搜索。

## 使用场景

当用户提出以下请求时使用：
- "找一个...技能"
- "搜索技能"
- "安装技能"
- "有哪些可用技能？"
- "更新我的技能"

## 搜索

```bash
npx --yes clawhub@latest search "web scraping" --limit 5
```

## 安装

```bash
npx --yes clawhub@latest install <slug> --workdir ~/.clawbot/workspace
```

将 `<slug>` 替换为搜索结果中的技能名称。技能会被安装到 `~/.clawbot/workspace/skills/` 目录，这是 clawbot 加载工作区技能的位置。必须包含 `--workdir` 参数。

## 更新

```bash
npx --yes clawhub@latest update --all --workdir ~/.clawbot/workspace
```

## 查看已安装

```bash
npx --yes clawhub@latest list --workdir ~/.clawbot/workspace
```

## 注意事项

- 需要 Node.js（自带 `npx`）
- 搜索和安装无需 API 密钥
- 登录（`npx --yes clawhub@latest login`）仅发布技能时需要
- `--workdir ~/.clawbot/workspace` 是关键参数，否则技能会安装到当前目录而非 clawbot 工作区
- 安装后提醒用户启动新会话以加载技能
