---
name: iflow-websearch
description: "Use iFlow CLI for web search and task execution. Supports searching content or executing tasks, with results automatically saved to workspace directory."
metadata:
  clawbot:
    emoji: "🔍"
    provides: ["web-search","do-task"]
    requires:
      bins: ["iflow"]
    workspace_aware: true
---

# iFlow WebSearch Skill

Use iFlow CLI for web search and task execution, with automatic result saving to workspace directory.

## Basic Usage

```bash
iflow -m glm-5 "{search content or task}" -y -o {save_path}
```

### Parameters

| Parameter | Description |
|-----------|-------------|
| `-m glm-5` | Use glm-5 model |
| `{search content or task}` | Content to search or task description |
| `-y` | Auto-confirm execution |
| `-o {save_path}` | Output save path (must be under workspace) |

## Examples

### 1. Web Search

```bash
# Search latest tech news
iflow -m glm-5 "Search most popular Python frameworks in 2024" -y -o ~/workspace/search_results/python_frameworks.md

# Search code examples
iflow -m glm-5 "Search FastAPI best practices examples" -y -o ~/workspace/search_results/fastapi_best_practices.md

# Search documentation
iflow -m glm-5 "Search Pydantic v2 migration guide" -y -o ~/workspace/search_results/pydantic_v2_migration.md
```

### 2. Technical Research

```bash
# Technology comparison
iflow -m glm-5 "Compare performance differences between React and Vue" -y -o ~/workspace/research/react_vue_comparison.md

# Architecture research
iflow -m glm-5 "Research microservices architecture best practices" -y -o ~/workspace/research/microservices_best_practices.md
```

### 3. Problem Solving

```bash
# Debug issues
iflow -m glm-5 "Search common Python asyncio deadlock issues and solutions" -y -o ~/workspace/debug/asyncio_deadlock_solutions.md

# Error troubleshooting
iflow -m glm-5 "Search common causes and solutions for 'Connection refused' error" -y -o ~/workspace/debug/connection_refused_fix.md
```

## Path Rules

**Important: Save path must be under workspace directory!**

```
# Correct ✓
~/workspace/search_results/...
~/workspace/research/...
~/workspace/debug/...
~/.clawbot/workspace/...

# Incorrect ✗
/tmp/...
/home/user/downloads/...
```

## Workflow

1. **Construct command**: Build iflow command based on user needs
2. **Validate path**: Ensure save path is under workspace directory
3. **Create directory**: Auto-create target directory if not exists
4. **Execute search**: Run iflow command
5. **Return result**: Return saved file path

## Best Practices

### Output File Naming

- Use meaningful filenames: `{topic}_{date}.md`
- Use underscores instead of spaces
- Add date suffix for easy management

```bash
iflow -m glm-5 "Search Docker security best practices" -y -o ~/workspace/search_results/docker_security_20240315.md
```

### Content Categorization

```
~/workspace/
├── search_results/     # Search results
├── research/           # Technical research
├── debug/              # Problem troubleshooting
├── tutorials/          # Tutorial collection
└── references/         # Reference materials
```

## Error Handling

If iflow command fails:

1. Check if iflow is properly installed
2. Check network connection
3. Verify save path is under workspace
4. Confirm directory permissions

```bash
# Check iflow installation
which iflow || echo "iflow not installed"

# Check workspace directory
ls -la ~/workspace/
```

## Integration Example

Using this skill in clawbot:

```python
import os
from pathlib import Path

def iflow_search(query: str, output_name: str) -> str:
    """Execute search using iFlow and save results"""
    workspace = Path.home() / ".clawbot" / "workspace"
    output_path = workspace / "search_results" / f"{output_name}.md"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    cmd = f'iflow -m glm-5 "{query}" -y -o "{output_path}"'
    os.system(cmd)
    
    return str(output_path)
```
