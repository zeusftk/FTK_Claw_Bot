---
name: iflow-websearch
description: "使用 iFlow CLI 进行网络搜索和任务执行。支持搜索内容或执行任务，结果自动保存到 workspace 目录。"
metadata:
  clawbot:
    emoji: "🔍"
    provides: ["web-search","do-task"]
    requires:
      bins: ["iflow"]
    workspace_aware: true
---

# iFlow WebSearch Skill

使用 iFlow CLI 进行网络搜索和任务执行，支持自动保存结果到 workspace 目录。

## 基本用法

```bash
iflow -m glm-5 "{搜索内容或任务}" -y -o {保存路径}
```

### 参数说明

| 参数 | 说明 |
|------|------|
| `-m glm-5` | 使用 glm-5 模型 |
| `{搜索内容或任务}` | 要搜索的内容或执行的任务描述 |
| `-y` | 自动确认执行 |
| `-o {保存路径}` | 输出保存路径（必须在 workspace 下） |

## 使用示例

### 1. 网络搜索

```bash
# 搜索最新技术资讯
iflow -m glm-5 "搜索 2024 年最受欢迎的 Python 框架" -y -o ~/workspace/search_results/python_frameworks.md

# 搜索代码示例
iflow -m glm-5 "搜索 FastAPI 最佳实践示例" -y -o ~/workspace/search_results/fastapi_best_practices.md

# 搜索文档
iflow -m glm-5 "搜索 Pydantic v2 迁移指南" -y -o ~/workspace/search_results/pydantic_v2_migration.md
```

### 2. 技术调研

```bash
# 技术对比
iflow -m glm-5 "对比 React 和 Vue 的性能差异" -y -o ~/workspace/research/react_vue_comparison.md

# 架构调研
iflow -m glm-5 "调研微服务架构最佳实践" -y -o ~/workspace/research/microservices_best_practices.md
```

### 3. 问题解决

```bash
# 调试问题
iflow -m glm-5 "搜索 Python asyncio 常见死锁问题及解决方案" -y -o ~/workspace/debug/asyncio_deadlock_solutions.md

# 错误排查
iflow -m glm-5 "搜索 'Connection refused' 错误的常见原因和解决方法" -y -o ~/workspace/debug/connection_refused_fix.md
```

## 路径规则

**重要：保存路径必须在 workspace 目录下！**

```
# 正确 ✓
~/workspace/search_results/...
~/workspace/research/...
~/workspace/debug/...
~/.clawbot/workspace/...

# 错误 ✗
/tmp/...
/home/user/downloads/...
```

## 工作流程

1. **构造命令**：根据用户需求构造 iflow 命令
2. **验证路径**：确保保存路径在 workspace 目录下
3. **创建目录**：如果目标目录不存在则自动创建
4. **执行搜索**：运行 iflow 命令
5. **返回结果**：返回保存的文件路径

## 最佳实践

### 输出文件命名

- 使用有意义的文件名：`{主题}_{日期}.md`
- 使用下划线代替空格
- 添加日期后缀便于管理

```bash
iflow -m glm-5 "搜索 Docker 安全最佳实践" -y -o ~/workspace/search_results/docker_security_20240315.md
```

### 内容分类保存

```
~/workspace/
├── search_results/     # 搜索结果
├── research/           # 技术调研
├── debug/              # 问题排查
├── tutorials/          # 教程收集
└── references/         # 参考资料
```

## 错误处理

如果 iflow 命令失败：

1. 检查 iflow 是否正确安装
2. 检查网络连接
3. 验证保存路径是否在 workspace 下
4. 确认目录权限

```bash
# 检查 iflow 安装
which iflow || echo "iflow 未安装"

# 检查 workspace 目录
ls -la ~/workspace/
```

## 集成示例

在 clawbot 中使用此 skill：

```python
import os
from pathlib import Path

def iflow_search(query: str, output_name: str) -> str:
    """使用 iFlow 执行搜索并保存结果"""
    workspace = Path.home() / ".clawbot" / "workspace"
    output_path = workspace / "search_results" / f"{output_name}.md"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    cmd = f'iflow -m glm-5 "{query}" -y -o "{output_path}"'
    os.system(cmd)
    
    return str(output_path)
```
