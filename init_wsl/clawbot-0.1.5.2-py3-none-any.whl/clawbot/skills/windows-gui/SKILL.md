---
name: windows-gui
description: |
  通过桥接连接从 WSL 控制 Windows GUI 应用程序和网页浏览器。用于：
  (1) 自动化 Windows 桌面应用（点击、输入、滚动）
  (2) 在 Windows 上截图分析
  (3) 查找或管理 Windows 窗口
  (4) 获取或设置 Windows 剪贴板内容
  (5) 启动 Windows 应用程序或 URL
  (6) 网页浏览器自动化（导航、点击、填充、提取数据）
  (7) 网页抓取和表单填充
  需要在 Windows 上运行 FTK_bot_A 桥接服务。
---

# Windows GUI 技能

通过桥接连接从 WSL 环境自动化 Windows 桌面应用程序和网页浏览器。

## 前提条件

Windows 桥接服务（FTK_bot_A）必须在 Windows 上运行。检查连接：

```json
{"action": "get_status"}
```

如果未连接，工具会自动连接。如果连接失败，请确保 FTK_bot_A 正在运行。

---

## 第一部分：桌面 GUI 自动化

使用 pyautogui 控制鼠标、键盘和截屏。

### 鼠标操作

| 操作 | 参数 | 说明 |
|--------|--------|-------------|
| mouse_click | x, y, button, clicks | 点击位置。button: left/right/middle，clicks: 1/2 |
| mouse_move | x, y, duration | 移动鼠标到指定位置 |
| mouse_drag | start_x, start_y, end_x, end_y, duration, button | 从起点拖动到终点 |
| mouse_scroll | clicks, x, y | 滚动滚轮。正数=向上，负数=向下 |

**示例：**

```json
{"action": "mouse_click", "params": {"x": 100, "y": 200}}
{"action": "mouse_click", "params": {"x": 100, "y": 200, "button": "right"}}
{"action": "mouse_click", "params": {"x": 100, "y": 200, "clicks": 2}}
{"action": "mouse_move", "params": {"x": 500, "y": 300, "duration": 0.5}}
{"action": "mouse_drag", "params": {"start_x": 100, "start_y": 100, "end_x": 300, "end_y": 300, "duration": 0.5}}
{"action": "mouse_scroll", "params": {"clicks": 3}}
```

### 键盘操作

| 操作 | 参数 | 说明 |
|--------|--------|-------------|
| keyboard_type | text, interval | 输入文本。非 ASCII 使用剪贴板 |
| keyboard_press | key | 按下单个键 |
| keyboard_hotkey | keys | 按下组合键 |

**示例：**

```json
{"action": "keyboard_type", "params": {"text": "Hello World"}}
{"action": "keyboard_type", "params": {"text": "Hello", "interval": 0.1}}
{"action": "keyboard_press", "params": {"key": "enter"}}
{"action": "keyboard_hotkey", "params": {"keys": ["ctrl", "c"]}}
{"action": "keyboard_hotkey", "params": {"keys": ["ctrl", "shift", "s"]}}
```

### 屏幕操作

| 操作 | 参数 | 说明 |
|--------|--------|-------------|
| screenshot | region | 截取屏幕。region: [x, y, width, height] |
| get_screen_size | - | 获取屏幕尺寸 |
| get_mouse_position | - | 获取当前鼠标位置 |

**示例：**

```json
{"action": "screenshot"}
{"action": "screenshot", "params": {"region": [0, 0, 800, 600]}}
{"action": "get_screen_size"}
{"action": "get_mouse_position"}
```

### 窗口操作

| 操作 | 参数 | 说明 |
|--------|--------|-------------|
| find_window | title | 按标题查找窗口（部分匹配） |
| launch_app | app_path, args | 启动应用程序或打开 URL |

**示例：**

```json
{"action": "find_window", "params": {"title": "Notepad"}}
{"action": "launch_app", "params": {"app_path": "notepad.exe"}}
{"action": "launch_app", "params": {"app_path": "https://example.com"}}
{"action": "launch_app", "params": {"app_path": "C:\\Program Files\\app.exe", "args": ["--flag"]}}
```

### 剪贴板操作

| 操作 | 参数 | 说明 |
|--------|--------|-------------|
| get_clipboard | - | 获取剪贴板文本 |
| set_clipboard | text | 设置剪贴板文本 |

**示例：**

```json
{"action": "get_clipboard"}
{"action": "set_clipboard", "params": {"text": "copied text"}}
```

### 图像识别

| 操作 | 参数 | 说明 |
|--------|--------|-------------|
| locate_on_screen | image_path, confidence | 在屏幕上查找图像 |
| wait_for_image | image_path, timeout, confidence | 等待图像出现 |

**示例：**

```json
{"action": "locate_on_screen", "params": {"image_path": "C:\\button.png", "confidence": 0.9}}
{"action": "wait_for_image", "params": {"image_path": "C:\\dialog.png", "timeout": 10.0}}
```

---

## 第二部分：网页自动化

使用 Playwright 控制网页浏览器。

### 浏览器控制

| 操作 | 参数 | 说明 |
|--------|--------|-------------|
| web_start | headless | 启动浏览器。headless: true/false |
| web_stop | - | 停止浏览器 |
| web_navigate | url, wait_until, timeout | 导航到 URL |
| web_get_url | - | 获取当前 URL |
| web_get_title | - | 获取页面标题 |
| web_go_back | - | 后退 |
| web_go_forward | - | 前进 |
| web_refresh | - | 刷新页面 |

**示例：**

```json
{"action": "web_start", "params": {"headless": false}}
{"action": "web_navigate", "params": {"url": "https://example.com"}}
{"action": "web_get_url"}
{"action": "web_get_title"}
{"action": "web_stop"}
```

### 页面交互

| 操作 | 参数 | 说明 |
|--------|--------|-------------|
| web_click | selector, timeout | 通过 CSS 选择器点击元素 |
| web_fill | selector, value, timeout | 通过 CSS 选择器填充输入框 |
| web_scroll | direction, amount | 滚动页面 |
| web_press | key | 按键 |
| web_type | text, delay | 带延迟输入文本 |

**示例：**

```json
{"action": "web_click", "params": {"selector": "#submit-btn"}}
{"action": "web_fill", "params": {"selector": "#username", "value": "user@example.com"}}
{"action": "web_scroll", "params": {"direction": "down", "amount": 500}}
{"action": "web_press", "params": {"key": "Enter"}}
{"action": "web_type", "params": {"text": "Hello", "delay": 50}}
```

### 页面信息

| 操作 | 参数 | 说明 |
|--------|--------|-------------|
| web_screenshot | selector, full_page | 截取页面或元素 |
| web_get_content | - | 获取页面 HTML |
| web_extract_elements | config | 提取交互元素 |
| web_extract_data | selectors | 通过选择器提取数据 |
| web_evaluate | script | 执行 JavaScript |

**示例：**

```json
{"action": "web_screenshot"}
{"action": "web_screenshot", "params": {"full_page": true}}
{"action": "web_extract_elements"}
{"action": "web_extract_data", "params": {"selectors": [{"name": "title", "selector": "h1"}]}}
{"action": "web_evaluate", "params": {"script": "document.title"}}
```

### 会话管理

| 操作 | 参数 | 说明 |
|--------|--------|-------------|
| web_get_cookies | - | 获取所有 cookies |
| web_set_cookies | cookies | 设置 cookies |
| web_save_session | session_id | 保存会话到文件 |
| web_load_session | session_id | 从文件加载会话 |

**示例：**

```json
{"action": "web_get_cookies"}
{"action": "web_set_cookies", "params": {"cookies": [{"name": "session", "value": "abc", "domain": ".example.com"}]}}
{"action": "web_save_session", "params": {"session_id": "my_session"}}
{"action": "web_load_session", "params": {"session_id": "my_session"}}
```

### 登录操作

| 操作 | 参数 | 说明 |
|--------|--------|-------------|
| web_login | type, params | 通过表单/cookie/二维码登录 |

**示例：**

```json
{"action": "web_login", "params": {"type": "form", "params": {"username_selector": "#user", "password_selector": "#pass", "submit_selector": "#submit", "username": "user", "password": "pass"}}}
{"action": "web_login", "params": {"type": "cookie", "params": {"cookies": [...], "url": "https://example.com"}}}
{"action": "web_login", "params": {"type": "qr", "params": {"selector": "#qrcode"}}}
```

### 等待操作

| 操作 | 参数 | 说明 |
|--------|--------|-------------|
| web_wait_for_selector | selector, timeout | 等待元素出现 |

**示例：**

```json
{"action": "web_wait_for_selector", "params": {"selector": ".loaded", "timeout": 10000}}
```

---

## 最佳实践

### 桌面 GUI

1. **先截图**：操作前始终截取屏幕
2. **使用 find_window**：点击前获取窗口位置
3. **添加延迟**：操作后等待 UI 响应
4. **验证结果**：再次截图确认

### 网页自动化

1. **先启动浏览器**：任何网页操作前调用 web_start
2. **使用选择器**：CSS 选择器比坐标更可靠
3. **等待元素**：动态内容使用 web_wait_for_selector
4. **保存会话**：使用会话管理保持登录状态

---

## 常见工作流程

- 参见 [desktop-workflows.md](references/desktop-workflows.md) 了解桌面自动化示例
- 参见 [web-workflows.md](references/web-workflows.md) 了解网页自动化示例

---

## 故障排除

| 问题 | 解决方案 |
|-------|----------|
| 连接失败 | 确保 FTK_bot_A 在 Windows 上运行 |
| 点击偏离目标 | 通过截图验证坐标 |
| 找不到窗口 | 检查窗口标题，使用部分匹配 |
| 输入太快 | 添加 interval 参数 |
| 浏览器未启动 | 先调用 web_start |
| 找不到元素 | 检查选择器，使用 web_wait_for_selector |

---

## 按键名称参考

keyboard_press 和 keyboard_hotkey 常用按键名称：

- 字母：a, b, c, ... z
- 数字：0, 1, 2, ... 9
- 特殊键：enter, tab, escape, space, backspace, delete
- 方向键：up, down, left, right
- 修饰键：shift, ctrl, alt, win
- 功能键：f1, f2, ... f12
