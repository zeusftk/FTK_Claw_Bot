# Web Automation Workflows

## 1. Basic Browser Session

```json
// Step 1: Start browser (headless=false to see browser)
{"action": "web_start", "params": {"headless": false}}

// Step 2: Navigate to URL
{"action": "web_navigate", "params": {"url": "https://example.com"}}

// Step 3: Get page info
{"action": "web_get_title"}
{"action": "web_get_url"}

// Step 4: Take screenshot
{"action": "web_screenshot"}

// Step 5: Stop browser when done
{"action": "web_stop"}
```

## 2. Form Filling and Submission

```json
// Step 1: Start browser and navigate
{"action": "web_start", "params": {"headless": false}}
{"action": "web_navigate", "params": {"url": "https://example.com/login"}}

// Step 2: Wait for form to load
{"action": "web_wait_for_selector", "params": {"selector": "#username", "timeout": 10000}}

// Step 3: Fill form fields
{"action": "web_fill", "params": {"selector": "#username", "value": "user@example.com"}}
{"action": "web_fill", "params": {"selector": "#password", "value": "mypassword"}}

// Step 4: Submit form
{"action": "web_click", "params": {"selector": "button[type=submit]"}}

// Step 5: Wait for navigation
{"action": "web_wait_for_selector", "params": {"selector": ".dashboard", "timeout": 15000}}
```

## 3. Login with Session Persistence

```json
// First time: Login and save session
{"action": "web_start", "params": {"headless": false}}
{"action": "web_navigate", "params": {"url": "https://example.com/login"}}
{"action": "web_login", "params": {"type": "form", "params": {"username_selector": "#user", "password_selector": "#pass", "submit_selector": "#submit", "username": "user", "password": "pass"}}}
{"action": "web_save_session", "params": {"session_id": "my_login"}}

// Later: Load session to skip login
{"action": "web_start", "params": {"headless": false}}
{"action": "web_load_session", "params": {"session_id": "my_login"}}
{"action": "web_navigate", "params": {"url": "https://example.com/dashboard"}}
```

## 4. Extract Page Elements

```json
// Step 1: Navigate to page
{"action": "web_start"}
{"action": "web_navigate", "params": {"url": "https://example.com/products"}}

// Step 2: Extract interactive elements
{"action": "web_extract_elements", "params": {"config": {"interactive_weight": 100, "min_area": 100}}}

// Result includes elements with:
// - id, tag, type, action_type
// - text, selector
// - location (x, y, width, height)
// - is_interactive, weight
```

## 5. Extract Specific Data

```json
// Step 1: Navigate to page
{"action": "web_start"}
{"action": "web_navigate", "params": {"url": "https://example.com/article"}}

// Step 2: Extract specific elements
{"action": "web_extract_data", "params": {"selectors": [
  {"name": "title", "selector": "h1"},
  {"name": "author", "selector": ".author-name"},
  {"name": "date", "selector": "time"},
  {"name": "paragraphs", "selector": "article p"}
]}}
```

## 6. Cookie-Based Login

```json
// Step 1: Start browser
{"action": "web_start", "params": {"headless": false}}

// Step 2: Login with cookies
{"action": "web_login", "params": {"type": "cookie", "params": {
  "cookies": [
    {"name": "session_id", "value": "abc123", "domain": ".example.com"}
  ],
  "url": "https://example.com/dashboard"
}}}
```

## 7. QR Code Login

```json
// Step 1: Start browser and navigate
{"action": "web_start", "params": {"headless": false}}
{"action": "web_navigate", "params": {"url": "https://web.wechat.com"}}

// Step 2: Get QR code image
{"action": "web_login", "params": {"type": "qr", "params": {"selector": ".qrcode-img"}}}

// Result: base64 image data for user to scan
```

## 8. JavaScript Execution

```json
// Step 1: Navigate to page
{"action": "web_start"}
{"action": "web_navigate", "params": {"url": "https://example.com"}}

// Step 2: Execute JavaScript
{"action": "web_evaluate", "params": {"script": "document.querySelector('h1').innerText"}}

// Step 3: Scroll to bottom
{"action": "web_evaluate", "params": {"script": "window.scrollTo(0, document.body.scrollHeight)"}}
```

## 9. Navigation History

```json
// Step 1: Navigate to pages
{"action": "web_start"}
{"action": "web_navigate", "params": {"url": "https://example.com/page1"}}
{"action": "web_click", "params": {"selector": "a.link"}}

// Step 2: Go back
{"action": "web_go_back"}

// Step 3: Go forward
{"action": "web_go_forward"}

// Step 4: Refresh
{"action": "web_refresh"}
```

## 10. Full Page Screenshot

```json
// Step 1: Navigate to page
{"action": "web_start"}
{"action": "web_navigate", "params": {"url": "https://example.com/long-page"}}

// Step 2: Capture full page
{"action": "web_screenshot", "params": {"full_page": true}}

// Or capture specific element
{"action": "web_screenshot", "params": {"selector": ".chart-container"}}
```

## 11. Cookie Management

```json
// Step 1: Start browser and navigate
{"action": "web_start"}
{"action": "web_navigate", "params": {"url": "https://example.com"}}

// Step 2: Get all cookies
{"action": "web_get_cookies"}

// Step 3: Set new cookies
{"action": "web_set_cookies", "params": {"cookies": [
  {"name": "preference", "value": "dark_mode", "domain": ".example.com"},
  {"name": "language", "value": "en", "domain": ".example.com"}
]}}
```

## 12. Dynamic Content Handling

```json
// Step 1: Start browser and navigate
{"action": "web_start"}
{"action": "web_navigate", "params": {"url": "https://example.com/search"}}

// Step 2: Wait for search input
{"action": "web_wait_for_selector", "params": {"selector": "#search-input", "timeout": 10000}}

// Step 3: Fill search and submit
{"action": "web_fill", "params": {"selector": "#search-input", "value": "query"}}
{"action": "web_press", "params": {"key": "Enter"}}

// Step 4: Wait for results to load
{"action": "web_wait_for_selector", "params": {"selector": ".search-results", "timeout": 15000}}

// Step 5: Extract results
{"action": "web_extract_elements"}
```
