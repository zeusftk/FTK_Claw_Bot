# Desktop Automation Workflows

## 1. Launch and Interact with Application

```json
// Step 1: Launch application
{"action": "launch_app", "params": {"app_path": "notepad.exe"}}

// Step 2: Wait and find window
{"action": "find_window", "params": {"title": "Notepad"}}

// Step 3: Take screenshot to see UI
{"action": "screenshot"}

// Step 4: Click on text area (based on window rect)
{"action": "mouse_click", "params": {"x": 200, "y": 300}}

// Step 5: Type text
{"action": "keyboard_type", "params": {"text": "Hello World"}}
```

## 2. Open URL in Default Browser

```json
// Step 1: Open URL (launch_app supports URLs)
{"action": "launch_app", "params": {"app_path": "https://github.com"}}
```

## 3. Form Filling with Coordinates

```json
// Step 1: Screenshot to locate form fields
{"action": "screenshot"}

// Step 2: Click on first input field
{"action": "mouse_click", "params": {"x": 150, "y": 200}}

// Step 3: Type value
{"action": "keyboard_type", "params": {"text": "user@example.com"}}

// Step 4: Move to next field with Tab
{"action": "keyboard_press", "params": {"key": "tab"}}

// Step 5: Type next value
{"action": "keyboard_type", "params": {"text": "password123"}}
```

## 4. Copy-Paste Operation

```json
// Step 1: Select all (Ctrl+A)
{"action": "keyboard_hotkey", "params": {"keys": ["ctrl", "a"]}}

// Step 2: Copy (Ctrl+C)
{"action": "keyboard_hotkey", "params": {"keys": ["ctrl", "c"]}}

// Step 3: Get clipboard content
{"action": "get_clipboard"}

// Step 4: Modify and set back
{"action": "set_clipboard", "params": {"text": "modified content"}}

// Step 5: Paste (Ctrl+V)
{"action": "keyboard_hotkey", "params": {"keys": ["ctrl", "v"]}}
```

## 5. Window Management

```json
// Step 1: Find target window
{"action": "find_window", "params": {"title": "Chrome"}}

// Step 2: Get screen size for reference
{"action": "get_screen_size"}

// Step 3: Click on window to focus
{"action": "mouse_click", "params": {"x": 960, "y": 540}}

// Step 4: Maximize window (Win+Up)
{"action": "keyboard_hotkey", "params": {"keys": ["win", "up"]}}
```

## 6. Image-Based Clicking

```json
// Step 1: Locate button image on screen
{"action": "locate_on_screen", "params": {"image_path": "C:\\buttons\\submit.png", "confidence": 0.9}}

// Step 2: If found, get center coordinates and click
// Result returns (left, top, width, height)
// Calculate center: x = left + width/2, y = top + height/2
{"action": "mouse_click", "params": {"x": 150, "y": 300}}
```

## 7. Drag and Drop

```json
// Step 1: Drag file from one location to another
{"action": "mouse_drag", "params": {"start_x": 100, "start_y": 200, "end_x": 500, "end_y": 400, "duration": 0.5}}
```

## 8. Scroll Through Content

```json
// Step 1: Scroll down 5 clicks
{"action": "mouse_scroll", "params": {"clicks": 5}}

// Step 2: Scroll up 3 clicks
{"action": "mouse_scroll", "params": {"clicks": -3}}
```

## 9. Right-Click Context Menu

```json
// Step 1: Right-click to open context menu
{"action": "mouse_click", "params": {"x": 200, "y": 300, "button": "right"}}

// Step 2: Take screenshot to see menu options
{"action": "screenshot"}

// Step 3: Click on menu item
{"action": "mouse_click", "params": {"x": 220, "y": 350}}
```

## 10. Double-Click to Open File

```json
// Step 1: Navigate to file location (e.g., Desktop)
{"action": "keyboard_hotkey", "params": {"keys": ["win", "d"]}}

// Step 2: Take screenshot to find file
{"action": "screenshot"}

// Step 3: Double-click on file icon
{"action": "mouse_click", "params": {"x": 100, "y": 200, "clicks": 2}}
```
