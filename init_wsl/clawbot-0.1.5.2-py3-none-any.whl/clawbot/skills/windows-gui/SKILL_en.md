---
name: windows-gui
description: |
  Control Windows GUI applications and web browsers from WSL via bridge connection. Use when:
  (1) Automating Windows desktop applications (clicking, typing, scrolling)
  (2) Taking screenshots on Windows for analysis
  (3) Finding or managing Windows windows
  (4) Getting or setting Windows clipboard content
  (5) Launching Windows applications or URLs
  (6) Web browser automation (navigate, click, fill, extract data)
  (7) Web scraping and form filling
  Requires FTK_bot_A bridge service running on Windows.
---

# Windows GUI Skill

Automate Windows desktop applications and web browsers from WSL environment through the bridge connection.

## Prerequisites

The Windows bridge service (FTK_bot_A) must be running on Windows. Check connection:

```json
{"action": "get_status"}
```

If not connected, the tool will auto-connect. If connection fails, ensure FTK_bot_A is running.

---

## Part 1: Desktop GUI Automation

Control mouse, keyboard, and capture screen using pyautogui.

### Mouse Operations

| Action | Params | Description |
|--------|--------|-------------|
| mouse_click | x, y, button, clicks | Click at position. button: left/right/middle, clicks: 1/2 |
| mouse_move | x, y, duration | Move mouse to position |
| mouse_drag | start_x, start_y, end_x, end_y, duration, button | Drag from start to end |
| mouse_scroll | clicks, x, y | Scroll wheel. positive=up, negative=down |

**Examples:**

```json
{"action": "mouse_click", "params": {"x": 100, "y": 200}}
{"action": "mouse_click", "params": {"x": 100, "y": 200, "button": "right"}}
{"action": "mouse_click", "params": {"x": 100, "y": 200, "clicks": 2}}
{"action": "mouse_move", "params": {"x": 500, "y": 300, "duration": 0.5}}
{"action": "mouse_drag", "params": {"start_x": 100, "start_y": 100, "end_x": 300, "end_y": 300, "duration": 0.5}}
{"action": "mouse_scroll", "params": {"clicks": 3}}
```

### Keyboard Operations

| Action | Params | Description |
|--------|--------|-------------|
| keyboard_type | text, interval | Type text. Non-ASCII uses clipboard |
| keyboard_press | key | Press single key |
| keyboard_hotkey | keys | Press key combination |

**Examples:**

```json
{"action": "keyboard_type", "params": {"text": "Hello World"}}
{"action": "keyboard_type", "params": {"text": "Hello", "interval": 0.1}}
{"action": "keyboard_press", "params": {"key": "enter"}}
{"action": "keyboard_hotkey", "params": {"keys": ["ctrl", "c"]}}
{"action": "keyboard_hotkey", "params": {"keys": ["ctrl", "shift", "s"]}}
```

### Screen Operations

| Action | Params | Description |
|--------|--------|-------------|
| screenshot | region | Capture screen. region: [x, y, width, height] |
| get_screen_size | - | Get screen dimensions |
| get_mouse_position | - | Get current mouse position |

**Examples:**

```json
{"action": "screenshot"}
{"action": "screenshot", "params": {"region": [0, 0, 800, 600]}}
{"action": "get_screen_size"}
{"action": "get_mouse_position"}
```

### Window Operations

| Action | Params | Description |
|--------|--------|-------------|
| find_window | title | Find window by title (partial match) |
| launch_app | app_path, args | Launch application or open URL |

**Examples:**

```json
{"action": "find_window", "params": {"title": "Notepad"}}
{"action": "launch_app", "params": {"app_path": "notepad.exe"}}
{"action": "launch_app", "params": {"app_path": "https://example.com"}}
{"action": "launch_app", "params": {"app_path": "C:\\Program Files\\app.exe", "args": ["--flag"]}}
```

### Clipboard Operations

| Action | Params | Description |
|--------|--------|-------------|
| get_clipboard | - | Get clipboard text |
| set_clipboard | text | Set clipboard text |

**Examples:**

```json
{"action": "get_clipboard"}
{"action": "set_clipboard", "params": {"text": "copied text"}}
```

### Image Recognition

| Action | Params | Description |
|--------|--------|-------------|
| locate_on_screen | image_path, confidence | Find image on screen |
| wait_for_image | image_path, timeout, confidence | Wait for image to appear |

**Examples:**

```json
{"action": "locate_on_screen", "params": {"image_path": "C:\\button.png", "confidence": 0.9}}
{"action": "wait_for_image", "params": {"image_path": "C:\\dialog.png", "timeout": 10.0}}
```

---

## Part 2: Web Automation

Control web browsers using Playwright.

### Browser Control

| Action | Params | Description |
|--------|--------|-------------|
| web_start | headless | Start browser. headless: true/false |
| web_stop | - | Stop browser |
| web_navigate | url, wait_until, timeout | Navigate to URL |
| web_get_url | - | Get current URL |
| web_get_title | - | Get page title |
| web_go_back | - | Go back |
| web_go_forward | - | Go forward |
| web_refresh | - | Refresh page |

**Examples:**

```json
{"action": "web_start", "params": {"headless": false}}
{"action": "web_navigate", "params": {"url": "https://example.com"}}
{"action": "web_get_url"}
{"action": "web_get_title"}
{"action": "web_stop"}
```

### Page Interaction

| Action | Params | Description |
|--------|--------|-------------|
| web_click | selector, timeout | Click element by CSS selector |
| web_fill | selector, value, timeout | Fill input by CSS selector |
| web_scroll | direction, amount | Scroll page |
| web_press | key | Press key |
| web_type | text, delay | Type text with delay |

**Examples:**

```json
{"action": "web_click", "params": {"selector": "#submit-btn"}}
{"action": "web_fill", "params": {"selector": "#username", "value": "user@example.com"}}
{"action": "web_scroll", "params": {"direction": "down", "amount": 500}}
{"action": "web_press", "params": {"key": "Enter"}}
{"action": "web_type", "params": {"text": "Hello", "delay": 50}}
```

### Page Information

| Action | Params | Description |
|--------|--------|-------------|
| web_screenshot | selector, full_page | Capture page or element |
| web_get_content | - | Get page HTML |
| web_extract_elements | config | Extract interactive elements |
| web_extract_data | selectors | Extract data by selectors |
| web_evaluate | script | Execute JavaScript |

**Examples:**

```json
{"action": "web_screenshot"}
{"action": "web_screenshot", "params": {"full_page": true}}
{"action": "web_extract_elements"}
{"action": "web_extract_data", "params": {"selectors": [{"name": "title", "selector": "h1"}]}}
{"action": "web_evaluate", "params": {"script": "document.title"}}
```

### Session Management

| Action | Params | Description |
|--------|--------|-------------|
| web_get_cookies | - | Get all cookies |
| web_set_cookies | cookies | Set cookies |
| web_save_session | session_id | Save session to file |
| web_load_session | session_id | Load session from file |

**Examples:**

```json
{"action": "web_get_cookies"}
{"action": "web_set_cookies", "params": {"cookies": [{"name": "session", "value": "abc", "domain": ".example.com"}]}}
{"action": "web_save_session", "params": {"session_id": "my_session"}}
{"action": "web_load_session", "params": {"session_id": "my_session"}}
```

### Login Operations

| Action | Params | Description |
|--------|--------|-------------|
| web_login | type, params | Login via form/cookie/QR |

**Examples:**

```json
{"action": "web_login", "params": {"type": "form", "params": {"username_selector": "#user", "password_selector": "#pass", "submit_selector": "#submit", "username": "user", "password": "pass"}}}
{"action": "web_login", "params": {"type": "cookie", "params": {"cookies": [...], "url": "https://example.com"}}}
{"action": "web_login", "params": {"type": "qr", "params": {"selector": "#qrcode"}}}
```

### Wait Operations

| Action | Params | Description |
|--------|--------|-------------|
| web_wait_for_selector | selector, timeout | Wait for element |

**Examples:**

```json
{"action": "web_wait_for_selector", "params": {"selector": ".loaded", "timeout": 10000}}
```

---

## Best Practices

### Desktop GUI

1. **Screenshot-First**: Always capture the screen before operating
2. **Use find_window**: Get window position before clicking
3. **Add delays**: Wait for UI to respond after actions
4. **Verify results**: Take another screenshot to confirm

### Web Automation

1. **Start browser first**: Call web_start before any web action
2. **Use selectors**: CSS selectors are more reliable than coordinates
3. **Wait for elements**: Use web_wait_for_selector for dynamic content
4. **Save sessions**: Use session management for login persistence

---

## Common Workflows

- See [desktop-workflows.md](references/desktop-workflows.md) for desktop automation examples
- See [web-workflows.md](references/web-workflows.md) for web automation examples

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Connection failed | Ensure FTK_bot_A is running on Windows |
| Click missed target | Verify coordinates with screenshot |
| Window not found | Check exact window title, use partial match |
| Typing too fast | Add interval parameter |
| Browser not started | Call web_start first |
| Element not found | Check selector, use web_wait_for_selector |

---

## Key Names Reference

Common key names for keyboard_press and keyboard_hotkey:

- Letters: a, b, c, ... z
- Numbers: 0, 1, 2, ... 9
- Special: enter, tab, escape, space, backspace, delete
- Arrows: up, down, left, right
- Modifiers: shift, ctrl, alt, win
- Function: f1, f2, ... f12
