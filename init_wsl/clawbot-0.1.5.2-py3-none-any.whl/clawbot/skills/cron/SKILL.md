---
name: cron
description: 调度提醒和周期性任务。
---

# Cron

使用 `cron` 工具调度提醒或周期性任务。

## 三种模式

1. **提醒** - 消息直接发送给用户
2. **任务** - 消息为任务描述，Agent 执行并返回结果
3. **一次性** - 在指定时间运行一次，然后自动删除

## 示例

固定提醒：
```
cron(action="add", message="Time to take a break!", every_seconds=1200)
```

动态任务（Agent 每次执行）：
```
cron(action="add", message="Check HKUDS/clawbot GitHub stars and report", every_seconds=600)
```

一次性定时任务（从当前时间计算 ISO 日期时间）：
```
cron(action="add", message="Remind me about the meeting", at="<ISO datetime>")
```

带时区的 cron：
```
cron(action="add", message="Morning standup", cron_expr="0 9 * * 1-5", tz="America/Vancouver")
```

列表/删除：
```
cron(action="list")
cron(action="remove", job_id="abc123")
```

## 时间表达式

| 用户说 | 参数 |
|--------|------|
| 每 20 分钟 | every_seconds: 1200 |
| 每小时 | every_seconds: 3600 |
| 每天早上 8 点 | cron_expr: "0 8 * * *" |
| 工作日下午 5 点 | cron_expr: "0 17 * * 1-5" |
| 温哥华时间每天早上 9 点 | cron_expr: "0 9 * * *", tz: "America/Vancouver" |
| 特定时间 | at: ISO 日期时间字符串（从当前时间计算） |

## 时区

使用 `tz` 配合 `cron_expr` 在指定 IANA 时区调度。不指定 `tz` 则使用服务器本地时区。
