"""
审计日志模块

提供审计日志记录和查询功能。"""

import json
import os
from typing import List, Optional

from .types import Actor, AuditEntry
from .utils import ensure_dir, exists

try:
    import aiofiles
    HAS_AIOFILES = True
except ImportError:
    HAS_AIOFILES = False


def _expand_home(value: str) -> str:
    """展开 ~ 为用户目录"""
    if value.startswith("~/"):
        return os.path.join(os.path.expanduser("~"), value[2:])
    return value


def _resolve_openwork_data_dir() -> str:
    """解析 OpenWork 数据目录"""
    override = os.environ.get("OPENWORK_DATA_DIR", "").strip()
    if override:
        return _expand_home(override)
    return os.path.join(os.path.expanduser("~"), ".openwork", "openwork-server")


def audit_log_path(workspace_id: str) -> str:
    """
    获取审计日志文件路径

    Args:
        workspace_id: 工作空间 ID

    Returns:
        审计日志文件路径
    """
    return os.path.join(_resolve_openwork_data_dir(), "audit", f"{workspace_id}.jsonl")


def legacy_audit_log_path(workspace_root: str) -> str:
    """
    获取旧版审计日志文件路径

    Args:
        workspace_root: 工作空间根目录

    Returns:
        旧版审计日志文件路径
    """
    return os.path.join(workspace_root, ".opencode", "openwork", "audit.jsonl")


async def _resolve_readable_audit_path(workspace_root: str, workspace_id: str) -> Optional[str]:
    """
    解析可读的审计日志路径

    Args:
        workspace_root: 工作空间根目录
        workspace_id: 工作空间 ID

    Returns:
        可读的审计日志路径，如果不存在则返回 None
    """
    primary = audit_log_path(workspace_id)
    if await exists(primary):
        return primary
    legacy = legacy_audit_log_path(workspace_root)
    if await exists(legacy):
        return legacy
    return None


def _actor_to_dict(actor: Actor) -> dict:
    """将 Actor 转换为字典"""
    if actor is None:
        return None
    return {
        "type": actor.type,
        "client_id": actor.client_id,
        "token_hash": actor.token_hash,
        "scope": actor.scope.value if actor.scope else None
    }


def _dict_to_actor(data: dict) -> Actor:
    """将字典转换为 Actor"""
    from .types import TokenScope
    return Actor(
        type=data.get("type", "unknown"),
        client_id=data.get("client_id"),
        token_hash=data.get("token_hash"),
        scope=TokenScope(data.get("scope")) if data.get("scope") else None
    )


async def record_audit(workspace_root: str, entry: AuditEntry) -> None:
    """
    记录审计日志

    Args:
        workspace_root: 工作空间根目录
        entry: 审计日志条目
    """
    workspace_id = entry.workspace_id.strip() if entry.workspace_id else ""

    if not workspace_id:
        path = legacy_audit_log_path(workspace_root)
    else:
        path = audit_log_path(workspace_id)

    await ensure_dir(os.path.dirname(path))

    entry_dict = {
        "id": entry.id,
        "workspaceId": entry.workspace_id,
        "actor": _actor_to_dict(entry.actor),
        "action": entry.action,
        "target": entry.target,
        "summary": entry.summary,
        "timestamp": entry.timestamp
    }

    if HAS_AIOFILES:
        async with aiofiles.open(path, "a", encoding="utf-8") as f:
            await f.write(json.dumps(entry_dict, ensure_ascii=False) + "\n")
    else:
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry_dict, ensure_ascii=False) + "\n")


async def read_last_audit(workspace_root: str, workspace_id: str) -> Optional[AuditEntry]:
    """
    读取最后一条审计日志

    Args:
        workspace_root: 工作空间根目录
        workspace_id: 工作空间 ID

    Returns:
        最后一条审计日志条目，如果没有则返回 None
    """
    path = await _resolve_readable_audit_path(workspace_root, workspace_id)
    if not path:
        return None

    if HAS_AIOFILES:
        async with aiofiles.open(path, "r", encoding="utf-8") as f:
            content = await f.read()
    else:
        with open(path, "r", encoding="utf-8") as f:
            content = f.read()

    lines = content.strip().split("\n")
    if not lines:
        return None

    last = lines[-1]
    if not last:
        return None

    try:
        data = json.loads(last)
        return AuditEntry(
            id=data.get("id", ""),
            workspace_id=data.get("workspaceId", ""),
            actor=_dict_to_actor(data.get("actor", {})),
            action=data.get("action", ""),
            target=data.get("target", ""),
            summary=data.get("summary", ""),
            timestamp=data.get("timestamp", 0)
        )
    except (json.JSONDecodeError, TypeError):
        return None


async def read_audit_entries(
    workspace_root: str,
    workspace_id: str,
    limit: int = 50
) -> List[AuditEntry]:
    """
    读取审计日志条目

    Args:
        workspace_root: 工作空间根目录
        workspace_id: 工作空间 ID
        limit: 最大返回数量

    Returns:
        审计日志条目列表（按时间倒序）
    """
    path = await _resolve_readable_audit_path(workspace_root, workspace_id)
    if not path:
        return []

    if HAS_AIOFILES:
        async with aiofiles.open(path, "r", encoding="utf-8") as f:
            content = await f.read()
    else:
        with open(path, "r", encoding="utf-8") as f:
            content = f.read()

    raw_lines = [line for line in content.strip().split("\n") if line]
    if not raw_lines:
        return []

    slice_lines = raw_lines[-limit:] if limit < len(raw_lines) else raw_lines
    entries: List[AuditEntry] = []

    for i in range(len(slice_lines) - 1, -1, -1):
        try:
            data = json.loads(slice_lines[i])
            entries.append(AuditEntry(
                id=data.get("id", ""),
                workspace_id=data.get("workspaceId", ""),
                actor=_dict_to_actor(data.get("actor", {})),
                action=data.get("action", ""),
                target=data.get("target", ""),
                summary=data.get("summary", ""),
                timestamp=data.get("timestamp", 0)
            ))
        except (json.JSONDecodeError, TypeError):
            pass

    return entries
