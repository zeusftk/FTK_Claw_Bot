"""
OpenWork Server 审批管理模块

提供审批请求的管理功能。"""

import asyncio
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from .types import Actor, ApprovalConfig, ApprovalRequest
from .utils import short_id


@dataclass
class ApprovalResult:
    """审批结果"""
    id: str
    allowed: bool
    reason: Optional[str] = None


@dataclass
class PendingApproval:
    """待处理审批"""
    request: ApprovalRequest
    resolve_callback: Any = None
    timeout_handle: Optional[asyncio.TimerHandle] = None


class ApprovalService:
    """审批服务"""

    def __init__(self, config: ApprovalConfig):
        """
        初始化审批服务

        Args:
            config: 审批配置
        """
        self.config = config
        self._pending: Dict[str, PendingApproval] = {}
        self._loop = asyncio.get_event_loop()

    def list(self) -> List[ApprovalRequest]:
        """
        列出所有待处理审批

        Returns:
            待处理审批列表
        """
        return [entry.request for entry in self._pending.values()]

    async def request_approval(
        self,
        workspace_id: str,
        action: str,
        summary: str,
        paths: List[str],
        actor: Actor
    ) -> ApprovalResult:
        """
        请求审批

        Args:
            workspace_id: 工作空间 ID
            action: 操作类型
            summary: 操作摘要
            paths: 涉及的路径列表
            actor: 操作者

        Returns:
            审批结果
        """
        # 自动模式直接通过
        if self.config.mode == "auto":
            return ApprovalResult(id="auto", allowed=True)

        # 创建审批请求
        request_id = short_id()
        request = ApprovalRequest(
            id=request_id,
            workspace_id=workspace_id,
            action=action,
            summary=summary,
            paths=paths,
            created_at=int(asyncio.get_event_loop().time() * 1000),
            actor=actor
        )

        # 创建 Future 用于等待结果
        future: asyncio.Future[ApprovalResult] = asyncio.Future()

        # 设置超时
        def on_timeout():
            if request_id in self._pending:
                del self._pending[request_id]
            if not future.done():
                future.set_result(ApprovalResult(
                    id=request_id,
                    allowed=False,
                    reason="timeout"
                ))

        timeout_handle = self._loop.call_later(
            self.config.timeout_ms / 1000,
            on_timeout
        )

        # 存储待处理审批
        self._pending[request_id] = PendingApproval(
            request=request,
            resolve_callback=future,
            timeout_handle=timeout_handle
        )

        # 等待结果
        result = await future
        return result

    def respond(self, request_id: str, reply: str) -> Optional[ApprovalResult]:
        """
        响应审批请求

        Args:
            request_id: 请求 ID
            reply: 响应类型 (allow/deny)

        Returns:
            审批结果，如果请求不存在则返回 None
        """
        pending = self._pending.get(request_id)
        if not pending:
            return None

        # 取消超时
        if pending.timeout_handle:
            pending.timeout_handle.cancel()

        # 移除待处理
        del self._pending[request_id]

        # 创建结果
        result = ApprovalResult(
            id=request_id,
            allowed=reply == "allow",
            reason=None if reply == "allow" else "denied"
        )

        # 设置结果
        if pending.resolve_callback and not pending.resolve_callback.done():
            pending.resolve_callback.set_result(result)

        return result

    def get_pending(self, request_id: str) -> Optional[ApprovalRequest]:
        """
        获取待处理审批

        Args:
            request_id: 请求 ID

        Returns:
            审批请求，如果不存在则返回 None
        """
        pending = self._pending.get(request_id)
        return pending.request if pending else None

    def clear(self) -> int:
        """
        清除所有待处理审批

        Returns:
            清除的数量
        """
        count = len(self._pending)

        for pending in self._pending.values():
            if pending.timeout_handle:
                pending.timeout_handle.cancel()
            if pending.resolve_callback and not pending.resolve_callback.done():
                pending.resolve_callback.set_result(ApprovalResult(
                    id=pending.request.id,
                    allowed=False,
                    reason="cleared"
                ))

        self._pending.clear()
        return count
