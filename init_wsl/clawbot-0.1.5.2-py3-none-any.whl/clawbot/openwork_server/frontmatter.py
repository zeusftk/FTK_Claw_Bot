"""
OpenWork Server Frontmatter 解析模块

提供 YAML frontmatter 解析和构建功能。"""

import re
from typing import Any, Dict, Tuple

try:
    import yaml
    HAS_YAML = True
except ImportError:
    HAS_YAML = False


def parse_frontmatter(content: str) -> Tuple[Dict[str, Any], str]:
    """
    解析 YAML frontmatter

    Args:
        content: 文件内容

    Returns:
        (frontmatter 数据, 正文内容)
    """
    # 匹配 frontmatter 模式
    pattern = r"^---\r?\n([\s\S]*?)\r?\n---\r?\n?"
    match = re.match(pattern, content)

    if not match:
        return {}, content

    raw = match.group(1) or ""
    body = content[match.end():]

    # 解析 YAML
    if HAS_YAML:
        try:
            data = yaml.safe_load(raw) or {}
        except yaml.YAMLError:
            data = {}
    else:
        # 简单解析，不支持复杂 YAML
        data = _parse_simple_yaml(raw)

    return data, body


def _parse_simple_yaml(raw: str) -> Dict[str, Any]:
    """
    简单 YAML 解析（不依赖 PyYAML）

    Args:
        raw: YAML 文本

    Returns:
        解析后的字典
    """
    result: Dict[str, Any] = {}
    lines = raw.split("\n")

    for line in lines:
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue

        # 解析键值对
        if ":" in stripped:
            key, _, value = stripped.partition(":")
            key = key.strip()
            value = value.strip()

            # 移除引号
            if (value.startswith('"') and value.endswith('"')) or \
               (value.startswith("'") and value.endswith("'")):
                value = value[1:-1]

            # 转换布尔值
            if value.lower() == "true":
                value = True
            elif value.lower() == "false":
                value = False
            # 转换数字
            elif value.isdigit():
                value = int(value)
            elif value.replace(".", "").isdigit():
                try:
                    value = float(value)
                except ValueError:
                    pass

            result[key] = value

    return result


def build_frontmatter(data: Dict[str, Any]) -> str:
    """
    构建 YAML frontmatter

    Args:
        data: frontmatter 数据

    Returns:
        frontmatter 字符串
    """
    if HAS_YAML:
        yaml_str = yaml.dump(data, allow_unicode=True, default_flow_style=False).strip()
    else:
        yaml_str = _build_simple_yaml(data)

    return f"---\n{yaml_str}\n---\n"


def _build_simple_yaml(data: Dict[str, Any]) -> str:
    """
    简单 YAML 构建（不依赖 PyYAML）

    Args:
        data: 数据字典

    Returns:
        YAML 字符串
    """
    lines = []

    for key, value in data.items():
        if value is None:
            continue
        elif isinstance(value, bool):
            lines.append(f"{key}: {str(value).lower()}")
        elif isinstance(value, (int, float)):
            lines.append(f"{key}: {value}")
        elif isinstance(value, str):
            # 检查是否需要引号
            if any(c in value for c in [":", "#", "\n", '"', "'"]) or \
               value.startswith(" ") or value.endswith(" "):
                # 使用双引号并转义
                escaped = value.replace("\\", "\\\\").replace('"', '\\"')
                lines.append(f'{key}: "{escaped}"')
            else:
                lines.append(f"{key}: {value}")
        elif isinstance(value, list):
            lines.append(f"{key}:")
            for item in value:
                if isinstance(item, str):
                    lines.append(f"  - {item}")
                else:
                    lines.append(f"  - {str(item)}")
        elif isinstance(value, dict):
            lines.append(f"{key}:")
            for k, v in value.items():
                if isinstance(v, str):
                    lines.append(f"  {k}: {v}")
                else:
                    lines.append(f"  {k}: {str(v)}")
        else:
            lines.append(f"{key}: {str(value)}")

    return "\n".join(lines)


def extract_trigger_from_body(body: str) -> str:
    """
    从正文中提取触发条件

    从 "When to use" 部分提取第一个触发条件。

    Args:
        body: 正文内容

    Returns:
        触发条件字符串
    """
    lines = body.split("\n")
    in_when_section = False

    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue

        # 检查标题
        heading_match = re.match(r"^#{1,6}\s+(.+)$", stripped)
        if heading_match:
            heading = heading_match.group(1).strip()
            in_when_section = re.match(r"^when to use$", heading, re.IGNORECASE) is not None
            continue

        if not in_when_section:
            continue

        # 提取列表项
        cleaned = re.sub(r"^[-*+]\s+", "", stripped)
        cleaned = re.sub(r"^\d+[.)]\s+", "", cleaned).strip()

        if cleaned:
            return cleaned

    return ""
