"""
OpenWork Server 命令管理模块

提供命令的列表、创建、更新和删除功能。"""

import os
from typing import List, Optional

from .errors import ApiError
from .frontmatter import build_frontmatter, parse_frontmatter
from .types import CommandItem
from .utils import ensure_dir, exists, join_path, read_file, remove_file, write_file
from .validators import sanitize_command_name, validate_command_name
from .workspace_files import global_commands_dir, project_commands_dir


async def _list_commands_in_dir(
    dir_path: str,
    scope: str
) -> List[CommandItem]:
    """
    列出目录中的命令

    Args:
        dir_path: 目录路径
        scope: 作用域 (workspace/global)

    Returns:
        命令列表
    """
    if not await exists(dir_path):
        return []

    items: List[CommandItem] = []

    try:
        entries = os.listdir(dir_path)
    except Exception:
        return []

    for name in entries:
        if not name.endswith(".md"):
            continue

        file_path = join_path(dir_path, name)

        try:
            content = await read_file(file_path)
            data, body = parse_frontmatter(content)

            cmd_name = data.get("name", name[:-3]) if isinstance(data.get("name"), str) else name[:-3]

            try:
                validate_command_name(cmd_name)
            except ApiError:
                continue

            items.append(CommandItem(
                name=cmd_name,
                description=data.get("description") if isinstance(data.get("description"), str) else None,
                template=body.strip(),
                agent=data.get("agent") if isinstance(data.get("agent"), str) else None,
                model=data.get("model") if isinstance(data.get("model"), str) else None,
                subtask=data.get("subtask") if isinstance(data.get("subtask"), bool) else None,
                scope=scope
            ))
        except Exception:
            continue

    return items


async def list_commands(
    workspace_root: str,
    scope: str = "workspace"
) -> List[CommandItem]:
    """
    列出命令

    Args:
        workspace_root: 工作空间根目录
        scope: 作用域 (workspace/global)

    Returns:
        命令列表
    """
    if scope == "global":
        dir_path = global_commands_dir()
        return await _list_commands_in_dir(dir_path, "global")

    dir_path = project_commands_dir(workspace_root)
    return await _list_commands_in_dir(dir_path, "workspace")


async def upsert_command(
    workspace_root: str,
    payload: dict
) -> str:
    """
    创建或更新命令

    Args:
        workspace_root: 工作空间根目录
        payload: 命令数据 {name, description?, template, agent?, model?, subtask?}

    Returns:
        命令文件路径

    Raises:
        ApiError: 如果参数无效
    """
    template = payload.get("template", "")
    if not template or not template.strip():
        raise ApiError(400, "invalid_command_template", "Command template is required")

    sanitized = sanitize_command_name(payload.get("name", ""))
    validate_command_name(sanitized)

    # 构建 frontmatter
    frontmatter = build_frontmatter({
        "name": sanitized,
        "description": payload.get("description"),
        "agent": payload.get("agent"),
        "model": payload.get("model"),
        "subtask": payload.get("subtask", False)
    })

    content = frontmatter + "\n" + template.strip() + "\n"

    # 创建命令目录和文件
    dir_path = project_commands_dir(workspace_root)
    await ensure_dir(dir_path)

    file_path = join_path(dir_path, f"{sanitized}.md")
    await write_file(file_path, content)

    return file_path


async def delete_command(
    workspace_root: str,
    name: str
) -> None:
    """
    删除命令

    Args:
        workspace_root: 工作空间根目录
        name: 命令名称

    Raises:
        ApiError: 如果命令不存在
    """
    sanitized = sanitize_command_name(name)
    validate_command_name(sanitized)

    dir_path = project_commands_dir(workspace_root)
    file_path = join_path(dir_path, f"{sanitized}.md")

    if not await exists(file_path):
        raise ApiError(404, "command_not_found", f"Command not found: {sanitized}")

    await remove_file(file_path)


async def get_command(
    workspace_root: str,
    name: str,
    scope: str = "workspace"
) -> Optional[CommandItem]:
    """
    获取单个命令

    Args:
        workspace_root: 工作空间根目录
        name: 命令名称
        scope: 作用域

    Returns:
        命令条目或 None
    """
    commands = await list_commands(workspace_root, scope)
    for cmd in commands:
        if cmd.name == name:
            return cmd
    return None


async def list_all_commands(workspace_root: str) -> List[CommandItem]:
    """
    列出所有命令（包括工作空间和全局：
    Args:
        workspace_root: 工作空间根目�?
    Returns:
        命令列表
    """
    workspace_commands = await list_commands(workspace_root, "workspace")
    global_commands = await list_commands(workspace_root, "global")

    # 合并，工作空间命令优先
    seen = set()
    result = []

    for cmd in workspace_commands:
        if cmd.name not in seen:
            seen.add(cmd.name)
            result.append(cmd)

    for cmd in global_commands:
        if cmd.name not in seen:
            seen.add(cmd.name)
            result.append(cmd)

    return result
