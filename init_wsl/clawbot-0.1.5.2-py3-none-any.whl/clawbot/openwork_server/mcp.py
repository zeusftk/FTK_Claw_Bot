"""
OpenWork Server MCP 管理模块

提供 MCP (Model Context Protocol) 的列表、添加和删除功能。"""

import fnmatch
from typing import Any, Dict, List, Optional

from .types import McpItem
from .utils import read_json_file, write_json_file
from .validators import validate_mcp_config, validate_mcp_name
from .workspace_files import global_opencode_config_path, opencode_config_path


def _get_mcp_config(config: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    """
    从配置中提取 MCP 配置

    Args:
        config: 配置字典

    Returns:
        MCP 配置字典
    """
    mcp = config.get("mcp")
    if not mcp or not isinstance(mcp, dict):
        return {}
    return {k: v for k, v in mcp.items() if isinstance(v, dict)}


def _get_denied_tool_patterns(config: Dict[str, Any]) -> List[str]:
    """
    从配置中获取被拒绝的工具模式

    Args:
        config: 配置字典

    Returns:
        工具模式列表
    """
    tools = config.get("tools")
    if not tools or not isinstance(tools, dict):
        return []

    deny = tools.get("deny")
    if not isinstance(deny, list):
        return []

    return [item for item in deny if isinstance(item, str)]


def _is_mcp_disabled_by_tools(config: Dict[str, Any], name: str) -> bool:
    """
    检查 MCP 是否被工具配置禁用

    Args:
        config: 配置字典
        name: MCP 名称

    Returns:
        是否被禁用
    """
    patterns = _get_denied_tool_patterns(config)
    if not patterns:
        return False

    candidates = [
        f"mcp.{name}",
        f"mcp.{name}.*",
        f"mcp:{name}",
        f"mcp:{name}:*",
        "mcp.*",
        "mcp:*"
    ]

    for pattern in patterns:
        for candidate in candidates:
            if fnmatch.fnmatch(candidate, pattern):
                return True

    return False


async def _read_config(path: str) -> Dict[str, Any]:
    """
    读取配置文件

    Args:
        path: 配置文件路径

    Returns:
        配置字典
    """
    config = await read_json_file(path)
    return config or {}


async def _update_config(path: str, updates: Dict[str, Any]) -> None:
    """
    更新配置文件

    Args:
        path: 配置文件路径
        updates: 更新内容
    """
    config = await _read_config(path)
    config.update(updates)
    await write_json_file(path, config)


async def list_mcp(workspace_root: str) -> List[McpItem]:
    """
    列出所有 MCP

    Args:
        workspace_root: 工作空间根目录

    Returns:
        MCP 列表
    """
    project_config_path = opencode_config_path(workspace_root)
    global_config_path = global_opencode_config_path()

    project_config = await _read_config(project_config_path)
    global_config = await _read_config(global_config_path)

    project_mcp_map = _get_mcp_config(project_config)
    global_mcp_map = _get_mcp_config(global_config)

    items: List[McpItem] = []

    # 全局 MCP（项目级会覆盖同名全局）
    for name, entry in global_mcp_map.items():
        if name in project_mcp_map:
            continue

        disabled = (
            _is_mcp_disabled_by_tools(global_config, name) or
            _is_mcp_disabled_by_tools(project_config, name)
        )

        items.append(McpItem(
            name=name,
            config=entry,
            source="config.global",
            disabled_by_tools=disabled or None
        ))

    # 项目 MCP（最高优先级）
    for name, entry in project_mcp_map.items():
        items.append(McpItem(
            name=name,
            config=entry,
            source="config.project",
            disabled_by_tools=_is_mcp_disabled_by_tools(project_config, name) or None
        ))

    return items


async def add_mcp(
    workspace_root: str,
    name: str,
    config: Dict[str, Any]
) -> Dict[str, str]:
    """
    添加或更新 MCP

    Args:
        workspace_root: 工作空间根目录
        name: MCP 名称
        config: MCP 配置

    Returns:
        {action: "added" | "updated"}

    Raises:
        ApiError: 如果参数无效
    """
    validate_mcp_name(name)
    validate_mcp_config(config)

    config_path = opencode_config_path(workspace_root)
    data = await _read_config(config_path)
    mcp_map = _get_mcp_config(data)

    existed = name in mcp_map
    mcp_map[name] = config

    await _update_config(config_path, {"mcp": mcp_map})

    return {"action": "updated" if existed else "added"}


async def remove_mcp(
    workspace_root: str,
    name: str
) -> bool:
    """
    移除 MCP

    Args:
        workspace_root: 工作空间根目录
        name: MCP 名称

    Returns:
        是否移除成功
    """
    config_path = opencode_config_path(workspace_root)
    data = await _read_config(config_path)
    mcp_map = _get_mcp_config(data)

    if name not in mcp_map:
        return False

    del mcp_map[name]
    await _update_config(config_path, {"mcp": mcp_map})

    return True


async def get_mcp(
    workspace_root: str,
    name: str
) -> Optional[McpItem]:
    """
    获取单个 MCP

    Args:
        workspace_root: 工作空间根目录
        name: MCP 名称

    Returns:
        MCP 条目或 None
    """
    items = await list_mcp(workspace_root)
    for item in items:
        if item.name == name:
            return item
    return None


async def update_mcp_config(
    workspace_root: str,
    name: str,
    updates: Dict[str, Any]
) -> bool:
    """
    更新 MCP 配置

    Args:
        workspace_root: 工作空间根目录
        name: MCP 名称
        updates: 配置更新

    Returns:
        是否更新成功
    """
    config_path = opencode_config_path(workspace_root)
    data = await _read_config(config_path)
    mcp_map = _get_mcp_config(data)

    if name not in mcp_map:
        return False

    mcp_map[name].update(updates)
    await _update_config(config_path, {"mcp": mcp_map})

    return True
