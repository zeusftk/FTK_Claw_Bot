"""
OpenWork Server 工具函数模块

提供通用的工具函数。
"""

import asyncio
import hashlib
import json
import os
import re
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional, TypeVar

T = TypeVar("T")


async def exists(path: str) -> bool:
    """
    检查路径是否存在
    Args:
        path: 文件路径

    Returns:
        路径是否存在
    """
    try:
        await asyncio.to_thread(os.stat, path)
        return True
    except (OSError, IOError):
        return False


async def ensure_dir(path: str) -> None:
    """
    确保目录存在

    Args:
        path: 目录路径
    """
    await asyncio.to_thread(os.makedirs, path, exist_ok=True)


async def read_file(path: str, encoding: str = "utf-8") -> str:
    """
    异步读取文件内容

    Args:
        path: 文件路径
        encoding: 编码格式

    Returns:
        文件内容
    """
    def _read():
        with open(path, "r", encoding=encoding) as f:
            return f.read()
    return await asyncio.to_thread(_read)


async def write_file(path: str, content: str, encoding: str = "utf-8") -> None:
    """
    异步写入文件内容

    Args:
        path: 文件路径
        content: 文件内容
        encoding: 编码格式
    """
    def _write():
        with open(path, "w", encoding=encoding) as f:
            f.write(content)
    await asyncio.to_thread(_write)


async def read_json_file(path: str) -> Optional[Dict[str, Any]]:
    """
    异步读取 JSON 文件

    Args:
        path: 文件路径

    Returns:
        JSON 数据或 None
    """
    try:
        content = await read_file(path)
        return json.loads(content)
    except (OSError, json.JSONDecodeError):
        return None


async def write_json_file(path: str, data: Any, indent: int = 2) -> None:
    """
    异步写入 JSON 文件

    Args:
        path: 文件路径
        data: JSON 数据
        indent: 缩进
    """
    content = json.dumps(data, indent=indent, ensure_ascii=False) + "\n"
    await write_file(path, content)


def hash_token(token: str) -> str:
    """
    计算 Token 的 SHA256 哈希值
    Args:
        token: Token 字符串
    Returns:
        哈希值
    """
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def short_id() -> str:
    """
    生成短 ID

    Returns:
        UUID 字符串
    """
    return str(uuid.uuid4())


def parse_list(input_value: Optional[str]) -> List[str]:
    """
    解析列表字符串
    Args:
        input_value: 输入字符串
    Returns:
        字符串列表
    """
    if not input_value:
        return []

    trimmed = input_value.strip()
    if not trimmed:
        return []

    # 尝试解析 JSON 数组
    if trimmed.startswith("["):
        try:
            parsed = json.loads(trimmed)
            if isinstance(parsed, list):
                return [str(item) for item in parsed if item]
        except json.JSONDecodeError:
            return []

    # 按逗号或分号分割
    return [
        value.strip()
        for value in re.split(r"[,;]", trimmed)
        if value.strip()
    ]


def resolve_home() -> str:
    """
    获取用户主目录
    Returns:
        主目录路径
    """
    return str(Path.home())


def join_path(*parts: str) -> str:
    """
    连接路径

    Args:
        *parts: 路径部分

    Returns:
        完整路径
    """
    return str(Path(*parts))


def resolve_path(path: str, base: Optional[str] = None) -> str:
    """
    解析路径

    Args:
        path: 路径
        base: 基础路径

    Returns:
        绝对路径
    """
    p = Path(path)
    if p.is_absolute():
        return str(p.resolve())

    if base:
        return str((Path(base) / path).resolve())
    return str(p.resolve())


def relative_path(path: str, base: str) -> str:
    """
    计算相对路径

    Args:
        path: 目标路径
        base: 基础路径

    Returns:
        相对路径
    """
    try:
        return str(Path(path).relative_to(base))
    except ValueError:
        return str(Path(path))


def basename(path: str) -> str:
    """
    获取文件名
    Args:
        path: 文件路径

    Returns:
        文件名
    """
    return os.path.basename(path)


def dirname(path: str) -> str:
    """
    获取目录名
    Args:
        path: 文件路径

    Returns:
        目录名
    """
    return os.path.dirname(path)


async def list_dir(path: str) -> List[os.DirEntry]:
    """
    列出目录内容

    Args:
        path: 目录路径

    Returns:
        目录条目列表
    """
    def _list():
        with os.scandir(path) as entries:
            return list(entries)
    return await asyncio.to_thread(_list)


async def mkdir(path: str, exist_ok: bool = True) -> None:
    """
    创建目录

    Args:
        path: 目录路径
        exist_ok: 是否允许已存在
    """
    await asyncio.to_thread(os.makedirs, path, exist_ok=exist_ok)


async def remove_dir(path: str, recursive: bool = False) -> None:
    """
    删除目录

    Args:
        path: 目录路径
        recursive: 是否递归删除
    """
    def _remove():
        import shutil
        if recursive:
            shutil.rmtree(path, ignore_errors=True)
        else:
            os.rmdir(path)
    await asyncio.to_thread(_remove)


async def remove_file(path: str) -> None:
    """
    删除文件

    Args:
        path: 文件路径
    """
    def _remove():
        try:
            os.remove(path)
        except FileNotFoundError:
            pass
    await asyncio.to_thread(_remove)


def get_env(key: str, default: Optional[str] = None) -> Optional[str]:
    """
    获取环境变量

    Args:
        key: 环境变量名
        default: 默认值
    Returns:
        环境变量值
    """
    return os.environ.get(key, default)


def get_env_bool(key: str, default: bool = False) -> bool:
    """
    获取布尔型环境变量
    Args:
        key: 环境变量名
        default: 默认值
    Returns:
        布尔值
    """
    value = get_env(key)
    if value is None:
        return default
    return value.lower() in ("true", "1", "yes", "on")


def get_env_int(key: str, default: int = 0) -> int:
    """
    获取整型环境变量

    Args:
        key: 环境变量名
        default: 默认值
    Returns:
        整数值
    """
    value = get_env(key)
    if value is None:
        return default
    try:
        return int(value)
    except ValueError:
        return default


def get_env_list(key: str, separator: str = ",") -> List[str]:
    """
    获取列表型环境变量
    Args:
        key: 环境变量名
        separator: 分隔符
    Returns:
        字符串列表
    """
    value = get_env(key)
    if not value:
        return []
    return [item.strip() for item in value.split(separator) if item.strip()]


def clamp_int(
    value: Any,
    min_val: int,
    max_val: int,
    name: str = "value"
) -> int:
    """
    限制整数值范围
    Args:
        value: 输入值
        min_val: 最小值
        max_val: 最大值
        name: 参数名称

    Returns:
        限制后的整数值

    Raises:
        ValueError: 如果值不在范围内
    """
    from .errors import ApiError

    num = int(value) if isinstance(value, (int, float, str)) else 0
    if not isinstance(num, int) or not str(num).isdigit():
        raise ApiError(400, "invalid_payload", f"{name} must be a number")

    result = int(num)
    if result < min_val or result > max_val:
        raise ApiError(
            400,
            "invalid_payload",
            f"{name} must be between {min_val} and {max_val}"
        )
    return result


def normalize_path_for_compare(value: str) -> str:
    """
    规范化路径用于比较
    Args:
        value: 路径值
    Returns:
        规范化后的路径
    """
    trimmed = value.strip()
    return str(Path(trimmed).resolve()) if trimmed else ""


def slugify(name: str) -> str:
    """
    将名称转换为 slug 格式

    Args:
        name: 名称

    Returns:
        slug 字符串
    """
    result = ""
    dash = False
    for char in name.strip().lower():
        if char.isalnum():
            result += char
            dash = False
        elif not dash:
            result += "-"
            dash = True
    return result.strip("-")
