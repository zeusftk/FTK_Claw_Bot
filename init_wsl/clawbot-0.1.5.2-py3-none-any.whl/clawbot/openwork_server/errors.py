"""
OpenWork Server 错误处理模块

定义 API 错误类型和错误格式化函数。"""

from typing import Any, Dict, Optional

from .types import ApiErrorBody


class ApiError(Exception):
    """API 错误类"""

    def __init__(
        self,
        status: int,
        code: str,
        message: str,
        details: Optional[Any] = None
    ):
        """
        初始化 API 错误

        Args:
            status: HTTP 状态码
            code: 错误代码
            message: 错误消息
            details: 错误详情
        """
        super().__init__(message)
        self.status = status
        self.code = code
        self.details = details

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        result = {
            "code": self.code,
            "message": str(self),
        }
        if self.details is not None:
            result["details"] = self.details
        return result


def format_error(err: ApiError) -> ApiErrorBody:
    """
    格式化 API 错误

    Args:
        err: API 错误实例

    Returns:
        API 错误响应体
    """
    return ApiErrorBody(
        code=err.code,
        message=str(err),
        details=err.details
    )


class NotFoundError(ApiError):
    """资源未找到错误"""

    def __init__(self, message: str = "Resource not found", code: str = "not_found"):
        super().__init__(404, code, message)


class UnauthorizedError(ApiError):
    """未授权错误"""

    def __init__(self, message: str = "Unauthorized", code: str = "unauthorized"):
        super().__init__(401, code, message)


class ForbiddenError(ApiError):
    """禁止访问错误"""

    def __init__(self, message: str = "Forbidden", code: str = "forbidden"):
        super().__init__(403, code, message)


class ValidationError(ApiError):
    """验证错误"""

    def __init__(
        self,
        message: str = "Validation failed",
        code: str = "validation_error",
        details: Optional[Any] = None
    ):
        super().__init__(400, code, message, details)


class InternalServerError(ApiError):
    """内部服务器错误"""

    def __init__(
        self,
        message: str = "Internal server error",
        code: str = "internal_error",
        details: Optional[Any] = None
    ):
        super().__init__(500, code, message, details)


class ServiceUnavailableError(ApiError):
    """服务不可用错误"""

    def __init__(
        self,
        message: str = "Service unavailable",
        code: str = "service_unavailable",
        details: Optional[Any] = None
    ):
        super().__init__(503, code, message, details)
