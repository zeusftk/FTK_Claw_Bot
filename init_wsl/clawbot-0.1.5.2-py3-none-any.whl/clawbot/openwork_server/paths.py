"""
路径安全检查模块
提供路径安全检查功能，防止路径遍历攻击。"""

import os

from .errors import ApiError


def assert_absolute(path: str) -> None:
    """
    断言路径是绝对路待
    Args:
        path: 要检查的路径

    Raises:
        ApiError: 如果路径不是绝对路径
    """
    if not os.path.isabs(path):
        raise ApiError(400, "invalid_path", "Path must be absolute")


async def resolve_within_root(root: str, *segments: str) -> str:
    """
    解析路径并确保在根目录内

    Args:
        root: 根目录路待        *segments: 路径片段

    Returns:
        解析后的绝对路径

    Raises:
        ApiError: 如果路径逃逸出根目录    """
    resolved_root = os.path.realpath(root)
    candidate = os.path.normpath(os.path.join(resolved_root, *segments))

    try:
        resolved_candidate = os.path.realpath(candidate)
    except OSError:
        resolved_candidate = candidate

    if resolved_candidate == resolved_root:
        return candidate

    if not resolved_candidate.startswith(resolved_root + os.sep):
        raise ApiError(400, "path_escape", "Path escapes workspace root")

    return candidate


def resolve_safe_child_path(parent: str, child: str) -> str:
    """
    安全地解析子路径

    Args:
        parent: 父目录路待        child: 子路径（相对路径：
    Returns:
        解析后的绝对路径

    Raises:
        ApiError: 如果子路径逃逸出父目录    """
    parent = os.path.realpath(parent)
    child_path = os.path.normpath(os.path.join(parent, child))

    if not child_path.startswith(parent + os.sep) and child_path != parent:
        raise ApiError(400, "path_escape", "Path escapes parent directory")

    return child_path


def normalize_workspace_relative_path(
    path: str,
    allow_subdirs: bool = False
) -> str:
    """
    规范化工作空间相对路待
    Args:
        path: 相对路径
        allow_subdirs: 是否允许子目录
    Returns:
        规范化后的相对路待
    Raises:
        ApiError: 如果路径无效或不允许子目录    """
    path = path.strip().replace("\\", "/")

    while path.startswith("/"):
        path = path[1:]

    while ".." in path:
        parts = path.split("/")
        new_parts = []
        for part in parts:
            if part == "..":
                if new_parts:
                    new_parts.pop()
                else:
                    raise ApiError(400, "invalid_path", "Path cannot escape workspace")
            else:
                new_parts.append(part)
        path = "/".join(new_parts)

    if not allow_subdirs and "/" in path:
        raise ApiError(400, "invalid_path", "Subdirectories are not allowed")

    return path
