"""
OpenWork Server HTTP 服务器模块

提供 HTTP API 服务器功能。"""

import json
import re
import time
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional, Tuple

from loguru import logger

from clawbot.constants import (
    DEFAULT_FILE_SIZE_LIMIT_BYTES,
    DEFAULT_PAGINATION_LIMIT,
    OPENCODE_DEFAULT_URL,
)

from .approvals import ApprovalService
from .config import ServerConfig
from .errors import ApiError, format_error
from .events import ReloadEventStore, SSEEventStore
from .session_manager import SessionManager
from .tokens import TokenService
from .types import Actor, Event, EventType, SessionStatus, TokenScope
from .utils import hash_token

SERVER_VERSION = "0.1.0"


@dataclass
class Route:
    """路由定义"""
    method: str
    pattern: str
    regex: re.Pattern
    param_names: List[str]
    auth: str
    handler: Callable


@dataclass
class RequestContext:
    """请求上下文"""
    request: Any
    path: str
    params: Dict[str, str]
    config: ServerConfig
    approvals: ApprovalService
    reload_events: ReloadEventStore
    tokens: TokenService
    actor: Optional[Actor] = None


class HTTPServer:
    """HTTP 服务器"""

    def __init__(self, config: ServerConfig):
        """
        初始化服务器

        Args:
            config: 服务器配置
        """
        self.config = config
        self.approvals = ApprovalService(config.approval)
        self.reload_events = ReloadEventStore()
        self.sse_events = SSEEventStore()
        self.sessions = SessionManager()
        self.tokens = TokenService(config)
        self.routes: List[Route] = []
        self._started_at = int(time.time() * 1000)

        # 任务管理器
        from .task_manager import OpenCodeTaskExecutor, TaskManager
        self.task_manager = TaskManager()

        # 设置任务执行器
        executor = OpenCodeTaskExecutor(
            opencode_base_url=getattr(config, 'opencode_base_url', None),
            opencode_cli_path=getattr(config, 'opencode_cli_path', None),
        )
        self.task_manager.set_executor(executor)

        self._setup_routes()

    def _setup_routes(self) -> None:
        """设置路由"""
        self._add_route("GET", "/health", "none", self._handle_health)
        self._add_route("GET", "/status", "client", self._handle_status)
        self._add_route("GET", "/capabilities", "client", self._handle_capabilities)
        self._add_route("GET", "/whoami", "client", self._handle_whoami)
        self._add_route("GET", "/workspaces", "client", self._handle_list_workspaces)

        self._add_route("GET", "/w/:id/health", "none", self._handle_health)
        self._add_route("GET", "/w/:id/status", "client", self._handle_workspace_status)
        self._add_route("GET", "/w/:id/capabilities", "client", self._handle_capabilities)
        self._add_route("GET", "/w/:id/workspaces", "client", self._handle_list_workspaces)
        self._add_route("POST", "/workspaces/:id/activate", "host", self._handle_activate_workspace)
        self._add_route("DELETE", "/workspaces/:id", "host", self._handle_delete_workspace)

        self._add_route("GET", "/tokens", "host", self._handle_list_tokens)
        self._add_route("POST", "/tokens", "host", self._handle_create_token)
        self._add_route("DELETE", "/tokens/:id", "host", self._handle_revoke_token)

        self._add_route("GET", "/workspace/:id/skills", "client", self._handle_list_skills)
        self._add_route("GET", "/workspace/:id/skills/:name", "client", self._handle_get_skill)
        self._add_route("POST", "/workspace/:id/skills", "client", self._handle_upsert_skill)
        self._add_route("DELETE", "/workspace/:id/skills/:name", "client", self._handle_delete_skill)

        self._add_route("GET", "/hub/skills", "client", self._handle_list_hub_skills)
        self._add_route("POST", "/workspace/:id/skills/hub/:name", "client", self._handle_install_hub_skill)

        self._add_route("GET", "/workspace/:id/plugins", "client", self._handle_list_plugins)
        self._add_route("POST", "/workspace/:id/plugins", "client", self._handle_add_plugin)
        self._add_route("DELETE", "/workspace/:id/plugins/:name", "client", self._handle_remove_plugin)

        self._add_route("GET", "/workspace/:id/mcp", "client", self._handle_list_mcp)
        self._add_route("POST", "/workspace/:id/mcp", "client", self._handle_add_mcp)
        self._add_route("DELETE", "/workspace/:id/mcp/:name", "client", self._handle_remove_mcp)

        self._add_route("GET", "/workspace/:id/commands", "client", self._handle_list_commands)
        self._add_route("POST", "/workspace/:id/commands", "client", self._handle_upsert_command)
        self._add_route("DELETE", "/workspace/:id/commands/:name", "client", self._handle_delete_command)

        self._add_route("GET", "/approvals", "host", self._handle_list_all_approvals)
        self._add_route("POST", "/approvals/:id", "host", self._handle_respond_global_approval)
        self._add_route("GET", "/workspace/:id/approvals", "host", self._handle_list_approvals)
        self._add_route("POST", "/workspace/:id/approvals/:requestId/respond", "host", self._handle_respond_approval)

        self._add_route("GET", "/workspace/:id/audit", "client", self._handle_get_audit)

        self._add_route("GET", "/workspace/:id/scheduler/jobs", "client", self._handle_list_jobs)
        self._add_route("DELETE", "/workspace/:id/scheduler/jobs/:name", "client", self._handle_delete_job)

        self._add_route("GET", "/workspace/:id/config", "client", self._handle_get_config)
        self._add_route("PATCH", "/workspace/:id/config", "client", self._handle_patch_config)

        self._add_route("GET", "/workspace/:id/files/content", "client", self._handle_get_file_content)
        self._add_route("POST", "/workspace/:id/files/content", "client", self._handle_write_file_content)

        self._add_route("POST", "/session", "client", self._handle_create_session)
        self._add_route("GET", "/session/:id", "client", self._handle_get_session)
        self._add_route("POST", "/session/:id/message", "client", self._handle_send_message)
        self._add_route("POST", "/session/:id/permissions/:permId", "client", self._handle_permission_response)
        self._add_route("GET", "/events", "client", self._handle_events_stream)
        self._add_route("GET", "/session/:id/events", "client", self._handle_session_events_stream)

        # OpenCode proxy routes - proxy to OpenCode CLI/Server
        self._add_route("POST", "/opencode/agents/:agent/messages", "client", self._handle_opencode_agent_message)
        self._add_route("GET", "/opencode/agents/:agent", "client", self._handle_opencode_agent_status)
        self._add_route("POST", "/opencode/sessions", "client", self._handle_opencode_create_session)
        self._add_route("GET", "/opencode/sessions/:id", "client", self._handle_opencode_session_status)
        self._add_route("POST", "/opencode/sessions/:id/messages", "client", self._handle_opencode_session_message)
        self._add_route("POST", "/opencode/execute", "client", self._handle_opencode_execute)

        # Task management routes - 任务管理 API
        self._add_route("POST", "/tasks", "client", self._handle_submit_task)
        self._add_route("GET", "/tasks", "client", self._handle_list_tasks)
        self._add_route("GET", "/tasks/stats", "client", self._handle_task_stats)
        self._add_route("GET", "/tasks/:id", "client", self._handle_get_task)
        self._add_route("POST", "/tasks/:id/start", "client", self._handle_start_task)
        self._add_route("DELETE", "/tasks/:id", "client", self._handle_cancel_task)
        self._add_route("GET", "/tasks/:id/progress", "client", self._handle_task_progress)
        self._add_route("GET", "/tasks/:id/events", "client", self._handle_task_events_stream)

        # Remote workspace management routes - 远程工作空间管理 API
        self._add_route("GET", "/remote/workspaces", "client", self._handle_list_remote_workspaces)
        self._add_route("POST", "/remote/workspaces", "client", self._handle_create_remote_workspace)
        self._add_route("GET", "/remote/workspaces/:id", "client", self._handle_get_remote_workspace)
        self._add_route("DELETE", "/remote/workspaces/:id", "client", self._handle_delete_remote_workspace)
        self._add_route("POST", "/remote/workspaces/:id/sync", "client", self._handle_sync_remote_workspace)
        self._add_route("GET", "/remote/workspaces/:id/files", "client", self._handle_list_remote_workspace_files)

    def _add_route(
        self,
        method: str,
        pattern: str,
        auth: str,
        handler: Callable
    ) -> None:
        """添加路由"""
        param_names = []
        regex_pattern = "^"
        parts = pattern.split("/")

        for part in parts:
            if not part:  # 跳过空字符串
                continue
            if part.startswith(":"):
                param_names.append(part[1:])
                regex_pattern += r"/([^/]+)"
            else:
                regex_pattern += f"/{re.escape(part)}"

        regex_pattern += "$"

        self.routes.append(Route(
            method=method,
            pattern=pattern,
            regex=re.compile(regex_pattern),
            param_names=param_names,
            auth=auth,
            handler=handler
        ))

    def _match_route(self, method: str, path: str) -> Optional[Tuple[Route, Dict[str, str]]]:
        """匹配路由"""
        for route in self.routes:
            if route.method != method:
                continue

            match = route.regex.match(path)
            if not match:
                continue

            params = {}
            for i, name in enumerate(route.param_names):
                params[name] = match.group(i + 1)

            return route, params

        return None

    async def _handle_request(
        self,
        method: str,
        path: str,
        headers: Dict[str, str],
        body: Optional[bytes] = None
    ) -> Tuple[int, Dict[str, Any], Dict[str, str]]:
        """
        处理请求

        Args:
            method: HTTP 方法
            path: 请求路径
            headers: 请求头
            body: 请求体
        Returns:
            (状态码, 响应体, 响应头)
        """
        response_headers = {}

        try:
            matched = self._match_route(method, path)
            if not matched:
                return 404, {"code": "not_found", "message": "Not found"}, response_headers

            route, params = matched

            actor = None
            if route.auth == "client":
                actor = await self._require_client(headers)
            elif route.auth == "host":
                actor = await self._require_host(headers)

            parsed_body = None
            if body:
                try:
                    parsed_body = json.loads(body.decode("utf-8"))
                except json.JSONDecodeError:
                    pass

            context = RequestContext(
                request={"headers": headers, "body": parsed_body},
                path=path,
                params=params,
                config=self.config,
                approvals=self.approvals,
                reload_events=self.reload_events,
                tokens=self.tokens,
                actor=actor
            )

            result = await route.handler(context)

            return 200, result, response_headers

        except ApiError as e:
            return e.status, format_error(e).__dict__, response_headers
        except Exception as e:
            return 500, {"code": "internal_error", "message": str(e)}, response_headers

    def _get_header(self, headers: Dict[str, str], name: str) -> str | None:
        """大小写不敏感地获取 header"""
        # 先尝试小写
        value = headers.get(name.lower())
        if value is not None:
            return value
        # 再尝试原始名称
        value = headers.get(name)
        if value is not None:
            return value
        # 遍历所有 key
        for key, val in headers.items():
            if key.lower() == name.lower():
                return val
        return None

    async def _require_client(self, headers: Dict[str, str]) -> Actor:
        """验证客户端 Token"""
        # 首先检查 host token
        host_token = self._get_header(headers, "x-openwork-host-token")
        if host_token and host_token == self.config.host_token:
            return Actor(type="host", token_hash=hash_token(host_token), scope=TokenScope.OWNER)

        # 然后检查 bearer token
        auth_header = self._get_header(headers, "authorization") or ""
        match = re.match(r"^Bearer\s+(.+)$", auth_header, re.IGNORECASE)
        token = match.group(1) if match else None

        if not token:
            raise ApiError(401, "unauthorized", "Invalid bearer token")

        scope = await self.tokens.scope_for_token(token)
        if not scope:
            raise ApiError(401, "unauthorized", "Invalid bearer token")

        client_id = self._get_header(headers, "x-openwork-client-id")
        return Actor(
            type="remote",
            client_id=client_id,
            token_hash=hash_token(token),
            scope=scope
        )

    async def _require_host(self, headers: Dict[str, str]) -> Actor:
        """验证主机 Token"""
        host_token = self._get_header(headers, "x-openwork-host-token")

        if host_token and host_token == self.config.host_token:
            return Actor(type="host", token_hash=hash_token(host_token), scope=TokenScope.OWNER)

        auth_header = self._get_header(headers, "authorization") or ""
        match = re.match(r"^Bearer\s+(.+)$", auth_header, re.IGNORECASE)
        bearer = match.group(1) if match else None

        if not bearer:
            raise ApiError(401, "unauthorized", "Invalid host token")

        scope = await self.tokens.scope_for_token(bearer)
        if scope != TokenScope.OWNER:
            raise ApiError(401, "unauthorized", "Invalid host token")

        client_id = self._get_header(headers, "x-openwork-client-id")
        return Actor(
            type="remote",
            client_id=client_id,
            token_hash=hash_token(bearer),
            scope=scope
        )

    async def _handle_health(self, ctx: RequestContext) -> Dict[str, Any]:
        """健康检查"""
        return {
            "ok": True,
            "version": SERVER_VERSION,
            "uptimeMs": int(time.time() * 1000) - self._started_at
        }

    async def _handle_status(self, ctx: RequestContext) -> Dict[str, Any]:
        """服务器状态"""
        active = self.config.workspaces[0] if self.config.workspaces else None
        return {
            "ok": True,
            "version": SERVER_VERSION,
            "uptimeMs": int(time.time() * 1000) - self._started_at,
            "readOnly": self.config.read_only,
            "approval": {
                "mode": self.config.approval.mode.value,
                "timeoutMs": self.config.approval.timeout_ms
            },
            "corsOrigins": self.config.cors_origins,
            "workspaceCount": len(self.config.workspaces),
            "activeWorkspaceId": active.id if active else None
        }

    async def _handle_capabilities(self, ctx: RequestContext) -> Dict[str, Any]:
        """服务器能力"""
        write_enabled = not self.config.read_only
        return {
            "schemaVersion": 1,
            "serverVersion": SERVER_VERSION,
            "skills": {"read": True, "write": write_enabled, "source": "openwork"},
            "plugins": {"read": True, "write": write_enabled},
            "mcp": {"read": True, "write": write_enabled},
            "commands": {"read": True, "write": write_enabled},
            "config": {"read": True, "write": write_enabled},
            "approvals": {
                "mode": self.config.approval.mode.value,
                "timeoutMs": self.config.approval.timeout_ms
            },
            "tokens": {"scoped": True, "scopes": ["owner", "collaborator", "viewer"]}
        }

    async def _handle_whoami(self, ctx: RequestContext) -> Dict[str, Any]:
        """获取当前用户信息"""
        return {
            "ok": True,
            "actor": {
                "type": ctx.actor.type if ctx.actor else None,
                "scope": ctx.actor.scope.value if ctx.actor and ctx.actor.scope else None
            }
        }

    async def _handle_list_workspaces(self, ctx: RequestContext) -> Dict[str, Any]:
        """列出工作空间"""
        from .workspaces import serialize_workspace

        active = self.config.workspaces[0] if self.config.workspaces else None
        items = [serialize_workspace(w) for w in self.config.workspaces]
        return {
            "items": items,
            "activeId": active.id if active else None
        }

    async def _handle_list_tokens(self, ctx: RequestContext) -> Dict[str, Any]:
        """列出 Token"""
        items = await self.tokens.list()
        return {"items": items}

    async def _handle_create_token(self, ctx: RequestContext) -> Dict[str, Any]:
        """创建 Token"""
        body = ctx.request.get("body", {})
        scope_str = body.get("scope", "").strip()

        if scope_str not in ("owner", "collaborator", "viewer"):
            raise ApiError(400, "invalid_scope", "Token scope must be owner, collaborator, or viewer")

        scope = TokenScope(scope_str)
        label = body.get("label", "").strip() if body.get("label") else None

        result = await self.tokens.create(scope, label)
        return result

    async def _handle_revoke_token(self, ctx: RequestContext) -> Dict[str, Any]:
        """撤销 Token"""
        token_id = ctx.params.get("id", "")
        ok = await self.tokens.revoke(token_id)

        if not ok:
            raise ApiError(404, "token_not_found", "Token not found")

        return {"ok": True}

    async def _handle_list_skills(self, ctx: RequestContext) -> Dict[str, Any]:
        """列出技能"""
        from .skills import list_skills
        from .workspaces import resolve_workspace

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        skills = await list_skills(workspace.path, include_global=True)

        return {
            "items": [
                {
                    "name": s.name,
                    "description": s.description,
                    "path": s.path,
                    "scope": s.scope,
                    "trigger": s.trigger
                }
                for s in skills
            ]
        }

    async def _handle_upsert_skill(self, ctx: RequestContext) -> Dict[str, Any]:
        """创建或更新技能"""
        from .skills import upsert_skill
        from .workspaces import resolve_workspace

        if self.config.read_only:
            raise ApiError(403, "read_only", "Server is in read-only mode")

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        body = ctx.request.get("body", {})

        result = await upsert_skill(workspace.path, body)
        return result

    async def _handle_delete_skill(self, ctx: RequestContext) -> Dict[str, Any]:
        """删除技能"""
        from .skills import delete_skill
        from .workspaces import resolve_workspace

        if self.config.read_only:
            raise ApiError(403, "read_only", "Server is in read-only mode")

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        name = ctx.params.get("name", "")

        result = await delete_skill(workspace.path, name)
        return result

    async def _handle_list_plugins(self, ctx: RequestContext) -> Dict[str, Any]:
        """列出插件"""
        from .plugins import list_plugins
        from .workspaces import resolve_workspace

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        result = await list_plugins(workspace.path, include_global=True)

        return {
            "items": [
                {
                    "spec": p.spec,
                    "source": p.source,
                    "scope": p.scope,
                    "path": p.path
                }
                for p in result["items"]
            ],
            "loadOrder": result["loadOrder"]
        }

    async def _handle_add_plugin(self, ctx: RequestContext) -> Dict[str, Any]:
        """添加插件"""
        from .plugins import add_plugin
        from .workspaces import resolve_workspace

        if self.config.read_only:
            raise ApiError(403, "read_only", "Server is in read-only mode")

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        body = ctx.request.get("body", {})
        spec = body.get("spec", "")

        ok = await add_plugin(workspace.path, spec)
        return {"ok": ok, "added": ok}

    async def _handle_remove_plugin(self, ctx: RequestContext) -> Dict[str, Any]:
        """移除插件"""
        from .plugins import remove_plugin
        from .workspaces import resolve_workspace

        if self.config.read_only:
            raise ApiError(403, "read_only", "Server is in read-only mode")

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        name = ctx.params.get("name", "")

        ok = await remove_plugin(workspace.path, name)
        return {"ok": ok, "removed": ok}

    async def _handle_list_mcp(self, ctx: RequestContext) -> Dict[str, Any]:
        """列出 MCP"""
        from .mcp import list_mcp
        from .workspaces import resolve_workspace

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        items = await list_mcp(workspace.path)

        return {
            "items": [
                {
                    "name": m.name,
                    "config": m.config,
                    "source": m.source,
                    "disabledByTools": m.disabled_by_tools
                }
                for m in items
            ]
        }

    async def _handle_add_mcp(self, ctx: RequestContext) -> Dict[str, Any]:
        """添加 MCP"""
        from .mcp import add_mcp
        from .workspaces import resolve_workspace

        if self.config.read_only:
            raise ApiError(403, "read_only", "Server is in read-only mode")

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        body = ctx.request.get("body", {})
        name = body.get("name", "")
        config = body.get("config", {})

        result = await add_mcp(workspace.path, name, config)
        return result

    async def _handle_remove_mcp(self, ctx: RequestContext) -> Dict[str, Any]:
        """移除 MCP"""
        from .mcp import remove_mcp
        from .workspaces import resolve_workspace

        if self.config.read_only:
            raise ApiError(403, "read_only", "Server is in read-only mode")

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        name = ctx.params.get("name", "")

        ok = await remove_mcp(workspace.path, name)
        return {"ok": ok, "removed": ok}

    async def _handle_list_commands(self, ctx: RequestContext) -> Dict[str, Any]:
        """列出命令"""
        from .commands import list_commands
        from .workspaces import resolve_workspace

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        commands = await list_commands(workspace.path, scope="workspace")

        return {
            "items": [
                {
                    "name": c.name,
                    "description": c.description,
                    "template": c.template,
                    "agent": c.agent,
                    "model": c.model,
                    "subtask": c.subtask,
                    "scope": c.scope
                }
                for c in commands
            ]
        }

    async def _handle_upsert_command(self, ctx: RequestContext) -> Dict[str, Any]:
        """创建或更新命令"""
        from .commands import upsert_command
        from .workspaces import resolve_workspace

        if self.config.read_only:
            raise ApiError(403, "read_only", "Server is in read-only mode")

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        body = ctx.request.get("body", {})

        path = await upsert_command(workspace.path, body)
        return {"ok": True, "path": path}

    async def _handle_delete_command(self, ctx: RequestContext) -> Dict[str, Any]:
        """删除命令"""
        from .commands import delete_command
        from .workspaces import resolve_workspace

        if self.config.read_only:
            raise ApiError(403, "read_only", "Server is in read-only mode")

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        name = ctx.params.get("name", "")

        await delete_command(workspace.path, name)
        return {"ok": True}

    async def _handle_list_approvals(self, ctx: RequestContext) -> Dict[str, Any]:
        """列出待处理审批"""
        requests = self.approvals.list()
        return {
            "items": [
                {
                    "id": r.id,
                    "workspaceId": r.workspace_id,
                    "action": r.action,
                    "summary": r.summary,
                    "paths": r.paths,
                    "createdAt": r.created_at
                }
                for r in requests
            ]
        }

    async def _handle_respond_approval(self, ctx: RequestContext) -> Dict[str, Any]:
        """响应审批"""
        request_id = ctx.params.get("requestId", "")
        body = ctx.request.get("body", {})
        reply = body.get("reply", "")

        if reply not in ("allow", "deny"):
            raise ApiError(400, "invalid_reply", "Reply must be 'allow' or 'deny'")

        result = self.approvals.respond(request_id, reply)
        if not result:
            raise ApiError(404, "approval_not_found", "Approval request not found")

        return {
            "ok": True,
            "id": result.id,
            "allowed": result.allowed,
            "reason": result.reason
        }

    async def _handle_list_jobs(self, ctx: RequestContext) -> Dict[str, Any]:
        """列出计划任务"""
        from .scheduler import list_scheduled_jobs
        from .workspaces import resolve_workspace

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        jobs = await list_scheduled_jobs(workdir=workspace.path)

        return {
            "items": [
                {
                    "slug": j.slug,
                    "name": j.name,
                    "schedule": j.schedule,
                    "createdAt": j.created_at,
                    "lastRunAt": j.last_run_at,
                    "lastRunStatus": j.last_run_status
                }
                for j in jobs
            ]
        }

    async def _handle_delete_job(self, ctx: RequestContext) -> Dict[str, Any]:
        """删除计划任务"""
        from .scheduler import delete_scheduled_job, resolve_scheduled_job
        from .workspaces import resolve_workspace

        if self.config.read_only:
            raise ApiError(403, "read_only", "Server is in read-only mode")

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        name = ctx.params.get("name", "")

        result = await resolve_scheduled_job(name, workdir=workspace.path)
        await delete_scheduled_job(result["job"], result["jobFile"])

        return {"ok": True}

    async def _handle_get_config(self, ctx: RequestContext) -> Dict[str, Any]:
        """获取配置"""
        from .utils import read_json_file
        from .workspace_files import opencode_config_path, openwork_config_path
        from .workspaces import resolve_workspace

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))

        opencode_config = await read_json_file(opencode_config_path(workspace.path))
        openwork_config = await read_json_file(openwork_config_path(workspace.path))

        return {
            "opencode": opencode_config or {},
            "openwork": openwork_config or {}
        }

    async def _handle_patch_config(self, ctx: RequestContext) -> Dict[str, Any]:
        """更新配置"""
        from .utils import read_json_file, write_json_file
        from .workspace_files import opencode_config_path, openwork_config_path
        from .workspaces import resolve_workspace

        if self.config.read_only:
            raise ApiError(403, "read_only", "Server is in read-only mode")

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        body = ctx.request.get("body", {})

        opencode_updates = body.get("opencode")
        openwork_updates = body.get("openwork")

        if opencode_updates:
            config = await read_json_file(opencode_config_path(workspace.path)) or {}
            config.update(opencode_updates)
            await write_json_file(opencode_config_path(workspace.path), config)

        if openwork_updates:
            config = await read_json_file(openwork_config_path(workspace.path)) or {}
            config.update(openwork_updates)
            await write_json_file(openwork_config_path(workspace.path), config)

        return {"ok": True, "updatedAt": int(time.time() * 1000)}

    async def _handle_workspace_status(self, ctx: RequestContext) -> Dict[str, Any]:
        """工作空间状态"""
        from .workspaces import resolve_workspace, serialize_workspace

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        return {
            "ok": True,
            "version": SERVER_VERSION,
            "uptimeMs": int(time.time() * 1000) - self._started_at,
            "readOnly": self.config.read_only,
            "approval": {
                "mode": self.config.approval.mode.value,
                "timeoutMs": self.config.approval.timeout_ms
            },
            "workspace": serialize_workspace(workspace),
        }

    async def _handle_activate_workspace(self, ctx: RequestContext) -> Dict[str, Any]:
        """激活工作空间"""
        from .workspaces import resolve_workspace, serialize_workspace

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))

        for i, w in enumerate(self.config.workspaces):
            if w.id == workspace.id:
                self.config.workspaces.pop(i)
                self.config.workspaces.insert(0, w)
                break

        return {"activeId": workspace.id, "workspace": serialize_workspace(workspace)}

    async def _handle_delete_workspace(self, ctx: RequestContext) -> Dict[str, Any]:
        """删除工作空间"""
        from .workspaces import resolve_workspace, serialize_workspace

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))

        self.config.workspaces = [w for w in self.config.workspaces if w.id != workspace.id]

        active = self.config.workspaces[0] if self.config.workspaces else None
        return {
            "ok": True,
            "deleted": True,
            "activeId": active.id if active else None,
            "items": [serialize_workspace(w) for w in self.config.workspaces]
        }

    async def _handle_get_skill(self, ctx: RequestContext) -> Dict[str, Any]:
        """获取技能详情"""
        from dataclasses import asdict

        from .skills import list_skills
        from .workspaces import resolve_workspace

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        name = ctx.params.get("name", "")

        skills = await list_skills(workspace.path, include_global=True)
        skill = next((s for s in skills if s.name == name), None)

        if not skill:
            raise ApiError(404, "skill_not_found", f"Skill not found: {name}")

        try:
            import aiofiles
            async with aiofiles.open(skill.path, "r", encoding="utf-8") as f:
                content = await f.read()
        except (ImportError, OSError, IOError) as e:
            logger.debug(f"Falling back to sync read for {skill.path}: {e}")
            with open(skill.path, "r", encoding="utf-8") as f:
                content = f.read()

        return {"item": asdict(skill), "content": content}

    async def _handle_list_hub_skills(self, ctx: RequestContext) -> Dict[str, Any]:
        """列出 Hub 技能"""

        from .skill_hub import list_hub_skills

        skills = await list_hub_skills()
        return {
            "items": [
                {
                    "name": s.name,
                    "description": s.description,
                    "trigger": s.trigger,
                    "source": s.source
                }
                for s in skills
            ]
        }

    async def _handle_install_hub_skill(self, ctx: RequestContext) -> Dict[str, Any]:
        """安装 Hub 技能"""
        from .skill_hub import install_hub_skill
        from .workspaces import resolve_workspace

        if self.config.read_only:
            raise ApiError(403, "read_only", "Server is in read-only mode")

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        name = ctx.params.get("name", "")
        body = ctx.request.get("body", {})
        overwrite = body.get("overwrite", False)

        result = await install_hub_skill(workspace.path, name, overwrite)
        return {
            "ok": True,
            "name": result.name,
            "path": result.path,
            "action": result.action,
            "written": result.written,
            "skipped": result.skipped
        }

    async def _handle_list_all_approvals(self, ctx: RequestContext) -> Dict[str, Any]:
        """列出所有待处理审批"""
        requests = self.approvals.list()
        return {
            "items": [
                {
                    "id": r.id,
                    "workspaceId": r.workspace_id,
                    "action": r.action,
                    "summary": r.summary,
                    "paths": r.paths,
                    "createdAt": r.created_at
                }
                for r in requests
            ]
        }

    async def _handle_respond_global_approval(self, ctx: RequestContext) -> Dict[str, Any]:
        """响应全局审批"""
        request_id = ctx.params.get("id", "")
        body = ctx.request.get("body", {})
        reply = body.get("reply", "")

        if reply not in ("allow", "deny"):
            raise ApiError(400, "invalid_reply", "Reply must be 'allow' or 'deny'")

        result = self.approvals.respond(request_id, reply)
        if not result:
            raise ApiError(404, "approval_not_found", "Approval request not found")

        return {
            "ok": True,
            "id": result.id,
            "allowed": result.allowed,
            "reason": result.reason
        }

    async def _handle_get_audit(self, ctx: RequestContext) -> Dict[str, Any]:
        """获取审计日志"""
        from dataclasses import asdict

        from .audit import read_audit_entries
        from .workspaces import resolve_workspace

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))

        query = ctx.request.get("query", {})
        limit_param = query.get("limit", str(DEFAULT_PAGINATION_LIMIT)) if isinstance(query, dict) else str(DEFAULT_PAGINATION_LIMIT)
        try:
            limit = min(int(limit_param), 200)
        except ValueError:
            limit = DEFAULT_PAGINATION_LIMIT

        items = await read_audit_entries(workspace.path, workspace.id, limit)
        return {"items": [asdict(item) for item in items]}

    async def _handle_get_file_content(self, ctx: RequestContext) -> Dict[str, Any]:
        """获取文件内容"""
        import os

        from .paths import resolve_safe_child_path
        from .utils import exists
        from .workspaces import resolve_workspace

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        query = ctx.request.get("query", {})
        requested_path = query.get("path", "").strip() if isinstance(query, dict) else ""

        if not requested_path:
            raise ApiError(400, "invalid_path", "Path is required")

        relative_path = os.path.normpath(requested_path)
        lowered = relative_path.lower()

        if not (lowered.endswith(".md") or lowered.endswith(".mdx") or lowered.endswith(".markdown")):
            raise ApiError(400, "invalid_path", "Only markdown files are supported")

        abs_path = resolve_safe_child_path(workspace.path, relative_path)

        if not await exists(abs_path):
            raise ApiError(404, "file_not_found", "File not found")

        stat = os.stat(abs_path)
        if not os.path.isfile(abs_path):
            raise ApiError(404, "file_not_found", "File not found")

        max_bytes = DEFAULT_FILE_SIZE_LIMIT_BYTES
        if stat.st_size > max_bytes:
            raise ApiError(413, "file_too_large", "File exceeds size limit", {"maxBytes": max_bytes, "size": stat.st_size})

        try:
            import aiofiles
            async with aiofiles.open(abs_path, "r", encoding="utf-8") as f:
                content = await f.read()
        except (ImportError, OSError, IOError) as e:
            logger.debug(f"Falling back to sync read for {abs_path}: {e}")
            with open(abs_path, "r", encoding="utf-8") as f:
                content = f.read()

        return {
            "path": relative_path,
            "content": content,
            "bytes": len(content.encode("utf-8")),
            "updatedAt": int(stat.st_mtime * 1000)
        }

    async def _handle_write_file_content(self, ctx: RequestContext) -> Dict[str, Any]:
        """写入文件内容"""
        import os

        from .paths import resolve_safe_child_path
        from .utils import ensure_dir
        from .workspaces import resolve_workspace

        if self.config.read_only:
            raise ApiError(403, "read_only", "Server is in read-only mode")

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        body = ctx.request.get("body", {})

        requested_path = str(body.get("path", ""))
        relative_path = os.path.normpath(requested_path)
        lowered = relative_path.lower()

        if not (lowered.endswith(".md") or lowered.endswith(".mdx") or lowered.endswith(".markdown")):
            raise ApiError(400, "invalid_path", "Only markdown files are supported")

        content = body.get("content")
        if not isinstance(content, str):
            raise ApiError(400, "invalid_payload", "content must be a string")

        bytes_len = len(content.encode("utf-8"))
        max_bytes = DEFAULT_FILE_SIZE_LIMIT_BYTES
        if bytes_len > max_bytes:
            raise ApiError(413, "file_too_large", "File exceeds size limit", {"maxBytes": max_bytes, "size": bytes_len})

        abs_path = resolve_safe_child_path(workspace.path, relative_path)

        await ensure_dir(os.path.dirname(abs_path))

        try:
            import aiofiles
            async with aiofiles.open(abs_path, "w", encoding="utf-8") as f:
                await f.write(content)
        except (ImportError, OSError, IOError) as e:
            logger.debug(f"Falling back to sync write for {abs_path}: {e}")
            with open(abs_path, "w", encoding="utf-8") as f:
                f.write(content)

        stat = os.stat(abs_path)
        return {"ok": True, "path": relative_path, "bytes": bytes_len, "updatedAt": int(stat.st_mtime * 1000)}

    async def _handle_create_session(self, ctx: RequestContext) -> Dict[str, Any]:
        """创建编程会话"""
        body = ctx.request.get("body", {})
        title = body.get("title", "Untitled Session")
        cwd = body.get("cwd", ".")

        session = await self.sessions.create(title=title, cwd=cwd)

        return {
            "id": session.id,
            "title": session.title,
            "cwd": session.cwd,
            "status": session.status.value,
            "createdAt": session.created_at,
            "updatedAt": session.updated_at,
        }

    async def _handle_get_session(self, ctx: RequestContext) -> Dict[str, Any]:
        """获取会话状态"""
        session_id = ctx.params.get("id", "")
        session = await self.sessions.get(session_id)

        if not session:
            raise ApiError(404, "session_not_found", f"Session not found: {session_id}")

        return {
            "id": session.id,
            "title": session.title,
            "cwd": session.cwd,
            "status": session.status.value,
            "createdAt": session.created_at,
            "updatedAt": session.updated_at,
            "messageCount": len(session.messages),
            "pendingPermissions": list(session.pending_permissions.keys()),
        }

    async def _handle_send_message(self, ctx: RequestContext) -> Dict[str, Any]:
        """发送消息到会话"""
        session_id = ctx.params.get("id", "")
        body = ctx.request.get("body", {})
        parts = body.get("parts", [])

        session = await self.sessions.get(session_id)
        if not session:
            raise ApiError(404, "session_not_found", f"Session not found: {session_id}")

        message = {
            "role": "user",
            "parts": parts,
            "timestamp": int(time.time() * 1000),
        }

        await self.sessions.add_message(session_id, message)
        await self.sessions.update_status(session_id, SessionStatus.RUNNING)

        await self.sse_events.publish(Event(
            type=EventType.PROGRESS,
            session_id=session_id,
            data={"message": "Task received", "status": "running"},
        ))

        return {
            "ok": True,
            "sessionId": session_id,
            "messageId": str(len(session.messages)),
        }

    async def _handle_permission_response(self, ctx: RequestContext) -> Dict[str, Any]:
        """响应权限请求"""
        session_id = ctx.params.get("id", "")
        perm_id = ctx.params.get("permId", "")
        body = ctx.request.get("body", {})
        response = body.get("response", "")

        if response not in ("allow", "deny"):
            raise ApiError(400, "invalid_response", "Response must be 'allow' or 'deny'")

        session = await self.sessions.get(session_id)
        if not session:
            raise ApiError(404, "session_not_found", f"Session not found: {session_id}")

        result = await self.sessions.resolve_permission(session_id, perm_id, response)
        if not result:
            raise ApiError(404, "permission_not_found", f"Permission request not found: {perm_id}")

        await self.sse_events.publish(Event(
            type=EventType.PROGRESS,
            session_id=session_id,
            data={"message": f"Permission {perm_id} resolved: {response}"},
        ))

        return {
            "ok": True,
            "permissionId": perm_id,
            "response": response,
        }

    # ========== OpenCode Proxy Handlers ==========

    async def _proxy_to_opencode(
        self,
        method: str,
        path: str,
        body: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        代理请求到 OpenCode CLI/Server

        Args:
            method: HTTP 方法
            path: 请求路径
            body: 请求体

        Returns:
            OpenCode 响应
        """
        import aiohttp

        opencode_url = getattr(self.config, 'opencode_base_url', OPENCODE_DEFAULT_URL)

        if not opencode_url:
            return await self._execute_via_opencode_cli(path, body)

        try:
            async with aiohttp.ClientSession() as session:
                url = f"{opencode_url.rstrip('/')}{path}"
                kwargs = {"timeout": aiohttp.ClientTimeout(total=300)}

                if body:
                    kwargs["json"] = body

                async with session.request(method, url, **kwargs) as resp:
                    if resp.status == 200:
                        return await resp.json()
                    else:
                        text = await resp.text()
                        raise ApiError(
                            resp.status,
                            "opencode_error",
                            f"OpenCode request failed: {text}"
                        )
        except aiohttp.ClientError:
            # 降级到 CLI 执行
            return await self._execute_via_opencode_cli(path, body)

    async def _execute_via_opencode_cli(
        self,
        path: str,
        body: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        通过 OpenCode CLI 执行命令

        Args:
            path: 请求路径
            body: 请求体

        Returns:
            执行结果
        """
        import asyncio
        import json
        import shutil

        # 检查 opencode CLI 是否可用
        opencode_bin = shutil.which("opencode")
        if not opencode_bin:
            raise ApiError(
                503,
                "opencode_not_available",
                "OpenCode CLI not found. Please install opencode or configure opencode_base_url."
            )

        # 解析请求
        content = body.get("content", "") if body else ""
        workspace = body.get("workspace", ".") if body else "."

        try:
            proc = await asyncio.create_subprocess_exec(
                opencode_bin,
                "-p", content,
                "-f", "json",
                "-q",
                cwd=workspace,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )

            stdout, stderr = await asyncio.wait_for(
                proc.communicate(),
                timeout=300
            )

            if proc.returncode == 0:
                try:
                    return json.loads(stdout.decode("utf-8"))
                except json.JSONDecodeError:
                    return {
                        "ok": True,
                        "output": stdout.decode("utf-8"),
                        "method": "cli",
                    }
            else:
                raise ApiError(
                    500,
                    "opencode_cli_error",
                    f"OpenCode CLI failed: {stderr.decode('utf-8')}"
                )
        except asyncio.TimeoutError:
            raise ApiError(504, "timeout", "OpenCode CLI execution timed out")

    async def _handle_opencode_agent_message(self, ctx: RequestContext) -> Dict[str, Any]:
        """
        发送消息到 OpenCode Agent

        POST /opencode/agents/:agent/messages
        """
        agent = ctx.params.get("agent", "default")
        body = ctx.request.get("body", {})

        return await self._proxy_to_opencode(
            "POST",
            f"/agents/{agent}/messages",
            body
        )

    async def _handle_opencode_agent_status(self, ctx: RequestContext) -> Dict[str, Any]:
        """
        获取 OpenCode Agent 状态

        GET /opencode/agents/:agent
        """
        agent = ctx.params.get("agent", "default")
        return await self._proxy_to_opencode("GET", f"/agents/{agent}")

    async def _handle_opencode_create_session(self, ctx: RequestContext) -> Dict[str, Any]:
        """
        创建 OpenCode 会话

        POST /opencode/sessions
        """
        body = ctx.request.get("body", {})
        return await self._proxy_to_opencode("POST", "/sessions", body)

    async def _handle_opencode_session_status(self, ctx: RequestContext) -> Dict[str, Any]:
        """
        获取 OpenCode 会话状态

        GET /opencode/sessions/:id
        """
        session_id = ctx.params.get("id", "")
        return await self._proxy_to_opencode("GET", f"/sessions/{session_id}")

    async def _handle_opencode_session_message(self, ctx: RequestContext) -> Dict[str, Any]:
        """
        发送消息到 OpenCode 会话

        POST /opencode/sessions/:id/messages
        """
        session_id = ctx.params.get("id", "")
        body = ctx.request.get("body", {})
        return await self._proxy_to_opencode("POST", f"/sessions/{session_id}/messages", body)

    async def _handle_opencode_execute(self, ctx: RequestContext) -> Dict[str, Any]:
        """
        执行 OpenCode 命令

        POST /opencode/execute
        """
        body = ctx.request.get("body", {})
        return await self._proxy_to_opencode("POST", "/execute", body)

    # ========== Task Management Handlers ==========

    async def _handle_submit_task(self, ctx: RequestContext) -> Dict[str, Any]:
        """
        提交任务

        POST /tasks
        """
        from dataclasses import asdict

        from .task_manager import TaskSubmitRequest
        from .types import TaskPriority, TaskType

        if self.config.read_only:
            raise ApiError(403, "read_only", "Server is in read-only mode")

        body = ctx.request.get("body", {})

        # 解析请求
        request = TaskSubmitRequest(
            prompt=body.get("prompt", ""),
            title=body.get("title"),
            type=TaskType(body.get("type", "custom")),
            priority=TaskPriority(body.get("priority", "normal")),
            workspace_id=body.get("workspace_id"),
            workspace_path=body.get("workspace_path"),
            files=body.get("files"),
            context=body.get("context"),
            env=body.get("env"),
            timeout_ms=body.get("timeout_ms"),
            tags=body.get("tags"),
            parent_task_id=body.get("parent_task_id"),
            auto_start=body.get("auto_start", True),
        )

        if not request.prompt:
            raise ApiError(400, "invalid_request", "prompt is required")

        task = await self.task_manager.submit(request)

        return {
            "ok": True,
            "task": asdict(task),
        }

    async def _handle_list_tasks(self, ctx: RequestContext) -> Dict[str, Any]:
        """
        列出任务

        GET /tasks?status=running&workspace_id=xxx&limit=50&offset=0
        """
        from dataclasses import asdict

        from .types import TaskStatus

        query = ctx.request.get("query", {})
        status_str = query.get("status")
        status = TaskStatus(status_str) if status_str else None
        workspace_id = query.get("workspace_id")
        limit = int(query.get("limit", "50"))
        offset = int(query.get("offset", "0"))

        tasks = await self.task_manager.list(
            status=status,
            workspace_id=workspace_id,
            limit=limit,
            offset=offset,
        )

        return {
            "ok": True,
            "tasks": [asdict(t) for t in tasks],
            "total": len(tasks),
        }

    async def _handle_task_stats(self, ctx: RequestContext) -> Dict[str, Any]:
        """
        获取任务统计

        GET /tasks/stats
        """
        return {
            "ok": True,
            "stats": self.task_manager.stats(),
        }

    async def _handle_get_task(self, ctx: RequestContext) -> Dict[str, Any]:
        """
        获取任务详情

        GET /tasks/:id
        """
        from dataclasses import asdict

        task_id = ctx.params.get("id", "")
        task = await self.task_manager.get(task_id)

        if not task:
            raise ApiError(404, "task_not_found", f"Task not found: {task_id}")

        return {
            "ok": True,
            "task": asdict(task),
        }

    async def _handle_start_task(self, ctx: RequestContext) -> Dict[str, Any]:
        """
        启动任务

        POST /tasks/:id/start
        """
        from dataclasses import asdict

        if self.config.read_only:
            raise ApiError(403, "read_only", "Server is in read-only mode")

        task_id = ctx.params.get("id", "")
        task = await self.task_manager.start(task_id)

        if not task:
            raise ApiError(400, "cannot_start", f"Cannot start task: {task_id}")

        return {
            "ok": True,
            "task": asdict(task),
        }

    async def _handle_cancel_task(self, ctx: RequestContext) -> Dict[str, Any]:
        """
        取消任务

        DELETE /tasks/:id
        """
        from dataclasses import asdict

        task_id = ctx.params.get("id", "")
        task = await self.task_manager.cancel(task_id)

        if not task:
            raise ApiError(400, "cannot_cancel", f"Cannot cancel task: {task_id}")

        return {
            "ok": True,
            "task": asdict(task),
        }

    async def _handle_task_progress(self, ctx: RequestContext) -> Dict[str, Any]:
        """
        获取任务进度

        GET /tasks/:id/progress
        """
        from dataclasses import asdict

        task_id = ctx.params.get("id", "")
        progress = await self.task_manager.get_progress(task_id)

        if not progress:
            raise ApiError(404, "task_not_found", f"Task not found: {task_id}")

        return {
            "ok": True,
            "progress": asdict(progress),
        }

    async def _handle_task_events_stream(self, ctx: RequestContext) -> Dict[str, Any]:
        """
        任务事件流

        GET /tasks/:id/events
        """
        task_id = ctx.params.get("id", "")
        task = await self.task_manager.get(task_id)

        if not task:
            raise ApiError(404, "task_not_found", f"Task not found: {task_id}")

        return {"_sse_stream": True, "_session_id": task_id}

    # ========== Remote Workspace Handlers ==========

    async def _handle_list_remote_workspaces(self, ctx: RequestContext) -> Dict[str, Any]:
        """
        列出远程工作空间

        GET /remote/workspaces
        """
        from .workspaces import list_workspaces

        workspaces = list_workspaces(self.config)

        return {
            "ok": True,
            "workspaces": [
                {
                    "id": w.id,
                    "name": w.name,
                    "path": w.path,
                    "status": "active" if (self.config.workspaces and w.id == self.config.workspaces[0].id) else "inactive",
                    "createdAt": int(time.time() * 1000),
                    "updatedAt": int(time.time() * 1000),
                }
                for w in workspaces
            ],
        }

    async def _handle_create_remote_workspace(self, ctx: RequestContext) -> Dict[str, Any]:
        """
        创建远程工作空间

        POST /remote/workspaces
        """
        import os
        import uuid

        if self.config.read_only:
            raise ApiError(403, "read_only", "Server is in read-only mode")

        body = ctx.request.get("body", {})
        name = body.get("name", f"workspace-{uuid.uuid4().hex[:8]}")
        path = body.get("path")

        if not path:
            # 在默认位置创建
            base_dir = os.path.expanduser("~/clawbot-workspaces")
            path = os.path.join(base_dir, name)

        # 创建目录
        os.makedirs(path, exist_ok=True)

        workspace_id = f"ws-{uuid.uuid4().hex[:8]}"

        return {
            "ok": True,
            "workspace": {
                "id": workspace_id,
                "name": name,
                "path": path,
                "status": "active",
                "createdAt": int(time.time() * 1000),
                "updatedAt": int(time.time() * 1000),
            },
        }

    async def _handle_get_remote_workspace(self, ctx: RequestContext) -> Dict[str, Any]:
        """
        获取远程工作空间详情

        GET /remote/workspaces/:id
        """
        import os

        from .workspaces import resolve_workspace

        workspace_id = ctx.params.get("id", "")

        try:
            workspace = await resolve_workspace(self.config, workspace_id)

            # 计算工作空间大小
            total_size = 0
            file_count = 0
            for root, dirs, files in os.walk(workspace.path):
                for f in files:
                    try:
                        total_size += os.path.getsize(os.path.join(root, f))
                        file_count += 1
                    except OSError:
                        pass

            return {
                "ok": True,
                "workspace": {
                    "id": workspace.id,
                    "name": workspace.name,
                    "path": workspace.path,
                    "status": "active",
                    "sizeBytes": total_size,
                    "fileCount": file_count,
                    "createdAt": int(time.time() * 1000),
                    "updatedAt": int(time.time() * 1000),
                },
            }
        except Exception:
            raise ApiError(404, "workspace_not_found", f"Workspace not found: {workspace_id}")

    async def _handle_delete_remote_workspace(self, ctx: RequestContext) -> Dict[str, Any]:
        """
        删除远程工作空间

        DELETE /remote/workspaces/:id
        """

        if self.config.read_only:
            raise ApiError(403, "read_only", "Server is in read-only mode")

        workspace_id = ctx.params.get("id", "")

        # 不允许删除活跃工作空间
        if self.config.workspaces and self.config.workspaces[0].id == workspace_id:
            raise ApiError(400, "cannot_delete_active", "Cannot delete active workspace")

        # 从配置中移除
        self.config.workspaces = [
            w for w in self.config.workspaces if w.id != workspace_id
        ]

        return {
            "ok": True,
            "deleted": workspace_id,
        }

    async def _handle_sync_remote_workspace(self, ctx: RequestContext) -> Dict[str, Any]:
        """
        同步远程工作空间

        POST /remote/workspaces/:id/sync
        """

        from .workspaces import resolve_workspace

        workspace_id = ctx.params.get("id", "")
        body = ctx.request.get("body", {})

        try:
            workspace = await resolve_workspace(self.config, workspace_id)

            # 同步操作：刷新文件列表等
            sync_type = body.get("type", "status")

            return {
                "ok": True,
                "synced": True,
                "type": sync_type,
                "workspaceId": workspace.id,
                "timestamp": int(time.time() * 1000),
            }
        except Exception:
            raise ApiError(404, "workspace_not_found", f"Workspace not found: {workspace_id}")

    async def _handle_list_remote_workspace_files(self, ctx: RequestContext) -> Dict[str, Any]:
        """
        列出远程工作空间文件

        GET /remote/workspaces/:id/files?path=xxx
        """
        import os

        from .workspaces import resolve_workspace

        workspace_id = ctx.params.get("id", "")
        query = ctx.request.get("query", {})
        relative_path = query.get("path", ".")

        try:
            workspace = await resolve_workspace(self.config, workspace_id)
            abs_path = os.path.normpath(os.path.join(workspace.path, relative_path))

            # 安全检查
            if not abs_path.startswith(workspace.path):
                raise ApiError(403, "access_denied", "Access denied")

            files = []
            dirs = []

            if os.path.isdir(abs_path):
                for entry in os.listdir(abs_path):
                    entry_path = os.path.join(abs_path, entry)
                    entry_stat = os.stat(entry_path)

                    item = {
                        "name": entry,
                        "path": os.path.join(relative_path, entry),
                        "size": entry_stat.st_size,
                        "modifiedAt": int(entry_stat.st_mtime * 1000),
                    }

                    if os.path.isdir(entry_path):
                        dirs.append(item)
                    else:
                        files.append(item)

            return {
                "ok": True,
                "path": relative_path,
                "files": files,
                "dirs": dirs,
            }
        except ApiError:
            raise
        except Exception:
            raise ApiError(404, "not_found", f"Path not found: {relative_path}")

    async def _handle_events_stream(self, ctx: RequestContext) -> Dict[str, Any]:
        """全局 SSE 事件流"""
        return {"_sse_stream": True, "_session_id": None}

    async def _handle_session_events_stream(self, ctx: RequestContext) -> Dict[str, Any]:
        """会话级 SSE 事件流"""
        session_id = ctx.params.get("id", "")

        session = await self.sessions.get(session_id)
        if not session:
            raise ApiError(404, "session_not_found", f"Session not found: {session_id}")

        return {"_sse_stream": True, "_session_id": session_id}


async def start_server(config: ServerConfig) -> HTTPServer:
    """
    启动服务器

    Args:
        config: 服务器配置

    Returns:
        HTTPServer 实例
    """
    server = HTTPServer(config)
    return server


def create_app(config: ServerConfig) -> HTTPServer:
    """
    创建应用实例

    Args:
        config: 服务器配置

    Returns:
        HTTPServer 实例
    """
    return HTTPServer(config)


async def run_server(server: HTTPServer) -> None:
    """
    运行 HTTP 服务器

    Args:
        server: HTTPServer 实例
    """
    import asyncio

    from aiohttp import web

    async def handle(request: web.Request) -> web.StreamResponse:
        method = request.method
        path = request.path
        headers = dict(request.headers)
        body = await request.read() if request.can_read_body else None

        status, body_dict, resp_headers = await server._handle_request(method, path, headers, body)

        # 检查是否为 SSE 流请求
        if isinstance(body_dict, dict) and body_dict.get("_sse_stream"):
            session_id = body_dict.get("_session_id")
            return await _handle_sse_request(request, server, session_id)

        return web.json_response(body_dict, status=status, headers=resp_headers)

    async def _handle_sse_request(
        request: web.Request,
        server: HTTPServer,
        session_id: str | None,
    ) -> web.StreamResponse:
        """处理 SSE 请求"""
        response = web.StreamResponse()
        response.headers["Content-Type"] = "text/event-stream"
        response.headers["Cache-Control"] = "no-cache"
        response.headers["Connection"] = "keep-alive"
        response.headers["X-Accel-Buffering"] = "no"

        await response.prepare(request)

        try:
            async for event in server.sse_events.subscribe(session_id):
                # 格式化为 SSE 格式
                data = {
                    "type": event.type.value if hasattr(event.type, "value") else str(event.type),
                    "sessionId": event.session_id,
                    "data": event.data,
                    "timestamp": event.timestamp,
                }
                import json
                message = f"data: {json.dumps(data)}\n\n"
                await response.write(message.encode("utf-8"))
        except asyncio.CancelledError:
            pass
        except Exception as e:
            import json
            error_msg = f"data: {json.dumps({'type': 'error', 'message': str(e)})}\n\n"
            await response.write(error_msg.encode("utf-8"))

        return response

    app = web.Application()
    app.router.add_route('*', '/{path:.*}', handle)

    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, server.config.host, server.config.port)
    await site.start()

    while True:
        await asyncio.sleep(3600)
