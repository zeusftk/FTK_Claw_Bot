"""
OpenWork Server 验证器模块
提供各种输入验证函数。
"""

import re
from typing import Any, Dict, Optional

from .errors import ApiError

# 验证正则表达式
SKILL_NAME_REGEX = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*$")
COMMAND_NAME_REGEX = re.compile(r"^[A-Za-z0-9_-]+$")
MCP_NAME_REGEX = re.compile(r"^[A-Za-z0-9_-]+$")


def validate_skill_name(name: str) -> None:
    """
    验证技能名称
    Args:
        name: 技能名称
    Raises:
        ApiError: 如果名称无效
    """
    if not name or len(name) < 1 or len(name) > 64 or not SKILL_NAME_REGEX.match(name):
        raise ApiError(
            400,
            "invalid_skill_name",
            "Skill name must be kebab-case (1-64 chars)"
        )


def validate_description(description: Optional[str]) -> None:
    """
    验证描述

    Args:
        description: 描述文本

    Raises:
        ApiError: 如果描述无效
    """
    if not description or len(description) < 1 or len(description) > 1024:
        raise ApiError(
            422,
            "invalid_description",
            "Description must be 1-1024 characters"
        )


def validate_plugin_spec(spec: str) -> None:
    """
    验证插件规格

    Args:
        spec: 插件规格

    Raises:
        ApiError: 如果规格无效
    """
    if not spec or not spec.strip():
        raise ApiError(400, "invalid_plugin_spec", "Plugin spec is required")


def sanitize_command_name(name: str) -> str:
    """
    清理命令名称

    Args:
        name: 命令名称

    Returns:
        清理后的命令名称
    """
    return name.strip().lstrip("/")


def validate_command_name(name: str) -> None:
    """
    验证命令名称

    Args:
        name: 命令名称

    Raises:
        ApiError: 如果名称无效
    """
    if not name or not COMMAND_NAME_REGEX.match(name):
        raise ApiError(
            400,
            "invalid_command_name",
            "Command name must be alphanumeric with _ or -"
        )


def validate_mcp_name(name: str) -> None:
    """
    验证 MCP 名称

    Args:
        name: MCP 名称

    Raises:
        ApiError: 如果名称无效
    """
    if not name or name.startswith("-") or not MCP_NAME_REGEX.match(name):
        raise ApiError(
            400,
            "invalid_mcp_name",
            "MCP name must be alphanumeric and not start with -"
        )


def validate_mcp_config(config: Dict[str, Any]) -> None:
    """
    验证 MCP 配置

    Args:
        config: MCP 配置

    Raises:
        ApiError: 如果配置无效
    """
    config_type = config.get("type")
    if config_type not in ("local", "remote"):
        raise ApiError(
            400,
            "invalid_mcp_config",
            "MCP config type must be local or remote"
        )

    if config_type == "local":
        command = config.get("command")
        if not isinstance(command, list) or len(command) == 0:
            raise ApiError(
                400,
                "invalid_mcp_config",
                "Local MCP requires command array"
            )

    if config_type == "remote":
        url = config.get("url")
        if not url or not isinstance(url, str):
            raise ApiError(
                400,
                "invalid_mcp_config",
                "Remote MCP requires url"
            )


def validate_token_scope(scope: str) -> str:
    """
    验证并返回 Token 范围

    Args:
        scope: Token 范围字符串
    Returns:
        验证后的范围

    Raises:
        ApiError: 如果范围无效
    """
    if scope not in ("owner", "collaborator", "viewer"):
        raise ApiError(
            400,
            "invalid_scope",
            "Token scope must be owner, collaborator, or viewer"
        )
    return scope


def validate_path(path: str, allow_subdirs: bool = True) -> str:
    """
    验证并规范化路径

    Args:
        path: 路径
        allow_subdirs: 是否允许子目录
    Returns:
        规范化后的路径
    Raises:
        ApiError: 如果路径无效
    """

    raw = str(path or "").strip()
    if not raw:
        raise ApiError(400, "invalid_path", "Path is required")

    if "\x00" in raw:
        raise ApiError(400, "invalid_path", "Path contains null byte")

    # 规范化路径
    normalized = raw.replace("\\", "/")
    normalized = normalized.lstrip("/")
    normalized = re.sub(r"^\./", "", normalized)
    normalized = re.sub(r"^workspace/", "", normalized)
    normalized = normalized.lstrip("/")

    parts = [p for p in normalized.split("/") if p]
    if not parts:
        raise ApiError(400, "invalid_path", "Path is required")

    if not allow_subdirs and len(parts) > 1:
        raise ApiError(400, "invalid_path", "Subdirectories are not allowed")

    for part in parts:
        if part in (".", ".."):
            raise ApiError(400, "invalid_path", "Path traversal is not allowed")

    return "/".join(parts)


def validate_json_body(body: Any, required_fields: list = None) -> Dict[str, Any]:
    """
    验证 JSON 请求体
    Args:
        body: 请求体
        required_fields: 必需字段列表

    Returns:
        验证后的字典

    Raises:
        ApiError: 如果请求体无效
    """
    if not isinstance(body, dict):
        raise ApiError(400, "invalid_payload", "Request body must be a JSON object")

    if required_fields:
        for field in required_fields:
            if field not in body:
                raise ApiError(
                    400,
                    "invalid_payload",
                    f"Missing required field: {field}"
                )

    return body


def validate_workspace_id(workspace_id: str) -> str:
    """
    验证工作空间 ID

    Args:
        workspace_id: 工作空间 ID

    Returns:
        验证后的 ID

    Raises:
        ApiError: 如果 ID 无效
    """
    if not workspace_id or not workspace_id.strip():
        raise ApiError(400, "invalid_workspace_id", "Workspace ID is required")
    return workspace_id.strip()


def validate_session_id(session_id: str) -> str:
    """
    验证会话 ID

    Args:
        session_id: 会话 ID

    Returns:
        验证后的 ID

    Raises:
        ApiError: 如果 ID 无效
    """
    if not session_id or not session_id.strip():
        raise ApiError(400, "invalid_session_id", "Session ID is required")
    return session_id.strip()
