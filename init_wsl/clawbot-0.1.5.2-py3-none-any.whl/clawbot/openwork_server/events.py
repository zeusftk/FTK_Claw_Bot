"""
OpenWork Server 事件存储模块

提供重载事件的管理功能。
"""

import asyncio
from collections import deque
from typing import AsyncIterator, Dict, List, Optional

import time

from .types import Event, EventType, ReloadEvent, ReloadReason, ReloadTrigger
from .utils import short_id


class ReloadEventStore:
    """重载事件存储"""

    def __init__(self, max_size: int = 200):
        """
        初始化事件存储

        Args:
            max_size: 最大存储数释        """
        self._events: List[ReloadEvent] = []
        self._seq = 0
        self._max_size = max_size
        self._last_recorded: Dict[str, int] = {}

    def record(
        self,
        workspace_id: str,
        reason: ReloadReason,
        trigger: Optional[ReloadTrigger] = None
    ) -> ReloadEvent:
        """
        记录重载事件

        Args:
            workspace_id: 工作空间 ID
            reason: 重载原因
            trigger: 触发器
        Returns:
            重载事件
        """
        self._seq += 1

        event = ReloadEvent(
            id=short_id(),
            seq=self._seq,
            workspace_id=workspace_id,
            reason=reason,
            trigger=trigger,
            timestamp=int(time.time() * 1000)
        )

        self._events.append(event)

        if len(self._events) > self._max_size:
            self._events = self._events[-self._max_size:]

        return event

    def record_debounced(
        self,
        workspace_id: str,
        reason: ReloadReason,
        trigger: Optional[ReloadTrigger] = None,
        debounce_ms: int = 750
    ) -> Optional[ReloadEvent]:
        """
        记录去抖动的重载事件

        Args:
            workspace_id: 工作空间 ID
            reason: 重载原因
            trigger: 触发器
            debounce_ms: 去抖动时间（毫秒）
        Returns:
            重载事件，如果在去抖动时间内则返回None
        """
        now = int(time.time() * 1000)
        key = f"{workspace_id}:{reason.value if isinstance(reason, ReloadReason) else reason}"
        last = self._last_recorded.get(key, 0)

        if now - last < debounce_ms:
            return None

        self._last_recorded[key] = now
        return self.record(workspace_id, reason, trigger)
    def list(
        self,
        workspace_id: str,
        since: Optional[int] = None
    ) -> List[ReloadEvent]:
        """
        列出重载事件

        Args:
            workspace_id: 工作空间 ID
            since: 起始序列发
        Returns:
            重载事件列表
        """
        cursor = since if isinstance(since, (int, float)) else 0

        return [
            event for event in self._events
            if event.workspace_id == workspace_id and event.seq > cursor
        ]

    def cursor(self) -> int:
        """
        获取当前序列发
        Returns:
            当前序列发        """
        return self._seq

    def clear(self) -> int:
        """
        清除所有事任
        Returns:
            清除的事件数释        """
        count = len(self._events)
        self._events.clear()
        self._last_recorded.clear()
        return count

    def get_latest(self, workspace_id: str) -> Optional[ReloadEvent]:
        """
        获取最新的重载事件

        Args:
            workspace_id: 工作空间 ID

        Returns:
            最新的重载事件，如果没有则返回 None
        """
        for event in reversed(self._events):
            if event.workspace_id == workspace_id:
                return event
        return None

    def get_by_reason(
        self,
        workspace_id: str,
        reason: ReloadReason
    ) -> List[ReloadEvent]:
        """
        按原因获取重载事任

        Args:
            workspace_id: 工作空间 ID
            reason: 重载原因

        Returns:
            重载事件列表
        """
        return [
            event for event in self._events
            if event.workspace_id == workspace_id and event.reason == reason
        ]


class SSEEventStore:
    """SSE 事件存储和推送"""

    def __init__(self, max_events: int = 1000):
        self._events: deque[Event] = deque(maxlen=max_events)
        self._subscribers: list[asyncio.Queue] = []
        self._session_subscribers: dict[str, list[asyncio.Queue]] = {}
        self._lock = asyncio.Lock()

    async def publish(self, event: Event) -> None:
        """发布事件"""
        async with self._lock:
            self._events.append(event)
            
            for queue in self._subscribers:
                try:
                    queue.put_nowait(event)
                except asyncio.QueueFull:
                    pass
            
            if event.session_id and event.session_id in self._session_subscribers:
                for queue in self._session_subscribers[event.session_id]:
                    try:
                        queue.put_nowait(event)
                    except asyncio.QueueFull:
                        pass

    async def subscribe(
        self, session_id: Optional[str] = None, queue_size: int = 100
    ) -> AsyncIterator[Event]:
        """订阅事件流"""
        queue: asyncio.Queue[Optional[Event]] = asyncio.Queue(maxsize=queue_size)
        
        async with self._lock:
            if session_id:
                if session_id not in self._session_subscribers:
                    self._session_subscribers[session_id] = []
                self._session_subscribers[session_id].append(queue)
            else:
                self._subscribers.append(queue)
        
        try:
            while True:
                event = await queue.get()
                if event is None:
                    break
                yield event
        finally:
            async with self._lock:
                if session_id and session_id in self._session_subscribers:
                    if queue in self._session_subscribers[session_id]:
                        self._session_subscribers[session_id].remove(queue)
                    if not self._session_subscribers[session_id]:
                        del self._session_subscribers[session_id]
                elif queue in self._subscribers:
                    self._subscribers.remove(queue)

    def unsubscribe_all(self, session_id: Optional[str] = None) -> None:
        """取消所有订阅"""
        if session_id and session_id in self._session_subscribers:
            for queue in self._session_subscribers[session_id]:
                try:
                    queue.put_nowait(None)
                except asyncio.QueueFull:
                    pass
            del self._session_subscribers[session_id]

    def get_recent_events(self, limit: int = 50) -> list[Event]:
        """获取最近事件"""
        return list(self._events)[-limit:]
