"""
OpenWork Server 任务管理器

提供任务的创建、执行、监控和管理功能。
"""

import asyncio
import time
import uuid
from collections import deque
from dataclasses import asdict
from typing import Any, Dict, List, Optional

from loguru import logger

from .types import (
    Event,
    EventType,
    Task,
    TaskInput,
    TaskOutput,
    TaskPriority,
    TaskProgress,
    TaskStatus,
    TaskSubmitRequest,
    TaskType,
)
from .utils import short_id


class TaskManager:
    """
    任务管理器

    功能：
    1. 任务创建和提交
    2. 任务队列管理
    3. 任务执行调度
    4. 任务状态跟踪
    5. 任务进度监控
    """

    def __init__(
        self,
        max_concurrent_tasks: int = 5,
        max_queued_tasks: int = 100,
        default_timeout_ms: int = 300000,
    ):
        """
        初始化任务管理器

        Args:
            max_concurrent_tasks: 最大并发任务数
            max_queued_tasks: 最大排队任务数
            default_timeout_ms: 默认超时时间（毫秒）
        """
        self.max_concurrent_tasks = max_concurrent_tasks
        self.max_queued_tasks = max_queued_tasks
        self.default_timeout_ms = default_timeout_ms

        self._tasks: Dict[str, Task] = {}
        self._task_queue: deque[str] = deque(maxlen=max_queued_tasks)
        self._running_tasks: Dict[str, asyncio.Task] = {}
        self._active_count: int = 0
        self._lock = asyncio.Lock()
        self._event_subscribers: List[asyncio.Queue] = []
        self._executor: Optional[TaskExecutor] = None

    def set_executor(self, executor: "TaskExecutor") -> None:
        """设置任务执行器"""
        self._executor = executor

    async def submit(self, request: TaskSubmitRequest) -> Task:
        """
        提交任务

        Args:
            request: 任务提交请求

        Returns:
            创建的任务对象
        """
        async with self._lock:
            task_id = f"task-{short_id()}"

            task = Task(
                id=task_id,
                title=request.title or request.prompt[:100],
                type=request.type,
                status=TaskStatus.PENDING,
                priority=request.priority,
                input=TaskInput(
                    prompt=request.prompt,
                    workspace_path=request.workspace_path,
                    files=request.files,
                    context=request.context,
                    env=request.env,
                ),
                workspace_id=request.workspace_id,
                parent_task_id=request.parent_task_id,
                timeout_ms=request.timeout_ms or self.default_timeout_ms,
                tags=request.tags or [],
            )

            self._tasks[task_id] = task

            if request.auto_start:
                self._task_queue.append(task_id)
                task.status = TaskStatus.QUEUED
                logger.info(f"Task {task_id} submitted and queued")

                # 尝试启动任务处理
                asyncio.create_task(self._process_queue())
            else:
                logger.info(f"Task {task_id} created, waiting for manual start")

            await self._emit_event(EventType.PROGRESS, task_id, {
                "action": "created",
                "status": task.status.value,
            })

            return task

    async def get(self, task_id: str) -> Optional[Task]:
        """获取任务"""
        return self._tasks.get(task_id)

    async def list(
        self,
        status: Optional[TaskStatus] = None,
        workspace_id: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> List[Task]:
        """
        列出任务

        Args:
            status: 按状态筛选
            workspace_id: 按工作空间筛选
            limit: 返回数量限制
            offset: 偏移量

        Returns:
            任务列表
        """
        tasks = list(self._tasks.values())

        if status:
            tasks = [t for t in tasks if t.status == status]
        if workspace_id:
            tasks = [t for t in tasks if t.workspace_id == workspace_id]

        # 按优先级和创建时间排序
        priority_order = {
            TaskPriority.CRITICAL: 0,
            TaskPriority.HIGH: 1,
            TaskPriority.NORMAL: 2,
            TaskPriority.LOW: 3,
        }
        tasks.sort(key=lambda t: (priority_order.get(t.priority, 2), -t.created_at))

        return tasks[offset:offset + limit]

    async def cancel(self, task_id: str) -> Optional[Task]:
        """
        取消任务

        Args:
            task_id: 任务 ID

        Returns:
            取消的任务，如果任务不存在或无法取消则返回 None
        """
        async with self._lock:
            task = self._tasks.get(task_id)
            if not task:
                return None

            if task.status in (TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED):
                return None

            # 如果任务正在运行，取消异步任务
            if task_id in self._running_tasks:
                async_task = self._running_tasks[task_id]
                async_task.cancel()
                try:
                    await async_task
                except asyncio.CancelledError:
                    pass
                del self._running_tasks[task_id]
                self._active_count -= 1

            task.status = TaskStatus.CANCELLED
            task.completed_at = int(time.time() * 1000)
            task.updated_at = task.completed_at

            await self._emit_event(EventType.PROGRESS, task_id, {
                "action": "cancelled",
                "status": TaskStatus.CANCELLED.value,
            })

            logger.info(f"Task {task_id} cancelled")
            return task

    async def start(self, task_id: str) -> Optional[Task]:
        """
        手动启动任务

        Args:
            task_id: 任务 ID

        Returns:
            启动的任务，如果任务不存在或无法启动则返回 None
        """
        async with self._lock:
            task = self._tasks.get(task_id)
            if not task:
                return None

            if task.status != TaskStatus.PENDING:
                return None

            self._task_queue.append(task_id)
            task.status = TaskStatus.QUEUED
            task.updated_at = int(time.time() * 1000)

            asyncio.create_task(self._process_queue())

            return task

    async def get_progress(self, task_id: str) -> Optional[TaskProgress]:
        """获取任务进度"""
        task = self._tasks.get(task_id)
        if not task:
            return None

        # 计算进度百分比
        progress_map = {
            TaskStatus.PENDING: 0,
            TaskStatus.QUEUED: 5,
            TaskStatus.RUNNING: 50,
            TaskStatus.WAITING_INPUT: 75,
            TaskStatus.COMPLETED: 100,
            TaskStatus.FAILED: 100,
            TaskStatus.CANCELLED: 100,
            TaskStatus.TIMEOUT: 100,
        }

        return TaskProgress(
            task_id=task_id,
            status=task.status,
            progress_percent=progress_map.get(task.status, 0),
            current_step=task.status.value,
            total_steps=4,
            completed_steps=int(progress_map.get(task.status, 0) / 25),
            message=task.error_message,
        )

    async def _process_queue(self) -> None:
        """处理任务队列"""
        async with self._lock:
            while self._task_queue and self._active_count < self.max_concurrent_tasks:
                task_id = self._task_queue.popleft()
                task = self._tasks.get(task_id)

                if not task or task.status != TaskStatus.QUEUED:
                    continue

                # 启动任务执行
                async_task = asyncio.create_task(self._execute_task(task_id))
                self._running_tasks[task_id] = async_task
                self._active_count += 1

    async def _execute_task(self, task_id: str) -> None:
        """执行任务"""
        task = self._tasks.get(task_id)
        if not task:
            return

        try:
            task.status = TaskStatus.RUNNING
            task.started_at = int(time.time() * 1000)
            task.updated_at = task.started_at

            await self._emit_event(EventType.PROGRESS, task_id, {
                "action": "started",
                "status": TaskStatus.RUNNING.value,
            })

            logger.info(f"Executing task {task_id}: {task.title}")

            # 使用执行器执行任务
            if self._executor:
                output = await asyncio.wait_for(
                    self._executor.execute(task),
                    timeout=task.timeout_ms / 1000,
                )
                task.output = output
                task.status = TaskStatus.COMPLETED
            else:
                # 没有执行器，模拟执行
                task.output = TaskOutput(result="No executor configured")
                task.status = TaskStatus.COMPLETED

            task.completed_at = int(time.time() * 1000)
            task.updated_at = task.completed_at

            await self._emit_event(EventType.COMPLETED, task_id, {
                "action": "completed",
                "status": TaskStatus.COMPLETED.value,
                "output": asdict(task.output) if task.output else None,
            })

            logger.info(f"Task {task_id} completed")

        except asyncio.TimeoutError:
            task.status = TaskStatus.TIMEOUT
            task.error_message = "Task execution timed out"
            task.error_code = "TIMEOUT"
            task.completed_at = int(time.time() * 1000)
            task.updated_at = task.completed_at

            await self._emit_event(EventType.ERROR, task_id, {
                "action": "timeout",
                "error": task.error_message,
            })

            logger.warning(f"Task {task_id} timed out")

        except asyncio.CancelledError:
            task.status = TaskStatus.CANCELLED
            task.completed_at = int(time.time() * 1000)
            task.updated_at = task.completed_at

            logger.info(f"Task {task_id} was cancelled")

        except Exception as e:
            task.status = TaskStatus.FAILED
            task.error_message = str(e)
            task.error_code = "EXECUTION_ERROR"
            task.completed_at = int(time.time() * 1000)
            task.updated_at = task.completed_at

            if task.retry_count < task.max_retries:
                task.retry_count += 1
                task.status = TaskStatus.QUEUED
                self._task_queue.append(task_id)
                logger.warning(f"Task {task_id} failed, retrying ({task.retry_count}/{task.max_retries})")
            else:
                await self._emit_event(EventType.ERROR, task_id, {
                    "action": "failed",
                    "error": str(e),
                })
                logger.error(f"Task {task_id} failed: {e}")

        finally:
            async with self._lock:
                if task_id in self._running_tasks:
                    del self._running_tasks[task_id]
                self._active_count -= 1

            # 处理队列中的下一个任务
            asyncio.create_task(self._process_queue())

    async def _emit_event(
        self,
        event_type: EventType,
        task_id: str,
        data: Dict[str, Any],
    ) -> None:
        """发送事件"""
        event = Event(
            type=event_type,
            session_id=task_id,
            data=data,
        )

        for queue in self._event_subscribers:
            try:
                queue.put_nowait(event)
            except asyncio.QueueFull:
                pass

    def subscribe_events(self, queue_size: int = 100) -> asyncio.Queue:
        """订阅任务事件"""
        queue: asyncio.Queue[Optional[Event]] = asyncio.Queue(maxsize=queue_size)
        self._event_subscribers.append(queue)
        return queue

    def unsubscribe_events(self, queue: asyncio.Queue) -> None:
        """取消订阅"""
        if queue in self._event_subscribers:
            self._event_subscribers.remove(queue)

    def stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        status_counts = {}
        for status in TaskStatus:
            status_counts[status.value] = sum(
                1 for t in self._tasks.values() if t.status == status
            )

        return {
            "total_tasks": len(self._tasks),
            "queued_tasks": len(self._task_queue),
            "running_tasks": self._active_count,
            "max_concurrent": self.max_concurrent_tasks,
            "status_counts": status_counts,
        }


class TaskExecutor:
    """
    任务执行器基类

    子类需要实现 execute 方法
    """

    async def execute(self, task: Task) -> TaskOutput:
        """
        执行任务

        Args:
            task: 要执行的任务

        Returns:
            任务输出
        """
        raise NotImplementedError("Subclasses must implement execute()")


class OpenCodeTaskExecutor(TaskExecutor):
    """
    OpenCode 任务执行器

    使用 OpenCode CLI 或 Server 执行任务
    """

    def __init__(
        self,
        opencode_base_url: Optional[str] = None,
        opencode_cli_path: Optional[str] = None,
    ):
        self.opencode_base_url = opencode_base_url
        self.opencode_cli_path = opencode_cli_path

    async def execute(self, task: Task) -> TaskOutput:
        """通过 OpenCode 执行任务"""
        import aiohttp

        # 优先使用 HTTP API
        if self.opencode_base_url:
            return await self._execute_via_api(task)

        # 降级到 CLI
        return await self._execute_via_cli(task)

    async def _execute_via_api(self, task: Task) -> TaskOutput:
        """通过 HTTP API 执行"""
        import aiohttp

        url = f"{self.opencode_base_url.rstrip('/')}/execute"

        payload = {
            "prompt": task.input.prompt,
            "workspace": task.input.workspace_path,
            "context": task.input.context,
            "files": task.input.files,
        }

        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=payload) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return TaskOutput(
                        result=data.get("output", ""),
                        files_changed=data.get("files_changed", []),
                        commands_executed=data.get("commands", []),
                    )
                else:
                    raise RuntimeError(f"OpenCode API error: {resp.status}")

    async def _execute_via_cli(self, task: Task) -> TaskOutput:
        """通过 CLI 执行"""
        import asyncio
        import json
        import shutil

        opencode_bin = self.opencode_cli_path or shutil.which("opencode")
        if not opencode_bin:
            raise RuntimeError("OpenCode CLI not found")

        workspace = task.input.workspace_path or "."

        proc = await asyncio.create_subprocess_exec(
            opencode_bin,
            "-p", task.input.prompt,
            "-f", "json",
            "-q",
            cwd=workspace,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        stdout, stderr = await proc.communicate()

        if proc.returncode == 0:
            try:
                data = json.loads(stdout.decode())
                return TaskOutput(
                    result=data.get("output", stdout.decode()),
                    files_changed=data.get("files_changed", []),
                )
            except json.JSONDecodeError:
                return TaskOutput(result=stdout.decode())
        else:
            raise RuntimeError(f"OpenCode CLI failed: {stderr.decode()}")
