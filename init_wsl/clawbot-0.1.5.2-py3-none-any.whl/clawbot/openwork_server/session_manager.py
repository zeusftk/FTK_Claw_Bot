"""
OpenWork Server 会话管理模块

提供编程会话的创建、管理和状态跟踪功能。
"""

import time
import uuid
from dataclasses import dataclass, field
from typing import Optional

from .types import Session, SessionStatus


class SessionManager:
    """会话管理器"""

    def __init__(self, max_sessions: int = 100, session_ttl_ms: int = 3600000):
        self._sessions: dict[str, Session] = {}
        self._max_sessions = max_sessions
        self._session_ttl_ms = session_ttl_ms

    async def create(self, title: str, cwd: str) -> Session:
        """创建新会话"""
        session_id = f"sess-{uuid.uuid4().hex[:8]}"
        now = int(time.time() * 1000)
        
        session = Session(
            id=session_id,
            title=title,
            cwd=cwd,
            status=SessionStatus.IDLE,
            created_at=now,
            updated_at=now,
        )
        
        self._sessions[session_id] = session
        self._cleanup_expired()
        
        return session

    async def get(self, session_id: str) -> Optional[Session]:
        """获取会话"""
        return self._sessions.get(session_id)

    async def update_status(self, session_id: str, status: SessionStatus) -> Optional[Session]:
        """更新会话状态"""
        session = self._sessions.get(session_id)
        if session:
            session.status = status
            session.updated_at = int(time.time() * 1000)
        return session
    async def add_message(self, session_id: str, message: dict) -> Optional[Session]:
        """添加消息到会话"""
        session = self._sessions.get(session_id)
        if session:
            session.messages.append(message)
            session.updated_at = int(time.time() * 1000)
        return session
    async def add_permission_request(
        self, session_id: str, permission_id: str, request: dict
    ) -> Optional[Session]:
        """添加权限请求"""
        session = self._sessions.get(session_id)
        if session:
            session.pending_permissions[permission_id] = request
            session.updated_at = int(time.time() * 1000)
        return session
    async def resolve_permission(
        self, session_id: str, permission_id: str, response: str
    ) -> Optional[dict]:
        """解析权限请求"""
        session = self._sessions.get(session_id)
        if session and permission_id in session.pending_permissions:
            request = session.pending_permissions.pop(permission_id)
            session.updated_at = int(time.time() * 1000)
            return {"request": request, "response": response}
        return None
    async def delete(self, session_id: str) -> bool:
        """删除会话"""
        if session_id in self._sessions:
            del self._sessions[session_id]
            return True
        return False
    def list(self) -> list[Session]:
        """列出所有会话"""
        return list(self._sessions.values())
    def _cleanup_expired(self) -> None:
        """清理过期会话"""
        now = int(time.time() * 1000)
        expired = [
            sid for sid, s in self._sessions.items()
            if now - s.updated_at > self._session_ttl_ms
        ]
        for sid in expired:
            del self._sessions[sid]
        
        if len(self._sessions) > self._max_sessions:
            sorted_sessions = sorted(
                self._sessions.items(),
                key=lambda x: x[1].updated_at
            )
            for sid, _ in sorted_sessions[:-self._max_sessions]:
                del self._sessions[sid]
