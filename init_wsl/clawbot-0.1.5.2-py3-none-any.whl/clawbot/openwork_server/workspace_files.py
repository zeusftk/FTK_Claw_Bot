"""
OpenWork Server 工作空间文件路径模块

提供工作空间相关路径的计算函数。"""

import os
from typing import Optional

from .utils import resolve_home


def opencode_config_path(workspace_root: str) -> str:
    """
    获取 OpenCode 配置文件路径

    优先返回 .jsonc 文件，如果不存在则返回.json 文件路径。
    Args:
        workspace_root: 工作空间根目录
    Returns:
        配置文件路径
    """
    jsonc_path = os.path.join(workspace_root, "opencode.jsonc")
    json_path = os.path.join(workspace_root, "opencode.json")

    if os.path.exists(jsonc_path):
        return jsonc_path
    if os.path.exists(json_path):
        return json_path

    return jsonc_path


def openwork_config_path(workspace_root: str) -> str:
    """
    获取 OpenWork 配置文件路径

    Args:
        workspace_root: 工作空间根目录
    Returns:
        配置文件路径
    """
    return os.path.join(workspace_root, ".opencode", "openwork.json")


def project_skills_dir(workspace_root: str) -> str:
    """
    获取项目技能目录

    Args:
        workspace_root: 工作空间根目录
    Returns:
        技能目录路径
    """
    return os.path.join(workspace_root, ".opencode", "skills")


def project_commands_dir(workspace_root: str) -> str:
    """
    获取项目命令目录

    Args:
        workspace_root: 工作空间根目录
    Returns:
        命令目录路径
    """
    return os.path.join(workspace_root, ".opencode", "commands")


def project_plugins_dir(workspace_root: str) -> str:
    """
    获取项目插件目录

    Args:
        workspace_root: 工作空间根目录
    Returns:
        插件目录路径
    """
    return os.path.join(workspace_root, ".opencode", "plugins")


def global_skills_dir() -> str:
    """
    获取全局技能目录
    Returns:
        全局技能目录路待    """
    return os.path.join(resolve_home(), ".config", "opencode", "skills")


def global_commands_dir() -> str:
    """
    获取全局命令目录

    Returns:
        全局命令目录路径
    """
    return os.path.join(resolve_home(), ".config", "opencode", "commands")


def global_plugins_dir() -> str:
    """
    获取全局插件目录

    Returns:
        全局插件目录路径
    """
    return os.path.join(resolve_home(), ".config", "opencode", "plugins")


def global_opencode_config_path() -> str:
    """
    获取全局 OpenCode 配置文件路径

    Returns:
        全局配置文件路径
    """
    base = os.path.join(resolve_home(), ".config", "opencode")
    jsonc_path = os.path.join(base, "opencode.jsonc")
    json_path = os.path.join(base, "opencode.json")

    if os.path.exists(jsonc_path):
        return jsonc_path
    if os.path.exists(json_path):
        return json_path

    return jsonc_path


def inbox_dir(workspace_root: str) -> str:
    """
    获取收件箱目录

    Args:
        workspace_root: 工作空间根目录
    Returns:
        收件箱目录路径
    """
    return os.path.join(workspace_root, ".opencode", "openwork", "inbox")


def outbox_dir(workspace_root: str) -> str:
    """
    获取发件箱目录

    Args:
        workspace_root: 工作空间根目录
    Returns:
        发件箱目录路径
    """
    return os.path.join(workspace_root, ".opencode", "openwork", "outbox")


def agent_lab_dir(workspace_root: str) -> str:
    """
    获取 Agent Lab 目录

    Args:
        workspace_root: 工作空间根目录
    Returns:
        Agent Lab 目录路径
    """
    return os.path.join(workspace_root, ".opencode", "openwork", "agentlab")


def agent_lab_automations_path(workspace_root: str) -> str:
    """
    获取 Agent Lab 自动化配置文件路待
    Args:
        workspace_root: 工作空间根目录
    Returns:
        自动化配置文件路待    """
    return os.path.join(agent_lab_dir(workspace_root), "automations.json")


def agent_lab_logs_dir(workspace_root: str) -> str:
    """
    获取 Agent Lab 日志目录

    Args:
        workspace_root: 工作空间根目录
    Returns:
        日志目录路径
    """
    return os.path.join(agent_lab_dir(workspace_root), "logs")


def audit_dir(workspace_root: str) -> str:
    """
    获取审计日志目录

    Args:
        workspace_root: 工作空间根目录
    Returns:
        审计日志目录路径
    """
    return os.path.join(workspace_root, ".opencode", "openwork", "audit")


def audit_file_path(workspace_root: str, workspace_id: str) -> str:
    """
    获取审计日志文件路径

    Args:
        workspace_root: 工作空间根目录        workspace_id: 工作空间 ID

    Returns:
        审计日志文件路径
    """
    return os.path.join(audit_dir(workspace_root), f"{workspace_id}.jsonl")


def token_store_path(config_path: Optional[str] = None) -> str:
    """
    获取 Token 存储文件路径

    Args:
        config_path: 服务器配置文件路径
    Returns:
        Token 存储文件路径
    """
    import os

    from .utils import get_env

    # 检查环境变量覆盖
    override = get_env("OPENWORK_TOKEN_STORE", "").strip()
    if override:
        return os.path.abspath(override)

    # 使用配置目录或默认目录
    if config_path:
        config_dir = os.path.dirname(config_path)
    else:
        config_dir = os.path.join(resolve_home(), ".config", "openwork")

    return os.path.join(config_dir, "tokens.json")


def scheduler_scopes_dir() -> str:
    """
    获取调度器作用域目录

    Returns:
        调度器作用域目录路径
    """
    return os.path.join(resolve_home(), ".config", "opencode", "scheduler", "scopes")


def legacy_jobs_dir() -> str:
    """
    获取旧版任务目录

    Returns:
        旧版任务目录路径
    """
    return os.path.join(resolve_home(), ".config", "opencode", "jobs")
