"""
OpenWork Server 工作空间管理模块

提供工作空间 ID 生成和信息构建功能。
"""

import hashlib
import os
from typing import List, Optional

from .types import WorkspaceConfig, WorkspaceInfo, WorkspaceType


def workspace_id_for_path(path: str) -> str:
    """
    根据路径生成工作空间 ID

    使用 SHA256 哈希路径并取前 12 个字符。
    Args:
        path: 工作空间路径

    Returns:
        工作空间 ID (格式: ws_xxxxxxxxxxxx)
    """
    hash_value = hashlib.sha256(path.encode("utf-8")).hexdigest()
    return f"ws_{hash_value[:12]}"


def build_workspace_infos(
    workspaces: List[WorkspaceConfig],
    cwd: str
) -> List[WorkspaceInfo]:
    """
    构建工作空间信息列表

    Args:
        workspaces: 工作空间配置列表
        cwd: 当前工作目录

    Returns:
        工作空间信息列表
    """
    result: List[WorkspaceInfo] = []

    for workspace in workspaces:
        resolved_path = os.path.abspath(os.path.join(cwd, workspace.path))
        workspace_id = workspace_id_for_path(resolved_path)
        name = workspace.name or os.path.basename(resolved_path)
        workspace_type = workspace.workspace_type or WorkspaceType.LOCAL

        info = WorkspaceInfo(
            id=workspace_id,
            name=name,
            path=resolved_path,
            workspace_type=workspace_type,
            base_url=workspace.base_url,
            directory=workspace.directory,
            opencode_username=workspace.opencode_username,
            opencode_password=workspace.opencode_password,
        )

        # 构建 opencode 信息对象
        if (workspace.base_url or workspace.directory or
            workspace.opencode_username or workspace.opencode_password):
            info.opencode = {
                "baseUrl": workspace.base_url,
                "directory": workspace.directory,
                "username": workspace.opencode_username,
                "password": workspace.opencode_password,
            }

        result.append(info)

    return result


def resolve_workspace(
    config,
    workspace_id: str
) -> WorkspaceInfo:
    """
    解析工作空间

    Args:
        config: 服务器配置
        workspace_id: 工作空间 ID

    Returns:
        工作空间信息

    Raises:
        ApiError: 如果工作空间未找到
    """
    from .errors import NotFoundError

    for workspace in config.workspaces:
        if workspace.id == workspace_id:
            return workspace

    raise NotFoundError(
        f"Workspace not found: {workspace_id}",
        "workspace_not_found"
    )


def serialize_workspace(workspace: WorkspaceInfo) -> dict:
    """
    序列化工作空间信息
    移除敏感信息（如密码）并构建响应字典。
    Args:
        workspace: 工作空间信息

    Returns:
        序列化后的字典
    """
    result = {
        "id": workspace.id,
        "name": workspace.name,
        "path": workspace.path,
        "workspaceType": workspace.workspace_type.value if isinstance(workspace.workspace_type, WorkspaceType) else workspace.workspace_type,
    }

    # 添加可选字段
    if workspace.base_url:
        result["baseUrl"] = workspace.base_url
    if workspace.directory:
        result["directory"] = workspace.directory

    # 添加 opencode 信息（不包含密码）
    if workspace.opencode:
        opencode_info = {}
        if workspace.opencode.get("baseUrl"):
            opencode_info["baseUrl"] = workspace.opencode["baseUrl"]
        if workspace.opencode.get("directory"):
            opencode_info["directory"] = workspace.opencode["directory"]
        if workspace.opencode.get("username"):
            opencode_info["username"] = workspace.opencode["username"]
        # 不包含密码
        if opencode_info:
            result["opencode"] = opencode_info

    return result


async def find_workspace_roots(workspace_root: str) -> List[str]:
    """
    查找工作空间根目录列表
    从给定路径向上遍历，直到找到 .git 目录或到达文件系统根目录。
    Args:
        workspace_root: 工作空间根目录
    Returns:
        根目录路径列表
    """
    roots: List[str] = []
    current = os.path.abspath(workspace_root)

    while True:
        roots.append(current)
        git_path = os.path.join(current, ".git")

        if os.path.exists(git_path):
            break

        parent = os.path.dirname(current)
        if parent == current:
            break
        current = parent

    return roots


def get_active_workspace(config) -> Optional[WorkspaceInfo]:
    """
    获取活动工作空间

    Args:
        config: 服务器配置
    Returns:
        活动工作空间信息，如果没有则返回 None
    """
    if config.workspaces:
        return config.workspaces[0]
    return None

def list_workspaces(config) -> List[WorkspaceInfo]:
    """
    列出所有工作空间

    Args:
        config: 服务器配置
    Returns:
        工作空间信息列表
    """
    return list(config.workspaces)


