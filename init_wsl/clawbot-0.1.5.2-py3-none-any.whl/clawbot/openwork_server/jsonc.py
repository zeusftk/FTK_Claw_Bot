"""
JSONC 解析模块

提供 JSONC (JSON with Comments) 解析和格式保留更新功能。"""

import json
import os
import re
from typing import Any, Dict, List, Tuple

from .errors import ApiError
from .utils import ensure_dir, exists

try:
    import aiofiles
    HAS_AIOFILES = True
except ImportError:
    HAS_AIOFILES = False


class JsoncParseError(ApiError):
    """JSONC 解析错误"""
    def __init__(self, message: str, details: List[Dict] = None):
        super().__init__(422, "invalid_jsonc", message, details)


def _remove_comments(content: str) -> str:
    """
    移除 JSONC 中的注释

    Args:
        content: JSONC 内容

    Returns:
        移除注释后的 JSON 字符串    """
    result = []
    i = 0
    in_string = False
    string_char = None

    while i < len(content):
        char = content[i]

        if in_string:
            result.append(char)
            if char == "\\" and i + 1 < len(content):
                result.append(content[i + 1])
                i += 2
                continue
            if char == string_char:
                in_string = False
            i += 1
            continue

        if char in ('"', "'"):
            in_string = True
            string_char = char
            result.append(char)
            i += 1
            continue

        if char == "/" and i + 1 < len(content):
            next_char = content[i + 1]
            if next_char == "/":
                while i < len(content) and content[i] != "\n":
                    i += 1
                continue
            elif next_char == "*":
                i += 2
                while i + 1 < len(content):
                    if content[i] == "*" and content[i + 1] == "/":
                        i += 2
                        break
                    i += 1
                continue

        result.append(char)
        i += 1

    return "".join(result)


def _remove_trailing_commas(content: str) -> str:
    """
    移除尾随逗号

    Args:
        content: JSON 内容

    Returns:
        移除尾随逗号后的 JSON 字符串    """
    return re.sub(r",(\s*[}\]])", r"\1", content)


def parse_jsonc(content: str) -> Any:
    """
    解析 JSONC 内容

    Args:
        content: JSONC 内容

    Returns:
        解析后的 Python 对象

    Raises:
        JsoncParseError: 解析失败
    """
    try:
        cleaned = _remove_comments(content)
        cleaned = _remove_trailing_commas(cleaned)
        return json.loads(cleaned)
    except json.JSONDecodeError as e:
        raise JsoncParseError(
            f"Failed to parse JSONC: {e.msg}",
            [{"code": "parse_error", "message": e.msg, "position": e.pos}]
        )


async def read_jsonc_file(path: str, fallback: Any = None) -> Tuple[Any, str]:
    """
    读取 JSONC 文件

    Args:
        path: 文件路径
        fallback: 文件不存在时的默认值
    Returns:
        (解析后的数据, 原始内容)
    """
    if not await exists(path):
        return fallback if fallback is not None else {}, ""

    if HAS_AIOFILES:
        async with aiofiles.open(path, "r", encoding="utf-8") as f:
            raw = await f.read()
    else:
        with open(path, "r", encoding="utf-8") as f:
            raw = f.read()

    data = parse_jsonc(raw)
    return data, raw


async def update_jsonc_top_level(path: str, updates: Dict[str, Any]) -> None:
    """
    更新 JSONC 文件的顶层字段（保留格式：
    Args:
        path: 文件路径
        updates: 要更新的字段
    """
    has_file = await exists(path)

    if not has_file:
        await ensure_dir(os.path.dirname(path))
        content = json.dumps(updates, indent=2, ensure_ascii=False) + "\n"
        if HAS_AIOFILES:
            async with aiofiles.open(path, "w", encoding="utf-8") as f:
                await f.write(content)
        else:
            with open(path, "w", encoding="utf-8") as f:
                f.write(content)
        return

    if HAS_AIOFILES:
        async with aiofiles.open(path, "r", encoding="utf-8") as f:
            content = await f.read()
    else:
        with open(path, "r", encoding="utf-8") as f:
            content = f.read()

    data = parse_jsonc(content)
    data.update(updates)

    content = json.dumps(data, indent=2, ensure_ascii=False)
    if not content.endswith("\n"):
        content += "\n"

    if HAS_AIOFILES:
        async with aiofiles.open(path, "w", encoding="utf-8") as f:
            await f.write(content)
    else:
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)


async def write_jsonc_file(path: str, value: Any) -> None:
    """
    写入 JSONC 文件

    Args:
        path: 文件路径
        value: 要写入的值    """
    await ensure_dir(os.path.dirname(path))
    content = json.dumps(value, indent=2, ensure_ascii=False) + "\n"
    if HAS_AIOFILES:
        async with aiofiles.open(path, "w", encoding="utf-8") as f:
            await f.write(content)
    else:
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)


def parse_jsonc_sync(content: str) -> Any:
    """
    同步解析 JSONC 内容

    Args:
        content: JSONC 内容

    Returns:
        解析后的 Python 对象
    """
    cleaned = _remove_comments(content)
    cleaned = _remove_trailing_commas(cleaned)
    return json.loads(cleaned)


def read_jsonc_file_sync(path: str, fallback: Any = None) -> Tuple[Any, str]:
    """
    同步读取 JSONC 文件

    Args:
        path: 文件路径
        fallback: 文件不存在时的默认值
    Returns:
        (解析后的数据, 原始内容)
    """
    if not os.path.exists(path):
        return fallback if fallback is not None else {}, ""

    with open(path, "r", encoding="utf-8") as f:
        raw = f.read()

    data = parse_jsonc_sync(raw)
    return data, raw
