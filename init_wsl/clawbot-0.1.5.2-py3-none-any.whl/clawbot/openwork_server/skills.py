"""
OpenWork Server 技能管理模块
提供技能的列表、创建、更新和删除功能。"""

import os
from typing import List, Optional

from .errors import ApiError
from .frontmatter import build_frontmatter, extract_trigger_from_body, parse_frontmatter
from .types import SkillItem
from .utils import ensure_dir, exists, join_path, read_file, remove_dir, resolve_home, write_file
from .validators import validate_description, validate_skill_name
from .workspace_files import project_skills_dir
from .workspaces import find_workspace_roots


async def _parse_skill_entry(
    skill_path: str,
    entry_name: str,
    scope: str
) -> Optional[SkillItem]:
    """
    解析技能条目

    Args:
        skill_path: 技能文件路径
        entry_name: 条目名称
        scope: 作用域(project/global)

    Returns:
        技能条目或 None
    """
    try:
        content = await read_file(skill_path)
        data, body = parse_frontmatter(content)

        name = data.get("name", entry_name) if isinstance(data.get("name"), str) else entry_name
        description = data.get("description", "") if isinstance(data.get("description"), str) else ""

        trigger = None
        if isinstance(data.get("trigger"), str):
            trigger = data["trigger"]
        elif isinstance(data.get("when"), str):
            trigger = data["when"]
        else:
            trigger = extract_trigger_from_body(body)

        try:
            validate_skill_name(name)
            validate_description(description)
        except ApiError:
            return None

        if name != entry_name:
            return None

        return SkillItem(
            name=name,
            description=description,
            path=skill_path,
            scope=scope,
            trigger=trigger.strip() if trigger else None
        )
    except Exception:
        return None


async def _list_skills_in_dir(
    dir_path: str,
    scope: str
) -> List[SkillItem]:
    """
    列出目录中的技能

    Args:
        dir_path: 目录路径
        scope: 作用域
    Returns:
        技能列表
    """
    if not await exists(dir_path):
        return []

    items: List[SkillItem] = []

    try:
        entries = await _list_dir_entries(dir_path)
    except Exception:
        return []

    for entry in entries:
        if not entry.is_dir():
            continue

        skill_path = join_path(dir_path, entry.name, "SKILL.md")

        if await exists(skill_path):
            item = await _parse_skill_entry(skill_path, entry.name, scope)
            if item:
                items.append(item)
        else:
            domain_dir = join_path(dir_path, entry.name)
            try:
                sub_entries = await _list_dir_entries(domain_dir)
            except Exception:
                continue

            for sub_entry in sub_entries:
                if not sub_entry.is_dir():
                    continue

                sub_skill_path = join_path(domain_dir, sub_entry.name, "SKILL.md")
                if not await exists(sub_skill_path):
                    continue

                item = await _parse_skill_entry(sub_skill_path, sub_entry.name, scope)
                if item:
                    items.append(item)

    return items


async def _list_dir_entries(dir_path: str):
    """列出目录条目"""
    from dataclasses import dataclass

    @dataclass
    class DirEntry:
        name: str
        path: str

        def is_dir(self) -> bool:
            return os.path.isdir(self.path)

        def is_file(self) -> bool:
            return os.path.isfile(self.path)

    entries = []
    for name in os.listdir(dir_path):
        entries.append(DirEntry(name=name, path=os.path.join(dir_path, name)))
    return entries


async def list_skills(
    workspace_root: str,
    include_global: bool = True
) -> List[SkillItem]:
    """
    列出所有技能

    Args:
        workspace_root: 工作空间根目录
        include_global: 是否包含全局技能
    Returns:
        技能列表
    """
    roots = await find_workspace_roots(workspace_root)
    items: List[SkillItem] = []

    for root in roots:
        opencode_dir = join_path(root, ".opencode", "skills")
        claude_dir = join_path(root, ".claude", "skills")
        items.extend(await _list_skills_in_dir(opencode_dir, "project"))
        items.extend(await _list_skills_in_dir(claude_dir, "project"))

    if include_global:
        global_openwork = join_path(resolve_home(), ".config", "opencode", "skills")
        global_claude = join_path(resolve_home(), ".claude", "skills")
        items.extend(await _list_skills_in_dir(global_openwork, "global"))
        items.extend(await _list_skills_in_dir(global_claude, "global"))

    seen = set()
    result = []
    for item in items:
        if item.name not in seen:
            seen.add(item.name)
            result.append(item)

    return result


async def upsert_skill(
    workspace_root: str,
    payload: dict
) -> dict:
    """
    创建或更新技能

    Args:
        workspace_root: 工作空间根目录
        payload: 技能数据 {name, content, description?}

    Returns:
        {path, action} 操作结果

    Raises:
        ApiError: 如果参数无效
    """
    name = payload.get("name", "").strip()
    validate_skill_name(name)

    content = payload.get("content", "")
    if not content:
        raise ApiError(400, "invalid_skill_content", "Skill content is required")

    data, body = parse_frontmatter(content)

    if data:
        frontmatter_name = data.get("name", "") if isinstance(data.get("name"), str) else ""
        frontmatter_description = data.get("description", "") if isinstance(data.get("description"), str) else ""

        if frontmatter_name and frontmatter_name != name:
            raise ApiError(
                400,
                "invalid_skill_name",
                "Skill frontmatter name must match payload name"
            )

        validate_description(frontmatter_description or payload.get("description", ""))

        next_description = frontmatter_description or payload.get("description", "")
        frontmatter = build_frontmatter({
            **data,
            "name": name,
            "description": next_description
        })
        content = frontmatter + body.lstrip("\n")
    else:
        validate_description(payload.get("description", ""))
        frontmatter = build_frontmatter({
            "name": name,
            "description": payload.get("description", "")
        })
        content = frontmatter + content.lstrip("\n")

    if not content.endswith("\n"):
        content += "\n"

    base_dir = project_skills_dir(workspace_root)
    skill_dir = join_path(base_dir, name)
    await ensure_dir(skill_dir)

    skill_path = join_path(skill_dir, "SKILL.md")
    existed = await exists(skill_path)

    await write_file(skill_path, content)

    return {
        "path": skill_path,
        "action": "updated" if existed else "added"
    }


async def delete_skill(
    workspace_root: str,
    name: str
) -> dict:
    """
    删除技能

    Args:
        workspace_root: 工作空间根目录
        name: 技能名称
    Returns:
        {path} 删除的路径
    Raises:
        ApiError: 如果技能不存在
    """
    trimmed = name.strip()
    validate_skill_name(trimmed)

    base_dir = project_skills_dir(workspace_root)
    skill_dir = join_path(base_dir, trimmed)
    skill_path = join_path(skill_dir, "SKILL.md")

    if not await exists(skill_path):
        raise ApiError(404, "skill_not_found", f"Skill not found: {trimmed}")

    await remove_dir(skill_dir, recursive=True)

    return {"path": skill_dir}


async def get_skill(
    workspace_root: str,
    name: str
) -> Optional[SkillItem]:
    """
    获取单个技能

    Args:
        workspace_root: 工作空间根目录
        name: 技能名称
    Returns:
        技能条目或 None
    """
    skills = await list_skills(workspace_root, include_global=True)
    for skill in skills:
        if skill.name == name:
            return skill
    return None
