"""
OpenWork Server 类型定义模块

定义了 OpenWork Server 使用的所有数据类型和接口。
"""

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class WorkspaceType(str, Enum):
    """工作空间类型"""
    LOCAL = "local"
    REMOTE = "remote"


class ApprovalMode(str, Enum):
    """审批模式"""
    MANUAL = "manual"
    AUTO = "auto"


class SessionStatus(str, Enum):
    """会话状态"""
    IDLE = "idle"
    RUNNING = "running"
    WAITING_PERMISSION = "waiting_permission"
    COMPLETED = "completed"
    FAILED = "failed"


class EventType(str, Enum):
    """SSE 事件类型"""
    PROGRESS = "progress"
    TODO_UPDATE = "todo_update"
    PERMISSION_REQUEST = "permission_request"
    ERROR = "error"
    COMPLETED = "completed"
    FILE_CHANGE = "file_change"


class TokenScope(str, Enum):
    """Token 权限范围"""
    OWNER = "owner"
    COLLABORATOR = "collaborator"
    VIEWER = "viewer"


class SandboxBackend(str, Enum):
    """沙箱后端类型"""
    NONE = "none"
    DOCKER = "docker"
    CONTAINER = "container"


class ProviderPlacement(str, Enum):
    """提供者部署位置"""
    IN_SANDBOX = "in-sandbox"
    HOST_MACHINE = "host-machine"
    CLIENT_MACHINE = "client-machine"
    EXTERNAL = "external"


class LogFormat(str, Enum):
    """日志格式"""
    PRETTY = "pretty"
    JSON = "json"


@dataclass
class WorkspaceConfig:
    """工作空间配置"""
    path: str
    name: Optional[str] = None
    workspace_type: Optional[WorkspaceType] = None
    base_url: Optional[str] = None
    directory: Optional[str] = None
    opencode_username: Optional[str] = None
    opencode_password: Optional[str] = None


@dataclass
class WorkspaceInfo:
    """工作空间信息"""
    id: str
    name: str
    path: str
    workspace_type: WorkspaceType
    base_url: Optional[str] = None
    directory: Optional[str] = None
    opencode_username: Optional[str] = None
    opencode_password: Optional[str] = None
    opencode: Optional[Dict[str, Any]] = None


@dataclass
class ApprovalConfig:
    """审批配置"""
    mode: ApprovalMode
    timeout_ms: int


@dataclass
class ServerConfig:
    """服务器配置"""
    host: str
    port: int
    token: str
    host_token: str
    config_path: Optional[str] = None
    approval: Optional[ApprovalConfig] = None
    cors_origins: List[str] = field(default_factory=lambda: ["*"])
    workspaces: List[WorkspaceInfo] = field(default_factory=list)
    authorized_roots: List[str] = field(default_factory=list)
    read_only: bool = False
    started_at: int = 0
    token_source: str = "generated"
    host_token_source: str = "generated"
    log_format: LogFormat = LogFormat.PRETTY
    log_requests: bool = True
    # OpenCode 代理配置
    opencode_base_url: Optional[str] = None  # OpenCode Server URL (e.g., http://127.0.0.1:3000)
    opencode_cli_path: Optional[str] = None  # OpenCode CLI 路径 (默认从 PATH 查找)


@dataclass
class Capabilities:
    """服务器能力描述"""
    schema_version: int = 1
    server_version: str = "0.1.0"
    skills: Dict[str, Any] = field(default_factory=lambda: {"read": True, "write": True, "source": "openwork"})
    hub: Dict[str, Any] = field(default_factory=lambda: {
        "skills": {
            "read": True,
            "install": True,
            "repo": {"owner": "different-ai", "name": "openwork-hub", "ref": "main"}
        }
    })
    plugins: Dict[str, Any] = field(default_factory=lambda: {"read": True, "write": True})
    mcp: Dict[str, Any] = field(default_factory=lambda: {"read": True, "write": True})
    commands: Dict[str, Any] = field(default_factory=lambda: {"read": True, "write": True})
    config: Dict[str, Any] = field(default_factory=lambda: {"read": True, "write": True})
    approvals: Dict[str, Any] = field(default_factory=lambda: {"mode": "manual", "timeout_ms": 30000})
    sandbox: Dict[str, Any] = field(default_factory=lambda: {"enabled": False, "backend": "none"})
    ui: Dict[str, Any] = field(default_factory=lambda: {"toy": True})
    tokens: Dict[str, Any] = field(default_factory=lambda: {"scoped": True, "scopes": ["owner", "collaborator", "viewer"]})
    proxy: Dict[str, Any] = field(default_factory=lambda: {"opencode": False, "opencode_router": False})
    tool_providers: Dict[str, Any] = field(default_factory=lambda: {
        "browser": {"enabled": False, "placement": "external", "mode": "none"},
        "files": {
            "injection": True,
            "outbox": True,
            "inbox_path": ".opencode/openwork/inbox/",
            "outbox_path": ".opencode/openwork/outbox/",
            "max_bytes": 50000000
        }
    })


class ReloadReason(str, Enum):
    """重载原因"""
    PLUGINS = "plugins"
    SKILLS = "skills"
    MCP = "mcp"
    CONFIG = "config"
    AGENTS = "agents"
    COMMANDS = "commands"


@dataclass
class ReloadTrigger:
    """重载触发器"""
    type: str
    name: Optional[str] = None
    action: Optional[str] = None
    path: Optional[str] = None


@dataclass
class ReloadEvent:
    """重载事件"""
    id: str
    seq: int
    workspace_id: str
    reason: ReloadReason
    timestamp: int
    trigger: Optional[ReloadTrigger] = None


@dataclass
class ApiErrorBody:
    """API 错误响应体"""
    code: str
    message: str
    details: Optional[Any] = None


@dataclass
class PluginItem:
    """插件项"""
    spec: str
    source: str
    scope: str
    path: Optional[str] = None


@dataclass
class McpItem:
    """MCP 项"""
    name: str
    config: Dict[str, Any]
    source: str
    disabled_by_tools: Optional[bool] = None


@dataclass
class SkillItem:
    """技能项"""
    name: str
    path: str
    description: str
    scope: str
    trigger: Optional[str] = None


@dataclass
class HubSkillItem:
    """Hub 技能项"""
    name: str
    description: str
    trigger: Optional[str] = None
    source: Optional[Dict[str, str]] = None


@dataclass
class CommandItem:
    """命令项"""
    name: str
    template: str
    scope: str
    description: Optional[str] = None
    agent: Optional[str] = None
    model: Optional[str] = None
    subtask: Optional[bool] = None


@dataclass
class Actor:
    """操作者信息"""
    type: str
    client_id: Optional[str] = None
    token_hash: Optional[str] = None
    scope: Optional[TokenScope] = None


@dataclass
class ApprovalRequest:
    """审批请求"""
    id: str
    workspace_id: str
    action: str
    summary: str
    paths: List[str]
    created_at: int
    actor: Actor


@dataclass
class AuditEntry:
    """审计日志条目"""
    id: str
    workspace_id: str
    actor: Actor
    action: str
    target: str
    summary: str
    timestamp: int


@dataclass
class ScheduledJobRun:
    """计划任务运行配置"""
    prompt: Optional[str] = None
    command: Optional[str] = None
    arguments: Optional[str] = None
    files: Optional[List[str]] = None
    agent: Optional[str] = None
    model: Optional[str] = None
    variant: Optional[str] = None
    title: Optional[str] = None
    share: Optional[bool] = None
    continue_session: Optional[bool] = field(default=None, metadata={"name": "continue"})
    session: Optional[str] = None
    run_format: Optional[str] = None
    attach_url: Optional[str] = None
    port: Optional[int] = None


@dataclass
class ScheduledJob:
    """计划任务"""
    slug: str
    name: str
    schedule: str
    created_at: str
    scope_id: Optional[str] = None
    timeout_seconds: Optional[int] = None
    invocation: Optional[Dict[str, Any]] = None
    prompt: Optional[str] = None
    attach_url: Optional[str] = None
    run: Optional[ScheduledJobRun] = None
    source: Optional[str] = None
    workdir: Optional[str] = None
    updated_at: Optional[str] = None
    last_run_at: Optional[str] = None
    last_run_exit_code: Optional[int] = None
    last_run_error: Optional[str] = None
    last_run_source: Optional[str] = None
    last_run_status: Optional[str] = None


@dataclass
class TokenRecord:
    """Token 记录"""
    id: str
    hash: str
    scope: TokenScope
    created_at: int
    label: Optional[str] = None


@dataclass
class Session:
    """编程会话"""
    id: str
    title: str
    cwd: str
    status: SessionStatus
    created_at: int
    updated_at: int
    messages: list[dict] = field(default_factory=list)
    pending_permissions: dict[str, dict] = field(default_factory=dict)


@dataclass
class Event:
    """SSE 事件"""
    type: EventType
    session_id: str
    data: dict
    timestamp: int = field(default_factory=lambda: int(time.time() * 1000))


# ========== 任务管理类型 ==========

class TaskStatus(str, Enum):
    """任务状态"""
    PENDING = "pending"           # 等待执行
    QUEUED = "queued"             # 已入队
    RUNNING = "running"           # 执行中
    WAITING_INPUT = "waiting_input"  # 等待用户输入
    COMPLETED = "completed"       # 已完成
    FAILED = "failed"             # 失败
    CANCELLED = "cancelled"       # 已取消
    TIMEOUT = "timeout"           # 超时


class TaskPriority(str, Enum):
    """任务优先级"""
    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    CRITICAL = "critical"


class TaskType(str, Enum):
    """任务类型"""
    CODE_GENERATION = "code_generation"
    BUG_FIX = "bug_fix"
    REFACTORING = "refactoring"
    TESTING = "testing"
    DOCUMENTATION = "documentation"
    DEPLOYMENT = "deployment"
    ANALYSIS = "analysis"
    CUSTOM = "custom"


@dataclass
class TaskInput:
    """任务输入"""
    prompt: str                              # 任务描述
    workspace_path: Optional[str] = None     # 工作空间路径
    files: Optional[Dict[str, str]] = None   # 附加文件 {路径: 内容}
    context: Optional[Dict[str, Any]] = None # 额外上下文
    env: Optional[Dict[str, str]] = None     # 环境变量


@dataclass
class TaskOutput:
    """任务输出"""
    result: Optional[str] = None              # 执行结果
    files_changed: List[str] = field(default_factory=list)  # 变更文件列表
    files_created: List[str] = field(default_factory=list)  # 创建文件列表
    files_deleted: List[str] = field(default_factory=list)  # 删除文件列表
    commands_executed: List[str] = field(default_factory=list)  # 执行的命令
    artifacts: Dict[str, str] = field(default_factory=dict)  # 产出物


@dataclass
class Task:
    """任务"""
    id: str
    title: str
    type: TaskType
    status: TaskStatus
    priority: TaskPriority
    input: TaskInput
    output: Optional[TaskOutput] = None
    workspace_id: Optional[str] = None
    session_id: Optional[str] = None
    parent_task_id: Optional[str] = None
    created_at: int = field(default_factory=lambda: int(time.time() * 1000))
    started_at: Optional[int] = None
    completed_at: Optional[int] = None
    updated_at: int = field(default_factory=lambda: int(time.time() * 1000))
    timeout_ms: int = 300000  # 5分钟默认超时
    retry_count: int = 0
    max_retries: int = 3
    error_message: Optional[str] = None
    error_code: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    tags: List[str] = field(default_factory=list)


@dataclass
class TaskSubmitRequest:
    """任务提交请求"""
    prompt: str
    title: Optional[str] = None
    type: TaskType = TaskType.CUSTOM
    priority: TaskPriority = TaskPriority.NORMAL
    workspace_id: Optional[str] = None
    workspace_path: Optional[str] = None
    files: Optional[Dict[str, str]] = None
    context: Optional[Dict[str, Any]] = None
    env: Optional[Dict[str, str]] = None
    timeout_ms: Optional[int] = None
    tags: Optional[List[str]] = None
    parent_task_id: Optional[str] = None
    auto_start: bool = True


@dataclass
class TaskProgress:
    """任务进度"""
    task_id: str
    status: TaskStatus
    progress_percent: float  # 0-100
    current_step: str
    total_steps: int
    completed_steps: int
    message: Optional[str] = None
    timestamp: int = field(default_factory=lambda: int(time.time() * 1000))


@dataclass
class RemoteWorkspace:
    """远程工作空间"""
    id: str
    name: str
    path: str
    status: str  # active, inactive, error
    created_at: int
    updated_at: int
    last_accessed_at: Optional[int] = None
    size_bytes: int = 0
    file_count: int = 0
    active_tasks: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)
