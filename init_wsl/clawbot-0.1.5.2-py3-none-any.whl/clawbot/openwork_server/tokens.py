"""
OpenWork Server Token 管理模块

提供 Token 的创建、验证和撤销功能。"""

import asyncio
import os
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from .types import ServerConfig, TokenRecord, TokenScope
from .utils import ensure_dir, hash_token, read_json_file, short_id, write_json_file
from .workspace_files import token_store_path


@dataclass
class TokenStoreFile:
    """Token 存储文件格式"""
    schema_version: int = 1
    updated_at: int = 0
    tokens: List[Dict[str, Any]] = None

    def __post_init__(self):
        if self.tokens is None:
            self.tokens = []


def _normalize_scope(value: Any) -> Optional[TokenScope]:
    """
    规范�?Token 范围

    Args:
        value: 范围�?
    Returns:
        TokenScope �?None
    """
    if value == "owner":
        return TokenScope.OWNER
    if value == "collaborator":
        return TokenScope.COLLABORATOR
    if value == "viewer":
        return TokenScope.VIEWER
    return None


async def _read_token_store(path: str) -> TokenStoreFile:
    """
    读取 Token 存储

    Args:
        path: 存储文件路径

    Returns:
        Token 存储数据
    """
    if not os.path.exists(path):
        return TokenStoreFile()

    try:
        data = await read_json_file(path)
        if not data:
            return TokenStoreFile()

        tokens = []
        for token in data.get("tokens", []):
            record = token if isinstance(token, dict) else {}
            token_id = record.get("id", "")
            token_hash = record.get("hash", "")
            scope = _normalize_scope(record.get("scope"))
            created_at = record.get("createdAt", 0)
            label = record.get("label")

            if token_id and token_hash and scope:
                tokens.append({
                    "id": token_id,
                    "hash": token_hash,
                    "scope": scope.value,
                    "createdAt": created_at,
                    **({"label": label} if label else {})
                })

        return TokenStoreFile(
            schema_version=data.get("schemaVersion", 1),
            updated_at=data.get("updatedAt", 0),
            tokens=tokens
        )
    except Exception:
        return TokenStoreFile()


async def _write_token_store(path: str, tokens: List[TokenRecord]) -> None:
    """
    写入 Token 存储

    Args:
        path: 存储文件路径
        tokens: Token 列表
    """
    await ensure_dir(os.path.dirname(path))

    payload = {
        "schemaVersion": 1,
        "updatedAt": int(asyncio.get_event_loop().time() * 1000),
        "tokens": [
            {
                "id": t.id,
                "hash": t.hash,
                "scope": t.scope.value,
                "createdAt": t.created_at,
                **({"label": t.label} if t.label else {})
            }
            for t in tokens
        ]
    }

    await write_json_file(path, payload)


class TokenService:
    """Token 服务"""

    def __init__(self, config: ServerConfig):
        """
        初始�?Token 服务

        Args:
            config: 服务器配�?        """
        self.config = config
        self._path = token_store_path(config.config_path)
        self._loaded = False
        self._tokens: List[TokenRecord] = []
        self._by_hash: Dict[str, TokenRecord] = {}

    async def _ensure_loaded(self) -> None:
        """确保已加�?Token 存储"""
        if self._loaded:
            return

        store = await _read_token_store(self._path)
        self._tokens = [
            TokenRecord(
                id=t["id"],
                hash=t["hash"],
                scope=TokenScope(t["scope"]),
                created_at=t["createdAt"],
                label=t.get("label")
            )
            for t in store.tokens
        ]
        self._by_hash = {t.hash: t for t in self._tokens}
        self._loaded = True

    async def list(self) -> List[Dict[str, Any]]:
        """
        列出所�?Token（不包含哈希：
        Returns:
            Token 列表
        """
        await self._ensure_loaded()
        return [
            {
                "id": t.id,
                "scope": t.scope.value,
                "createdAt": t.created_at,
                **({"label": t.label} if t.label else {})
            }
            for t in self._tokens
        ]

    async def create(
        self,
        scope: TokenScope,
        label: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        创建新 Token

        Args:
            scope: Token 范围
            label: Token 标签

        Returns:
            创建的 Token 信息（包含明文 Token）
        """
        await self._ensure_loaded()

        token_id = short_id()
        # 生成 Token 字符串
        token = f"owt_{short_id().replace('-', '')}"
        created_at = int(asyncio.get_event_loop().time() * 1000)

        record = TokenRecord(
            id=token_id,
            hash=hash_token(token),
            scope=scope,
            created_at=created_at,
            label=label.strip() if label and label.strip() else None
        )

        self._tokens.insert(0, record)
        self._by_hash[record.hash] = record

        await _write_token_store(self._path, self._tokens)

        return {
            "id": token_id,
            "token": token,
            "scope": scope.value,
            "createdAt": created_at,
            **({"label": record.label} if record.label else {})
        }

    async def revoke(self, token_id: str) -> bool:
        """
        撤销 Token

        Args:
            token_id: Token ID

        Returns:
            是否撤销成功
        """
        await self._ensure_loaded()

        for i, t in enumerate(self._tokens):
            if t.id == token_id:
                removed = self._tokens.pop(i)
                del self._by_hash[removed.hash]
                await _write_token_store(self._path, self._tokens)
                return True

        return False

    async def scope_for_token(self, token: str) -> Optional[TokenScope]:
        """
        获取 Token 的范围

        Args:
            token: Token 字符串
        Returns:
            Token 范围，如果无效则返回 None
        """
        trimmed = token.strip()
        if not trimmed:
            return None

        # 检查是否是服务�?Token
        if trimmed == self.config.token:
            return TokenScope.COLLABORATOR

        await self._ensure_loaded()

        record = self._by_hash.get(hash_token(trimmed))
        return record.scope if record else None

    async def validate_token(self, token: str) -> Optional[Dict[str, Any]]:
        """
        验证 Token

        Args:
            token: Token 字符串
        Returns:
            Token 信息，如果无效则返回 None
        """
        trimmed = token.strip()
        if not trimmed:
            return None

        scope = await self.scope_for_token(trimmed)
        if not scope:
            return None

        return {
            "valid": True,
            "scope": scope.value
        }
