"""
技能 Hub 模块

提供从 GitHub Hub 获取和安装技能的功能。"""

import os
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from .errors import ApiError
from .frontmatter import parse_frontmatter
from .utils import ensure_dir, exists
from .validators import validate_skill_name
from .workspace_files import project_skills_dir

try:
    import aiohttp
    HAS_AIOHTTP = True
except ImportError:
    HAS_AIOHTTP = False

try:
    import aiofiles
    HAS_AIOFILES = True
except ImportError:
    HAS_AIOFILES = False


@dataclass
class HubRepo:
    """Hub 仓库配置"""
    owner: str = "different-ai"
    repo: str = "openwork-hub"
    ref: str = "main"


@dataclass
class HubSkillItem:
    """Hub 技能项"""
    name: str
    description: str
    trigger: Optional[str] = None
    source: Optional[Dict[str, str]] = None


@dataclass
class InstallResult:
    """安装结果"""
    name: str
    path: str
    action: str  # "added" or "updated"
    written: int = 0
    skipped: int = 0


DEFAULT_HUB_REPO = HubRepo()
CATALOG_TTL_MS = 5 * 60 * 1000  # 5 minutes
_cached_catalog: Optional[Dict[str, Any]] = None


def _hub_api_base(repo: HubRepo) -> str:
    """获取 GitHub API 基础 URL"""
    return f"https://api.github.com/repos/{repo.owner}/{repo.repo}"


def _hub_raw_base(repo: HubRepo) -> str:
    """获取 GitHub Raw 基础 URL"""
    return f"https://raw.githubusercontent.com/{repo.owner}/{repo.repo}/{repo.ref}"


async def _fetch_json(url: str) -> Any:
    """获取 JSON 数据"""
    if not HAS_AIOHTTP:
        raise RuntimeError("aiohttp is required for hub functionality")

    async with aiohttp.ClientSession() as session:
        headers = {
            "Accept": "application/vnd.github+json",
            "User-Agent": "openwork-server"
        }
        async with session.get(url, headers=headers) as response:
            if response.status != 200:
                text = await response.text()
                raise ApiError(502, "hub_fetch_failed", f"Failed to fetch hub data ({response.status}): {text or url}")
            return await response.json()


async def _fetch_text(url: str) -> str:
    """获取文本数据"""
    if not HAS_AIOHTTP:
        raise RuntimeError("aiohttp is required for hub functionality")

    async with aiohttp.ClientSession() as session:
        headers = {
            "Accept": "text/plain",
            "User-Agent": "openwork-server"
        }
        async with session.get(url, headers=headers) as response:
            if response.status != 200:
                text = await response.text()
                raise ApiError(502, "hub_fetch_failed", f"Failed to fetch hub data ({response.status}): {text or url}")
            return await response.text()


async def _fetch_bytes(url: str) -> bytes:
    """获取二进制数据"""
    if not HAS_AIOHTTP:
        raise RuntimeError("aiohttp is required for hub functionality")

    async with aiohttp.ClientSession() as session:
        headers = {
            "User-Agent": "openwork-server"
        }
        async with session.get(url, headers=headers) as response:
            if response.status != 200:
                text = await response.text()
                raise ApiError(502, "hub_fetch_failed", f"Failed to fetch hub file ({response.status}): {text or url}")
            return await response.read()


def _extract_trigger_from_body(body: str) -> str:
    """从技能内容中提取触发条件"""
    lines = body.split("\n")
    in_when_section = False

    for line in lines:
        trimmed = line.strip()
        if not trimmed:
            continue

        if trimmed.startswith("#"):
            heading = trimmed.lstrip("#").strip()
            in_when_section = heading.lower() == "when to use"
            continue

        if not in_when_section:
            continue

        import re
        cleaned = re.sub(r"^[-*+]\s+", "", trimmed)
        cleaned = re.sub(r"^\d+[.)]\s+", "", cleaned)
        cleaned = cleaned.strip()
        if cleaned:
            return cleaned

    return ""


async def list_hub_skills(repo: HubRepo = None) -> List[HubSkillItem]:
    """
    列出 Hub 中的所有技�?
    Args:
        repo: Hub 仓库配置，默认使�?DEFAULT_HUB_REPO

    Returns:
        Hub 技能列�?    """
    global _cached_catalog

    if repo is None:
        repo = DEFAULT_HUB_REPO

    now = int(time.time() * 1000)

    if _cached_catalog and (now - _cached_catalog.get("at", 0)) < CATALOG_TTL_MS:
        return _cached_catalog.get("items", [])

    listing = await _fetch_json(f"{_hub_api_base(repo)}/contents/skills?ref={repo.ref}")

    dirs = []
    if isinstance(listing, list):
        for entry in listing:
            if isinstance(entry, dict) and entry.get("type") == "dir" and isinstance(entry.get("name"), str):
                dirs.append(entry["name"])

    raw_base = _hub_raw_base(repo)
    items: List[HubSkillItem] = []

    for dir_name in dirs:
        try:
            skill_name = dir_name.strip()
            validate_skill_name(skill_name)

            skill_md = await _fetch_text(f"{raw_base}/skills/{skill_name}/SKILL.md")
            data, body = parse_frontmatter(skill_md)

            name = data.get("name", skill_name) if isinstance(data.get("name"), str) else skill_name
            description_raw = data.get("description", "") if isinstance(data.get("description"), str) else ""

            trigger_raw = ""
            if isinstance(data.get("trigger"), str):
                trigger_raw = data["trigger"]
            elif isinstance(data.get("when"), str):
                trigger_raw = data["when"]
            else:
                trigger_raw = _extract_trigger_from_body(body)

            if name != skill_name:
                continue

            description = " ".join(description_raw.split())[:1024]
            trigger = trigger_raw.strip() if trigger_raw else ""

            item = HubSkillItem(
                name=name,
                description=description,
                trigger=trigger if trigger else None,
                source={
                    "owner": repo.owner,
                    "repo": repo.repo,
                    "ref": repo.ref,
                    "path": f"skills/{skill_name}"
                }
            )
            items.append(item)
        except Exception:
            continue

    items.sort(key=lambda x: x.name)

    _cached_catalog = {"at": now, "items": items}
    return items


def _resolve_safe_child(base_dir: str, child: str) -> str:
    """安全地解析子路径"""
    base = os.path.realpath(base_dir)
    target = os.path.realpath(os.path.join(base_dir, child))

    if target == base:
        return target

    if not (target.startswith(base + "/") or target.startswith(base + "\\")):
        raise ApiError(400, "invalid_path", "Invalid file path")

    return target


async def install_hub_skill(
    workspace_root: str,
    name: str,
    overwrite: bool = False,
    repo: HubRepo = None
) -> InstallResult:
    """
    从 Hub 安装技能到工作空间

    Args:
        workspace_root: 工作空间路径
        name: 技能名称
        overwrite: 是否覆盖已存在的文件
        repo: 自定义仓库信息
    Returns:
        安装结果
    """
    if repo is None:
        repo = DEFAULT_HUB_REPO

    skill_name = name.strip()
    validate_skill_name(skill_name)

    prefix = f"skills/{skill_name}/"
    base_dir = os.path.join(project_skills_dir(workspace_root), skill_name)
    skill_md_path = os.path.join(base_dir, "SKILL.md")
    existed_before = await exists(skill_md_path)

    await ensure_dir(base_dir)

    tree = await _fetch_json(f"{_hub_api_base(repo)}/git/trees/{repo.ref}?recursive=1")

    entries = []
    if isinstance(tree, dict) and isinstance(tree.get("tree"), list):
        for entry in tree["tree"]:
            if isinstance(entry, dict) and entry.get("type") == "blob" and isinstance(entry.get("path"), str):
                if entry["path"].startswith(prefix):
                    entries.append({
                        "path": entry["path"],
                        "mode": entry.get("mode", "100644")
                    })

    if not entries:
        raise ApiError(404, "hub_skill_not_found", f"Hub skill not found: {skill_name}")

    written = 0
    skipped = 0
    raw_base = _hub_raw_base(repo)

    for file_entry in entries:
        rel = file_entry["path"][len(prefix):]
        if not rel or rel.startswith("/") or ".." in rel:
            continue

        dest_path = _resolve_safe_child(base_dir, rel)

        if not overwrite and await exists(dest_path):
            skipped += 1
            continue

        await ensure_dir(os.path.dirname(dest_path))

        content = await _fetch_bytes(f"{raw_base}/{file_entry['path']}")

        if HAS_AIOFILES:
            async with aiofiles.open(dest_path, "wb") as f:
                await f.write(content)
        else:
            with open(dest_path, "wb") as f:
                f.write(content)

        if file_entry["mode"] == "100755":
            try:
                os.chmod(dest_path, 0o755)
            except OSError:
                pass

        written += 1

    if not await exists(skill_md_path):
        raise ApiError(502, "hub_install_failed", f"Hub skill install failed (missing SKILL.md): {skill_name}")

    return InstallResult(
        name=skill_name,
        path=base_dir,
        action="updated" if existed_before else "added",
        written=written,
        skipped=skipped
    )
