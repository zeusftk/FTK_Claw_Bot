"""
OpenWork Server 插件管理模块

提供插件的列表、添加和删除功能。"""

import os
from typing import Any, Dict, List, Optional

from .types import PluginItem
from .utils import exists, join_path, read_json_file, relative_path, write_json_file
from .validators import validate_plugin_spec
from .workspace_files import global_plugins_dir, opencode_config_path, project_plugins_dir


def normalize_plugin_spec(spec: str) -> str:
    """
    规范化插件规格

    Args:
        spec: 插件规格

    Returns:
        规范化后的规格
    """
    trimmed = spec.strip()

    # 保留 URL 和文件路径
    if trimmed.startswith(("file:", "http:", "https:", "git:")):
        return trimmed

    # 绝对路径
    if trimmed.startswith("/"):
        return trimmed

    # 作用域包名 (@org/package)
    if trimmed.startswith("@"):
        at_index = trimmed.find("@", 1)
        return trimmed[:at_index] if at_index > 0 else trimmed

    # 普通包名，移除版本号
    at_index = trimmed.find("@")
    return trimmed[:at_index] if at_index > 0 else trimmed


def _plugin_list_from_config(config: Dict[str, Any]) -> List[str]:
    """
    从配置中提取插件列表

    Args:
        config: 配置字典

    Returns:
        插件规格列表
    """
    plugin = config.get("plugin")
    if isinstance(plugin, str):
        return [plugin]
    if isinstance(plugin, list):
        return [item for item in plugin if isinstance(item, str)]
    return []


async def _list_plugin_files(
    dir_path: str,
    scope: str,
    workspace_root: Optional[str] = None
) -> List[PluginItem]:
    """
    列出目录中的插件文件

    Args:
        dir_path: 目录路径
        scope: 作用域
        workspace_root: 工作空间根目录

    Returns:
        插件列表
    """
    if not await exists(dir_path):
        return []

    items: List[PluginItem] = []

    try:
        entries = os.listdir(dir_path)
    except Exception:
        return []

    for name in entries:
        if not name.endswith((".js", ".ts")):
            continue

        absolute_path = join_path(dir_path, name)

        if workspace_root:
            rel_path = relative_path(absolute_path, workspace_root)
        else:
            rel_path = absolute_path

        items.append(PluginItem(
            spec=f"file://{absolute_path}",
            source="dir.project" if scope == "project" else "dir.global",
            scope=scope,
            path=rel_path
        ))

    return items


async def _read_opencode_config(workspace_root: str) -> Dict[str, Any]:
    """
    读取 OpenCode 配置文件

    Args:
        workspace_root: 工作空间根目录

    Returns:
        配置字典
    """
    config_path = opencode_config_path(workspace_root)
    config = await read_json_file(config_path)
    return config or {}


async def _update_opencode_config(
    workspace_root: str,
    updates: Dict[str, Any]
) -> None:
    """
    更新 OpenCode 配置文件

    Args:
        workspace_root: 工作空间根目录
        updates: 更新内容
    """
    config_path = opencode_config_path(workspace_root)
    config = await _read_opencode_config(workspace_root)
    config.update(updates)
    await write_json_file(config_path, config)


async def list_plugins(
    workspace_root: str,
    include_global: bool = True
) -> Dict[str, Any]:
    """
    列出所有插件

    Args:
        workspace_root: 工作空间根目录
        include_global: 是否包含全局插件

    Returns:
        {items: [...], loadOrder: [...]}
    """
    config = await _read_opencode_config(workspace_root)
    plugin_specs = _plugin_list_from_config(config)

    items: List[PluginItem] = []

    # 配置中的插件
    for spec in plugin_specs:
        items.append(PluginItem(
            spec=spec,
            source="config",
            scope="project"
        ))

    # 项目目录中的插件
    project_dir = project_plugins_dir(workspace_root)
    items.extend(await _list_plugin_files(project_dir, "project", workspace_root))

    # 全局插件
    if include_global:
        global_dir = global_plugins_dir()
        items.extend(await _list_plugin_files(global_dir, "global"))

    return {
        "items": items,
        "loadOrder": ["config.global", "config.project", "dir.global", "dir.project"]
    }


async def add_plugin(
    workspace_root: str,
    spec: str
) -> bool:
    """
    添加插件

    Args:
        workspace_root: 工作空间根目录
        spec: 插件规格

    Returns:
        是否添加成功（如果已存在则返回 False）
    """
    validate_plugin_spec(spec)

    config = await _read_opencode_config(workspace_root)
    plugin_specs = _plugin_list_from_config(config)

    normalized = normalize_plugin_spec(spec)

    # 检查是否已存在
    for existing in plugin_specs:
        if normalize_plugin_spec(existing) == normalized:
            return False

    plugin_specs.append(spec)
    await _update_opencode_config(workspace_root, {"plugin": plugin_specs})

    return True


async def remove_plugin(
    workspace_root: str,
    name: str
) -> bool:
    """
    移除插件

    Args:
        workspace_root: 工作空间根目录
        name: 插件名称或规格

    Returns:
        是否移除成功
    """
    config = await _read_opencode_config(workspace_root)
    plugin_specs = _plugin_list_from_config(config)

    normalized = normalize_plugin_spec(name)
    filtered = [s for s in plugin_specs if normalize_plugin_spec(s) != normalized]

    if len(filtered) == len(plugin_specs):
        return False

    await _update_opencode_config(workspace_root, {"plugin": filtered})
    return True


async def get_plugin(
    workspace_root: str,
    name: str
) -> Optional[PluginItem]:
    """
    获取单个插件

    Args:
        workspace_root: 工作空间根目录
        name: 插件名称

    Returns:
        插件条目或 None
    """
    result = await list_plugins(workspace_root, include_global=True)
    normalized = normalize_plugin_spec(name)

    for item in result["items"]:
        if normalize_plugin_spec(item.spec) == normalized:
            return item

    return None
