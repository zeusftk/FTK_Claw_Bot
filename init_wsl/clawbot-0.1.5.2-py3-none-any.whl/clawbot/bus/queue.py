"""Async message queue for decoupled channel-agent communication."""

import asyncio

from loguru import logger

from clawbot.bus.events import InboundMessage, OutboundMessage


class MessageBus:
    """
    Async message bus that decouples chat channels from the agent core.

    Channels push messages to the inbound queue, and the agent processes
    them and pushes responses to the outbound queue.
    """

    DEFAULT_MAX_QUEUE_SIZE = 1000

    def __init__(self, max_size: int | None = None):
        size = max_size or self.DEFAULT_MAX_QUEUE_SIZE
        self.inbound: asyncio.Queue[InboundMessage] = asyncio.Queue(maxsize=size)
        self.outbound: asyncio.Queue[OutboundMessage] = asyncio.Queue(maxsize=size)
        self._max_size = size

    async def publish_inbound(self, msg: InboundMessage) -> bool:
        try:
            self.inbound.put_nowait(msg)
            return True
        except asyncio.QueueFull:
            logger.warning("Inbound queue full, message dropped")
            return False

    async def consume_inbound(self) -> InboundMessage:
        return await self.inbound.get()

    async def publish_outbound(self, msg: OutboundMessage) -> bool:
        try:
            self.outbound.put_nowait(msg)
            return True
        except asyncio.QueueFull:
            logger.warning("Outbound queue full, message dropped")
            return False

    async def consume_outbound(self) -> OutboundMessage:
        return await self.outbound.get()

    @property
    def inbound_size(self) -> int:
        return self.inbound.qsize()

    @property
    def outbound_size(self) -> int:
        return self.outbound.qsize()

    def clear_inbound(self) -> int:
        count = 0
        while not self.inbound.empty():
            try:
                self.inbound.get_nowait()
                count += 1
            except asyncio.QueueEmpty:
                break
        return count

    def clear_outbound(self) -> int:
        count = 0
        while not self.outbound.empty():
            try:
                self.outbound.get_nowait()
                count += 1
            except asyncio.QueueEmpty:
                break
        return count

    @property
    def max_size(self) -> int:
        return self._max_size
