"""Workspace management for opencode projects."""

import re
from pathlib import Path


class WorkspaceManager:
    """Manages workspace for opencode projects."""

    def __init__(self, root: Path | None = None):
        self._root = root or Path.home() / "clawbot-workspace"
        self._init_directories()

    def _init_directories(self):
        """Initialize workspace directories."""
        self._root.mkdir(parents=True, exist_ok=True)
        (self._root / "projects").mkdir(exist_ok=True)
        (self._root / "tasks").mkdir(exist_ok=True)
        (self._root / ".clawbot").mkdir(exist_ok=True)

    @property
    def root(self) -> Path:
        return self._root

    @property
    def projects_dir(self) -> Path:
        return self._root / "projects"

    @property
    def tasks_dir(self) -> Path:
        return self._root / "tasks"

    def generate_project_name(self, task: str) -> str:
        """Generate project name from task description."""
        name = re.sub(r'[^\w\s\u4e00-\u9fff]', '', task)
        name = name.lower().strip()
        name = re.sub(r'[\s]+', '-', name)

        if len(name) > 50:
            name = name[:50].rstrip('-')

        name = re.sub(r'^\d+-', '', name)

        return name or "project"

    def create_project(self, name: str) -> Path:
        """Create a new project directory."""
        project_dir = self.projects_dir / name
        project_dir.mkdir(parents=True, exist_ok=True)
        return project_dir

    def find_existing_project(self, task: str) -> Path | None:
        """Find existing project that matches the task."""
        target_name = self.generate_project_name(task)

        for project in self.projects_dir.iterdir():
            if project.is_dir() and target_name in project.name:
                return project

        return None

    def list_projects(self) -> list[Path]:
        """List all project directories."""
        if not self.projects_dir.exists():
            return []
        return [p for p in self.projects_dir.iterdir() if p.is_dir()]

    def get_or_create_project(self, task: str) -> tuple[Path, bool]:
        """Get existing project or create new one. Returns (path, is_new)."""
        existing = self.find_existing_project(task)
        if existing:
            return existing, False

        name = self.generate_project_name(task)
        project = self.create_project(name)
        return project, True
