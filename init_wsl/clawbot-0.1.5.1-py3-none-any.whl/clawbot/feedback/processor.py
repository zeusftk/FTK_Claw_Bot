"""
Feedback Processor - 增强版反馈处理器

新增功能:
1. 多维度分析 - 评分 + 评论 + 操作 + 上下文
2. 情感分析 - 分析评论情感
3. 根因分析 - 分析失败根因
4. 改进建议 - 自动生成改进建议
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable

from clawbot.openwork.feedback_collector import (
    FeedbackCollector,
    Feedback,
    FeedbackType,
    FeedbackStatus,
    FeedbackResult,
)

if TYPE_CHECKING:
    from clawbot.openwork.memory import OpenWorkMemoryBridge

logger = logging.getLogger(__name__)


@dataclass
class SentimentResult:
    """情感分析结果"""
    sentiment: str
    confidence: float
    positive_keywords: list[str]
    negative_keywords: list[str]


@dataclass
class RootCauseAnalysis:
    """根因分析结果"""
    root_cause: str
    category: str
    severity: str
    affected_operations: list[str]
    recommendations: list[str]


@dataclass
class ProcessedFeedback:
    """处理后的反馈"""
    feedback: Feedback
    sentiment: SentimentResult | None
    root_cause: RootCauseAnalysis | None
    suggestions: list[str]
    operations: list[str]
    context: dict[str, Any] = field(default_factory=dict)


@dataclass
class FeedbackStats:
    """反馈统计"""
    total_feedback: int
    average_rating: float
    rating_distribution: dict[int, int]
    sentiment_distribution: dict[str, int]
    top_issues: list[str]
    improvement_trend: float


class FeedbackProcessor:
    """
    反馈处理器（增强版）
    
    新增功能:
    1. 多维度分析 - 评分 + 评论 + 操作 + 上下文
    2. 情感分析 - 分析评论情感
    3. 根因分析 - 分析失败根因
    4. 改进建议 - 自动生成改进建议
    """
    
    POSITIVE_KEYWORDS = [
        "满意", "完美", "优秀", "快速", "准确", "高效",
        "good", "great", "excellent", "perfect", "fast",
    ]
    
    NEGATIVE_KEYWORDS = [
        "不满意", "失败", "错误", "问题", "慢", "不准确",
        "bad", "error", "failed", "wrong", "slow", "issue",
    ]
    
    ROOT_CAUSE_PATTERNS = {
        "timeout": {
            "pattern": r"(超时|timeout|timed out)",
            "category": "performance",
            "severity": "medium",
        },
        "permission": {
            "pattern": r"(权限|permission|denied|unauthorized)",
            "category": "security",
            "severity": "high",
        },
        "syntax": {
            "pattern": r"(语法|syntax|parse|invalid)",
            "category": "code_quality",
            "severity": "low",
        },
        "dependency": {
            "pattern": r"(依赖|dependency|module|import|not found)",
            "category": "environment",
            "severity": "medium",
        },
        "logic": {
            "pattern": r"(逻辑|logic|incorrect|wrong result)",
            "category": "logic",
            "severity": "medium",
        },
    }
    
    def __init__(
        self,
        memory: "OpenWorkMemoryBridge",
        on_feedback_processed: Callable[[ProcessedFeedback], None] | None = None,
    ):
        self.memory = memory
        self.on_feedback_processed = on_feedback_processed
        
        self._collector = FeedbackCollector(memory_bridge=memory)
        self._feedback_history: list[ProcessedFeedback] = []
        self._pending_suggestions: list[str] = []
    
    async def process(self, feedback: Feedback) -> ProcessedFeedback:
        """
        处理反馈
        
        Args:
            feedback: 原始反馈
            
        Returns:
            处理后的反馈
        """
        sentiment = await self._analyze_sentiment(feedback.comment)
        
        root_cause = None
        if not feedback.rating or feedback.rating <= 2:
            root_cause = await self._analyze_root_cause(feedback)
        
        suggestions = await self._generate_suggestions(feedback, sentiment, root_cause)
        
        operations = self._extract_operations(feedback)
        
        processed = ProcessedFeedback(
            feedback=feedback,
            sentiment=sentiment,
            root_cause=root_cause,
            suggestions=suggestions,
            operations=operations,
        )
        
        self._feedback_history.append(processed)
        if len(self._feedback_history) > 1000:
            self._feedback_history = self._feedback_history[-500:]
        
        if self.on_feedback_processed:
            try:
                self.on_feedback_processed(processed)
            except Exception as e:
                logger.error(f"Feedback processed callback error: {e}")
        
        return processed
    
    async def _analyze_sentiment(
        self,
        comment: str | None,
    ) -> SentimentResult | None:
        """
        分析情感
        
        Args:
            comment: 评论内容
            
        Returns:
            情感分析结果
        """
        if not comment:
            return None
        
        comment_lower = comment.lower()
        
        positive_found = [kw for kw in self.POSITIVE_KEYWORDS if kw in comment_lower]
        negative_found = [kw for kw in self.NEGATIVE_KEYWORDS if kw in comment_lower]
        
        positive_count = len(positive_found)
        negative_count = len(negative_found)
        
        if positive_count > negative_count:
            sentiment = "positive"
            confidence = positive_count / (positive_count + negative_count + 1)
        elif negative_count > positive_count:
            sentiment = "negative"
            confidence = negative_count / (positive_count + negative_count + 1)
        else:
            sentiment = "neutral"
            confidence = 0.5
        
        return SentimentResult(
            sentiment=sentiment,
            confidence=min(1.0, confidence),
            positive_keywords=positive_found,
            negative_keywords=negative_found,
        )
    
    async def _analyze_root_cause(
        self,
        feedback: Feedback,
    ) -> RootCauseAnalysis | None:
        """
        分析根因
        
        Args:
            feedback: 反馈
            
        Returns:
            根因分析结果
        """
        comment = feedback.comment or ""
        metadata = feedback.metadata
        
        combined_text = comment + " " + json.dumps(metadata, ensure_ascii=False)
        
        for cause_id, config in self.ROOT_CAUSE_PATTERNS.items():
            if re.search(config["pattern"], combined_text, re.IGNORECASE):
                return RootCauseAnalysis(
                    root_cause=cause_id,
                    category=config["category"],
                    severity=config["severity"],
                    affected_operations=self._extract_operations(feedback),
                    recommendations=self._get_recommendations(cause_id),
                )
        
        return RootCauseAnalysis(
            root_cause="unknown",
            category="general",
            severity="medium",
            affected_operations=self._extract_operations(feedback),
            recommendations=["请提供更多详细信息以便分析"],
        )
    
    def _get_recommendations(self, root_cause: str) -> list[str]:
        """获取改进建议"""
        recommendations = {
            "timeout": [
                "增加超时时间",
                "优化执行效率",
                "检查网络连接",
            ],
            "permission": [
                "检查权限配置",
                "确认用户授权",
                "审查安全策略",
            ],
            "syntax": [
                "检查代码语法",
                "验证输入格式",
                "更新解析规则",
            ],
            "dependency": [
                "检查依赖安装",
                "更新依赖版本",
                "验证环境配置",
            ],
            "logic": [
                "审查业务逻辑",
                "增加测试覆盖",
                "验证边界条件",
            ],
        }
        return recommendations.get(root_cause, ["请提供更多详细信息"])
    
    async def _generate_suggestions(
        self,
        feedback: Feedback,
        sentiment: SentimentResult | None,
        root_cause: RootCauseAnalysis | None,
    ) -> list[str]:
        """
        生成改进建议
        
        Args:
            feedback: 反馈
            sentiment: 情感分析结果
            root_cause: 根因分析结果
            
        Returns:
            改进建议列表
        """
        suggestions = []
        
        if feedback.rating and feedback.rating <= 2:
            suggestions.append("建议人工审核此任务")
            
            if root_cause:
                suggestions.extend(root_cause.recommendations)
        
        if sentiment and sentiment.sentiment == "negative":
            suggestions.append("关注用户负面反馈中的关键词")
            if sentiment.negative_keywords:
                suggestions.append(f"关键词: {', '.join(sentiment.negative_keywords)}")
        
        if feedback.rating and feedback.rating >= 4:
            suggestions.append("记录此成功案例作为参考")
        
        if feedback.lessons_learned:
            for lesson in feedback.lessons_learned:
                suggestions.append(f"经验教训: {lesson}")
        
        return suggestions
    
    def _extract_operations(self, feedback: Feedback) -> list[str]:
        """提取操作类型"""
        operations = []
        
        metadata = feedback.metadata or {}
        if "operations" in metadata:
            operations.extend(metadata["operations"])
        
        if feedback.comment:
            operation_keywords = [
                "file_read", "file_write", "file_delete",
                "command", "http_request", "database",
            ]
            for kw in operation_keywords:
                if kw in feedback.comment.lower():
                    operations.append(kw)
        
        return list(set(operations))
    
    def get_recent(self, count: int = 10) -> list[Feedback]:
        """获取最近反馈"""
        return [pf.feedback for pf in self._feedback_history[-count:]]
    
    async def get_aggregated_stats(self) -> FeedbackStats:
        """获取聚合统计"""
        if not self._feedback_history:
            return FeedbackStats(
                total_feedback=0,
                average_rating=0,
                rating_distribution={},
                sentiment_distribution={},
                top_issues=[],
                improvement_trend=0,
            )
        
        ratings = [
            pf.feedback.rating for pf in self._feedback_history
            if pf.feedback.rating is not None
        ]
        
        avg_rating = sum(ratings) / len(ratings) if ratings else 0
        
        rating_dist: dict[int, int] = {}
        for r in ratings:
            rating_dist[r] = rating_dist.get(r, 0) + 1
        
        sentiment_dist: dict[str, int] = {}
        for pf in self._feedback_history:
            if pf.sentiment:
                s = pf.sentiment.sentiment
                sentiment_dist[s] = sentiment_dist.get(s, 0) + 1
        
        issues: dict[str, int] = {}
        for pf in self._feedback_history:
            if pf.root_cause:
                rc = pf.root_cause.root_cause
                issues[rc] = issues.get(rc, 0) + 1
        top_issues = sorted(issues.keys(), key=lambda x: issues[x], reverse=True)[:5]
        
        trend = 0.0
        if len(self._feedback_history) >= 10:
            recent = self._feedback_history[-5:]
            older = self._feedback_history[-10:-5]
            
            recent_avg = sum(
                pf.feedback.rating or 0 for pf in recent
            ) / len(recent)
            older_avg = sum(
                pf.feedback.rating or 0 for pf in older
            ) / len(older)
            
            trend = recent_avg - older_avg
        
        return FeedbackStats(
            total_feedback=len(self._feedback_history),
            average_rating=avg_rating,
            rating_distribution=rating_dist,
            sentiment_distribution=sentiment_dist,
            top_issues=top_issues,
            improvement_trend=trend,
        )
    
    async def collect(
        self,
        project_id: str,
        user_id: str,
        timeout: float = 300.0,
    ) -> Feedback | None:
        """收集反馈"""
        return await self._collector.collect(project_id, user_id, timeout)
    
    async def process_feedback(self, feedback: Feedback) -> FeedbackResult:
        """处理反馈（兼容接口）"""
        processed = await self.process(feedback)
        
        return FeedbackResult(
            feedback=feedback,
            enhancement_triggered=False,
            patterns_extracted=0,
            rules_updated=0,
        )
    
    async def submit_direct(
        self,
        project_id: str,
        user_id: str,
        rating: int,
        comment: str | None = None,
    ) -> Feedback:
        """直接提交反馈"""
        feedback = Feedback(
            feedback_id=f"fb-{datetime.now().strftime('%Y%m%d%H%M%S')}",
            project_id=project_id,
            user_id=user_id,
            feedback_type=FeedbackType.RATING,
            rating=rating,
            comment=comment,
            status=FeedbackStatus.COLLECTED,
        )
        
        await self.process(feedback)
        
        return feedback
    
    def get_stats(self) -> dict:
        """获取统计信息"""
        return {
            "total_feedback": len(self._feedback_history),
            "pending_suggestions": len(self._pending_suggestions),
        }
