"""
Progress Monitor - 增强版进度监控器

新增功能：
1. 里程碑检测 - 自动检测关键里程碑
2. 异常检测 - 检测异常进度模式
3. 预估完成时间 - 基于历史预估
4. 进度可视化 - 生成进度报告
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import TYPE_CHECKING, Any, Callable

from clawbot.openwork.progress_reporter import (
    ProgressEvent,
    ProgressEventType,
)

if TYPE_CHECKING:
    from clawbot.core.state_machine import Project

logger = logging.getLogger(__name__)


@dataclass
class Milestone:
    """里程碑"""
    milestone_id: str
    name: str
    description: str
    timestamp: datetime
    progress_percent: float
    is_completed: bool
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class Anomaly:
    """异常"""
    anomaly_type: str
    severity: str
    message: str
    timestamp: datetime
    details: dict[str, Any] = field(default_factory=dict)


@dataclass
class ProgressReport:
    """进度报告"""
    session_id: str
    project_id: str
    generated_at: datetime
    status: str
    progress_percent: float
    elapsed_seconds: float
    estimated_remaining_seconds: float | None
    completed_milestones: list[Milestone]
    pending_milestones: list[Milestone]
    tool_calls_count: int
    errors_count: int
    anomalies: list[Anomaly]
    summary: str


class ProgressMonitor:
    """
    进度监控器（增强版）

    新增功能：
    1. 里程碑检测 - 自动检测关键里程碑
    2. 异常检测 - 检测异常进度模式
    3. 预估完成时间 - 基于历史预估
    4. 进度可视化 - 生成进度报告
    """

    MILESTONE_DEFINITIONS = [
        {
            "id": "analysis_complete",
            "name": "需求分析完成",
            "pattern": ["分析", "解析", "理解"],
            "progress": 10,
        },
        {
            "id": "plan_created",
            "name": "执行计划创建",
            "pattern": ["计划", "方案", "步骤"],
            "progress": 20,
        },
        {
            "id": "files_created",
            "name": "文件创建完成",
            "pattern": ["创建", "新建", "生成"],
            "progress": 40,
        },
        {
            "id": "code_implemented",
            "name": "代码实现完成",
            "pattern": ["实现", "编写", "完成"],
            "progress": 60,
        },
        {
            "id": "tests_passed",
            "name": "测试通过",
            "pattern": ["测试", "通过", "验证"],
            "progress": 80,
        },
        {
            "id": "task_completed",
            "name": "任务完成",
            "pattern": ["完成", "结束", "成功"],
            "progress": 100,
        },
    ]

    ANOMALY_THRESHOLDS = {
        "stall_time_seconds": 300,
        "error_rate": 0.3,
        "retry_count": 3,
    }

    def __init__(
        self,
        on_milestone: Callable[[Milestone], None] | None = None,
        on_anomaly: Callable[[Anomaly], None] | None = None,
    ):
        self.on_milestone = on_milestone
        self.on_anomaly = on_anomaly

        self._monitored_projects: dict[str, dict] = {}
        self._milestones: dict[str, list[Milestone]] = {}
        self._anomalies: dict[str, list[Anomaly]] = {}
        self._history: dict[str, list[dict]] = {}

    async def start_monitoring(self, project: "Project") -> None:
        """
        开始监控项目

        Args:
            project: 项目对象
        """
        project_id = project.project_id

        self._monitored_projects[project_id] = {
            "project": project,
            "started_at": datetime.now(),
            "last_update": datetime.now(),
            "last_progress": 0.0,
            "tool_calls": [],
            "errors": [],
            "events": [],
        }

        self._milestones[project_id] = []
        self._anomalies[project_id] = []
        self._history[project_id] = []

        logger.info(f"Started monitoring project: {project_id}")

    async def stop_monitoring(self, project_id: str) -> None:
        """停止监控"""
        if project_id in self._monitored_projects:
            del self._monitored_projects[project_id]
            logger.info(f"Stopped monitoring project: {project_id}")

    async def update_progress(
        self,
        project_id: str,
        event: ProgressEvent,
    ) -> None:
        """
        更新进度

        Args:
            project_id: 项目 ID
            event: 进度事件
        """
        if project_id not in self._monitored_projects:
            return

        monitor_data = self._monitored_projects[project_id]
        monitor_data["last_update"] = datetime.now()
        monitor_data["events"].append({
            "event_type": event.event_type.value,
            "message": event.message,
            "timestamp": event.timestamp.isoformat(),
        })

        milestone = await self.detect_milestone(event)
        if milestone:
            self._milestones[project_id].append(milestone)
            if self.on_milestone:
                try:
                    self.on_milestone(milestone)
                except Exception as e:
                    logger.error(f"Milestone callback error: {e}")

        if event.event_type == ProgressEventType.ERROR:
            monitor_data["errors"].append(event.message)

        if event.event_type == ProgressEventType.TOOL_CALL:
            monitor_data["tool_calls"].append(event.details)

        await self._check_anomalies(project_id, event)

    async def detect_milestone(self, event: ProgressEvent) -> Milestone | None:
        """
        检测里程碑

        Args:
            event: 进度事件

        Returns:
            检测到的里程碑或None
        """
        message = event.message.lower()

        for definition in self.MILESTONE_DEFINITIONS:
            if any(p in message for p in definition["pattern"]):
                return Milestone(
                    milestone_id=definition["id"],
                    name=definition["name"],
                    description=event.message,
                    timestamp=datetime.now(),
                    progress_percent=definition["progress"],
                    is_completed=True,
                    metadata={"event_type": event.event_type.value},
                )

        if event.is_milestone:
            return Milestone(
                milestone_id=f"custom_{event.event_type.value}",
                name=event.message[:50],
                description=event.message,
                timestamp=datetime.now(),
                progress_percent=event.progress_percent or 0,
                is_completed=True,
            )

        return None

    async def estimate_completion(
        self,
        project_id: str,
    ) -> datetime | None:
        """
        预估完成时间

        Args:
            project_id: 项目 ID

        Returns:
            预估完成时间或None
        """
        if project_id not in self._monitored_projects:
            return None

        monitor_data = self._monitored_projects[project_id]
        started_at = monitor_data["started_at"]

        milestones = self._milestones.get(project_id, [])
        if not milestones:
            return None

        latest_milestone = max(milestones, key=lambda m: m.progress_percent)
        progress = latest_milestone.progress_percent

        if progress <= 0:
            return None

        elapsed = (datetime.now() - started_at).total_seconds()
        estimated_total = elapsed / (progress / 100)
        estimated_remaining = estimated_total - elapsed

        return datetime.now() + timedelta(seconds=estimated_remaining)

    async def generate_report(
        self,
        project_id: str,
    ) -> ProgressReport | None:
        """
        生成进度报告

        Args:
            project_id: 项目 ID

        Returns:
            进度报告或None
        """
        if project_id not in self._monitored_projects:
            return None

        monitor_data = self._monitored_projects[project_id]
        project = monitor_data["project"]

        started_at = monitor_data["started_at"]
        elapsed = (datetime.now() - started_at).total_seconds()

        milestones = self._milestones.get(project_id, [])
        completed = [m for m in milestones if m.is_completed]
        pending = [m for m in milestones if not m.is_completed]

        latest_progress = 0.0
        if completed:
            latest_progress = max(m.progress_percent for m in completed)

        estimated_completion = await self.estimate_completion(project_id)
        estimated_remaining = None
        if estimated_completion:
            estimated_remaining = (estimated_completion - datetime.now()).total_seconds()

        anomalies = self._anomalies.get(project_id, [])

        summary = self._generate_summary(
            project_id=project_id,
            progress=latest_progress,
            elapsed=elapsed,
            milestones_completed=len(completed),
            errors=len(monitor_data["errors"]),
        )

        return ProgressReport(
            session_id=project.session_id or "",
            project_id=project_id,
            generated_at=datetime.now(),
            status=project.state.value,
            progress_percent=latest_progress,
            elapsed_seconds=elapsed,
            estimated_remaining_seconds=estimated_remaining,
            completed_milestones=completed,
            pending_milestones=pending,
            tool_calls_count=len(monitor_data["tool_calls"]),
            errors_count=len(monitor_data["errors"]),
            anomalies=anomalies,
            summary=summary,
        )

    def _generate_summary(
        self,
        project_id: str,
        progress: float,
        elapsed: float,
        milestones_completed: int,
        errors: int,
    ) -> str:
        """生成摘要"""
        elapsed_str = self._format_duration(elapsed)

        status_emoji = "✅" if progress >= 100 else "🔄" if progress > 0 else "⏳"

        summary = (
            f"{status_emoji} 项目 {project_id} 进度: {progress:.0f}%\n"
            f"⏱️ 已用时间: {elapsed_str}\n"
            f"🎯 已完成里程碑: {milestones_completed}\n"
        )

        if errors > 0:
            summary += f"⚠️ 错误数: {errors}\n"

        return summary

    def _format_duration(self, seconds: float) -> str:
        """格式化时间"""
        if seconds < 60:
            return f"{seconds:.0f}秒"
        elif seconds < 3600:
            minutes = seconds / 60
            return f"{minutes:.1f}分钟"
        else:
            hours = seconds / 3600
            return f"{hours:.1f}小时"

    async def _check_anomalies(
        self,
        project_id: str,
        event: ProgressEvent,
    ) -> None:
        """检查异常"""
        monitor_data = self._monitored_projects[project_id]

        last_update = monitor_data["last_update"]
        stall_time = (datetime.now() - last_update).total_seconds()

        if stall_time > self.ANOMALY_THRESHOLDS["stall_time_seconds"]:
            anomaly = Anomaly(
                anomaly_type="stall",
                severity="warning",
                message=f"进度停滞 {stall_time:.0f} 秒",
                timestamp=datetime.now(),
                details={"stall_time": stall_time},
            )
            self._anomalies[project_id].append(anomaly)
            if self.on_anomaly:
                self.on_anomaly(anomaly)

        errors = monitor_data["errors"]
        total_events = len(monitor_data["events"])
        if total_events > 10:
            error_rate = len(errors) / total_events
            if error_rate > self.ANOMALY_THRESHOLDS["error_rate"]:
                anomaly = Anomaly(
                    anomaly_type="high_error_rate",
                    severity="error",
                    message=f"错误率过高: {error_rate:.0%}",
                    timestamp=datetime.now(),
                    details={"error_rate": error_rate},
                )
                self._anomalies[project_id].append(anomaly)
                if self.on_anomaly:
                    self.on_anomaly(anomaly)

    def get_milestones(self, project_id: str) -> list[Milestone]:
        """获取里程碑列表"""
        return self._milestones.get(project_id, [])

    def get_anomalies(self, project_id: str) -> list[Anomaly]:
        """获取异常列表"""
        return self._anomalies.get(project_id, [])
