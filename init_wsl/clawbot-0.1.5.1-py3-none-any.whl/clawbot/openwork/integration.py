"""
OpenWork Integration for AgentLoop.

This module provides the integration between OpenWork and AgentLoop,
enabling unattended autonomous programming through Opencode.
"""

import asyncio
import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable

from clawbot.openwork.decision_engine import AIPMDecisionEngine
from clawbot.openwork.log_visualizer import LogVisualizer
from clawbot.openwork.memory import OpenWorkMemoryBridge
from clawbot.openwork.orchestrator import OpenWorkOrchestrator, ProjectStatus
from clawbot.openwork.pattern_extractor import PatternExtractor
from clawbot.openwork.self_enhancer import EnhancementScheduler, SelfEnhancer

if TYPE_CHECKING:
    from clawbot.providers.base import LLMProvider

logger = logging.getLogger(__name__)


class OpenWorkIntegration:
    """OpenWork integration manager for AgentLoop."""

    OPENWORK_KEYWORDS = [
        "实现", "开发", "创建项目", "写一个", "帮我写",
        "implement", "develop", "create", "build",
        "编程", "代码", "程序",
    ]

    def __init__(
        self,
        workspace: Path,
        provider: "LLMProvider",
        send_message: Callable[[str, str], None],
        openwork_url: str = "http://localhost:7777",
        embedding_api_config: Any = None,
        enhancement_interval_hours: int = 24,
    ):
        self.workspace = workspace
        self.provider = provider
        self.send_message = send_message
        self.openwork_url = openwork_url

        self._memory_bridge = OpenWorkMemoryBridge(
            workspace=workspace / "openwork",
        )

        self._decision_engine = AIPMDecisionEngine(
            llm_provider=provider,
            memory_store=self._memory_bridge,
        )

        self._log_visualizer = LogVisualizer(
            output_mode="cli",
        )

        self._orchestrator = OpenWorkOrchestrator(
            openwork_url=openwork_url,
            decision_engine=self._decision_engine,
            memory_store=self._memory_bridge,
            log_visualizer=self._log_visualizer,
            send_message=send_message,
            default_workspace=workspace / "openwork",
        )

        self._pattern_extractor = PatternExtractor(
            memory_bridge=self._memory_bridge,
        )

        self._self_enhancer = SelfEnhancer(
            memory_bridge=self._memory_bridge,
            pattern_extractor=self._pattern_extractor,
        )

        self._enhancement_scheduler = EnhancementScheduler(
            self_enhancer=self._self_enhancer,
            interval_hours=enhancement_interval_hours,
        )

        self._running = False
        self._user_rating_futures: dict[str, asyncio.Future] = {}

    async def start(self):
        """Start the OpenWork integration."""
        if self._running:
            return

        self._running = True

        try:
            await self._orchestrator.start()
            await self._enhancement_scheduler.start()
            logger.info("OpenWork integration started")
        except Exception as e:
            logger.error(f"Failed to start OpenWork integration: {e}")
            raise

    async def stop(self):
        """Stop the OpenWork integration."""
        if not self._running:
            return

        self._running = False

        await self._enhancement_scheduler.stop()
        await self._orchestrator.stop()
        logger.info("OpenWork integration stopped")

    def is_openwork_task(self, content: str) -> bool:
        """Check if a message is an OpenWork task."""
        content_lower = content.lower()

        for keyword in self.OPENWORK_KEYWORDS:
            if keyword in content_lower:
                return True

        if len(content) > 20 and not content.startswith("/"):
            return True

        return False

    async def start_project(
        self,
        user_idea: str,
        user_id: str,
        workspace: Path | None = None,
    ) -> str:
        """Start a new OpenWork project."""
        return await self._orchestrator.start_project(
            user_idea=user_idea,
            user_id=user_id,
            workspace=workspace,
        )

    def handle_permission_response(
        self,
        user_id: str,
        response: str,
    ) -> bool:
        """Handle user response to permission request."""
        project = self._orchestrator.get_user_active_project(user_id)
        if not project:
            return False

        if project.status != ProjectStatus.WAITING_USER:
            return False

        normalized = response.strip().lower()
        if normalized in ["允许", "allow", "yes", "y", "是", "ok"]:
            permission_id = self._find_pending_permission(project.project_id)
            if permission_id:
                self._orchestrator.respond_to_permission(permission_id, "allow")
                return True
        elif normalized in ["拒绝", "deny", "no", "n", "否"]:
            permission_id = self._find_pending_permission(project.project_id)
            if permission_id:
                self._orchestrator.respond_to_permission(permission_id, "deny")
                return True

        return False

    def _find_pending_permission(self, project_id: str) -> str | None:
        """Find pending permission for a project."""
        for perm_id, future in list(self._orchestrator._permission_futures.items()):
            if not future.done():
                return perm_id
        return None

    def handle_user_rating(
        self,
        project_id: str,
        rating: int,
    ) -> bool:
        """Handle user rating for a completed project."""
        if project_id in self._user_rating_futures:
            future = self._user_rating_futures[project_id]
            if not future.done():
                future.set_result(rating)
                del self._user_rating_futures[project_id]
                return True
        return False

    async def trigger_enhancement(self):
        """Manually trigger self-enhancement."""
        return await self._enhancement_scheduler.trigger_enhancement()

    def get_active_project(self, user_id: str):
        """Get active project for a user."""
        return self._orchestrator.get_user_active_project(user_id)

    def get_project(self, project_id: str):
        """Get project by ID."""
        return self._orchestrator.get_project(project_id)

    def get_status(self) -> dict:
        """Get integration status."""
        return {
            "running": self._running,
            "openwork_url": self.openwork_url,
            "active_projects": len(self._orchestrator.projects),
            "enhancement_status": self._enhancement_scheduler.get_status(),
        }

    def set_websocket_callback(self, callback: Callable[[dict], None]):
        """Set WebSocket push callback for log visualization."""
        self._log_visualizer.set_websocket_push(callback)


def create_openwork_integration(
    workspace: Path,
    provider: "LLMProvider",
    send_message: Callable[[str, str], None],
    **kwargs,
) -> OpenWorkIntegration:
    """Factory function to create OpenWork integration."""
    return OpenWorkIntegration(
        workspace=workspace,
        provider=provider,
        send_message=send_message,
        **kwargs,
    )
