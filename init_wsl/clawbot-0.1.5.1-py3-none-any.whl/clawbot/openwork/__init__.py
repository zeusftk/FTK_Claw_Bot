"""
OpenWork Integration Module

This module provides integration with OpenWork Orchestrator for
unattended autonomous programming through Opencode.

Architecture:
    Layer 1: clawbot (Python) - HTTP POST / SSE
    Layer 2: OpenWork Orchestrator (Node.js)
    Layer 3: Opencode (LLM Engine)

Components:
    - OpenWorkClient: HTTP/SSE client for communication
    - OpenWorkOrchestrator: Task orchestration
    - AIPMDecisionEngine: Graded decision engine
    - OpenWorkMemoryBridge: Memory integration
    - PatternExtractor: Pattern extraction from history
    - SelfEnhancer: Self-enhancement system
    - LogVisualizer: Log visualization
    - OpenWorkIntegration: AgentLoop integration
    - IdeaProcessor: Idea processing and analysis
    - ProgressReporter: Progress reporting
    - FeedbackCollector: Feedback collection
    - TaskRouter: Task routing
    - SessionManager: Session management
    - UnattendedProgrammingManager: Unified manager
"""

from clawbot.openwork.client import (
    EventType,
    OpenWorkClient,
    PermissionRequest,
    QualityScore,
    SSEEvent,
    TaskResult,
)
from clawbot.openwork.decision_engine import (
    AIPMDecisionEngine,
    Decision,
    DecisionLevel,
)
from clawbot.openwork.feedback_collector import (
    Feedback,
    FeedbackCollector,
    FeedbackRequest,
    FeedbackResult,
    FeedbackStatus,
    FeedbackType,
)
from clawbot.openwork.idea_processor import (
    ComplexityLevel,
    Feature,
    IdeaProcessor,
    ProcessedIdea,
    RiskLevel,
    TaskType,
    TechnicalSuggestion,
)
from clawbot.openwork.integration import (
    OpenWorkIntegration,
    create_openwork_integration,
)
from clawbot.openwork.log_visualizer import (
    LogEntry,
    LogVisualizer,
)
from clawbot.openwork.memory import (
    CodeSnippet,
    DecisionRecord,
    ErrorPattern,
    OpenWorkMemoryBridge,
    ProjectContext,
    SuccessCase,
)
from clawbot.openwork.orchestrator import (
    ActiveProject,
    OpenWorkOrchestrator,
    ProjectStatus,
)
from clawbot.openwork.pattern_extractor import (
    DecisionPattern,
    PatternExtractor,
)
from clawbot.openwork.progress_reporter import (
    ProgressEvent,
    ProgressEventType,
    ProgressReporter,
    SessionProgress,
    TodoItem,
    ToolCallInfo,
)
from clawbot.openwork.self_enhancer import (
    EnhancementResult,
    EnhancementScheduler,
    SelfEnhancer,
)
from clawbot.openwork.session_manager import (
    Session,
    SessionConfig,
    SessionManager,
    SessionStatus,
)
from clawbot.openwork.task_router import (
    ExecutionResult,
    ExecutionStrategy,
    ExecutionTarget,
    RouteDecision,
    TaskRouter,
)
from clawbot.openwork.unattended_programming_manager import (
    Project,
    UnattendedProgrammingManager,
)
from clawbot.openwork.unattended_programming_manager import (
    ProjectStatus as UPMProjectStatus,
)

__all__ = [
    "OpenWorkClient",
    "EventType",
    "SSEEvent",
    "PermissionRequest",
    "TaskResult",
    "QualityScore",
    "OpenWorkOrchestrator",
    "ProjectStatus",
    "ActiveProject",
    "AIPMDecisionEngine",
    "DecisionLevel",
    "Decision",
    "OpenWorkMemoryBridge",
    "DecisionRecord",
    "SuccessCase",
    "ProjectContext",
    "CodeSnippet",
    "ErrorPattern",
    "PatternExtractor",
    "DecisionPattern",
    "SelfEnhancer",
    "EnhancementResult",
    "EnhancementScheduler",
    "LogVisualizer",
    "LogEntry",
    "OpenWorkIntegration",
    "create_openwork_integration",
    "IdeaProcessor",
    "ProcessedIdea",
    "Feature",
    "TechnicalSuggestion",
    "ComplexityLevel",
    "RiskLevel",
    "TaskType",
    "ProgressReporter",
    "ProgressEvent",
    "ProgressEventType",
    "ToolCallInfo",
    "TodoItem",
    "SessionProgress",
    "FeedbackCollector",
    "Feedback",
    "FeedbackType",
    "FeedbackStatus",
    "FeedbackRequest",
    "FeedbackResult",
    "TaskRouter",
    "RouteDecision",
    "ExecutionStrategy",
    "ExecutionTarget",
    "ExecutionResult",
    "SessionManager",
    "Session",
    "SessionStatus",
    "SessionConfig",
    "UnattendedProgrammingManager",
    "Project",
    "UPMProjectStatus",
]
