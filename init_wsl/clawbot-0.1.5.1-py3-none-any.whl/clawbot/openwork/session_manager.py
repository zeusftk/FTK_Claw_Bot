"""
Session Manager - 会话管理器

管理 OpenWork 会话生命周期。
"""

import asyncio
import json
import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable

import aiohttp

if TYPE_CHECKING:
    from clawbot.services.openwork_service import OpenWorkService

logger = logging.getLogger(__name__)


class SessionStatus(Enum):
    IDLE = "idle"
    RUNNING = "running"
    WAITING = "waiting"
    COMPLETED = "completed"
    FAILED = "failed"
    TIMEOUT = "timeout"
    ARCHIVED = "archived"


@dataclass
class Session:
    session_id: str
    user_id: str
    workspace: Path
    title: str
    status: SessionStatus
    created_at: datetime
    last_active: datetime
    message_count: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def age_seconds(self) -> float:
        return (datetime.now() - self.created_at).total_seconds()

    @property
    def idle_seconds(self) -> float:
        return (datetime.now() - self.last_active).total_seconds()


@dataclass
class SessionConfig:
    timeout_seconds: int = 3600
    max_idle_seconds: int = 1800
    max_sessions_per_user: int = 10
    auto_archive: bool = True
    persist_state: bool = True


class SessionManager:
    """
    会话管理器

    功能：
    1. 创建/恢复会话
    2. 会话状态持久化
    3. 会话超时处理
    4. 多用户会话隔离
    5. 会话清理和归档
    """

    DEFAULT_CONFIG = SessionConfig()

    def __init__(
        self,
        openwork_service: "OpenWorkService | None" = None,
        base_url: str = "http://localhost:7777",
        workspace_root: Path | None = None,
        config: SessionConfig | None = None,
        on_session_created: Callable[[Session], None] | None = None,
        on_session_expired: Callable[[Session], None] | None = None,
    ):
        self.openwork = openwork_service
        self.base_url = base_url.rstrip("/")
        self.workspace_root = workspace_root or Path.home() / "clawbot-sessions"
        self.config = config or self.DEFAULT_CONFIG
        self._on_session_created = on_session_created
        self._on_session_expired = on_session_expired

        self._sessions: dict[str, Session] = {}
        self._user_sessions: dict[str, list[str]] = {}
        self._session: aiohttp.ClientSession | None = None
        self._cleanup_task: asyncio.Task | None = None
        self._running = False

        self._state_file = self.workspace_root / "sessions_state.json"
        self._ensure_workspace()

    def _ensure_workspace(self) -> None:
        """确保工作目录存在"""
        self.workspace_root.mkdir(parents=True, exist_ok=True)

    async def start(self) -> None:
        """启动会话管理器"""
        if self._running:
            return

        self._running = True
        self._session = aiohttp.ClientSession()

        if self.config.persist_state:
            await self._load_state()

        self._cleanup_task = asyncio.create_task(self._cleanup_loop())

        logger.info(f"SessionManager started, base_url: {self.base_url}")

    async def stop(self) -> None:
        """停止会话管理器"""
        self._running = False

        if self._cleanup_task:
            self._cleanup_task.cancel()
            try:
                await self._cleanup_task
            except asyncio.CancelledError:
                pass

        if self.config.persist_state:
            await self._save_state()

        if self._session:
            await self._session.close()
            self._session = None

        logger.info("SessionManager stopped")

    async def create(
        self,
        user_id: str,
        workspace: Path | None = None,
        title: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Session:
        """
        创建新会话

        Args:
            user_id: 用户 ID
            workspace: 工作目录
            title: 会话标题
            metadata: 元数据

        Returns:
            Session 新会话
        """
        session_id = f"sess-{uuid.uuid4().hex[:8]}"
        ws = workspace or self.workspace_root / user_id / session_id
        ws.mkdir(parents=True, exist_ok=True)

        session_title = title or f"Session {session_id}"

        try:
            remote_session_id = await self._create_remote_session(ws, session_title)
            if remote_session_id:
                session_id = remote_session_id
        except Exception as e:
            logger.warning(f"Failed to create remote session: {e}")

        session = Session(
            session_id=session_id,
            user_id=user_id,
            workspace=ws,
            title=session_title,
            status=SessionStatus.IDLE,
            created_at=datetime.now(),
            last_active=datetime.now(),
            metadata=metadata or {},
        )

        self._sessions[session_id] = session

        if user_id not in self._user_sessions:
            self._user_sessions[user_id] = []
        self._user_sessions[user_id].append(session_id)

        await self._enforce_session_limit(user_id)

        if self._on_session_created:
            try:
                self._on_session_created(session)
            except Exception as e:
                logger.error(f"Session created callback error: {e}")

        logger.info(f"Session created: {session_id} for user {user_id}")
        return session

    async def get(self, session_id: str) -> Session | None:
        """获取会话"""
        return self._sessions.get(session_id)

    async def get_active(self, user_id: str) -> Session | None:
        """
        获取用户的活跃会话

        Args:
            user_id: 用户 ID

        Returns:
            Session 活跃会话，无则返回 None
        """
        user_session_ids = self._user_sessions.get(user_id, [])

        for session_id in reversed(user_session_ids):
            session = self._sessions.get(session_id)
            if session and session.status in [SessionStatus.IDLE, SessionStatus.RUNNING]:
                if session.idle_seconds < self.config.max_idle_seconds:
                    return session

        return None

    async def get_or_create(
        self,
        user_id: str,
        workspace: Path | None = None,
    ) -> Session:
        """
        获取或创建会话

        Args:
            user_id: 用户 ID
            workspace: 工作目录

        Returns:
            Session 会话
        """
        session = await self.get_active(user_id)
        if session:
            return session

        return await self.create(user_id, workspace)

    async def update(
        self,
        session_id: str,
        status: SessionStatus | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Session | None:
        """
        更新会话

        Args:
            session_id: 会话 ID
            status: 新状态
            metadata: 新元数据

        Returns:
            Session 更新后的会话
        """
        session = self._sessions.get(session_id)
        if not session:
            return None

        if status:
            session.status = status

        if metadata:
            session.metadata.update(metadata)

        session.last_active = datetime.now()

        return session

    async def touch(self, session_id: str) -> None:
        """更新会话活跃时间"""
        session = self._sessions.get(session_id)
        if session:
            session.last_active = datetime.now()

    async def increment_messages(self, session_id: str) -> None:
        """增加消息计数"""
        session = self._sessions.get(session_id)
        if session:
            session.message_count += 1
            session.last_active = datetime.now()

    async def archive(self, session_id: str) -> bool:
        """
        归档会话

        Args:
            session_id: 会话 ID

        Returns:
            bool 是否成功
        """
        session = self._sessions.get(session_id)
        if not session:
            return False

        session.status = SessionStatus.ARCHIVED

        archive_dir = self.workspace_root / "archived"
        archive_dir.mkdir(parents=True, exist_ok=True)

        archive_file = archive_dir / f"{session_id}.json"
        archive_data = {
            "session_id": session.session_id,
            "user_id": session.user_id,
            "workspace": str(session.workspace),
            "title": session.title,
            "status": session.status.value,
            "created_at": session.created_at.isoformat(),
            "last_active": session.last_active.isoformat(),
            "message_count": session.message_count,
            "metadata": session.metadata,
            "archived_at": datetime.now().isoformat(),
        }

        with open(archive_file, "w", encoding="utf-8") as f:
            json.dump(archive_data, f, ensure_ascii=False, indent=2)

        self._sessions.pop(session_id, None)

        user_sessions = self._user_sessions.get(session.user_id, [])
        if session_id in user_sessions:
            user_sessions.remove(session_id)

        logger.info(f"Session archived: {session_id}")
        return True

    async def delete(self, session_id: str) -> bool:
        """
        删除会话

        Args:
            session_id: 会话 ID

        Returns:
            bool 是否成功
        """
        session = self._sessions.get(session_id)
        if not session:
            return False

        self._sessions.pop(session_id, None)

        user_sessions = self._user_sessions.get(session.user_id, [])
        if session_id in user_sessions:
            user_sessions.remove(session_id)

        logger.info(f"Session deleted: {session_id}")
        return True

    async def list_sessions(
        self,
        user_id: str | None = None,
        status: SessionStatus | None = None,
        limit: int = 20,
    ) -> list[Session]:
        """
        列出会话

        Args:
            user_id: 用户 ID 过滤
            status: 状态过滤
            limit: 最大数量

        Returns:
            list[Session] 会话列表
        """
        sessions = list(self._sessions.values())

        if user_id:
            sessions = [s for s in sessions if s.user_id == user_id]

        if status:
            sessions = [s for s in sessions if s.status == status]

        sessions.sort(key=lambda s: s.last_active, reverse=True)

        return sessions[:limit]

    async def _create_remote_session(self, workspace: Path, title: str) -> str | None:
        """创建远程会话"""
        if not self._session:
            return None

        try:
            async with self._session.post(
                f"{self.base_url}/session",
                json={"title": title, "cwd": str(workspace)},
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return data.get("id")
        except Exception as e:
            logger.error(f"Failed to create remote session: {e}")

        return None

    async def _enforce_session_limit(self, user_id: str) -> None:
        """强制执行会话数量限制"""
        user_session_ids = self._user_sessions.get(user_id, [])

        while len(user_session_ids) > self.config.max_sessions_per_user:
            oldest_id = user_session_ids.pop(0)
            oldest_session = self._sessions.get(oldest_id)

            if oldest_session:
                if self.config.auto_archive:
                    await self.archive(oldest_id)
                else:
                    await self.delete(oldest_id)

    async def _cleanup_loop(self) -> None:
        """清理循环"""
        while self._running:
            try:
                await self._cleanup_expired_sessions()
                await asyncio.sleep(60)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Cleanup error: {e}")
                await asyncio.sleep(60)

    async def _cleanup_expired_sessions(self) -> None:
        """清理过期会话"""
        expired = []

        for session_id, session in self._sessions.items():
            if session.status == SessionStatus.ARCHIVED:
                continue

            if session.age_seconds > self.config.timeout_seconds:
                expired.append((session_id, "timeout"))
            elif session.idle_seconds > self.config.max_idle_seconds:
                expired.append((session_id, "idle"))

        for session_id, reason in expired:
            session = self._sessions.get(session_id)
            if session:
                session.status = SessionStatus.TIMEOUT

                if self._on_session_expired:
                    try:
                        self._on_session_expired(session)
                    except Exception as e:
                        logger.error(f"Session expired callback error: {e}")

                if self.config.auto_archive:
                    await self.archive(session_id)
                else:
                    await self.delete(session_id)

                logger.info(f"Session expired ({reason}): {session_id}")

    async def _load_state(self) -> None:
        """加载状态"""
        if not self._state_file.exists():
            return

        try:
            with open(self._state_file, encoding="utf-8") as f:
                data = json.load(f)

            for session_data in data.get("sessions", []):
                session = Session(
                    session_id=session_data["session_id"],
                    user_id=session_data["user_id"],
                    workspace=Path(session_data["workspace"]),
                    title=session_data["title"],
                    status=SessionStatus(session_data.get("status", "idle")),
                    created_at=datetime.fromisoformat(session_data["created_at"]),
                    last_active=datetime.fromisoformat(session_data["last_active"]),
                    message_count=session_data.get("message_count", 0),
                    metadata=session_data.get("metadata", {}),
                )

                self._sessions[session.session_id] = session

                if session.user_id not in self._user_sessions:
                    self._user_sessions[session.user_id] = []
                self._user_sessions[session.user_id].append(session.session_id)

            logger.info(f"Loaded {len(self._sessions)} sessions from state")

        except Exception as e:
            logger.error(f"Failed to load state: {e}")

    async def _save_state(self) -> None:
        """保存状态"""
        try:
            data = {
                "sessions": [
                    {
                        "session_id": s.session_id,
                        "user_id": s.user_id,
                        "workspace": str(s.workspace),
                        "title": s.title,
                        "status": s.status.value,
                        "created_at": s.created_at.isoformat(),
                        "last_active": s.last_active.isoformat(),
                        "message_count": s.message_count,
                        "metadata": s.metadata,
                    }
                    for s in self._sessions.values()
                    if s.status not in [SessionStatus.ARCHIVED]
                ],
                "saved_at": datetime.now().isoformat(),
            }

            with open(self._state_file, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)

            logger.debug(f"Saved {len(data['sessions'])} sessions to state")

        except Exception as e:
            logger.error(f"Failed to save state: {e}")

    def get_stats(self) -> dict[str, Any]:
        """获取统计信息"""
        status_counts = {}
        for status in SessionStatus:
            status_counts[status.value] = sum(
                1 for s in self._sessions.values() if s.status == status
            )

        return {
            "total_sessions": len(self._sessions),
            "total_users": len(self._user_sessions),
            "status_counts": status_counts,
            "config": {
                "timeout_seconds": self.config.timeout_seconds,
                "max_idle_seconds": self.config.max_idle_seconds,
                "max_sessions_per_user": self.config.max_sessions_per_user,
            },
        }
