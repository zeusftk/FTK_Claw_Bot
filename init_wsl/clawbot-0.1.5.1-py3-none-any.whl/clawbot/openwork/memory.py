"""
OpenWork Memory Bridge - Memory integration for OpenWork.

This module provides the memory bridge that integrates OpenWork
with the existing MemoryStore system for decision recording,
success case archiving, and semantic search.

Enhanced features:
- Project context storage
- Code snippet indexing
- Error pattern recording
- Success pattern archiving
"""

import asyncio
import json
import logging
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from clawbot.memory.hybrid_manager import HybridMemoryManager

logger = logging.getLogger(__name__)


@dataclass
class DecisionRecord:
    record_id: str
    project_id: str
    timestamp: datetime

    event_type: str
    event_details: dict

    decision_level: str
    decision_answer: str | None
    was_auto_resolved: bool

    outcome: str | None = None
    success: bool | None = None
    user_rating: int | None = None
    lessons_learned: str | None = None


@dataclass
class SuccessCase:
    case_id: str
    idea: str
    result_summary: str
    workspace_snapshot: str
    quality_score: float
    decisions: list[dict] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)
    tags: list[str] = field(default_factory=list)


@dataclass
class ProjectContext:
    project_id: str
    name: str
    description: str
    technologies: list[str]
    created_at: datetime
    updated_at: datetime
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class CodeSnippet:
    snippet_id: str
    project_id: str
    file_path: str
    language: str
    content: str
    description: str
    tags: list[str]
    created_at: datetime


@dataclass
class ErrorPattern:
    pattern_id: str
    error_type: str
    error_message: str
    context: dict
    solution: str | None
    occurrence_count: int
    first_seen: datetime
    last_seen: datetime


class OpenWorkMemoryBridge:
    """
    OpenWork memory bridge - integrates with existing MemoryStore.

    Enhanced features:
    - Project context storage
    - Code snippet indexing
    - Error pattern recording
    - Success pattern archiving
    """

    KEYWORDS_TAGS = {
        "认证": "authentication",
        "登录": "login",
        "注册": "register",
        "API": "api",
        "数据库": "database",
        "测试": "testing",
        "重构": "refactor",
        "优化": "optimization",
        "爬虫": "crawler",
        "接口": "interface",
        "缓存": "cache",
        "消息": "message",
        "队列": "queue",
        "定时": "scheduler",
        "文件": "file",
        "配置": "config",
    }

    def __init__(
        self,
        workspace: Path,
        hybrid_manager: "HybridMemoryManager | None" = None,
    ):
        self.workspace = workspace
        self.hybrid_manager = hybrid_manager

        self.decisions_namespace = "openwork_decisions"
        self.cases_namespace = "openwork_cases"
        self.patterns_namespace = "openwork_patterns"
        self.projects_namespace = "openwork_projects"
        self.snippets_namespace = "openwork_snippets"
        self.errors_namespace = "openwork_errors"

        self.decisions_file = workspace / "openwork_decisions.jsonl"
        self.cases_file = workspace / "openwork_cases.jsonl"
        self.projects_file = workspace / "openwork_projects.jsonl"
        self.snippets_file = workspace / "openwork_snippets.jsonl"
        self.errors_file = workspace / "openwork_errors.jsonl"

        self._file_lock = asyncio.Lock()

        self._ensure_files()

    def _ensure_files(self):
        """Ensure data files exist."""
        self.workspace.mkdir(parents=True, exist_ok=True)
        for file_path in [
            self.decisions_file,
            self.cases_file,
            self.projects_file,
            self.snippets_file,
            self.errors_file,
        ]:
            if not file_path.exists():
                file_path.touch()

    async def record_decision(self, data: dict) -> str:
        """Record a decision."""
        record_id = f"dec-{uuid.uuid4().hex[:8]}"
        timestamp = datetime.now()

        record = DecisionRecord(
            record_id=record_id,
            project_id=data.get("project_id", ""),
            timestamp=timestamp,
            event_type=data.get("event_type", ""),
            event_details=data.get("event_details", {}),
            decision_level=data.get("decision_level", ""),
            decision_answer=data.get("decision_answer"),
            was_auto_resolved=data.get("was_auto_resolved", False),
            outcome=data.get("outcome"),
            success=data.get("success"),
            user_rating=data.get("user_rating"),
            lessons_learned=data.get("lessons_learned"),
        )

        record_dict = asdict(record)
        record_dict["timestamp"] = timestamp.isoformat()

        async with self._file_lock:
            with open(self.decisions_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(record_dict, ensure_ascii=False) + "\n")

        if self.hybrid_manager:
            await self._store_to_hybrid_manager(record)

        logger.debug(f"Recorded decision: {record_id}")
        return record_id

    async def _store_to_hybrid_manager(self, record: DecisionRecord):
        """Store decision to hybrid manager for semantic search."""
        content = f"""
## 决策记录

**时间**: {record.timestamp}
**类型**: {record.event_type}
**级别**: {record.decision_level}
**自动解决**: {record.was_auto_resolved}

### 事件详情
{json.dumps(record.event_details, ensure_ascii=False, indent=2)}

### 结果
- 成功: {record.success}
- 评分: {record.user_rating}
"""

        try:
            await self.hybrid_manager.store_memory(
                namespace=self.decisions_namespace,
                content=content,
                metadata={
                    "record_id": record.record_id,
                    "event_type": record.event_type,
                    "decision_level": record.decision_level,
                    "success": record.success,
                },
            )
        except Exception as e:
            logger.error(f"Failed to store to hybrid manager: {e}")

    async def search_similar_decisions(
        self,
        query: str,
        limit: int = 5,
    ) -> list[dict]:
        """Search similar historical decisions."""
        results = []

        if self.hybrid_manager:
            try:
                hybrid_results = await self.hybrid_manager.search(
                    query=query,
                    namespace=self.decisions_namespace,
                    limit=limit,
                )
                for r in hybrid_results:
                    results.append({
                        "record_id": r.metadata.get("record_id"),
                        "event_type": r.metadata.get("event_type"),
                        "decision_level": r.metadata.get("decision_level"),
                        "success": r.metadata.get("success"),
                        "content": r.content,
                        "score": getattr(r, "score", 0.5),
                        "success_rate": getattr(r, "score", 0.5),
                    })
                if results:
                    return results
            except Exception as e:
                logger.error(f"Hybrid search failed: {e}")

        results = self._keyword_search_decisions(query, limit)
        return results

    def _keyword_search_decisions(self, query: str, limit: int) -> list[dict]:
        """Keyword-based search for decisions."""
        results = []
        query_lower = query.lower()

        if not self.decisions_file.exists():
            return results

        with open(self.decisions_file, encoding="utf-8") as f:
            for line in f:
                try:
                    record = json.loads(line.strip())
                    if query_lower in str(record).lower():
                        results.append({
                            **record,
                            "score": 0.5,
                            "success_rate": 0.5,
                        })
                        if len(results) >= limit:
                            break
                except json.JSONDecodeError:
                    continue

        return results

    async def archive_success_case(
        self,
        idea: str,
        result: dict,
        quality_score: float,
        decisions: list[dict] | None = None,
    ) -> str:
        """Archive a success case."""
        case_id = f"case-{uuid.uuid4().hex[:8]}"
        timestamp = datetime.now()

        case = SuccessCase(
            case_id=case_id,
            idea=idea,
            result_summary=result.get("summary", ""),
            workspace_snapshot=result.get("workspace_snapshot", ""),
            quality_score=quality_score,
            decisions=decisions or [],
            created_at=timestamp,
            tags=self._extract_tags(idea),
        )

        case_dict = asdict(case)
        case_dict["created_at"] = timestamp.isoformat()

        async with self._file_lock:
            with open(self.cases_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(case_dict, ensure_ascii=False) + "\n")

        await self._append_to_memory_md(idea, result, quality_score)

        logger.info(f"Archived success case: {case_id}")
        return case_id

    async def _append_to_memory_md(
        self,
        idea: str,
        result: dict,
        quality_score: float,
    ):
        """Append to MEMORY.md file."""
        memory_file = self.workspace / "MEMORY.md"

        if not memory_file.exists():
            memory_file.write_text("# 项目记忆\n\n", encoding="utf-8")

        entry = f"""
### 成功案例 ({datetime.now().strftime('%Y-%m-%d')})

**需�?*: {idea[:100]}
**评分**: {quality_score:.1f}/5.0

**实现摘要**:
{result.get('summary', 'N/A')[:500]}

---
"""

        with open(memory_file, "a", encoding="utf-8") as f:
            f.write(entry)

    def _extract_tags(self, text: str) -> list[str]:
        """Extract tags from text."""
        tags = []
        for kw, tag in self.KEYWORDS_TAGS.items():
            if kw in text.lower():
                tags.append(tag)
        return tags

    async def update_decision_outcome(
        self,
        record_id: str,
        outcome: str,
        success: bool,
        user_rating: int | None = None,
    ):
        """Update decision outcome."""
        if not self.decisions_file.exists():
            return

        lines = []
        updated = False

        async with self._file_lock:
            with open(self.decisions_file, encoding="utf-8") as f:
                for line in f:
                    try:
                        record = json.loads(line.strip())
                        if record.get("record_id") == record_id:
                            record["outcome"] = outcome
                            record["success"] = success
                            if user_rating is not None:
                                record["user_rating"] = user_rating
                            updated = True
                        lines.append(json.dumps(record, ensure_ascii=False))
                    except json.JSONDecodeError:
                        lines.append(line.strip())

            if updated:
                with open(self.decisions_file, "w", encoding="utf-8") as f:
                    f.write("\n".join(lines) + "\n")

    async def get_all_decisions(self) -> list[dict]:
        """Get all decision records."""
        decisions = []

        if not self.decisions_file.exists():
            return decisions

        with open(self.decisions_file, encoding="utf-8") as f:
            for line in f:
                try:
                    record = json.loads(line.strip())
                    decisions.append(record)
                except json.JSONDecodeError:
                    continue

        return decisions

    async def get_success_cases(self, limit: int = 10) -> list[dict]:
        """Get success cases."""
        cases = []

        if not self.cases_file.exists():
            return cases

        with open(self.cases_file, encoding="utf-8") as f:
            for line in f:
                try:
                    case = json.loads(line.strip())
                    cases.append(case)
                    if len(cases) >= limit:
                        break
                except json.JSONDecodeError:
                    continue

        return sorted(cases, key=lambda x: x.get("quality_score", 0), reverse=True)

    async def store_project_context(
        self,
        project_id: str,
        name: str,
        description: str,
        technologies: list[str],
        metadata: dict[str, Any] | None = None,
    ) -> str:
        """存储项目上下文"""
        context = ProjectContext(
            project_id=project_id,
            name=name,
            description=description,
            technologies=technologies,
            created_at=datetime.now(),
            updated_at=datetime.now(),
            metadata=metadata or {},
        )

        context_dict = asdict(context)
        context_dict["created_at"] = context.created_at.isoformat()
        context_dict["updated_at"] = context.updated_at.isoformat()

        async with self._file_lock:
            with open(self.projects_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(context_dict, ensure_ascii=False) + "\n")

        if self.hybrid_manager:
            await self._store_project_to_hybrid(context)

        logger.info(f"Stored project context: {project_id}")
        return project_id

    async def _store_project_to_hybrid(self, context: ProjectContext):
        """存储项目到 hybrid manager"""
        content = f"""
## 项目上下文

**名称**: {context.name}
**描述**: {context.description}
**技术栈**: {', '.join(context.technologies)}
**创建时间**: {context.created_at}
"""

        try:
            await self.hybrid_manager.store_memory(
                namespace=self.projects_namespace,
                content=content,
                metadata={
                    "project_id": context.project_id,
                    "name": context.name,
                    "technologies": context.technologies,
                },
            )
        except Exception as e:
            logger.error(f"Failed to store project to hybrid manager: {e}")

    async def get_project_context(self, project_id: str) -> ProjectContext | None:
        """获取项目上下文"""
        if not self.projects_file.exists():
            return None

        with open(self.projects_file, encoding="utf-8") as f:
            for line in f:
                try:
                    data = json.loads(line.strip())
                    if data.get("project_id") == project_id:
                        return ProjectContext(
                            project_id=data["project_id"],
                            name=data["name"],
                            description=data["description"],
                            technologies=data["technologies"],
                            created_at=datetime.fromisoformat(data["created_at"]),
                            updated_at=datetime.fromisoformat(data["updated_at"]),
                            metadata=data.get("metadata", {}),
                        )
                except json.JSONDecodeError:
                    continue

        return None

    async def store_code_snippet(
        self,
        project_id: str,
        file_path: str,
        language: str,
        content: str,
        description: str,
        tags: list[str] | None = None,
    ) -> str:
        """存储代码片段"""
        snippet_id = f"snippet-{uuid.uuid4().hex[:8]}"

        snippet = CodeSnippet(
            snippet_id=snippet_id,
            project_id=project_id,
            file_path=file_path,
            language=language,
            content=content,
            description=description,
            tags=tags or [],
            created_at=datetime.now(),
        )

        snippet_dict = asdict(snippet)
        snippet_dict["created_at"] = snippet.created_at.isoformat()

        async with self._file_lock:
            with open(self.snippets_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(snippet_dict, ensure_ascii=False) + "\n")

        if self.hybrid_manager:
            await self._store_snippet_to_hybrid(snippet)

        logger.info(f"Stored code snippet: {snippet_id}")
        return snippet_id

    async def _store_snippet_to_hybrid(self, snippet: CodeSnippet):
        """存储代码片段到 hybrid manager"""
        content = f"""
## 代码片段

**文件**: {snippet.file_path}
**语言**: {snippet.language}
**描述**: {snippet.description}

````
{snippet.content[:500]}
```
"""

        try:
            await self.hybrid_manager.store_memory(
                namespace=self.snippets_namespace,
                content=content,
                metadata={
                    "snippet_id": snippet.snippet_id,
                    "project_id": snippet.project_id,
                    "language": snippet.language,
                    "tags": snippet.tags,
                },
            )
        except Exception as e:
            logger.error(f"Failed to store snippet to hybrid manager: {e}")

    async def search_code_snippets(
        self,
        query: str,
        project_id: str | None = None,
        language: str | None = None,
        limit: int = 5,
    ) -> list[dict]:
        """搜索代码片段"""
        results = []

        if self.hybrid_manager:
            try:
                hybrid_results = await self.hybrid_manager.search(
                    query=query,
                    namespace=self.snippets_namespace,
                    limit=limit,
                )
                for r in hybrid_results:
                    if project_id and r.metadata.get("project_id") != project_id:
                        continue
                    if language and r.metadata.get("language") != language:
                        continue
                    results.append({
                        "snippet_id": r.metadata.get("snippet_id"),
                        "project_id": r.metadata.get("project_id"),
                        "file_path": r.metadata.get("file_path"),
                        "language": r.metadata.get("language"),
                        "content": r.content,
                        "score": getattr(r, "score", 0.5),
                    })
                if results:
                    return results
            except Exception as e:
                logger.error(f"Hybrid search for snippets failed: {e}")

        results = self._keyword_search_snippets(query, project_id, language, limit)
        return results

    def _keyword_search_snippets(
        self,
        query: str,
        project_id: str | None,
        language: str | None,
        limit: int,
    ) -> list[dict]:
        """关键词搜索代码片段"""
        results = []
        query_lower = query.lower()

        if not self.snippets_file.exists():
            return results

        with open(self.snippets_file, encoding="utf-8") as f:
            for line in f:
                try:
                    snippet = json.loads(line.strip())
                    if project_id and snippet.get("project_id") != project_id:
                        continue
                    if language and snippet.get("language") != language:
                        continue
                    if query_lower in str(snippet).lower():
                        results.append({
                            **snippet,
                            "score": 0.5,
                        })
                        if len(results) >= limit:
                            break
                except json.JSONDecodeError:
                    continue

        return results

    async def record_error_pattern(
        self,
        error_type: str,
        error_message: str,
        context: dict,
        solution: str | None = None,
    ) -> str:
        """记录错误模式"""
        pattern_id = f"err-{uuid.uuid4().hex[:8]}"
        now = datetime.now()

        existing = await self._find_error_pattern(error_type, error_message)

        if existing:
            existing["occurrence_count"] += 1
            existing["last_seen"] = now.isoformat()
            if solution:
                existing["solution"] = solution
            await self._update_error_pattern(existing)
            return existing["pattern_id"]

        pattern = ErrorPattern(
            pattern_id=pattern_id,
            error_type=error_type,
            error_message=error_message[:500],
            context=context,
            solution=solution,
            occurrence_count=1,
            first_seen=now,
            last_seen=now,
        )

        pattern_dict = asdict(pattern)
        pattern_dict["first_seen"] = now.isoformat()
        pattern_dict["last_seen"] = now.isoformat()

        async with self._file_lock:
            with open(self.errors_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(pattern_dict, ensure_ascii=False) + "\n")

        logger.info(f"Recorded error pattern: {pattern_id}")
        return pattern_id

    async def _find_error_pattern(
        self,
        error_type: str,
        error_message: str,
    ) -> dict | None:
        """查找现有错误模式"""
        if not self.errors_file.exists():
            return None

        with open(self.errors_file, encoding="utf-8") as f:
            for line in f:
                try:
                    pattern = json.loads(line.strip())
                    if pattern.get("error_type") == error_type:
                        pattern_msg = pattern.get("error_message", "")
                        if pattern_msg in error_message or error_message in pattern_msg:
                            return pattern
                except json.JSONDecodeError:
                    continue

        return None

    async def _update_error_pattern(self, pattern: dict) -> None:
        """更新错误模式"""
        if not self.errors_file.exists():
            return

        lines = []
        async with self._file_lock:
            with open(self.errors_file, encoding="utf-8") as f:
                for line in f:
                    try:
                        record = json.loads(line.strip())
                        if record.get("pattern_id") == pattern["pattern_id"]:
                            lines.append(json.dumps(pattern, ensure_ascii=False))
                        else:
                            lines.append(line.strip())
                    except json.JSONDecodeError:
                        lines.append(line.strip())

            with open(self.errors_file, "w", encoding="utf-8") as f:
                f.write("\n".join(lines) + "\n")

    async def get_error_patterns(
        self,
        error_type: str | None = None,
        limit: int = 10,
    ) -> list[dict]:
        """获取错误模式"""
        patterns = []

        if not self.errors_file.exists():
            return patterns

        with open(self.errors_file, encoding="utf-8") as f:
            for line in f:
                try:
                    pattern = json.loads(line.strip())
                    if error_type and pattern.get("error_type") != error_type:
                        continue
                    patterns.append(pattern)
                    if len(patterns) >= limit:
                        break
                except json.JSONDecodeError:
                    continue

        return sorted(patterns, key=lambda x: x.get("occurrence_count", 0), reverse=True)

    async def get_error_solution(self, error_message: str) -> str | None:
        """获取错误解决方案"""
        if not self.errors_file.exists():
            return None

        with open(self.errors_file, encoding="utf-8") as f:
            for line in f:
                try:
                    pattern = json.loads(line.strip())
                    pattern_msg = pattern.get("error_message", "")
                    if pattern_msg in error_message or error_message in pattern_msg:
                        return pattern.get("solution")
                except json.JSONDecodeError:
                    continue

        return None

    async def get_stats(self) -> dict[str, Any]:
        """获取统计信息"""
        decisions = await self.get_all_decisions()
        cases = await self.get_success_cases(limit=1000)

        success_count = sum(1 for d in decisions if d.get("success"))
        failure_count = sum(1 for d in decisions if d.get("success") is False)

        avg_rating = 0.0
        ratings = [d.get("user_rating") for d in decisions if d.get("user_rating")]
        if ratings:
            avg_rating = sum(ratings) / len(ratings)

        return {
            "total_decisions": len(decisions),
            "total_cases": len(cases),
            "success_count": success_count,
            "failure_count": failure_count,
            "success_rate": success_count / len(decisions) if decisions else 0,
            "average_rating": round(avg_rating, 2),
            "files": {
                "decisions": str(self.decisions_file),
                "cases": str(self.cases_file),
                "projects": str(self.projects_file),
                "snippets": str(self.snippets_file),
                "errors": str(self.errors_file),
            },
        }
