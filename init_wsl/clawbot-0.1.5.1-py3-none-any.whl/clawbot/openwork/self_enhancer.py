"""
Self Enhancer - Continuous self-enhancement system.

This module provides the self-enhancer that continuously improves
decision-making capabilities based on historical patterns.
"""

import asyncio
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from clawbot.openwork.memory import OpenWorkMemoryBridge
    from clawbot.openwork.pattern_extractor import DecisionPattern, PatternExtractor

logger = logging.getLogger(__name__)


@dataclass
class EnhancementResult:
    timestamp: datetime
    adjustments: dict
    new_rules: list[dict]
    prompt_updates: list[dict]
    recommendations: list[str]
    feedback_insights: list[dict] = field(default_factory=list)
    error_pattern_updates: list[dict] = field(default_factory=list)
    capability_expansions: list[dict] = field(default_factory=list)


@dataclass
class FeedbackInsight:
    insight_type: str
    description: str
    affected_operations: list[str]
    suggested_action: str
    confidence: float


@dataclass
class CapabilityExpansion:
    operation_type: str
    previous_level: str
    new_level: str
    evidence_count: int
    success_rate: float
    reason: str


class SelfEnhancer:
    """Self enhancer - continuously optimizes decision capabilities."""

    DEFAULT_THRESHOLDS = {
        "auto_resolve": 0.7,
        "require_human": 0.3,
    }

    DEFAULT_AUTO_SAFE = frozenset([
        "file_read", "file_create", "file_modify",
        "command_safe", "http_request",
        "directory_create", "git_status", "git_log",
    ])

    DEFAULT_REQUIRE_HUMAN = frozenset([
        "file_delete", "directory_delete", "command_dangerous",
        "database_drop", "database_truncate",
        "external_service_config", "credential_access",
    ])

    def __init__(
        self,
        memory_bridge: "OpenWorkMemoryBridge",
        pattern_extractor: "PatternExtractor",
        config_path: Path | None = None,
    ):
        self.memory = memory_bridge
        self.extractor = pattern_extractor
        self.config_path = config_path or memory_bridge.workspace / "openwork_enhancements.json"

        self.thresholds = dict(self.DEFAULT_THRESHOLDS)
        self.auto_safe_operations = set(self.DEFAULT_AUTO_SAFE)
        self.require_human_operations = set(self.DEFAULT_REQUIRE_HUMAN)

        self._feedback_history: list[dict] = []
        self._error_learning_enabled = True
        self._capability_expansion_enabled = True
        self._min_samples_for_expansion = 5
        self._min_success_rate_for_expansion = 0.85

        self._load_config()

    def _load_config(self):
        """Load configuration."""
        if self.config_path.exists():
            try:
                with open(self.config_path, encoding="utf-8") as f:
                    config = json.load(f)
                self.thresholds = config.get("thresholds", self.thresholds)
                self.auto_safe_operations = set(config.get("auto_safe_operations", []))
                self.require_human_operations = set(config.get("require_human_operations", []))
                logger.info("Loaded enhancement configuration")
            except Exception as e:
                logger.error(f"Failed to load config: {e}")

    def _save_config(self):
        """Save configuration."""
        config = {
            "thresholds": self.thresholds,
            "auto_safe_operations": list(self.auto_safe_operations),
            "require_human_operations": list(self.require_human_operations),
            "last_updated": datetime.now().isoformat(),
        }

        try:
            with open(self.config_path, "w", encoding="utf-8") as f:
                json.dump(config, f, ensure_ascii=False, indent=2)
            logger.info("Saved enhancement configuration")
        except Exception as e:
            logger.error(f"Failed to save config: {e}")

    async def enhance(self) -> EnhancementResult:
        """Execute self-enhancement."""
        logger.info("Starting self-enhancement process...")

        patterns = await self.extractor.extract_patterns()

        adjustments = await self._adjust_thresholds(patterns)

        new_rules = await self._generate_new_rules(patterns)

        prompt_updates = await self._optimize_prompts(patterns)

        feedback_insights = await self._analyze_feedback_patterns()

        error_pattern_updates = await self._learn_from_errors()

        capability_expansions = await self._expand_capabilities(patterns)

        recommendations = self._generate_recommendations(patterns)

        self._save_config()

        result = EnhancementResult(
            timestamp=datetime.now(),
            adjustments=adjustments,
            new_rules=new_rules,
            prompt_updates=prompt_updates,
            recommendations=recommendations,
            feedback_insights=feedback_insights,
            error_pattern_updates=error_pattern_updates,
            capability_expansions=capability_expansions,
        )

        logger.info(
            f"Self-enhancement complete: "
            f"{len(new_rules)} new rules, "
            f"{len(adjustments)} threshold adjustments, "
            f"{len(feedback_insights)} feedback insights, "
            f"{len(capability_expansions)} capability expansions"
        )

        return result

    async def _adjust_thresholds(self, patterns: list["DecisionPattern"]) -> dict:
        """Adjust decision thresholds."""
        adjustments = {}

        high_confidence_patterns = [
            p for p in patterns
            if p.confidence > 0.9 and p.sample_count > 10
        ]

        if high_confidence_patterns:
            old_threshold = self.thresholds["auto_resolve"]
            new_threshold = max(0.5, old_threshold - 0.05)
            self.thresholds["auto_resolve"] = new_threshold
            adjustments["auto_resolve_threshold"] = {
                "old": old_threshold,
                "new": new_threshold,
                "reason": f"基于 {len(high_confidence_patterns)} 个高置信度模式",
            }
            logger.info(f"Adjusted auto_resolve threshold: {old_threshold} -> {new_threshold}")

        return adjustments

    async def _generate_new_rules(self, patterns: list["DecisionPattern"]) -> list[dict]:
        """Generate new auto-approval rules."""
        new_rules = []

        for pattern in patterns:
            if pattern.pattern_type == "operation_type":
                op_type = pattern.trigger_conditions.get("event_type")

                if (
                    op_type
                    and op_type not in self.auto_safe_operations
                    and pattern.success_rate > 0.85
                    and pattern.sample_count > 5
                ):
                    self.auto_safe_operations.add(op_type)
                    new_rules.append({
                        "operation": op_type,
                        "level": "auto_safe",
                        "confidence": pattern.confidence,
                        "samples": pattern.sample_count,
                    })
                    logger.info(f"Added new auto-safe rule: {op_type}")

        return new_rules

    async def _optimize_prompts(self, patterns: list["DecisionPattern"]) -> list[dict]:
        """Optimize decision prompts."""
        updates = []

        success_patterns = [
            p for p in patterns
            if p.success_rate > 0.9
        ]

        if success_patterns:
            new_guidelines = "\n".join([
                f"- {p.trigger_conditions} -> {p.recommended_level} (置信度: {p.confidence:.0%})"
                for p in success_patterns[:5]
            ])

            updates.append({
                "type": "decision_guidelines",
                "content": new_guidelines,
            })

        return updates

    def _generate_recommendations(self, patterns: list["DecisionPattern"]) -> list[str]:
        """Generate capability recommendations."""
        recommendations = []

        low_success = [p for p in patterns if p.success_rate < 0.5]
        if low_success:
            recommendations.append(
                f"⚠️ 发现 {len(low_success)} 个低成功率操作类型，建议人工审核"
            )

        high_auto = [p for p in patterns if p.confidence > 0.9]
        if high_auto:
            recommendations.append(
                f"✅ 发现 {len(high_auto)} 个高置信度模式，已自动优化决策阈值"
            )

        return recommendations

    async def _analyze_feedback_patterns(self) -> list[dict]:
        """Analyze feedback patterns for insights."""
        insights = []

        if not self._feedback_history:
            return insights

        rating_distribution = {"positive": 0, "neutral": 0, "negative": 0}
        operation_ratings: dict[str, list[int]] = {}

        for feedback in self._feedback_history:
            rating = feedback.get("rating", 0)
            if rating >= 4:
                rating_distribution["positive"] += 1
            elif rating >= 2:
                rating_distribution["neutral"] += 1
            else:
                rating_distribution["negative"] += 1

            operations = feedback.get("operations", [])
            for op in operations:
                if op not in operation_ratings:
                    operation_ratings[op] = []
                operation_ratings[op].append(rating)

        for op, ratings in operation_ratings.items():
            avg_rating = sum(ratings) / len(ratings)
            if avg_rating < 2.5 and len(ratings) >= 3:
                insights.append({
                    "type": "low_rated_operation",
                    "operation": op,
                    "avg_rating": avg_rating,
                    "sample_count": len(ratings),
                    "suggestion": f"考虑将 {op} 移至 require_human 级别",
                })
                if op in self.auto_safe_operations:
                    self.auto_safe_operations.discard(op)
                    if op not in self.require_human_operations:
                        self.require_human_operations.add(op)
            elif avg_rating >= 4.5 and len(ratings) >= 5:
                insights.append({
                    "type": "high_rated_operation",
                    "operation": op,
                    "avg_rating": avg_rating,
                    "sample_count": len(ratings),
                    "suggestion": f"{op} 表现优秀，可考虑提升自动化级别",
                })

        return insights

    async def _learn_from_errors(self) -> list[dict]:
        """Learn from error patterns."""
        if not self._error_learning_enabled:
            return []

        updates = []

        try:
            error_patterns = await self.memory.get_error_patterns()

            for pattern in error_patterns:
                if pattern.get("occurrence_count", 0) >= 3:
                    error_type = pattern.get("error_type", "")
                    solution = pattern.get("solution", "")

                    if solution:
                        updates.append({
                            "type": "error_solution_learned",
                            "error_type": error_type,
                            "solution": solution,
                            "occurrence_count": pattern.get("occurrence_count"),
                        })

                        related_ops = pattern.get("related_operations", [])
                        for op in related_ops:
                            if op in self.auto_safe_operations:
                                self.auto_safe_operations.discard(op)
                                logger.info(f"Removed {op} from auto_safe due to error pattern")
        except Exception as e:
            logger.error(f"Error learning from error patterns: {e}")

        return updates

    async def _expand_capabilities(self, patterns: list["DecisionPattern"]) -> list[dict]:
        """Expand automation capabilities based on patterns."""
        if not self._capability_expansion_enabled:
            return []

        expansions = []

        for pattern in patterns:
            if pattern.pattern_type != "operation_type":
                continue

            op_type = pattern.trigger_conditions.get("event_type")
            if not op_type:
                continue

            if op_type in self.auto_safe_operations:
                continue

            if op_type in self.require_human_operations:
                if (pattern.success_rate >= self._min_success_rate_for_expansion and
                    pattern.sample_count >= self._min_samples_for_expansion * 2):
                    previous_level = "require_human"
                    self.require_human_operations.discard(op_type)
                    self.auto_safe_operations.add(op_type)

                    expansions.append({
                        "operation_type": op_type,
                        "previous_level": previous_level,
                        "new_level": "auto_safe",
                        "evidence_count": pattern.sample_count,
                        "success_rate": pattern.success_rate,
                        "reason": f"基于 {pattern.sample_count} 次成功案例，成功率 {pattern.success_rate:.0%}",
                    })
                    logger.info(f"Expanded capability: {op_type} -> auto_safe")
            else:
                if (pattern.success_rate >= self._min_success_rate_for_expansion and
                    pattern.sample_count >= self._min_samples_for_expansion):
                    expansions.append({
                        "operation_type": op_type,
                        "previous_level": "auto_resolve",
                        "new_level": "auto_safe",
                        "evidence_count": pattern.sample_count,
                        "success_rate": pattern.success_rate,
                        "reason": f"基于 {pattern.sample_count} 次成功案例",
                    })
                    self.auto_safe_operations.add(op_type)
                    logger.info(f"Expanded capability: {op_type} -> auto_safe")

        return expansions

    def record_feedback(self, feedback: dict):
        """Record feedback for analysis."""
        self._feedback_history.append({
            **feedback,
            "timestamp": datetime.now().isoformat(),
        })

        if len(self._feedback_history) > 1000:
            self._feedback_history = self._feedback_history[-500:]

    async def process_feedback_for_enhancement(self, feedback: dict) -> dict:
        """Process feedback and trigger immediate enhancement if needed."""
        self.record_feedback(feedback)

        rating = feedback.get("rating", 0)
        operations = feedback.get("operations", [])
        immediate_actions = []

        if rating <= 1:
            for op in operations:
                if op in self.auto_safe_operations:
                    self.auto_safe_operations.discard(op)
                    if op not in self.require_human_operations:
                        self.require_human_operations.add(op)
                    immediate_actions.append({
                        "action": "downgrade_to_require_human",
                        "operation": op,
                        "reason": "低评分反馈触发立即降级",
                    })
                    logger.warning(f"Downgraded {op} to require_human due to low rating")

        elif rating >= 5:
            for op in operations:
                if op in self.require_human_operations:
                    self.require_human_operations.discard(op)
                    immediate_actions.append({
                        "action": "remove_from_require_human",
                        "operation": op,
                        "reason": "高评分反馈触发升级候选",
                    })
                    logger.info(f"Removed {op} from require_human due to high rating")

        if immediate_actions:
            self._save_config()

        return {
            "immediate_actions": immediate_actions,
            "feedback_recorded": True,
        }

    def get_enhancement_stats(self) -> dict:
        """Get detailed enhancement statistics."""
        return {
            "thresholds": self.thresholds,
            "auto_safe_operations": list(self.auto_safe_operations),
            "require_human_operations": list(self.require_human_operations),
            "feedback_history_count": len(self._feedback_history),
            "error_learning_enabled": self._error_learning_enabled,
            "capability_expansion_enabled": self._capability_expansion_enabled,
            "config_path": str(self.config_path),
        }

    def get_decision_level(self, operation_type: str) -> str:
        """Get decision level for an operation type."""
        if operation_type in self.auto_safe_operations:
            return "auto_safe"
        if operation_type in self.require_human_operations:
            return "require_human"
        return "auto_resolve"

    def get_stats(self) -> dict:
        """Get enhancer statistics (simplified)."""
        return {
            "thresholds": self.thresholds,
            "auto_safe_operations_count": len(self.auto_safe_operations),
            "require_human_operations_count": len(self.require_human_operations),
            "config_path": str(self.config_path),
            "feedback_history_count": len(self._feedback_history),
        }


class EnhancementScheduler:
    """Enhancement scheduler - runs periodic self-enhancement."""

    def __init__(
        self,
        self_enhancer: SelfEnhancer,
        interval_hours: int = 24,
    ):
        self.enhancer = self_enhancer
        self.interval = timedelta(hours=interval_hours)
        self._task: asyncio.Task | None = None
        self._running = False
        self._last_enhancement: datetime | None = None
        self._enhancement_count = 0

    async def start(self):
        """Start the scheduler."""
        self._running = True
        self._task = asyncio.create_task(self._run_loop())
        logger.info(f"Enhancement scheduler started, interval: {self.interval}")

    async def stop(self):
        """Stop the scheduler."""
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        logger.info("Enhancement scheduler stopped")

    async def _run_loop(self):
        """Run the enhancement loop."""
        while self._running:
            try:
                await asyncio.sleep(self.interval.total_seconds())

                if not self._running:
                    break

                result = await self.enhancer.enhance()
                self._last_enhancement = result.timestamp
                self._enhancement_count += 1

                logger.info(
                    f"Self-enhancement #{self._enhancement_count} complete: "
                    f"{len(result.new_rules)} new rules, "
                    f"{len(result.adjustments)} threshold adjustments"
                )

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Self-enhancement failed: {e}")

    async def trigger_enhancement(self) -> EnhancementResult:
        """Manually trigger enhancement."""
        result = await self.enhancer.enhance()
        self._last_enhancement = result.timestamp
        self._enhancement_count += 1
        return result

    def get_status(self) -> dict:
        """Get scheduler status."""
        return {
            "running": self._running,
            "interval_hours": self.interval.total_seconds() / 3600,
            "last_enhancement": self._last_enhancement.isoformat() if self._last_enhancement else None,
            "enhancement_count": self._enhancement_count,
        }
