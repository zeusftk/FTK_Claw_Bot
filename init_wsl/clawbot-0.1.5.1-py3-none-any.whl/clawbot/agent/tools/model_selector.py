"""Model selection for opencode integration."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable

from loguru import logger

from clawbot.agent.tools.model_detector import ModelInfo, ModelDetector

if TYPE_CHECKING:
    from clawbot.bus.queue import MessageBus


@dataclass
class ModelSelection:
    """Result of model selection."""
    model: ModelInfo
    user_selected: bool
    was_auto_selected: bool


class ModelSelector:
    """Handles model selection for opencode."""
    
    def __init__(
        self,
        detector: ModelDetector | None = None,
        on_selection_needed: Callable[[list[ModelInfo]], str | None] | None = None,
    ):
        self._detector = detector or ModelDetector()
        self._on_selection_needed = on_selection_needed
        self._selected_model: ModelInfo | None = None
        self._selection_history: list[str] = []
    
    def format_model_list(self, models: list[ModelInfo]) -> str:
        """Format model list for user display."""
        lines = ["📋 检测到以下可用模型：\n"]
        
        for i, model in enumerate(models, 1):
            status = ""
            if model.is_configured:
                status = "✅ 已配置"
            elif model.is_free:
                status = "🆓 免费"
            
            desc = f" - {model.description}" if model.description else ""
            lines.append(f"  [{i}] {model.name} ({model.provider}) {status}{desc}")
        
        lines.append("\n请选择要使用的模型 (输入数字)")
        return "\n".join(lines)
    
    def format_model_list_compact(self, models: list[ModelInfo]) -> str:
        """Format model list in compact form."""
        items = []
        for i, model in enumerate(models, 1):
            status = "✅" if model.is_configured else ("🆓" if model.is_free else "")
            items.append(f"{i}.{model.name}{status}")
        return " ".join(items)
    
    async def select_model(
        self,
        models: list[ModelInfo] | None = None,
        auto_select_if_one: bool = True,
    ) -> ModelSelection | None:
        """Select a model from available options."""
        if models is None:
            models = await self._detector.get_free_models()
        
        if not models:
            logger.warning("No available models found")
            return None
        
        if auto_select_if_one and len(models) == 1:
            self._selected_model = models[0]
            return ModelSelection(
                model=models[0],
                user_selected=False,
                was_auto_selected=True,
            )
        
        if self._on_selection_needed:
            selected_id = await self._on_selection_needed(models)
            if selected_id:
                model = next((m for m in models if m.id == selected_id), None)
                if model:
                    self._selected_model = model
                    return ModelSelection(
                        model=model,
                        user_selected=True,
                        was_auto_selected=False,
                    )
        
        recommended = self._detector.get_recommended_model()
        if recommended:
            self._selected_model = recommended
            return ModelSelection(
                model=recommended,
                user_selected=False,
                was_auto_selected=True,
            )
        
        return None
    
    def select_by_index(self, models: list[ModelInfo], index: int) -> ModelInfo | None:
        """Select model by index (1-based)."""
        if 1 <= index <= len(models):
            return models[index - 1]
        return None
    
    def select_by_name(self, models: list[ModelInfo], name: str) -> ModelInfo | None:
        """Select model by name (case-insensitive partial match)."""
        name_lower = name.lower()
        for model in models:
            if name_lower in model.name.lower() or name_lower in model.id.lower():
                return model
        return None
    
    async def set_model(self, model_id: str, config_path: Path | None = None) -> bool:
        """Set the model in opencode configuration."""
        if config_path is None:
            config_path = self._detector.get_config_path()
        
        if config_path is None:
            config_path = Path.home() / ".config" / "opencode" / "opencode.json"
            config_path.parent.mkdir(parents=True, exist_ok=True)
        
        config = self._detector.config.copy()
        if "models" not in config:
            config["models"] = {}
        
        config["models"]["default"] = model_id
        
        try:
            config_path.write_text(
                json.dumps(config, indent=2, ensure_ascii=False),
                encoding="utf-8"
            )
            logger.info(f"Set model to {model_id} in {config_path}")
            return True
        except OSError as e:
            logger.error(f"Failed to write config: {e}")
            return False
    
    def get_selected_model(self) -> ModelInfo | None:
        """Get the currently selected model."""
        return self._selected_model
    
    def clear_selection(self) -> None:
        """Clear the current selection."""
        self._selected_model = None
    
    def get_selection_history(self) -> list[str]:
        """Get history of selected model IDs."""
        return self._selection_history.copy()
    
    def record_selection(self, model: ModelInfo) -> None:
        """Record a model selection."""
        self._selection_history.append(model.id)
        self._selected_model = model


class InteractiveModelSelector:
    """Interactive model selector that works with message bus."""
    
    def __init__(
        self,
        bus: "MessageBus | None" = None,
        channel: str = "cli",
        chat_id: str = "model-selection",
    ):
        self._bus = bus
        self._channel = channel
        self._chat_id = chat_id
        self._selector = ModelSelector()
        self._pending_selection: dict[str, Any] = {}
    
    async def prompt_and_select(
        self,
        models: list[ModelInfo] | None = None,
    ) -> ModelInfo | None:
        """Prompt user and get selection."""
        if models is None:
            models = await self._selector._detector.get_free_models()
        
        if not models:
            return None
        
        if len(models) == 1:
            return models[0]
        
        message = self._selector.format_model_list(models)
        
        if self._bus:
            from clawbot.bus.events import OutboundMessage
            await self._bus.publish_outbound(OutboundMessage(
                channel=self._channel,
                chat_id=self._chat_id,
                content=message,
                metadata={"model_selection": True, "model_count": len(models)},
            ))
        
        self._pending_selection = {
            "models": models,
            "waiting": True,
        }
        
        return None
    
    def handle_response(self, response: str) -> ModelInfo | None:
        """Handle user response to model selection prompt."""
        if not self._pending_selection.get("waiting"):
            return None
        
        models = self._pending_selection.get("models", [])
        
        try:
            index = int(response.strip())
            selected = self._selector.select_by_index(models, index)
        except ValueError:
            selected = self._selector.select_by_name(models, response)
        
        if selected:
            self._pending_selection["waiting"] = False
            self._selector.record_selection(selected)
        
        return selected
    
    def set_context(self, channel: str, chat_id: str) -> None:
        """Set the channel and chat_id for messages."""
        self._channel = channel
        self._chat_id = chat_id
