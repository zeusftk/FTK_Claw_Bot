"""Opencode tool for clawbot using HTTP API."""

from __future__ import annotations

import asyncio
import json
import subprocess
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable

import requests
from loguru import logger

from clawbot.agent.tools.base import Tool
from clawbot.agent.tools.model_detector import ModelDetector, ModelInfo
from clawbot.agent.tools.model_selector import ModelSelector, ModelSelection
from clawbot.config.workspace import WorkspaceManager

if TYPE_CHECKING:
    from clawbot.agent.decider import DecisionEngine


class ControlRequestType(Enum):
    CONFIRMATION = "confirmation"
    CLARIFICATION = "clarification"
    PERMISSION = "permission"
    CHOICE = "choice"


@dataclass
class ControlRequest:
    """Control request from opencode."""
    type: ControlRequestType
    message: str
    options: list[str] = field(default_factory=list)
    session_id: str = ""
    metadata: dict = field(default_factory=dict)


@dataclass
class OpencodeSession:
    """Manages an opencode session."""
    session_id: str
    workspace: Path
    history: list[dict] = field(default_factory=list)
    
    def needs_confirmation(self, response: dict) -> bool:
        """Check if response needs confirmation."""
        return response.get("needs_confirmation", False)
    
    def is_completed(self, response: dict) -> bool:
        """Check if task is completed."""
        return response.get("status") == "completed" or response.get("done", False)


class OpencodeTool(Tool):
    """Tool to interact with opencode for automated programming."""
    
    def __init__(
        self,
        port: int = 7777,
        workspace_manager: WorkspaceManager | None = None,
        decider: "DecisionEngine | None" = None,
        on_confirmation_request: Callable[[ControlRequest], Any] | None = None,
        on_model_selection: Callable[[list[ModelInfo]], str | None] | None = None,
    ):
        self._port = port
        self._base_url = f"http://localhost:{port}"
        self._server_process = None
        self._session_id = None
        self._workspace_manager = workspace_manager or WorkspaceManager()
        self._decider = decider
        self._on_confirmation_request = on_confirmation_request
        self._sessions: dict[str, OpencodeSession] = {}
        
        self._model_detector = ModelDetector()
        self._model_selector = ModelSelector(
            detector=self._model_detector,
            on_selection_needed=on_model_selection,
        )
        self._selected_model: ModelInfo | None = None
        self._model_checked = False
    
    @property
    def name(self) -> str:
        return "opencode"
    
    @property
    def description(self) -> str:
        return (
            "Execute opencode for automated programming tasks. "
            "Use this to generate code, analyze projects, or perform development tasks. "
            "Supports both direct execution and background task modes."
        )
    
    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "task": {
                    "type": "string",
                    "description": "Task description for opencode to execute"
                },
                "workspace": {
                    "type": "string",
                    "description": "Optional workspace directory path. If not provided, uses default workspace."
                },
                "mode": {
                    "type": "string",
                    "enum": ["direct", "background"],
                    "description": "Execution mode: 'direct' for quick tasks, 'background' for long-running tasks"
                },
                "task_type": {
                    "type": "string",
                    "enum": ["fix", "coding", "explain", "design", "refactor", "testing", "setup", "documentation"],
                    "description": "Optional task type classification"
                }
            },
            "required": ["task"]
        }
    
    async def _ensure_server(self) -> bool:
        """Ensure opencode server is running."""
        try:
            r = requests.get(f"{self._base_url}/global/health", timeout=2)
            if r.status_code == 200:
                return True
        except Exception:
            pass
        
        try:
            self._server_process = subprocess.Popen(
                ["opencode", "serve", "--port", str(self._port)],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            await self._wait_for_server()
            return True
        except Exception as e:
            logger.warning(f"Failed to start opencode server: {e}")
            return False
    
    async def _wait_for_server(self, timeout: int = 30):
        """Wait for server to be ready."""
        start = time.time()
        while time.time() - start < timeout:
            try:
                r = requests.get(f"{self._base_url}/global/health", timeout=2)
                if r.status_code == 200:
                    return
            except Exception:
                pass
            await asyncio.sleep(0.5)
        raise TimeoutError("opencode server failed to start")
    
    async def execute(self, task: str, workspace: str | None = None, mode: str = "direct", task_type: str | None = None, **kwargs) -> str:
        """Execute opencode task."""
        if not self._model_checked:
            model_result = await self._check_and_select_model(task_type)
            if model_result is not None:
                return model_result
            self._model_checked = True
        
        project_path, is_new = self._workspace_manager.get_or_create_project(task)
        workspace_path = Path(workspace) if workspace else project_path
        
        server_available = await self._ensure_server()
        
        if server_available:
            return await self._execute_via_api(task, workspace_path, mode)
        else:
            return await self._execute_via_cli(task, workspace_path, mode)
    
    async def _check_and_select_model(self, task_type: str | None = None) -> str | None:
        """Check available models and select one if needed."""
        if not self._model_detector.is_opencode_installed():
            return (
                "⚠️ opencode 未安装\n\n"
                "请先安装 opencode:\n"
                "  curl -fsSL https://opencode.ai/install | bash\n"
                "或\n"
                "  npm install -g opencode-ai\n\n"
                "安装后使用 `opencode auth login` 配置模型。"
            )
        
        models = await self._model_detector.get_free_models()
        
        if not models:
            return (
                "⚠️ 没有可用的模型\n\n"
                "请配置 opencode 模型:\n"
                "1. 使用 `opencode auth login anthropic` 登录 Anthropic\n"
                "2. 或使用 `opencode auth login openai` 登录 OpenAI\n"
                "3. 或配置本地模型 (Ollama)\n\n"
                "配置文件位置: ~/.config/opencode/opencode.json"
            )
        
        if len(models) == 1:
            self._selected_model = models[0]
            logger.info(f"Auto-selected model: {self._selected_model.name}")
            return None
        
        selection = await self._model_selector.select_model(models, auto_select_if_one=False)
        
        if selection:
            self._selected_model = selection.model
            if selection.was_auto_selected:
                logger.info(f"Auto-selected recommended model: {self._selected_model.name}")
            return None
        
        return (
            "📋 检测到多个可用模型，请选择:\n\n" +
            self._model_selector.format_model_list(models) +
            "\n\n请重新执行任务并指定模型。"
        )
    
    async def _execute_via_api(self, task: str, workspace: Path, mode: str) -> str:
        """Execute task via HTTP API."""
        try:
            session = await self._create_session(workspace)
            self._session_id = session.get("id")
            
            if not self._session_id:
                return "Error: Failed to create opencode session"
            
            self._sessions[self._session_id] = OpencodeSession(
                session_id=self._session_id,
                workspace=workspace
            )
            
            response = await self._send_prompt(self._session_id, task)
            
            if response.get("done"):
                return response.get("result", "Task completed")
            
            control = await self._wait_for_control()
            decision = await self._handle_control(control)
            await self._respond_to_control(decision)
            
            return response.get("result", "Task initiated")
            
        except Exception as e:
            logger.error(f"API execution failed: {e}")
            return f"Error: {str(e)}"
    
    async def _execute_via_cli(self, task: str, workspace: Path, mode: str) -> str:
        """Execute task via CLI as fallback."""
        try:
            cmd = ["opencode", "run", task, "--cwd", str(workspace)]
            
            if mode == "background":
                process = subprocess.Popen(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    cwd=str(workspace)
                )
                return f"Background task started in {workspace}"
            
            process = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=300,
                cwd=str(workspace)
            )
            
            if process.returncode == 0:
                return process.stdout or "Task completed successfully"
            else:
                return f"Error: {process.stderr}"
                
        except subprocess.TimeoutExpired:
            return "Error: Task timed out after 300 seconds"
        except Exception as e:
            return f"Error: {str(e)}"
    
    async def _create_session(self, workspace: Path) -> dict:
        """Create a new session."""
        r = requests.post(
            f"{self._base_url}/session",
            json={"title": "clawbot-task", "cwd": str(workspace)},
            timeout=10
        )
        return r.json()
    
    async def _send_prompt(self, session_id: str, prompt: str) -> dict:
        """Send message to session."""
        r = requests.post(
            f"{self._base_url}/session/{session_id}/message",
            json={"parts": [{"type": "text", "text": prompt}]},
            timeout=300
        )
        return r.json()
    
    async def _wait_for_control(self, timeout: int = 300) -> dict:
        """Wait for control request."""
        try:
            r = requests.get(
                f"{self._base_url}/tui/control/next",
                timeout=timeout
            )
            return r.json()
        except requests.Timeout:
            return {"type": "timeout"}
    
    async def _handle_control(self, control: dict) -> dict:
        """Process control request via DecisionEngine."""
        if control.get("type") == "timeout":
            return {"response": "continue"}
        
        request = ControlRequest(
            type=ControlRequestType(control.get("type", "confirmation")),
            message=control.get("message", ""),
            options=control.get("options", []),
            session_id=self._session_id or "",
            metadata=control.get("metadata", {})
        )
        
        if self._on_confirmation_request:
            result = await self._on_confirmation_request(request)
            return {"response": result}
        
        if self._decider:
            from clawbot.agent.decider import DecisionContext
            context = DecisionContext(
                task=request.message,
                is_high_risk=self._is_high_risk_request(request)
            )
            needs_confirm = await self._decider.should_confirm(context)
            if needs_confirm:
                return {"response": "ask_user", "request": request}
        
        return {"response": "allow"}
    
    def _is_high_risk_request(self, request: ControlRequest) -> bool:
        """Check if request is high risk."""
        high_risk_keywords = ["delete", "remove", "drop", "rm", "清空", "删除"]
        message_lower = request.message.lower()
        return any(kw in message_lower for kw in high_risk_keywords)
    
    async def _respond_to_control(self, response: dict) -> bool:
        """Respond to control request."""
        try:
            r = requests.post(
                f"{self._base_url}/tui/control/response",
                json={"body": response},
                timeout=10
            )
            return r.status_code == 200
        except Exception as e:
            logger.error(f"Failed to respond to control: {e}")
            return False
    
    async def respond_to_permission(self, session_id: str, perm_id: str, response: str, remember: bool = False) -> bool:
        """Respond to permission request."""
        try:
            r = requests.post(
                f"{self._base_url}/session/{session_id}/permissions/{perm_id}",
                json={"response": response, "remember": remember},
                timeout=10
            )
            return r.status_code == 200
        except Exception as e:
            logger.error(f"Failed to respond to permission: {e}")
            return False
    
    def get_session(self, session_id: str) -> OpencodeSession | None:
        """Get session by ID."""
        return self._sessions.get(session_id)
    
    def list_sessions(self) -> list[str]:
        """List all session IDs."""
        return list(self._sessions.keys())
    
    def get_selected_model(self) -> ModelInfo | None:
        """Get the currently selected model."""
        return self._selected_model
    
    def set_model(self, model_id: str) -> bool:
        """Manually set the model to use."""
        models = self._model_detector._get_configured_models()
        model = next((m for m in models if m.id == model_id), None)
        
        if model:
            self._selected_model = model
            self._model_checked = True
            return True
        
        for free_model in self._model_detector.get_recommended_model.__self__.FREE_MODELS if hasattr(self._model_detector.get_recommended_model, '__self__') else []:
            if free_model.id == model_id:
                self._selected_model = free_model
                self._model_checked = True
                return True
        
        return False
    
    async def list_available_models(self) -> list[ModelInfo]:
        """List all available models."""
        return await self._model_detector.detect_available_models()
    
    def reset_model_selection(self) -> None:
        """Reset model selection to force re-selection."""
        self._selected_model = None
        self._model_checked = False
