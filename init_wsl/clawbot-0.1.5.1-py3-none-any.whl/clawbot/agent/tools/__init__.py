"""Agent tools module."""

from clawbot.agent.tools.base import Tool
from clawbot.agent.tools.registry import ToolRegistry
from clawbot.agent.tools.opencode import OpencodeTool, OpencodeSession, ControlRequest, ControlRequestType
from clawbot.agent.tools.model_detector import ModelDetector, ModelInfo
from clawbot.agent.tools.model_selector import ModelSelector, ModelSelection

__all__ = [
    "Tool",
    "ToolRegistry",
    "OpencodeTool",
    "OpencodeSession",
    "ControlRequest",
    "ControlRequestType",
    "ModelDetector",
    "ModelInfo",
    "ModelSelector",
    "ModelSelection",
]
