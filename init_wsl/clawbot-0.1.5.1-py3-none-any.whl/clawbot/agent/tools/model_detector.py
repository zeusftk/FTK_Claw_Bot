"""Model detection for opencode integration."""

from __future__ import annotations

import json
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from loguru import logger


@dataclass
class ModelInfo:
    """Information about an available model."""
    id: str
    name: str
    provider: str
    is_free: bool = False
    is_configured: bool = False
    context_window: int = 4096
    description: str = ""
    tags: list[str] = field(default_factory=list)
    
    def __str__(self) -> str:
        status = "✅ 已配置" if self.is_configured else ("🆓 免费" if self.is_free else "")
        return f"{self.name} ({self.provider}) {status}"


FREE_MODELS: list[ModelInfo] = [
    ModelInfo(
        id="aiping/minimax-m2",
        name="MiniMax-M2",
        provider="aiping",
        is_free=True,
        context_window=245000,
        description="高效文本生成，适合批量文档处理与代码注释",
        tags=["free", "text-generation", "chinese"],
    ),
    ModelInfo(
        id="aiping/glm-4.6",
        name="GLM-4.6",
        provider="aiping",
        is_free=True,
        context_window=128000,
        description="中文理解能力突出，本地化需求分析利器",
        tags=["free", "chinese", "analysis"],
    ),
    ModelInfo(
        id="aiping/kimi-k2-thinking",
        name="Kimi-K2-Thinking",
        provider="aiping",
        is_free=True,
        context_window=200000,
        description="长上下文处理强，代码审查、重构首选",
        tags=["free", "long-context", "code-review"],
    ),
    ModelInfo(
        id="ollama/llama3.1",
        name="Llama 3.1",
        provider="ollama",
        is_free=True,
        context_window=128000,
        description="本地运行，隐私保护，通用模型",
        tags=["free", "local", "privacy"],
    ),
    ModelInfo(
        id="ollama/codellama",
        name="Code Llama",
        provider="ollama",
        is_free=True,
        context_window=16384,
        description="本地代码生成专用模型",
        tags=["free", "local", "code"],
    ),
    ModelInfo(
        id="ollama/deepseek-coder",
        name="DeepSeek Coder",
        provider="ollama",
        is_free=True,
        context_window=16384,
        description="本地代码生成，支持多种编程语言",
        tags=["free", "local", "code"],
    ),
    ModelInfo(
        id="groq/llama-3.1-70b",
        name="Llama 3.1 70B",
        provider="groq",
        is_free=True,
        context_window=8192,
        description="Groq 高速推理，适合快速响应",
        tags=["free", "fast", "inference"],
    ),
    ModelInfo(
        id="deepseek/deepseek-coder",
        name="DeepSeek Coder",
        provider="deepseek",
        is_free=False,
        context_window=64000,
        description="代码生成专家，性价比高",
        tags=["code", "affordable"],
    ),
]


class ModelDetector:
    """Detects available models for opencode."""
    
    CONFIG_PATHS = [
        Path.cwd() / ".opencode" / "opencode.json",
        Path.home() / ".config" / "opencode" / "opencode.json",
    ]
    
    def __init__(self, workspace: Path | None = None):
        self._workspace = workspace or Path.cwd()
        self._config: dict | None = None
    
    @property
    def config(self) -> dict:
        """Lazy load opencode config."""
        if self._config is None:
            self._config = self._load_config()
        return self._config
    
    def _load_config(self) -> dict:
        """Load opencode configuration."""
        for path in self.CONFIG_PATHS:
            if path.exists():
                try:
                    return json.loads(path.read_text(encoding="utf-8"))
                except (json.JSONDecodeError, OSError) as e:
                    logger.warning(f"Failed to load config from {path}: {e}")
        return {}
    
    def is_opencode_installed(self) -> bool:
        """Check if opencode is installed."""
        return shutil.which("opencode") is not None
    
    async def detect_available_models(self) -> list[ModelInfo]:
        """Detect all available models."""
        models: list[ModelInfo] = []
        
        configured_models = self._get_configured_models()
        models.extend(configured_models)
        
        for free_model in FREE_MODELS:
            if not any(m.id == free_model.id for m in models):
                free_model_copy = ModelInfo(
                    id=free_model.id,
                    name=free_model.name,
                    provider=free_model.provider,
                    is_free=free_model.is_free,
                    is_configured=self._is_provider_configured(free_model.provider),
                    context_window=free_model.context_window,
                    description=free_model.description,
                    tags=free_model.tags.copy(),
                )
                models.append(free_model_copy)
        
        return models
    
    async def get_free_models(self) -> list[ModelInfo]:
        """Get list of free models."""
        models = await self.detect_available_models()
        return [m for m in models if m.is_free or m.is_configured]
    
    def _get_configured_models(self) -> list[ModelInfo]:
        """Extract configured models from config."""
        models: list[ModelInfo] = []
        config = self.config
        
        providers = config.get("providers", {})
        model_defs = config.get("models", {})
        
        for model_key, model_id in model_defs.items():
            if isinstance(model_id, str):
                provider = model_id.split("/")[0] if "/" in model_id else "unknown"
                is_configured = provider in providers
                
                existing = next((m for m in FREE_MODELS if m.id == model_id), None)
                
                models.append(ModelInfo(
                    id=model_id,
                    name=existing.name if existing else model_key,
                    provider=provider,
                    is_free=existing.is_free if existing else False,
                    is_configured=is_configured,
                    context_window=existing.context_window if existing else 4096,
                    description=existing.description if existing else "",
                    tags=existing.tags.copy() if existing and existing.tags else [],
                ))
        
        return models
    
    def _is_provider_configured(self, provider: str) -> bool:
        """Check if a provider is configured."""
        providers = self.config.get("providers", {})
        return provider in providers
    
    async def check_model_availability(self, model_id: str) -> bool:
        """Check if a specific model is available."""
        models = await self.detect_available_models()
        return any(m.id == model_id for m in models)
    
    def get_config_path(self) -> Path | None:
        """Get the path to the opencode config file."""
        for path in self.CONFIG_PATHS:
            if path.exists():
                return path
        return None
    
    async def get_models_from_cli(self) -> list[ModelInfo]:
        """Get models using opencode CLI."""
        if not self.is_opencode_installed():
            return []
        
        try:
            result = subprocess.run(
                ["opencode", "models", "list", "--json"],
                capture_output=True,
                text=True,
                timeout=30,
            )
            if result.returncode == 0:
                data = json.loads(result.stdout)
                return [
                    ModelInfo(
                        id=m.get("id", ""),
                        name=m.get("name", m.get("id", "")),
                        provider=m.get("provider", "unknown"),
                        is_configured=True,
                    )
                    for m in data.get("models", [])
                ]
        except (subprocess.TimeoutExpired, json.JSONDecodeError, OSError) as e:
            logger.warning(f"Failed to get models from CLI: {e}")
        
        return []
    
    def get_recommended_model(self, task_type: str | None = None) -> ModelInfo | None:
        """Get recommended model based on task type."""
        models = [m for m in FREE_MODELS if m.is_free]
        
        if not models:
            return None
        
        if task_type == "code":
            for m in models:
                if "code" in m.tags:
                    return m
        elif task_type == "chinese":
            for m in models:
                if "chinese" in m.tags:
                    return m
        elif task_type == "review":
            for m in models:
                if "code-review" in m.tags or "long-context" in m.tags:
                    return m
        
        return models[0]
