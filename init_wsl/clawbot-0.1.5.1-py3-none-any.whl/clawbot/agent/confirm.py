"""Confirmation flow handling for opencode integration."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any, Awaitable, Callable

from loguru import logger

if TYPE_CHECKING:
    from clawbot.bus.queue import MessageBus


class ConfirmationStatus(Enum):
    PENDING = "pending"
    APPROVED = "approved"
    DENIED = "denied"
    TIMEOUT = "timeout"


@dataclass
class ConfirmationRequest:
    """Request for human confirmation."""
    task: str
    question: str
    options: list[str] = field(default_factory=lambda: ["确认", "取消"])
    session_id: str = ""
    metadata: dict = field(default_factory=dict)
    timeout_seconds: int = 300


@dataclass
class ConfirmationResponse:
    """Response to a confirmation request."""
    request_id: str
    status: ConfirmationStatus
    user_response: str | None = None
    user_id: str | None = None


class ConfirmationManager:
    """Manages confirmation requests and responses."""
    
    def __init__(self):
        self._pending_requests: dict[str, ConfirmationRequest] = {}
        self._responses: dict[str, ConfirmationResponse] = {}
        self._callbacks: dict[str, Callable[[ConfirmationResponse], Awaitable[None]]] = {}
    
    def create_request(
        self,
        task: str,
        question: str,
        options: list[str] | None = None,
        session_id: str = "",
        metadata: dict | None = None,
    ) -> str:
        """Create a new confirmation request."""
        import uuid
        request_id = str(uuid.uuid4())[:8]
        
        request = ConfirmationRequest(
            task=task,
            question=question,
            options=options or ["确认", "取消"],
            session_id=session_id,
            metadata=metadata or {},
        )
        
        self._pending_requests[request_id] = request
        logger.info(f"Created confirmation request: {request_id}")
        return request_id
    
    def get_request(self, request_id: str) -> ConfirmationRequest | None:
        """Get a pending request by ID."""
        return self._pending_requests.get(request_id)
    
    async def submit_response(
        self,
        request_id: str,
        response: str,
        user_id: str | None = None,
    ) -> bool:
        """Submit a response to a confirmation request."""
        if request_id not in self._pending_requests:
            logger.warning(f"Unknown confirmation request: {request_id}")
            return False
        
        request = self._pending_requests.pop(request_id)
        
        if response in ["确认", "是", "yes", "ok", "allow"]:
            status = ConfirmationStatus.APPROVED
        else:
            status = ConfirmationStatus.DENIED
        
        confirmation_response = ConfirmationResponse(
            request_id=request_id,
            status=status,
            user_response=response,
            user_id=user_id,
        )
        
        self._responses[request_id] = confirmation_response
        
        if callback := self._callbacks.pop(request_id, None):
            await callback(confirmation_response)
        
        logger.info(f"Confirmation response submitted: {request_id} -> {status.value}")
        return True
    
    def register_callback(
        self,
        request_id: str,
        callback: Callable[[ConfirmationResponse], Awaitable[None]],
    ) -> None:
        """Register a callback for when a response is received."""
        self._callbacks[request_id] = callback
    
    def get_response(self, request_id: str) -> ConfirmationResponse | None:
        """Get a response by request ID."""
        return self._responses.get(request_id)
    
    def cancel_request(self, request_id: str) -> bool:
        """Cancel a pending request."""
        if request_id in self._pending_requests:
            self._pending_requests.pop(request_id)
            self._callbacks.pop(request_id, None)
            return True
        return False
    
    def list_pending(self) -> list[dict[str, Any]]:
        """List all pending confirmation requests."""
        return [
            {
                "request_id": rid,
                "task": req.task,
                "question": req.question,
                "options": req.options,
            }
            for rid, req in self._pending_requests.items()
        ]


async def ask_confirmation(
    request: ConfirmationRequest,
    bus: "MessageBus | None" = None,
    channel: str = "cli",
    chat_id: str = "confirmation",
) -> str:
    """Ask human for confirmation via message bus.
    
    Returns the user's response.
    """
    from clawbot.bus.events import OutboundMessage
    
    message = f"⚠️ 需要确认\n\n{request.question}\n\n选项: {' / '.join(request.options)}"
    
    if bus:
        await bus.publish_outbound(OutboundMessage(
            channel=channel,
            chat_id=chat_id,
            content=message,
            metadata={"confirmation_request": True, "options": request.options},
        ))
    
    return "pending"
