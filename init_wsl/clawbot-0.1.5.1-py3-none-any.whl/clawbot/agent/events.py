"""Event notification system for opencode integration."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any

from loguru import logger

if TYPE_CHECKING:
    from clawbot.bus.queue import MessageBus


class TaskEvent(Enum):
    INITIALIZING = "initializing"
    ANALYZING = "analyzing"
    CODING = "coding"
    TESTING = "testing"
    COMPLETED = "completed"
    FAILED = "failed"
    WAITING = "waiting"
    CONFIRMING = "confirming"


@dataclass
class TaskProgress:
    """Progress update for a task."""
    event: TaskEvent
    message: str
    task_id: str = ""
    details: dict = field(default_factory=dict)
    progress_percent: int | None = None


class EventNotifier:
    """Notify user about task progress."""
    
    EVENT_EMOJIS = {
        TaskEvent.INITIALIZING: "🔄",
        TaskEvent.ANALYZING: "🔍",
        TaskEvent.CODING: "💻",
        TaskEvent.TESTING: "🧪",
        TaskEvent.COMPLETED: "✅",
        TaskEvent.FAILED: "❌",
        TaskEvent.WAITING: "⏳",
        TaskEvent.CONFIRMING: "❓",
    }
    
    def __init__(self, bus: "MessageBus | None" = None, channel: str = "cli", chat_id: str = "opencode"):
        self._bus = bus
        self._channel = channel
        self._chat_id = chat_id
        self._history: list[TaskProgress] = []
    
    async def notify(self, progress: TaskProgress) -> None:
        """Send notification to user."""
        self._history.append(progress)
        
        message = self._format_message(progress)
        logger.info(f"[EventNotifier] {progress.event.value}: {progress.message}")
        
        if self._bus:
            from clawbot.bus.events import OutboundMessage
            await self._bus.publish_outbound(OutboundMessage(
                channel=self._channel,
                chat_id=self._chat_id,
                content=message,
                metadata={"task_event": progress.event.value, "task_id": progress.task_id},
            ))
    
    def _format_message(self, progress: TaskProgress) -> str:
        """Format progress message with emoji."""
        emoji = self.EVENT_EMOJIS.get(progress.event, "")
        base = f"{emoji} {progress.message}"
        
        if progress.progress_percent is not None:
            base += f" ({progress.progress_percent}%)"
        
        return base
    
    def set_context(self, channel: str, chat_id: str) -> None:
        """Set the channel and chat_id for notifications."""
        self._channel = channel
        self._chat_id = chat_id
    
    def get_history(self, task_id: str | None = None) -> list[TaskProgress]:
        """Get notification history, optionally filtered by task_id."""
        if task_id:
            return [p for p in self._history if p.task_id == task_id]
        return list(self._history)
    
    def clear_history(self) -> None:
        """Clear notification history."""
        self._history.clear()


class TaskEventEmitter:
    """Emit task events with progress tracking."""
    
    def __init__(self, notifier: EventNotifier | None = None):
        self._notifier = notifier or EventNotifier()
        self._current_task_id: str | None = None
    
    def start_task(self, task_id: str, message: str = "正在初始�?..") -> None:
        """Start a new task."""
        self._current_task_id = task_id
    
    async def emit(self, event: TaskEvent, message: str, **kwargs) -> None:
        """Emit a task event."""
        progress = TaskProgress(
            event=event,
            message=message,
            task_id=self._current_task_id or "",
            details=kwargs,
        )
        
        if self._notifier:
            await self._notifier.notify(progress)
    
    async def emit_initializing(self, message: str = "正在初始化项�?..") -> None:
        await self.emit(TaskEvent.INITIALIZING, message)
    
    async def emit_analyzing(self, message: str = "正在分析需求...") -> None:
        await self.emit(TaskEvent.ANALYZING, message)
    
    async def emit_coding(self, message: str = "正在编写代码...") -> None:
        await self.emit(TaskEvent.CODING, message)
    
    async def emit_testing(self, message: str = "正在测试验证...") -> None:
        await self.emit(TaskEvent.TESTING, message)
    
    async def emit_completed(self, message: str = "任务完成") -> None:
        await self.emit(TaskEvent.COMPLETED, message)
    
    async def emit_failed(self, message: str, error: str | None = None) -> None:
        details = {"error": error} if error else {}
        await self.emit(TaskEvent.FAILED, message, **details)
    
    async def emit_waiting(self, message: str = "等待响应...") -> None:
        await self.emit(TaskEvent.WAITING, message)
    
    async def emit_confirming(self, message: str = "等待用户确认...") -> None:
        await self.emit(TaskEvent.CONFIRMING, message)
