"""Decision engine for determining when to ask human confirmation."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from clawbot.agent.memory import MemoryStore

from clawbot.config.schema import TimeoutsConfig


@dataclass
class DecisionContext:
    """Context for decision making."""

    task: str
    is_high_risk: bool = False
    has_ambiguity: bool = False
    confidence: float = 1.0
    metadata: dict[str, Any] = field(default_factory=dict)
    timeouts: TimeoutsConfig = field(default_factory=TimeoutsConfig)


    
    def get_effective_timeout(self, operation: str) -> int:
        """Get timeout for a specific operation type."""
        timeout_map = {
            "llm_request": self.timeouts.llm_request,
            "tool_execution": self.timeouts.tool_execution,
            "mcp_connection": self.timeouts.mcp_connection,
        }
        return timeout_map.get(operation, 60)


class DecisionEngine:
    """Engine for deciding when to ask human confirmation."""
    
    HIGH_RISK_KEYWORDS = [
        "删除", "删除文件", "rm -rf", "drop table",
        "清空", "重置", "还原", "回滚", "delete",
        "remove", "truncate", "erase", "wipe",
    ]
    
    AMBIGUOUS_KEYWORDS = [
        "优化", "改进", "看看", "检查一下",
        "improve", "optimize", "refactor",
        "fix", "update", "change",
    ]
    
    SKIP_CONFIRMATION_KEYWORDS = [
        "读取", "查看", "显示", "列出",
        "read", "show", "list", "display",
        "explain", "help", "what", "how",
    ]
    
    def __init__(self, memory_store: "MemoryStore | None" = None):
        self._memory = memory_store
    
    async def should_confirm(self, context: DecisionContext) -> bool:
        """Determine if human confirmation is needed."""
        if self._should_skip_confirmation(context.task):
            return False
        
        if context.is_high_risk or self._is_high_risk(context.task):
            return True
        
        if context.has_ambiguity or self._is_ambiguous(context.task):
            return True
        
        if self._memory and not await self._has_similar_memory(context.task):
            return True
        
        if context.confidence < 0.7:
            return True
        
        return False
    
    def _should_skip_confirmation(self, task: str) -> bool:
        """Check if task should skip confirmation entirely."""
        task_lower = task.lower()
        return any(kw in task_lower for kw in self.SKIP_CONFIRMATION_KEYWORDS)
    
    def _is_high_risk(self, task: str) -> bool:
        """Check if task is high risk."""
        task_lower = task.lower()
        return any(kw in task_lower for kw in self.HIGH_RISK_KEYWORDS)
    
    def _is_ambiguous(self, task: str) -> bool:
        """Check if task is ambiguous."""
        return any(kw in task for kw in self.AMBIGUOUS_KEYWORDS)
    
    async def _has_similar_memory(self, task: str) -> bool:
        """Check if there's similar task in memory."""
        if not self._memory:
            return False
        return True
    
    def analyze_task(self, task: str) -> dict[str, Any]:
        """Analyze task and return detailed breakdown."""
        return {
            "task": task,
            "is_high_risk": self._is_high_risk(task),
            "is_ambiguous": self._is_ambiguous(task),
            "should_skip": self._should_skip_confirmation(task),
            "risk_level": self._calculate_risk_level(task),
            "suggested_action": self._suggest_action(task),
        }
    
    def _calculate_risk_level(self, task: str) -> str:
        """Calculate risk level: low, medium, high."""
        if self._is_high_risk(task):
            return "high"
        if self._is_ambiguous(task):
            return "medium"
        return "low"
    
    def _suggest_action(self, task: str) -> str:
        """Suggest action based on task analysis."""
        if self._should_skip_confirmation(task):
            return "auto_execute"
        if self._is_high_risk(task):
            return "require_confirmation"
        if self._is_ambiguous(task):
            return "clarify_first"
        return "auto_execute"
    
    def get_confirmation_message(self, context: DecisionContext) -> str:
        """Generate confirmation message for user."""
        if self._is_high_risk(context.task):
            return f"⚠️ 高风险操作需要确认：{context.task}\n\n此操作可能造成数据丢失或不可逆更改，是否继续？"
        if self._is_ambiguous(context.task):
            return f"❓ 任务描述不够明确：{context.task}\n\n请提供更多细节或确认是否按当前理解执行。"
        return f"📋 需要确认：{context.task}\n\n是否执行此操作？"
