"""
OpenWork Service Manager - OpenWork 服务管理器

职责：
1. 服务生命周期管理
2. 自动启动/重启
3. 健康检查
4. 状态监控
"""

from __future__ import annotations

import asyncio
import shutil
import subprocess
import time
import weakref
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

import aiohttp
from loguru import logger

from .base import ServiceHealth, ServiceStatus


@dataclass
class ServiceStats:
    """服务统计"""
    status: ServiceStatus
    uptime_seconds: float = 0.0
    total_requests: int = 0
    successful_requests: int = 0
    failed_requests: int = 0
    last_error: str | None = None
    restart_count: int = 0


class OpenWorkServiceManager:
    """
    OpenWork 服务管理器
    
    职责：
    1. 服务生命周期管理
    2. 自动启动/重启
    3. 健康检查
    4. 状态监控
    """
    
    DEFAULT_PORT = 7777
    DEFAULT_TIMEOUT = 30
    HEALTH_CHECK_INTERVAL = 10
    
    CLI_COMMANDS = [
        ("openwork-server", []),
        ("npx", ["openwork-server"]),
        ("bunx", ["openwork-server"]),
    ]
    
    def __init__(
        self,
        port: int = DEFAULT_PORT,
        workspace: Path | None = None,
        auto_start: bool = True,
        auto_restart: bool = True,
        fallback_to_local: bool = True,
        startup_timeout: int = DEFAULT_TIMEOUT,
    ):
        self.port = port
        self.workspace = workspace
        self.auto_start = auto_start
        self.auto_restart = auto_restart
        self.fallback_to_local = fallback_to_local
        self.startup_timeout = startup_timeout
        
        self._base_url = f"http://localhost:{port}"
        self._process: subprocess.Popen | None = None
        self._status = ServiceStatus.STOPPED
        self._health_check_task: asyncio.Task | None = None
        self._session: aiohttp.ClientSession | None = None
        self._started_at: datetime | None = None
        self._stats = ServiceStats(status=ServiceStatus.STOPPED)
        self._detected_command: tuple[str, list[str]] | None = None
        
        self._finalizer = weakref.finalize(self, self._cleanup_process, self)
    
    @property
    def status(self) -> ServiceStatus:
        """获取当前状态"""
        return self._status
    
    @property
    def base_url(self) -> str:
        """获取服务 URL"""
        return self._base_url
    
    @property
    def is_running(self) -> bool:
        """检查是否运行中"""
        return self._status == ServiceStatus.RUNNING
    
    def _detect_cli_command(self) -> tuple[str, list[str]] | None:
        """检测可用的 CLI 命令"""
        for cmd, args in self.CLI_COMMANDS:
            if shutil.which(cmd):
                logger.debug(f"Detected OpenWork CLI: {cmd}")
                return (cmd, args)
        return None
    
    def _build_start_command(self) -> list[str] | None:
        """构建启动命令"""
        if self._detected_command is None:
            self._detected_command = self._detect_cli_command()
        
        if self._detected_command is None:
            logger.error("No OpenWork CLI command found")
            return None
        
        cmd, base_args = self._detected_command
        args = base_args.copy()
        args.extend(["--port", str(self.port)])
        
        if self.workspace:
            args.extend(["--workspace", str(self.workspace)])
        
        return [cmd] + args
    
    async def start(self) -> bool:
        """启动 OpenWork 服务"""
        if self._status == ServiceStatus.RUNNING:
            health = await self.health_check()
            if health.healthy:
                return True
        
        if not self._is_installed():
            logger.warning("OpenWork not installed, execution capability limited")
            self._status = ServiceStatus.NOT_INSTALLED
            self._stats.status = ServiceStatus.NOT_INSTALLED
            return False
        
        logger.info(f"Starting OpenWork service at {self._base_url}")
        self._status = ServiceStatus.STARTING
        self._stats.status = ServiceStatus.STARTING
        
        try:
            cmd_args = self._build_start_command()
            if cmd_args is None:
                self._status = ServiceStatus.NOT_INSTALLED
                self._stats.status = ServiceStatus.NOT_INSTALLED
                return False
            
            logger.debug(f"Starting OpenWork with command: {' '.join(cmd_args)}")
            
            self._process = subprocess.Popen(
                cmd_args,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
            )
            
            ready = await self._wait_for_ready()
            
            if ready:
                self._status = ServiceStatus.RUNNING
                self._stats.status = ServiceStatus.RUNNING
                self._started_at = datetime.now()
                self._start_health_monitor()
                logger.info(f"OpenWork service started successfully at {self._base_url}")
                return True
            else:
                self._status = ServiceStatus.ERROR
                self._stats.status = ServiceStatus.ERROR
                self._stats.last_error = "Service failed to start within timeout"
                logger.error("OpenWork service failed to start within timeout")
                return False
                
        except Exception as e:
            logger.error(f"Failed to start OpenWork service: {e}")
            self._status = ServiceStatus.ERROR
            self._stats.status = ServiceStatus.ERROR
            self._stats.last_error = str(e)
            return False
    
    async def stop(self) -> None:
        """停止服务"""
        if self._status == ServiceStatus.STOPPED:
            return
        
        logger.info("Stopping OpenWork service...")
        self._status = ServiceStatus.STOPPING
        self._stats.status = ServiceStatus.STOPPING
        
        if self._health_check_task:
            self._health_check_task.cancel()
            try:
                await self._health_check_task
            except asyncio.CancelledError:
                pass
            self._health_check_task = None
        
        if self._process:
            self._process.terminate()
            try:
                self._process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self._process.kill()
                self._process.wait()
            self._process = None
        
        if self._session:
            await self._session.close()
            self._session = None
        
        self._status = ServiceStatus.STOPPED
        self._stats.status = ServiceStatus.STOPPED
        self._started_at = None
        logger.info("OpenWork service stopped")
    
    async def restart(self) -> bool:
        """重启服务"""
        await self.stop()
        self._stats.restart_count += 1
        return await self.start()
    
    async def health_check(self) -> ServiceHealth:
        """健康检查"""
        start_time = time.monotonic()
        
        try:
            async with self._get_session() as session:
                async with session.get(
                    f"{self._base_url}/health",
                    timeout=aiohttp.ClientTimeout(total=5),
                ) as resp:
                    latency = (time.monotonic() - start_time) * 1000
                    healthy = resp.status == 200
                    
                    return ServiceHealth(
                        healthy=healthy,
                        status=ServiceStatus.RUNNING if healthy else ServiceStatus.ERROR,
                        latency_ms=latency,
                        last_check=datetime.now(),
                    )
        except Exception as e:
            return ServiceHealth(
                healthy=False,
                status=ServiceStatus.ERROR,
                latency_ms=(time.monotonic() - start_time) * 1000,
                last_check=datetime.now(),
                error_message=str(e),
            )
    
    async def is_healthy(self) -> bool:
        """检查是否健康"""
        health = await self.health_check()
        return health.healthy
    
    async def ensure_running(self) -> bool:
        """确保服务运行"""
        if self._status == ServiceStatus.RUNNING:
            if await self.is_healthy():
                return True
        
        if self.auto_start:
            return await self.start()
        
        return False
    
    async def execute(
        self,
        task: str,
        task_type: str | None = None,
        workspace: Path | None = None,
        timeout: int = 300,
    ) -> dict[str, Any]:
        """
        执行任务
        
        Args:
            task: 任务描述
            task_type: 任务类型
            workspace: 工作目录
            timeout: 超时时间
            
        Returns:
            执行结果
        """
        if not await self.ensure_running():
            return {
                "success": False,
                "error": "OpenWork service not available",
                "output": None,
            }
        
        self._stats.total_requests += 1
        
        try:
            url = f"{self._base_url}/opencode/agents/default/messages"
            payload = {
                "content": task,
                "context": {
                    "task_type": task_type,
                    "workspace": str(workspace) if workspace else None,
                },
            }
            
            async with self._get_session() as session:
                async with session.post(
                    url,
                    json=payload,
                    timeout=aiohttp.ClientTimeout(total=timeout),
                ) as resp:
                    if resp.status == 200:
                        result = await resp.json()
                        self._stats.successful_requests += 1
                        return {
                            "success": True,
                            "output": result.get("content", ""),
                            "data": result,
                        }
                    else:
                        error_text = await resp.text()
                        self._stats.failed_requests += 1
                        self._stats.last_error = error_text
                        return {
                            "success": False,
                            "error": f"HTTP {resp.status}: {error_text}",
                            "output": None,
                        }
                        
        except asyncio.TimeoutError:
            self._stats.failed_requests += 1
            self._stats.last_error = "Request timeout"
            return {
                "success": False,
                "error": "Request timeout",
                "output": None,
            }
        except Exception as e:
            self._stats.failed_requests += 1
            self._stats.last_error = str(e)
            return {
                "success": False,
                "error": str(e),
                "output": None,
            }
    
    def get_stats(self) -> ServiceStats:
        """获取服务统计"""
        if self._started_at and self._status == ServiceStatus.RUNNING:
            self._stats.uptime_seconds = (datetime.now() - self._started_at).total_seconds()
        return self._stats
    
    def get_status_info(self) -> dict[str, Any]:
        """获取状态信息"""
        return {
            "status": self._status.value,
            "base_url": self._base_url,
            "port": self.port,
            "workspace": str(self.workspace) if self.workspace else None,
            "auto_start": self.auto_start,
            "auto_restart": self.auto_restart,
            "is_installed": self._is_installed(),
            "uptime_seconds": self._stats.uptime_seconds,
            "restart_count": self._stats.restart_count,
            "detected_command": self._detected_command,
        }
    
    def _is_installed(self) -> bool:
        """检查 OpenWork 是否已安装"""
        return self._detect_cli_command() is not None
    
    async def _wait_for_ready(self, timeout: int | None = None) -> bool:
        """等待服务就绪"""
        timeout = timeout or self.startup_timeout
        
        for _ in range(timeout * 2):
            await asyncio.sleep(0.5)
            try:
                async with self._get_session() as session:
                    async with session.get(
                        f"{self._base_url}/health",
                        timeout=aiohttp.ClientTimeout(total=2),
                    ) as resp:
                        if resp.status == 200:
                            return True
            except Exception:
                pass
        
        return False
    
    def _get_session(self) -> aiohttp.ClientSession:
        """获取或创建 HTTP session"""
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession()
        return self._session
    
    def _start_health_monitor(self):
        """启动健康监控"""
        async def monitor():
            consecutive_failures = 0
            max_failures = 3
            
            while self._status == ServiceStatus.RUNNING:
                await asyncio.sleep(self.HEALTH_CHECK_INTERVAL)
                
                health = await self.health_check()
                if not health.healthy:
                    consecutive_failures += 1
                    logger.warning(
                        f"OpenWork service unhealthy (attempt {consecutive_failures}/{max_failures}): "
                        f"{health.error_message}"
                    )
                    
                    if consecutive_failures >= max_failures and self.auto_restart:
                        logger.info("Attempting to restart OpenWork service...")
                        await self.restart()
                        consecutive_failures = 0
                else:
                    consecutive_failures = 0
        
        self._health_check_task = asyncio.create_task(monitor())
    
    @staticmethod
    def _cleanup_process(self_ref: "OpenWorkServiceManager") -> None:
        """清理进程"""
        process = self_ref._process
        if process is not None:
            try:
                process.terminate()
                process.wait(timeout=5)
            except (subprocess.TimeoutExpired, Exception):
                try:
                    process.kill()
                    process.wait()
                except Exception:
                    pass


async def check_openwork_available(port: int = 7777) -> bool:
    """检查 OpenWork 服务是否可用"""
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                f"http://localhost:{port}/health",
                timeout=aiohttp.ClientTimeout(total=5),
            ) as resp:
                return resp.status == 200
    except Exception:
        return False
