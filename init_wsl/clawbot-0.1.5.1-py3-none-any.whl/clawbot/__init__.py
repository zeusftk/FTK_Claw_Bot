"""
clawbot - A lightweight AI agent framework
"""

__version__ = "0.1.5.1"
__logo__ = "🦐"
