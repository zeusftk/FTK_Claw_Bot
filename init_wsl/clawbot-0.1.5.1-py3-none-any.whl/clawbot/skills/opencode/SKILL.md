---
name: opencode
description: "使用 OpenWork Server 执行代码开发任务。支持代码生成、bug修复、设计规划、测试驱动开发等。当用户需要写代码、修复bug、设计方案、编写测试时触发此技能。"
metadata: {"clawbot":{"emoji":"🤖","os":["darwin","linux","windows"],"requires":{"bins":["openwork"]},"version":"3.0.0","features":["代码执行（通过 OpenWork Server）","后台任务管理","任务路由"]}}
---

# Opencode 技能 v3.0

## 概述

Opencode 技能通过 OpenWork Server 执行编程任务，提供：

1. **代码执行** - 代码生成、bug修复、重构等
2. **后台任务** - 长时间运行的任务管理
3. **任务路由** - 智能选择执行模式

## 前置条件

确保 OpenWork Server 正在运行：

```bash
openwork start --port 7777
```

或在配置中启用自动启动：

```json
{
  "tools": {
    "openwork": {
      "enabled": true,
      "orchestrator_port": 7777,
      "auto_start": true
    }
  }
}
```

## 使用方式

### 方式一：通过 Agent 自然语言

```
用户: 帮我写一个 Python 的 hello world 程序
```

Agent 会自动调用 opencode 技能执行任务。

### 方式二：直接使用服务

```python
from clawbot.services import OpenWorkService

service = OpenWorkService(base_url="http://localhost:7777")

if await service.ensure():
    result = await service.execute_code("Generate hello world in Python")
    print(result)
```

### 方式三：使用 UnattendedProgrammingService

```python
from clawbot.services import OpenWorkService, UnattendedProgrammingService
from pathlib import Path

openwork = OpenWorkService()
service = UnattendedProgrammingService(
    openwork=openwork,
    workspace=Path("/path/to/workspace"),
    enable_evolution=True,
)

await service.start()
result = await service.execute("开发一个用户登录系统")
print(result.output)
```

## 执行模式

| 模式 | 说明 | 超时 |
|------|------|------|
| direct | 直接执行，适合快速任务 | 30-60秒 |
| background | 后台执行，适合长时间任务 | 5-30分钟 |

## 任务类型

| 类型 | 关键词 | 执行模式 |
|------|--------|----------|
| fix | fix, bug, 修复 | direct |
| coding | write, create, 编写 | direct |
| explain | explain, 解释 | direct |
| design | design, plan, 设计 | background |
| refactor | refactor, 重构 | background |
| testing | test, 测试 | background |

## OpenWork Server API

OpenWork Server 提供完整 API

### 代码执行
- `POST /opencode/agents/default/messages` - 执行代码任务

### 技能管理
- `GET /workspace/:id/skills` - 列出技能
- `POST /workspace/:id/skills` - 创建技能
- `POST /workspace/:id/skills/hub/:name` - 从 Hub 安装技能

### 插件管理
- `GET /workspace/:id/plugins` - 列出插件
- `POST /workspace/:id/plugins` - 安装插件

### MCP 管理
- `GET /workspace/:id/mcp` - 列出 MCP 服务
- `POST /workspace/:id/mcp` - 添加 MCP

### 自动化
- `GET /workspace/:id/agentlab/automations` - 列出自动化任务
- `POST /workspace/:id/agentlab/automations/:id/run` - 运行自动化

### 文件交换
- `POST /workspace/:id/inbox` - 上传文件
- `GET /workspace/:id/artifacts` - 列出 Artifacts

### 审批管理
- `GET /approvals` - 列出待审批
- `POST /approvals/:id` - 响应审批

## 配置

### 环境变量

```bash
clawbot_OPENWORK_URL=http://localhost:7777
clawbot_OPENWORK_ENABLED=true
```

### 配置文件

`~/.clawbot/config.json`:

```json
{
  "tools": {
    "openwork": {
      "enabled": true,
      "orchestrator_url": "http://localhost:7777",
      "orchestrator_port": 7777,
      "auto_start": true
    }
  }
}
```

## 记忆与自我进化

UnattendedProgrammingService 提供记忆和自我进化能力：

- **决策记录**: 记录每次决策的完整信息
- **成功案例**: 归档高质量成功案例
- **模式提取**: 从历史数据中提取决策模式
- **自我进化**: 持续优化决策能力

```python
# 触发自我进化
result = await service.trigger_evolution()
print(result)

# 更新用户评分
await service.update_rating(record_id, user_rating=5)
```

## 更新日志

### v3.0.0 (2026-02-26)
- 重构：使用 OpenWork Server 作为唯一后端
- 移除：复杂的无人值守流程（由 OpenWork 处理）
- 新增：标准化服务接口 BaseExternalService
- 新增：UnattendedProgrammingService 整合记忆与进化
- 新增：完整的 OpenWork API 封装

### v2.0.0
- 无人值守自助编程功能

### v1.0.0
- 基础 opencode 集成功能
