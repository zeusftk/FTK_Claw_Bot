"""
Opencode skill for clawbot - Execute tasks using OpenWork Server

Simplified version - All complex logic handled by OpenWork Server
"""

from .background_manager import BackgroundTaskManager
from .opencode_skill import OpencodeSkill
from .task_router import TaskRouter

__all__ = [
    "OpencodeSkill",
    "TaskRouter",
    "BackgroundTaskManager",
]

__version__ = "3.0.0"

__features__ = [
    "Code execution (via OpenWork Server)",
    "Background task management",
    "Task routing",
]


def get_skill_info() -> dict:
    """Get skill information"""
    return {
        "name": "opencode",
        "version": __version__,
        "features": __features__,
        "description": "Code execution skill - Execute programming tasks via OpenWork Server",
    }
