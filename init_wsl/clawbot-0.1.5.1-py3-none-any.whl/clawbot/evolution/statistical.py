"""
StatisticalEvolver - 统计驱动进化器

基于历史数据的统计分析，快速调整决策参数。
"""

from __future__ import annotations

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

from clawbot.evolution.types import (
    ImmediateAction,
    StatisticalResult,
)

if TYPE_CHECKING:
    from clawbot.openwork.memory import OpenWorkMemoryBridge
    from clawbot.openwork.feedback_collector import FeedbackCollector

logger = logging.getLogger(__name__)


class StatisticalEvolver:
    """
    统计驱动进化器
    
    功能：
    1. 阈值调整 - 基于成功率的动态调整
    2. 规则生成 - 自动生成新的自动审批规则
    3. 能力扩展 - 将操作从 require_human 提升到 auto_safe
    4. 即时响应 - 低评分立即降级
    """
    
    DEFAULT_THRESHOLDS = {
        "auto_resolve": 0.7,
        "require_human": 0.3,
    }
    
    DEFAULT_AUTO_SAFE = frozenset([
        "file_read", "file_create", "file_modify",
        "command_safe", "http_request",
        "directory_create", "git_status", "git_log",
    ])
    
    DEFAULT_REQUIRE_HUMAN = frozenset([
        "file_delete", "directory_delete", "command_dangerous",
        "database_drop", "database_truncate",
        "external_service_config", "credential_access",
    ])
    
    def __init__(
        self,
        memory: "OpenWorkMemoryBridge",
        feedback_processor: "FeedbackCollector | None" = None,
        config_path: Path | None = None,
    ):
        self.memory = memory
        self.feedback_processor = feedback_processor
        self.config_path = config_path or memory.workspace / "evolution_config.json"
        
        self.thresholds = dict(self.DEFAULT_THRESHOLDS)
        self.auto_safe_operations = set(self.DEFAULT_AUTO_SAFE)
        self.require_human_operations = set(self.DEFAULT_REQUIRE_HUMAN)
        
        self._min_samples_for_expansion = 5
        self._min_success_rate_for_expansion = 0.85
        self._adjustment_factor = 0.05
        
        self._load_config()
    
    def _load_config(self) -> None:
        """加载配置"""
        if self.config_path.exists():
            try:
                with open(self.config_path, encoding="utf-8") as f:
                    config = json.load(f)
                
                self.thresholds = config.get("thresholds", self.thresholds)
                self.auto_safe_operations = set(config.get("auto_safe_operations", []))
                self.require_human_operations = set(config.get("require_human_operations", []))
                
                logger.info("Loaded evolution configuration")
            except Exception as e:
                logger.error(f"Failed to load config: {e}")
    
    def _save_config(self) -> None:
        """保存配置"""
        config = {
            "thresholds": self.thresholds,
            "auto_safe_operations": list(self.auto_safe_operations),
            "require_human_operations": list(self.require_human_operations),
            "last_updated": datetime.now().isoformat(),
        }
        
        try:
            with open(self.config_path, "w", encoding="utf-8") as f:
                json.dump(config, f, ensure_ascii=False, indent=2)
            logger.info("Saved evolution configuration")
        except Exception as e:
            logger.error(f"Failed to save config: {e}")
    
    async def analyze(self) -> StatisticalResult:
        """执行统计分析"""
        logger.info("Starting statistical analysis...")
        
        patterns = await self._extract_patterns()
        
        adjustments = await self._adjust_thresholds(patterns)
        
        new_rules = await self._generate_rules(patterns)
        
        expansions = await self._expand_capabilities(patterns)
        
        self._save_config()
        
        result = StatisticalResult(
            patterns=patterns,
            adjustments=adjustments,
            new_rules=new_rules,
            expansions=expansions,
        )
        
        logger.info(
            f"Statistical analysis complete: "
            f"{len(patterns)} patterns, "
            f"{len(new_rules)} new rules, "
            f"{len(expansions)} expansions"
        )
        
        return result
    
    async def process_immediate(self, feedback: Any) -> ImmediateAction:
        """即时处理反馈"""
        actions = []
        rating = getattr(feedback, 'rating', 0)
        operations = getattr(feedback, 'operations', [])
        
        if rating <= 1:
            for op in operations:
                if op in self.auto_safe_operations:
                    self.auto_safe_operations.discard(op)
                    self.require_human_operations.add(op)
                    actions.append({
                        "type": "downgrade",
                        "operation": op,
                        "reason": "低评分立即降级",
                        "rating": rating,
                    })
                    logger.warning(f"Downgraded {op} due to low rating: {rating}")
        
        elif rating >= 5:
            for op in operations:
                if op in self.require_human_operations:
                    actions.append({
                        "type": "upgrade_candidate",
                        "operation": op,
                        "reason": "高评分标记升级候选",
                        "rating": rating,
                    })
                    logger.info(f"Marked {op} as upgrade candidate due to high rating: {rating}")
        
        if actions:
            self._save_config()
        
        return ImmediateAction(actions=actions)
    
    async def _extract_patterns(self) -> list[dict]:
        """提取决策模式"""
        patterns = []
        
        try:
            decisions = await self.memory.get_all_decisions()
            
            operation_stats: dict[str, dict] = {}
            
            for decision in decisions:
                event_type = decision.get("event_type", "unknown")
                success = decision.get("success", False)
                
                if event_type not in operation_stats:
                    operation_stats[event_type] = {
                        "total": 0,
                        "success": 0,
                        "ratings": [],
                    }
                
                operation_stats[event_type]["total"] += 1
                if success:
                    operation_stats[event_type]["success"] += 1
                
                rating = decision.get("user_rating")
                if rating:
                    operation_stats[event_type]["ratings"].append(rating)
            
            for op_type, stats in operation_stats.items():
                if stats["total"] >= 3:
                    success_rate = stats["success"] / stats["total"]
                    avg_rating = (
                        sum(stats["ratings"]) / len(stats["ratings"])
                        if stats["ratings"] else 0
                    )
                    
                    patterns.append({
                        "pattern_type": "operation_type",
                        "operation_type": op_type,
                        "sample_count": stats["total"],
                        "success_rate": success_rate,
                        "avg_rating": avg_rating,
                        "confidence": min(1.0, stats["total"] / 10),
                    })
        
        except Exception as e:
            logger.error(f"Failed to extract patterns: {e}")
        
        return patterns
    
    async def _adjust_thresholds(self, patterns: list[dict]) -> dict:
        """调整阈值"""
        adjustments = {"thresholds": {}}
        
        high_confidence_patterns = [
            p for p in patterns
            if p.get("confidence", 0) > 0.9 and p.get("sample_count", 0) > 10
        ]
        
        if high_confidence_patterns:
            avg_success_rate = sum(
                p.get("success_rate", 0) for p in high_confidence_patterns
            ) / len(high_confidence_patterns)
            
            if avg_success_rate > 0.85:
                old_threshold = self.thresholds.get("auto_resolve", 0.7)
                new_threshold = max(0.5, old_threshold - self._adjustment_factor)
                self.thresholds["auto_resolve"] = new_threshold
                
                adjustments["thresholds"]["auto_resolve"] = {
                    "old": old_threshold,
                    "new": new_threshold,
                    "reason": f"基于 {len(high_confidence_patterns)} 个高置信度模式",
                }
                
                logger.info(
                    f"Adjusted auto_resolve threshold: {old_threshold} -> {new_threshold}"
                )
        
        return adjustments
    
    async def _generate_rules(self, patterns: list[dict]) -> list[dict]:
        """生成新的自动审批规则"""
        new_rules = []
        
        for pattern in patterns:
            if pattern.get("pattern_type") != "operation_type":
                continue
            
            op_type = pattern.get("operation_type")
            success_rate = pattern.get("success_rate", 0)
            sample_count = pattern.get("sample_count", 0)
            confidence = pattern.get("confidence", 0)
            
            if (
                op_type
                and op_type not in self.auto_safe_operations
                and op_type not in self.require_human_operations
                and success_rate > self._min_success_rate_for_expansion
                and sample_count >= self._min_samples_for_expansion
            ):
                self.auto_safe_operations.add(op_type)
                new_rules.append({
                    "operation": op_type,
                    "level": "auto_safe",
                    "confidence": confidence,
                    "samples": sample_count,
                    "success_rate": success_rate,
                })
                logger.info(f"Added new auto-safe rule: {op_type}")
        
        return new_rules
    
    async def _expand_capabilities(self, patterns: list[dict]) -> list[dict]:
        """扩展自动化能力"""
        expansions = []
        
        for pattern in patterns:
            if pattern.get("pattern_type") != "operation_type":
                continue
            
            op_type = pattern.get("operation_type")
            if not op_type:
                continue
            
            success_rate = pattern.get("success_rate", 0)
            sample_count = pattern.get("sample_count", 0)
            
            if op_type in self.require_human_operations:
                if (
                    success_rate >= self._min_success_rate_for_expansion
                    and sample_count >= self._min_samples_for_expansion * 2
                ):
                    self.require_human_operations.discard(op_type)
                    self.auto_safe_operations.add(op_type)
                    
                    expansions.append({
                        "operation_type": op_type,
                        "previous_level": "require_human",
                        "new_level": "auto_safe",
                        "evidence_count": sample_count,
                        "success_rate": success_rate,
                        "reason": f"基于 {sample_count} 次成功案例",
                    })
                    logger.info(f"Expanded capability: {op_type} -> auto_safe")
            
            elif op_type not in self.auto_safe_operations:
                if (
                    success_rate >= self._min_success_rate_for_expansion
                    and sample_count >= self._min_samples_for_expansion
                ):
                    self.auto_safe_operations.add(op_type)
                    
                    expansions.append({
                        "operation_type": op_type,
                        "previous_level": "auto_resolve",
                        "new_level": "auto_safe",
                        "evidence_count": sample_count,
                        "success_rate": success_rate,
                        "reason": f"基于 {sample_count} 次成功案例",
                    })
                    logger.info(f"Expanded capability: {op_type} -> auto_safe")
        
        return expansions
    
    def get_decision_level(self, operation_type: str) -> str:
        """获取操作的决策级别"""
        if operation_type in self.auto_safe_operations:
            return "auto_safe"
        if operation_type in self.require_human_operations:
            return "require_human"
        return "auto_resolve"
    
    def get_stats(self) -> dict:
        """获取统计信息"""
        return {
            "thresholds": self.thresholds,
            "auto_safe_operations_count": len(self.auto_safe_operations),
            "require_human_operations_count": len(self.require_human_operations),
            "config_path": str(self.config_path),
        }
