"""
Memory Manager - 增强版记忆管理器

新增功能：
1. 智能检索 - 基于语义的相似案例检索
2. 上下文关联 - 项目上下文自动关联
3. 记忆压缩 - 自动压缩历史记忆
4. 记忆遗忘 - 低价值记忆自动清理
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import TYPE_CHECKING

from clawbot.openwork.memory import (
    OpenWorkMemoryBridge,
    ProjectContext,
)

if TYPE_CHECKING:
    from clawbot.memory.hybrid_manager import HybridMemoryManager

logger = logging.getLogger(__name__)


@dataclass
class SimilarDecision:
    """相似决策结果"""
    record_id: str
    event_type: str
    decision_level: str
    success: bool | None
    content: str
    score: float
    relevance: float = 0.0
    context_match: float = 0.0


@dataclass
class MemoryStats:
    """记忆统计"""
    total_decisions: int
    total_cases: int
    total_snippets: int
    total_errors: int
    storage_size_bytes: int
    oldest_record: datetime | None
    newest_record: datetime | None
    avg_relevance_score: float = 0.0


@dataclass
class CompressionResult:
    """压缩结果"""
    compressed_count: int
    freed_bytes: int
    compression_ratio: float


class MemoryManager:
    """
    记忆管理器（增强版）

    新增功能：
    1. 智能检索 - 基于语义的相似案例检索
    2. 上下文关联 - 项目上下文自动关联
    3. 记忆压缩 - 自动压缩历史记忆
    4. 记忆遗忘 - 低价值记忆自动清理
    """

    VALUE_THRESHOLD = 0.3
    COMPRESSION_AGE_DAYS = 30
    MAX_MEMORY_AGE_DAYS = 365

    def __init__(
        self,
        workspace: Path,
        hybrid_manager: "HybridMemoryManager | None" = None,
    ):
        self.workspace = workspace
        self.hybrid_manager = hybrid_manager

        self.bridge = OpenWorkMemoryBridge(
            workspace=workspace,
            hybrid_manager=hybrid_manager,
        )

        self._ensure_workspace()

    def _ensure_workspace(self) -> None:
        """确保工作目录存在"""
        self.workspace.mkdir(parents=True, exist_ok=True)

    async def start(self) -> None:
        """启动记忆管理器"""
        logger.info("MemoryManager started")

    async def search_similar_decisions(
        self,
        query: str,
        context: dict | None = None,
        limit: int = 5,
    ) -> list[SimilarDecision]:
        """
        智能检索相似决策

        Args:
            query: 查询字符串
            context: 上下文信息
            limit: 返回数量限制

        Returns:
            相似决策列表
        """
        results = await self.bridge.search_similar_decisions(query, limit * 2)

        similar_decisions = []
        for r in results:
            context_match = 0.0
            if context:
                context_match = self._calculate_context_match(r, context)

            relevance = r.get("score", 0.5) * 0.7 + context_match * 0.3

            similar_decisions.append(SimilarDecision(
                record_id=r.get("record_id", ""),
                event_type=r.get("event_type", ""),
                decision_level=r.get("decision_level", ""),
                success=r.get("success"),
                content=r.get("content", ""),
                score=r.get("score", 0.5),
                relevance=relevance,
                context_match=context_match,
            ))

        similar_decisions.sort(key=lambda x: x.relevance, reverse=True)

        return similar_decisions[:limit]

    def _calculate_context_match(
        self,
        record: dict,
        context: dict,
    ) -> float:
        """计算上下文匹配度"""
        score = 0.0
        total_weight = 0.0

        if "project_type" in context:
            total_weight += 1.0
            record_details = record.get("event_details", {})
            if context["project_type"] in str(record_details):
                score += 1.0

        if "technologies" in context:
            total_weight += 1.0
            record_str = str(record).lower()
            matches = sum(
                1 for tech in context["technologies"]
                if tech.lower() in record_str
            )
            if context["technologies"]:
                score += matches / len(context["technologies"])

        if "operation_type" in context:
            total_weight += 1.0
            if record.get("event_type") == context["operation_type"]:
                score += 1.0

        return score / total_weight if total_weight > 0 else 0.0

    async def store_with_context(
        self,
        content: str,
        metadata: dict,
        project_context: ProjectContext | None = None,
    ) -> str:
        """
        带上下文存储

        Args:
            content: 内容
            metadata: 元数据
            project_context: 项目上下文

        Returns:
            记录 ID
        """
        if project_context:
            metadata["project_id"] = project_context.project_id
            metadata["technologies"] = project_context.technologies
            metadata["project_name"] = project_context.name

        record_id = await self.bridge.record_decision({
            "project_id": metadata.get("project_id", ""),
            "event_type": metadata.get("event_type", "unknown"),
            "event_details": {
                "content": content[:500],
                **metadata,
            },
            "decision_level": metadata.get("decision_level", "auto_resolve"),
            "decision_answer": metadata.get("decision_answer"),
            "was_auto_resolved": metadata.get("was_auto_resolved", True),
        })

        return record_id

    async def compress_memories(
        self,
        older_than_days: int = 30,
    ) -> CompressionResult:
        """
        压缩历史记忆

        Args:
            older_than_days: 压缩多少天前的记忆

        Returns:
            压缩结果
        """
        cutoff_date = datetime.now() - timedelta(days=older_than_days)

        decisions = await self.bridge.get_all_decisions()

        to_compress = []
        to_keep = []

        for decision in decisions:
            try:
                timestamp_str = decision.get("timestamp", "")
                if timestamp_str:
                    timestamp = datetime.fromisoformat(timestamp_str)
                    if timestamp < cutoff_date:
                        to_compress.append(decision)
                        continue
                to_keep.append(decision)
            except Exception:
                to_keep.append(decision)

        compressed_count = len(to_compress)

        if to_compress:
            archive_file = self.workspace / "memory" / "archived_decisions.jsonl"
            archive_file.parent.mkdir(parents=True, exist_ok=True)

            with open(archive_file, "a", encoding="utf-8") as f:
                for decision in to_compress:
                    f.write(json.dumps(decision, ensure_ascii=False) + "\n")

        original_size = len(json.dumps(decisions, ensure_ascii=False))
        compressed_size = len(json.dumps(to_keep, ensure_ascii=False))
        freed_bytes = original_size - compressed_size

        compression_ratio = freed_bytes / original_size if original_size > 0 else 0

        logger.info(
            f"Compressed {compressed_count} memories, "
            f"freed {freed_bytes} bytes ({compression_ratio:.1%})"
        )

        return CompressionResult(
            compressed_count=compressed_count,
            freed_bytes=freed_bytes,
            compression_ratio=compression_ratio,
        )

    async def forget_low_value(
        self,
        threshold: float = 0.3,
    ) -> int:
        """
        遗忘低价值记忆
        
        Args:
            threshold: 价值阈值
            
        Returns:
            遗忘的记忆数量
        """
        decisions = await self.bridge.get_all_decisions()

        to_forget = []
        to_keep = []

        for decision in decisions:
            value = self._calculate_memory_value(decision)

            if value < threshold:
                to_forget.append(decision)
            else:
                to_keep.append(decision)

        forgotten_count = len(to_forget)

        if to_forget:
            decisions_file = self.bridge.decisions_file
            with open(decisions_file, "w", encoding="utf-8") as f:
                for decision in to_keep:
                    f.write(json.dumps(decision, ensure_ascii=False) + "\n")

        logger.info(f"Forgot {forgotten_count} low-value memories")

        return forgotten_count

    def _calculate_memory_value(self, decision: dict) -> float:
        """计算记忆价值"""
        value = 0.5

        if decision.get("success"):
            value += 0.2
        else:
            value -= 0.1

        rating = decision.get("user_rating")
        if rating:
            if rating >= 4:
                value += 0.2
            elif rating <= 2:
                value -= 0.2

        if decision.get("lessons_learned"):
            value += 0.1

        event_type = decision.get("event_type", "")
        if event_type in ["file_delete", "credential_access", "database_drop"]:
            value += 0.1

        return max(0.0, min(1.0, value))

    async def get_stats(self) -> MemoryStats:
        """获取记忆统计"""
        decisions = await self.bridge.get_all_decisions()
        cases = await self.bridge.get_success_cases(limit=1000)

        storage_size = 0
        for file_path in [
            self.bridge.decisions_file,
            self.bridge.cases_file,
            self.bridge.projects_file,
            self.bridge.snippets_file,
            self.bridge.errors_file,
        ]:
            if file_path.exists():
                storage_size += file_path.stat().st_size

        oldest = None
        newest = None
        for d in decisions:
            try:
                ts = datetime.fromisoformat(d.get("timestamp", ""))
                if oldest is None or ts < oldest:
                    oldest = ts
                if newest is None or ts > newest:
                    newest = ts
            except Exception:
                pass

        return MemoryStats(
            total_decisions=len(decisions),
            total_cases=len(cases),
            total_snippets=0,
            total_errors=0,
            storage_size_bytes=storage_size,
            oldest_record=oldest,
            newest_record=newest,
        )

    async def record_decision(self, data: dict) -> str:
        """记录决策"""
        return await self.bridge.record_decision(data)

    async def archive_success_case(
        self,
        idea: str,
        result: dict,
        quality_score: float,
        decisions: list[dict] | None = None,
    ) -> str:
        """归档成功案例"""
        return await self.bridge.archive_success_case(
            idea=idea,
            result=result,
            quality_score=quality_score,
            decisions=decisions,
        )

    async def get_all_decisions(self) -> list[dict]:
        """获取所有决策"""
        return await self.bridge.get_all_decisions()

    async def get_success_cases(self, limit: int = 10) -> list[dict]:
        """获取成功案例"""
        return await self.bridge.get_success_cases(limit=limit)

    async def get_error_patterns(
        self,
        error_type: str | None = None,
        limit: int = 10,
    ) -> list[dict]:
        """获取错误模式"""
        return await self.bridge.get_error_patterns(error_type=error_type, limit=limit)
