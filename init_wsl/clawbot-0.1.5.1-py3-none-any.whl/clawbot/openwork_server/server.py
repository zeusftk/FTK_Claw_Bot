"""
OpenWork Server HTTP 服务器模块

提供 HTTP API 服务器功能。"""

import json
import re
import time
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional, Tuple

from .approvals import ApprovalService
from .config import ServerConfig
from .errors import ApiError, format_error
from .events import ReloadEventStore
from .tokens import TokenService
from .types import Actor, TokenScope
from .utils import hash_token

SERVER_VERSION = "0.1.0"


@dataclass
class Route:
    """路由定义"""
    method: str
    pattern: str
    regex: re.Pattern
    param_names: List[str]
    auth: str
    handler: Callable


@dataclass
class RequestContext:
    """请求上下文"""
    request: Any
    path: str
    params: Dict[str, str]
    config: ServerConfig
    approvals: ApprovalService
    reload_events: ReloadEventStore
    tokens: TokenService
    actor: Optional[Actor] = None


class HTTPServer:
    """HTTP 服务器"""

    def __init__(self, config: ServerConfig):
        """
        初始化服务器

        Args:
            config: 服务器配置
        """
        self.config = config
        self.approvals = ApprovalService(config.approval)
        self.reload_events = ReloadEventStore()
        self.tokens = TokenService(config)
        self.routes: List[Route] = []
        self._started_at = int(time.time() * 1000)

        self._setup_routes()

    def _setup_routes(self) -> None:
        """设置路由"""
        self._add_route("GET", "/health", "none", self._handle_health)
        self._add_route("GET", "/status", "client", self._handle_status)
        self._add_route("GET", "/capabilities", "client", self._handle_capabilities)
        self._add_route("GET", "/whoami", "client", self._handle_whoami)
        self._add_route("GET", "/workspaces", "client", self._handle_list_workspaces)

        self._add_route("GET", "/w/:id/health", "none", self._handle_health)
        self._add_route("GET", "/w/:id/status", "client", self._handle_workspace_status)
        self._add_route("GET", "/w/:id/capabilities", "client", self._handle_capabilities)
        self._add_route("GET", "/w/:id/workspaces", "client", self._handle_list_workspaces)
        self._add_route("POST", "/workspaces/:id/activate", "host", self._handle_activate_workspace)
        self._add_route("DELETE", "/workspaces/:id", "host", self._handle_delete_workspace)

        self._add_route("GET", "/tokens", "host", self._handle_list_tokens)
        self._add_route("POST", "/tokens", "host", self._handle_create_token)
        self._add_route("DELETE", "/tokens/:id", "host", self._handle_revoke_token)

        self._add_route("GET", "/workspace/:id/skills", "client", self._handle_list_skills)
        self._add_route("GET", "/workspace/:id/skills/:name", "client", self._handle_get_skill)
        self._add_route("POST", "/workspace/:id/skills", "client", self._handle_upsert_skill)
        self._add_route("DELETE", "/workspace/:id/skills/:name", "client", self._handle_delete_skill)

        self._add_route("GET", "/hub/skills", "client", self._handle_list_hub_skills)
        self._add_route("POST", "/workspace/:id/skills/hub/:name", "client", self._handle_install_hub_skill)

        self._add_route("GET", "/workspace/:id/plugins", "client", self._handle_list_plugins)
        self._add_route("POST", "/workspace/:id/plugins", "client", self._handle_add_plugin)
        self._add_route("DELETE", "/workspace/:id/plugins/:name", "client", self._handle_remove_plugin)

        self._add_route("GET", "/workspace/:id/mcp", "client", self._handle_list_mcp)
        self._add_route("POST", "/workspace/:id/mcp", "client", self._handle_add_mcp)
        self._add_route("DELETE", "/workspace/:id/mcp/:name", "client", self._handle_remove_mcp)

        self._add_route("GET", "/workspace/:id/commands", "client", self._handle_list_commands)
        self._add_route("POST", "/workspace/:id/commands", "client", self._handle_upsert_command)
        self._add_route("DELETE", "/workspace/:id/commands/:name", "client", self._handle_delete_command)

        self._add_route("GET", "/approvals", "host", self._handle_list_all_approvals)
        self._add_route("POST", "/approvals/:id", "host", self._handle_respond_global_approval)
        self._add_route("GET", "/workspace/:id/approvals", "host", self._handle_list_approvals)
        self._add_route("POST", "/workspace/:id/approvals/:requestId/respond", "host", self._handle_respond_approval)

        self._add_route("GET", "/workspace/:id/audit", "client", self._handle_get_audit)

        self._add_route("GET", "/workspace/:id/scheduler/jobs", "client", self._handle_list_jobs)
        self._add_route("DELETE", "/workspace/:id/scheduler/jobs/:name", "client", self._handle_delete_job)

        self._add_route("GET", "/workspace/:id/config", "client", self._handle_get_config)
        self._add_route("PATCH", "/workspace/:id/config", "client", self._handle_patch_config)

        self._add_route("GET", "/workspace/:id/files/content", "client", self._handle_get_file_content)
        self._add_route("POST", "/workspace/:id/files/content", "client", self._handle_write_file_content)

    def _add_route(
        self,
        method: str,
        pattern: str,
        auth: str,
        handler: Callable
    ) -> None:
        """添加路由"""
        param_names = []
        regex_pattern = "^"
        parts = pattern.split("/")

        for part in parts:
            if part.startswith(":"):
                param_names.append(part[1:])
                regex_pattern += r"/([^/]+)"
            else:
                regex_pattern += f"/{re.escape(part)}"

        regex_pattern += "$"

        self.routes.append(Route(
            method=method,
            pattern=pattern,
            regex=re.compile(regex_pattern),
            param_names=param_names,
            auth=auth,
            handler=handler
        ))

    def _match_route(self, method: str, path: str) -> Optional[Tuple[Route, Dict[str, str]]]:
        """匹配路由"""
        for route in self.routes:
            if route.method != method:
                continue

            match = route.regex.match(path)
            if not match:
                continue

            params = {}
            for i, name in enumerate(route.param_names):
                params[name] = match.group(i + 1)

            return route, params

        return None

    async def _handle_request(
        self,
        method: str,
        path: str,
        headers: Dict[str, str],
        body: Optional[bytes] = None
    ) -> Tuple[int, Dict[str, Any], Dict[str, str]]:
        """
        处理请求

        Args:
            method: HTTP 方法
            path: 请求路径
            headers: 请求头
            body: 请求体
        Returns:
            (状态码, 响应体, 响应头)
        """
        response_headers = {"Content-Type": "application/json"}

        try:
            matched = self._match_route(method, path)
            if not matched:
                return 404, {"code": "not_found", "message": "Not found"}, response_headers

            route, params = matched

            actor = None
            if route.auth == "client":
                actor = await self._require_client(headers)
            elif route.auth == "host":
                actor = await self._require_host(headers)

            parsed_body = None
            if body:
                try:
                    parsed_body = json.loads(body.decode("utf-8"))
                except json.JSONDecodeError:
                    pass

            context = RequestContext(
                request={"headers": headers, "body": parsed_body},
                path=path,
                params=params,
                config=self.config,
                approvals=self.approvals,
                reload_events=self.reload_events,
                tokens=self.tokens,
                actor=actor
            )

            result = await route.handler(context)

            return 200, result, response_headers

        except ApiError as e:
            return e.status, format_error(e).__dict__, response_headers
        except Exception as e:
            return 500, {"code": "internal_error", "message": str(e)}, response_headers

    async def _require_client(self, headers: Dict[str, str]) -> Actor:
        """验证客户端 Token"""
        auth_header = headers.get("authorization", "")
        match = re.match(r"^Bearer\s+(.+)$", auth_header, re.IGNORECASE)
        token = match.group(1) if match else None

        if not token:
            raise ApiError(401, "unauthorized", "Invalid bearer token")

        scope = await self.tokens.scope_for_token(token)
        if not scope:
            raise ApiError(401, "unauthorized", "Invalid bearer token")

        client_id = headers.get("x-openwork-client-id")
        return Actor(
            type="remote",
            client_id=client_id,
            token_hash=hash_token(token),
            scope=scope
        )

    async def _require_host(self, headers: Dict[str, str]) -> Actor:
        """验证主机 Token"""
        host_token = headers.get("x-openwork-host-token")

        if host_token and host_token == self.config.host_token:
            return Actor(type="host", token_hash=hash_token(host_token), scope=TokenScope.OWNER)

        auth_header = headers.get("authorization", "")
        match = re.match(r"^Bearer\s+(.+)$", auth_header, re.IGNORECASE)
        bearer = match.group(1) if match else None

        if not bearer:
            raise ApiError(401, "unauthorized", "Invalid host token")

        scope = await self.tokens.scope_for_token(bearer)
        if scope != TokenScope.OWNER:
            raise ApiError(401, "unauthorized", "Invalid host token")

        client_id = headers.get("x-openwork-client-id")
        return Actor(
            type="remote",
            client_id=client_id,
            token_hash=hash_token(bearer),
            scope=scope
        )

    async def _handle_health(self, ctx: RequestContext) -> Dict[str, Any]:
        """健康检查"""
        return {
            "ok": True,
            "version": SERVER_VERSION,
            "uptimeMs": int(time.time() * 1000) - self._started_at
        }

    async def _handle_status(self, ctx: RequestContext) -> Dict[str, Any]:
        """服务器状态"""
        active = self.config.workspaces[0] if self.config.workspaces else None
        return {
            "ok": True,
            "version": SERVER_VERSION,
            "uptimeMs": int(time.time() * 1000) - self._started_at,
            "readOnly": self.config.read_only,
            "approval": {
                "mode": self.config.approval.mode.value,
                "timeoutMs": self.config.approval.timeout_ms
            },
            "corsOrigins": self.config.cors_origins,
            "workspaceCount": len(self.config.workspaces),
            "activeWorkspaceId": active.id if active else None
        }

    async def _handle_capabilities(self, ctx: RequestContext) -> Dict[str, Any]:
        """服务器能力"""
        write_enabled = not self.config.read_only
        return {
            "schemaVersion": 1,
            "serverVersion": SERVER_VERSION,
            "skills": {"read": True, "write": write_enabled, "source": "openwork"},
            "plugins": {"read": True, "write": write_enabled},
            "mcp": {"read": True, "write": write_enabled},
            "commands": {"read": True, "write": write_enabled},
            "config": {"read": True, "write": write_enabled},
            "approvals": {
                "mode": self.config.approval.mode.value,
                "timeoutMs": self.config.approval.timeout_ms
            },
            "tokens": {"scoped": True, "scopes": ["owner", "collaborator", "viewer"]}
        }

    async def _handle_whoami(self, ctx: RequestContext) -> Dict[str, Any]:
        """获取当前用户信息"""
        return {
            "ok": True,
            "actor": {
                "type": ctx.actor.type if ctx.actor else None,
                "scope": ctx.actor.scope.value if ctx.actor and ctx.actor.scope else None
            }
        }

    async def _handle_list_workspaces(self, ctx: RequestContext) -> Dict[str, Any]:
        """列出工作空间"""
        from .workspaces import serialize_workspace

        active = self.config.workspaces[0] if self.config.workspaces else None
        items = [serialize_workspace(w) for w in self.config.workspaces]
        return {
            "items": items,
            "activeId": active.id if active else None
        }

    async def _handle_list_tokens(self, ctx: RequestContext) -> Dict[str, Any]:
        """列出 Token"""
        items = await self.tokens.list()
        return {"items": items}

    async def _handle_create_token(self, ctx: RequestContext) -> Dict[str, Any]:
        """创建 Token"""
        body = ctx.request.get("body", {})
        scope_str = body.get("scope", "").strip()

        if scope_str not in ("owner", "collaborator", "viewer"):
            raise ApiError(400, "invalid_scope", "Token scope must be owner, collaborator, or viewer")

        scope = TokenScope(scope_str)
        label = body.get("label", "").strip() if body.get("label") else None

        result = await self.tokens.create(scope, label)
        return result

    async def _handle_revoke_token(self, ctx: RequestContext) -> Dict[str, Any]:
        """撤销 Token"""
        token_id = ctx.params.get("id", "")
        ok = await self.tokens.revoke(token_id)

        if not ok:
            raise ApiError(404, "token_not_found", "Token not found")

        return {"ok": True}

    async def _handle_list_skills(self, ctx: RequestContext) -> Dict[str, Any]:
        """列出技能"""
        from .skills import list_skills
        from .workspaces import resolve_workspace

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        skills = await list_skills(workspace.path, include_global=True)

        return {
            "items": [
                {
                    "name": s.name,
                    "description": s.description,
                    "path": s.path,
                    "scope": s.scope,
                    "trigger": s.trigger
                }
                for s in skills
            ]
        }

    async def _handle_upsert_skill(self, ctx: RequestContext) -> Dict[str, Any]:
        """创建或更新技能"""
        from .skills import upsert_skill
        from .workspaces import resolve_workspace

        if self.config.read_only:
            raise ApiError(403, "read_only", "Server is in read-only mode")

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        body = ctx.request.get("body", {})

        result = await upsert_skill(workspace.path, body)
        return result

    async def _handle_delete_skill(self, ctx: RequestContext) -> Dict[str, Any]:
        """删除技能"""
        from .skills import delete_skill
        from .workspaces import resolve_workspace

        if self.config.read_only:
            raise ApiError(403, "read_only", "Server is in read-only mode")

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        name = ctx.params.get("name", "")

        result = await delete_skill(workspace.path, name)
        return result

    async def _handle_list_plugins(self, ctx: RequestContext) -> Dict[str, Any]:
        """列出插件"""
        from .plugins import list_plugins
        from .workspaces import resolve_workspace

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        result = await list_plugins(workspace.path, include_global=True)

        return {
            "items": [
                {
                    "spec": p.spec,
                    "source": p.source,
                    "scope": p.scope,
                    "path": p.path
                }
                for p in result["items"]
            ],
            "loadOrder": result["loadOrder"]
        }

    async def _handle_add_plugin(self, ctx: RequestContext) -> Dict[str, Any]:
        """添加插件"""
        from .plugins import add_plugin
        from .workspaces import resolve_workspace

        if self.config.read_only:
            raise ApiError(403, "read_only", "Server is in read-only mode")

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        body = ctx.request.get("body", {})
        spec = body.get("spec", "")

        ok = await add_plugin(workspace.path, spec)
        return {"ok": ok, "added": ok}

    async def _handle_remove_plugin(self, ctx: RequestContext) -> Dict[str, Any]:
        """移除插件"""
        from .plugins import remove_plugin
        from .workspaces import resolve_workspace

        if self.config.read_only:
            raise ApiError(403, "read_only", "Server is in read-only mode")

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        name = ctx.params.get("name", "")

        ok = await remove_plugin(workspace.path, name)
        return {"ok": ok, "removed": ok}

    async def _handle_list_mcp(self, ctx: RequestContext) -> Dict[str, Any]:
        """列出 MCP"""
        from .mcp import list_mcp
        from .workspaces import resolve_workspace

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        items = await list_mcp(workspace.path)

        return {
            "items": [
                {
                    "name": m.name,
                    "config": m.config,
                    "source": m.source,
                    "disabledByTools": m.disabled_by_tools
                }
                for m in items
            ]
        }

    async def _handle_add_mcp(self, ctx: RequestContext) -> Dict[str, Any]:
        """添加 MCP"""
        from .mcp import add_mcp
        from .workspaces import resolve_workspace

        if self.config.read_only:
            raise ApiError(403, "read_only", "Server is in read-only mode")

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        body = ctx.request.get("body", {})
        name = body.get("name", "")
        config = body.get("config", {})

        result = await add_mcp(workspace.path, name, config)
        return result

    async def _handle_remove_mcp(self, ctx: RequestContext) -> Dict[str, Any]:
        """移除 MCP"""
        from .mcp import remove_mcp
        from .workspaces import resolve_workspace

        if self.config.read_only:
            raise ApiError(403, "read_only", "Server is in read-only mode")

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        name = ctx.params.get("name", "")

        ok = await remove_mcp(workspace.path, name)
        return {"ok": ok, "removed": ok}

    async def _handle_list_commands(self, ctx: RequestContext) -> Dict[str, Any]:
        """列出命令"""
        from .commands import list_commands
        from .workspaces import resolve_workspace

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        commands = await list_commands(workspace.path, scope="workspace")

        return {
            "items": [
                {
                    "name": c.name,
                    "description": c.description,
                    "template": c.template,
                    "agent": c.agent,
                    "model": c.model,
                    "subtask": c.subtask,
                    "scope": c.scope
                }
                for c in commands
            ]
        }

    async def _handle_upsert_command(self, ctx: RequestContext) -> Dict[str, Any]:
        """创建或更新命令"""
        from .commands import upsert_command
        from .workspaces import resolve_workspace

        if self.config.read_only:
            raise ApiError(403, "read_only", "Server is in read-only mode")

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        body = ctx.request.get("body", {})

        path = await upsert_command(workspace.path, body)
        return {"ok": True, "path": path}

    async def _handle_delete_command(self, ctx: RequestContext) -> Dict[str, Any]:
        """删除命令"""
        from .commands import delete_command
        from .workspaces import resolve_workspace

        if self.config.read_only:
            raise ApiError(403, "read_only", "Server is in read-only mode")

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        name = ctx.params.get("name", "")

        await delete_command(workspace.path, name)
        return {"ok": True}

    async def _handle_list_approvals(self, ctx: RequestContext) -> Dict[str, Any]:
        """列出待处理审批"""
        requests = self.approvals.list()
        return {
            "items": [
                {
                    "id": r.id,
                    "workspaceId": r.workspace_id,
                    "action": r.action,
                    "summary": r.summary,
                    "paths": r.paths,
                    "createdAt": r.created_at
                }
                for r in requests
            ]
        }

    async def _handle_respond_approval(self, ctx: RequestContext) -> Dict[str, Any]:
        """响应审批"""
        request_id = ctx.params.get("requestId", "")
        body = ctx.request.get("body", {})
        reply = body.get("reply", "")

        if reply not in ("allow", "deny"):
            raise ApiError(400, "invalid_reply", "Reply must be 'allow' or 'deny'")

        result = self.approvals.respond(request_id, reply)
        if not result:
            raise ApiError(404, "approval_not_found", "Approval request not found")

        return {
            "ok": True,
            "id": result.id,
            "allowed": result.allowed,
            "reason": result.reason
        }

    async def _handle_list_jobs(self, ctx: RequestContext) -> Dict[str, Any]:
        """列出计划任务"""
        from .scheduler import list_scheduled_jobs
        from .workspaces import resolve_workspace

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        jobs = await list_scheduled_jobs(workdir=workspace.path)

        return {
            "items": [
                {
                    "slug": j.slug,
                    "name": j.name,
                    "schedule": j.schedule,
                    "createdAt": j.created_at,
                    "lastRunAt": j.last_run_at,
                    "lastRunStatus": j.last_run_status
                }
                for j in jobs
            ]
        }

    async def _handle_delete_job(self, ctx: RequestContext) -> Dict[str, Any]:
        """删除计划任务"""
        from .scheduler import delete_scheduled_job, resolve_scheduled_job
        from .workspaces import resolve_workspace

        if self.config.read_only:
            raise ApiError(403, "read_only", "Server is in read-only mode")

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        name = ctx.params.get("name", "")

        result = await resolve_scheduled_job(name, workdir=workspace.path)
        await delete_scheduled_job(result["job"], result["jobFile"])

        return {"ok": True}

    async def _handle_get_config(self, ctx: RequestContext) -> Dict[str, Any]:
        """获取配置"""
        from .utils import read_json_file
        from .workspace_files import opencode_config_path, openwork_config_path
        from .workspaces import resolve_workspace

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))

        opencode_config = await read_json_file(opencode_config_path(workspace.path))
        openwork_config = await read_json_file(openwork_config_path(workspace.path))

        return {
            "opencode": opencode_config or {},
            "openwork": openwork_config or {}
        }

    async def _handle_patch_config(self, ctx: RequestContext) -> Dict[str, Any]:
        """更新配置"""
        from .utils import read_json_file, write_json_file
        from .workspace_files import opencode_config_path, openwork_config_path
        from .workspaces import resolve_workspace

        if self.config.read_only:
            raise ApiError(403, "read_only", "Server is in read-only mode")

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        body = ctx.request.get("body", {})

        opencode_updates = body.get("opencode")
        openwork_updates = body.get("openwork")

        if opencode_updates:
            config = await read_json_file(opencode_config_path(workspace.path)) or {}
            config.update(opencode_updates)
            await write_json_file(opencode_config_path(workspace.path), config)

        if openwork_updates:
            config = await read_json_file(openwork_config_path(workspace.path)) or {}
            config.update(openwork_updates)
            await write_json_file(openwork_config_path(workspace.path), config)

        return {"ok": True, "updatedAt": int(time.time() * 1000)}

    async def _handle_workspace_status(self, ctx: RequestContext) -> Dict[str, Any]:
        """工作空间状态"""
        from .workspaces import resolve_workspace, serialize_workspace

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        return {
            "ok": True,
            "version": SERVER_VERSION,
            "uptimeMs": int(time.time() * 1000) - self._started_at,
            "readOnly": self.config.read_only,
            "approval": {
                "mode": self.config.approval.mode.value,
                "timeoutMs": self.config.approval.timeout_ms
            },
            "workspace": serialize_workspace(workspace),
        }

    async def _handle_activate_workspace(self, ctx: RequestContext) -> Dict[str, Any]:
        """激活工作空间"""
        from .workspaces import resolve_workspace, serialize_workspace

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))

        for i, w in enumerate(self.config.workspaces):
            if w.id == workspace.id:
                self.config.workspaces.pop(i)
                self.config.workspaces.insert(0, w)
                break

        return {"activeId": workspace.id, "workspace": serialize_workspace(workspace)}

    async def _handle_delete_workspace(self, ctx: RequestContext) -> Dict[str, Any]:
        """删除工作空间"""
        from .workspaces import resolve_workspace, serialize_workspace

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))

        self.config.workspaces = [w for w in self.config.workspaces if w.id != workspace.id]

        active = self.config.workspaces[0] if self.config.workspaces else None
        return {
            "ok": True,
            "deleted": True,
            "activeId": active.id if active else None,
            "items": [serialize_workspace(w) for w in self.config.workspaces]
        }

    async def _handle_get_skill(self, ctx: RequestContext) -> Dict[str, Any]:
        """获取技能详情"""
        from dataclasses import asdict

        from .skills import list_skills
        from .workspaces import resolve_workspace

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        name = ctx.params.get("name", "")

        skills = await list_skills(workspace.path, include_global=True)
        skill = next((s for s in skills if s.name == name), None)

        if not skill:
            raise ApiError(404, "skill_not_found", f"Skill not found: {name}")

        try:
            import aiofiles
            async with aiofiles.open(skill.path, "r", encoding="utf-8") as f:
                content = await f.read()
        except Exception:
            with open(skill.path, "r", encoding="utf-8") as f:
                content = f.read()

        return {"item": asdict(skill), "content": content}

    async def _handle_list_hub_skills(self, ctx: RequestContext) -> Dict[str, Any]:
        """列出 Hub 技能"""

        from .skill_hub import list_hub_skills

        skills = await list_hub_skills()
        return {
            "items": [
                {
                    "name": s.name,
                    "description": s.description,
                    "trigger": s.trigger,
                    "source": s.source
                }
                for s in skills
            ]
        }

    async def _handle_install_hub_skill(self, ctx: RequestContext) -> Dict[str, Any]:
        """安装 Hub 技能"""
        from .skill_hub import install_hub_skill
        from .workspaces import resolve_workspace

        if self.config.read_only:
            raise ApiError(403, "read_only", "Server is in read-only mode")

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        name = ctx.params.get("name", "")
        body = ctx.request.get("body", {})
        overwrite = body.get("overwrite", False)

        result = await install_hub_skill(workspace.path, name, overwrite)
        return {
            "ok": True,
            "name": result.name,
            "path": result.path,
            "action": result.action,
            "written": result.written,
            "skipped": result.skipped
        }

    async def _handle_list_all_approvals(self, ctx: RequestContext) -> Dict[str, Any]:
        """列出所有待处理审批"""
        requests = self.approvals.list()
        return {
            "items": [
                {
                    "id": r.id,
                    "workspaceId": r.workspace_id,
                    "action": r.action,
                    "summary": r.summary,
                    "paths": r.paths,
                    "createdAt": r.created_at
                }
                for r in requests
            ]
        }

    async def _handle_respond_global_approval(self, ctx: RequestContext) -> Dict[str, Any]:
        """响应全局审批"""
        request_id = ctx.params.get("id", "")
        body = ctx.request.get("body", {})
        reply = body.get("reply", "")

        if reply not in ("allow", "deny"):
            raise ApiError(400, "invalid_reply", "Reply must be 'allow' or 'deny'")

        result = self.approvals.respond(request_id, reply)
        if not result:
            raise ApiError(404, "approval_not_found", "Approval request not found")

        return {
            "ok": True,
            "id": result.id,
            "allowed": result.allowed,
            "reason": result.reason
        }

    async def _handle_get_audit(self, ctx: RequestContext) -> Dict[str, Any]:
        """获取审计日志"""
        from dataclasses import asdict

        from .audit import read_audit_entries
        from .workspaces import resolve_workspace

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))

        query = ctx.request.get("query", {})
        limit_param = query.get("limit", "50") if isinstance(query, dict) else "50"
        try:
            limit = min(int(limit_param), 200)
        except ValueError:
            limit = 50

        items = await read_audit_entries(workspace.path, workspace.id, limit)
        return {"items": [asdict(item) for item in items]}

    async def _handle_get_file_content(self, ctx: RequestContext) -> Dict[str, Any]:
        """获取文件内容"""
        import os

        from .paths import resolve_safe_child_path
        from .utils import exists
        from .workspaces import resolve_workspace

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        query = ctx.request.get("query", {})
        requested_path = query.get("path", "").strip() if isinstance(query, dict) else ""

        if not requested_path:
            raise ApiError(400, "invalid_path", "Path is required")

        relative_path = os.path.normpath(requested_path)
        lowered = relative_path.lower()

        if not (lowered.endswith(".md") or lowered.endswith(".mdx") or lowered.endswith(".markdown")):
            raise ApiError(400, "invalid_path", "Only markdown files are supported")

        abs_path = resolve_safe_child_path(workspace.path, relative_path)

        if not await exists(abs_path):
            raise ApiError(404, "file_not_found", "File not found")

        stat = os.stat(abs_path)
        if not os.path.isfile(abs_path):
            raise ApiError(404, "file_not_found", "File not found")

        max_bytes = 5_000_000
        if stat.st_size > max_bytes:
            raise ApiError(413, "file_too_large", "File exceeds size limit", {"maxBytes": max_bytes, "size": stat.st_size})

        try:
            import aiofiles
            async with aiofiles.open(abs_path, "r", encoding="utf-8") as f:
                content = await f.read()
        except Exception:
            with open(abs_path, "r", encoding="utf-8") as f:
                content = f.read()

        return {
            "path": relative_path,
            "content": content,
            "bytes": len(content.encode("utf-8")),
            "updatedAt": int(stat.st_mtime * 1000)
        }

    async def _handle_write_file_content(self, ctx: RequestContext) -> Dict[str, Any]:
        """写入文件内容"""
        import os

        from .paths import resolve_safe_child_path
        from .utils import ensure_dir
        from .workspaces import resolve_workspace

        if self.config.read_only:
            raise ApiError(403, "read_only", "Server is in read-only mode")

        workspace = await resolve_workspace(self.config, ctx.params.get("id", ""))
        body = ctx.request.get("body", {})

        requested_path = str(body.get("path", ""))
        relative_path = os.path.normpath(requested_path)
        lowered = relative_path.lower()

        if not (lowered.endswith(".md") or lowered.endswith(".mdx") or lowered.endswith(".markdown")):
            raise ApiError(400, "invalid_path", "Only markdown files are supported")

        content = body.get("content")
        if not isinstance(content, str):
            raise ApiError(400, "invalid_payload", "content must be a string")

        bytes_len = len(content.encode("utf-8"))
        max_bytes = 5_000_000
        if bytes_len > max_bytes:
            raise ApiError(413, "file_too_large", "File exceeds size limit", {"maxBytes": max_bytes, "size": bytes_len})

        abs_path = resolve_safe_child_path(workspace.path, relative_path)

        await ensure_dir(os.path.dirname(abs_path))

        try:
            import aiofiles
            async with aiofiles.open(abs_path, "w", encoding="utf-8") as f:
                await f.write(content)
        except Exception:
            with open(abs_path, "w", encoding="utf-8") as f:
                f.write(content)

        stat = os.stat(abs_path)
        return {"ok": True, "path": relative_path, "bytes": bytes_len, "updatedAt": int(stat.st_mtime * 1000)}


async def start_server(config: ServerConfig) -> HTTPServer:
    """
    启动服务器

    Args:
        config: 服务器配置

    Returns:
        HTTPServer 实例
    """
    server = HTTPServer(config)
    return server


def create_app(config: ServerConfig) -> HTTPServer:
    """
    创建应用实例

    Args:
        config: 服务器配置

    Returns:
        HTTPServer 实例
    """
    return HTTPServer(config)
