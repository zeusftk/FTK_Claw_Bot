"""
OpenWork Server - Python 实现

这是一个 HTTP API 服务，提供以下功能：
- 技能管理 (skills)
- 插件管理 (plugins)
- MCP 管理 (mcp)
- 命令管理 (commands)
- 调度器 (scheduler)
- 工作空间管理 (workspaces)
- 审批管理 (approvals)
- Token 管理 (tokens)

使用示例:
    from clawbot.openwork_server import create_app, resolve_server_config, CliArgs

    # 解析配置
    args = CliArgs(host="127.0.0.1", port=8787)
    config = await resolve_server_config(args)

    # 创建服务器
    server = create_app(config)
"""

__version__ = "0.1.0"
__author__ = "OpenWork Team"

# 导出主要类型
# 导出服务
from .approvals import ApprovalResult, ApprovalService
from .audit import (
    audit_log_path,
    legacy_audit_log_path,
    read_audit_entries,
    read_last_audit,
    record_audit,
)
from .commands import delete_command, get_command, list_commands, upsert_command

# 导出配置
from .config import (
    CliArgs,
    FileConfig,
    parse_cli_args,
    print_help,
    resolve_server_config,
)

# 导出错误类
from .errors import (
    ApiError,
    ForbiddenError,
    InternalServerError,
    NotFoundError,
    ServiceUnavailableError,
    UnauthorizedError,
    ValidationError,
    format_error,
)
from .events import ReloadEventStore
from .jsonc import (
    JsoncParseError,
    parse_jsonc,
    parse_jsonc_sync,
    read_jsonc_file,
    read_jsonc_file_sync,
    update_jsonc_top_level,
    write_jsonc_file,
)
from .mcp import add_mcp, get_mcp, list_mcp, remove_mcp

# 导出新模块
from .paths import (
    assert_absolute,
    normalize_workspace_relative_path,
    resolve_safe_child_path,
    resolve_within_root,
)
from .plugins import add_plugin, get_plugin, list_plugins, remove_plugin
from .scheduler import delete_scheduled_job, list_scheduled_jobs, resolve_scheduled_job

# 导出服务器
from .server import HTTPServer, create_app, start_server
from .skill_hub import (
    HubRepo,
    HubSkillItem,
    InstallResult,
    install_hub_skill,
    list_hub_skills,
)

# 导出管理模块
from .skills import delete_skill, get_skill, list_skills, upsert_skill
from .tokens import TokenService
from .types import (
    Actor,
    ApiErrorBody,
    ApprovalConfig,
    ApprovalMode,
    ApprovalRequest,
    AuditEntry,
    Capabilities,
    CommandItem,
    LogFormat,
    McpItem,
    PluginItem,
    ProviderPlacement,
    ReloadEvent,
    ReloadReason,
    ReloadTrigger,
    SandboxBackend,
    ScheduledJob,
    ScheduledJobRun,
    ServerConfig,
    SkillItem,
    TokenRecord,
    TokenScope,
    WorkspaceConfig,
    WorkspaceInfo,
    WorkspaceType,
)

# 导出工具函数
from .utils import (
    ensure_dir,
    exists,
    hash_token,
    parse_list,
    read_file,
    read_json_file,
    short_id,
    write_file,
    write_json_file,
)

# 导出验证器
from .validators import (
    validate_command_name,
    validate_description,
    validate_mcp_config,
    validate_mcp_name,
    validate_path,
    validate_plugin_spec,
    validate_skill_name,
    validate_token_scope,
)
from .workspaces import (
    build_workspace_infos,
    get_active_workspace,
    resolve_workspace,
    serialize_workspace,
    workspace_id_for_path,
)

__all__ = [
    # 版本信息
    "__version__",
    "__author__",

    # 类型
    "WorkspaceType",
    "ApprovalMode",
    "TokenScope",
    "SandboxBackend",
    "ProviderPlacement",
    "LogFormat",
    "WorkspaceConfig",
    "WorkspaceInfo",
    "ApprovalConfig",
    "ServerConfig",
    "Capabilities",
    "ReloadReason",
    "ReloadTrigger",
    "ReloadEvent",
    "ApiErrorBody",
    "PluginItem",
    "McpItem",
    "SkillItem",
    "HubSkillItem",
    "CommandItem",
    "Actor",
    "ApprovalRequest",
    "AuditEntry",
    "ScheduledJob",
    "ScheduledJobRun",
    "TokenRecord",

    # 错误
    "ApiError",
    "NotFoundError",
    "UnauthorizedError",
    "ForbiddenError",
    "ValidationError",
    "InternalServerError",
    "ServiceUnavailableError",
    "format_error",

    # 服务
    "ApprovalService",
    "ApprovalResult",
    "TokenService",
    "ReloadEventStore",

    # 服务器
    "HTTPServer",
    "start_server",
    "create_app",

    # 配置
    "CliArgs",
    "FileConfig",
    "parse_cli_args",
    "print_help",
    "resolve_server_config",

    # 技能管理
    "list_skills",
    "upsert_skill",
    "delete_skill",
    "get_skill",

    # 插件管理
    "list_plugins",
    "add_plugin",
    "remove_plugin",
    "get_plugin",

    # MCP 管理
    "list_mcp",
    "add_mcp",
    "remove_mcp",
    "get_mcp",

    # 命令管理
    "list_commands",
    "upsert_command",
    "delete_command",
    "get_command",

    # 调度器
    "list_scheduled_jobs",
    "resolve_scheduled_job",
    "delete_scheduled_job",

    # 工作空间
    "workspace_id_for_path",
    "build_workspace_infos",
    "resolve_workspace",
    "serialize_workspace",
    "get_active_workspace",

    # 工具函数
    "exists",
    "ensure_dir",
    "read_file",
    "write_file",
    "read_json_file",
    "write_json_file",
    "hash_token",
    "short_id",
    "parse_list",

    # 验证器
    "validate_skill_name",
    "validate_description",
    "validate_plugin_spec",
    "validate_command_name",
    "validate_mcp_name",
    "validate_mcp_config",
    "validate_token_scope",
    "validate_path",

    # 路径安全
    "assert_absolute",
    "resolve_within_root",
    "resolve_safe_child_path",
    "normalize_workspace_relative_path",

    # 审计日志
    "record_audit",
    "read_last_audit",
    "read_audit_entries",
    "audit_log_path",
    "legacy_audit_log_path",

    # JSONC
    "parse_jsonc",
    "read_jsonc_file",
    "update_jsonc_top_level",
    "write_jsonc_file",
    "parse_jsonc_sync",
    "read_jsonc_file_sync",
    "JsoncParseError",

    # 技能 Hub
    "list_hub_skills",
    "install_hub_skill",
    "HubRepo",
    "HubSkillItem",
    "InstallResult",
]
