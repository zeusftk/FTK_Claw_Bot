"""
OpenWork Server 事件存储模块

提供重载事件的管理功能。"""

from typing import Dict, List, Optional

from .types import ReloadEvent, ReloadReason, ReloadTrigger
from .utils import short_id


class ReloadEventStore:
    """重载事件存储"""

    def __init__(self, max_size: int = 200):
        """
        初始化事件存储
        Args:
            max_size: 最大存储数释        """
        self._events: List[ReloadEvent] = []
        self._seq = 0
        self._max_size = max_size
        self._last_recorded: Dict[str, int] = {}

    def record(
        self,
        workspace_id: str,
        reason: ReloadReason,
        trigger: Optional[ReloadTrigger] = None
    ) -> ReloadEvent:
        """
        记录重载事件

        Args:
            workspace_id: 工作空间 ID
            reason: 重载原因
            trigger: 触发器
        Returns:
            重载事件
        """
        import time

        self._seq += 1

        event = ReloadEvent(
            id=short_id(),
            seq=self._seq,
            workspace_id=workspace_id,
            reason=reason,
            trigger=trigger,
            timestamp=int(time.time() * 1000)
        )

        self._events.append(event)

        # 限制存储大小
        if len(self._events) > self._max_size:
            self._events = self._events[-self._max_size:]

        return event

    def record_debounced(
        self,
        workspace_id: str,
        reason: ReloadReason,
        trigger: Optional[ReloadTrigger] = None,
        debounce_ms: int = 750
    ) -> Optional[ReloadEvent]:
        """
        记录去抖动的重载事件

        Args:
            workspace_id: 工作空间 ID
            reason: 重载原因
            trigger: 触发器            debounce_ms: 去抖动时间（毫秒：
        Returns:
            重载事件，如果在去抖动时间内则返回None
        """
        import time

        now = int(time.time() * 1000)
        key = f"{workspace_id}:{reason.value if isinstance(reason, ReloadReason) else reason}"
        last = self._last_recorded.get(key, 0)

        if now - last < debounce_ms:
            return None

        self._last_recorded[key] = now
        return self.record(workspace_id, reason, trigger)

    def list(
        self,
        workspace_id: str,
        since: Optional[int] = None
    ) -> List[ReloadEvent]:
        """
        列出重载事件

        Args:
            workspace_id: 工作空间 ID
            since: 起始序列发
        Returns:
            重载事件列表
        """
        cursor = since if isinstance(since, (int, float)) else 0

        return [
            event for event in self._events
            if event.workspace_id == workspace_id and event.seq > cursor
        ]

    def cursor(self) -> int:
        """
        获取当前序列发
        Returns:
            当前序列发        """
        return self._seq

    def clear(self) -> int:
        """
        清除所有事任
        Returns:
            清除的事件数释        """
        count = len(self._events)
        self._events.clear()
        self._last_recorded.clear()
        return count

    def get_latest(self, workspace_id: str) -> Optional[ReloadEvent]:
        """
        获取最新的重载事件

        Args:
            workspace_id: 工作空间 ID

        Returns:
            最新的重载事件，如果没有则返回 None
        """
        for event in reversed(self._events):
            if event.workspace_id == workspace_id:
                return event
        return None

    def get_by_reason(
        self,
        workspace_id: str,
        reason: ReloadReason
    ) -> List[ReloadEvent]:
        """
        按原因获取重载事任
        Args:
            workspace_id: 工作空间 ID
            reason: 重载原因

        Returns:
            重载事件列表
        """
        return [
            event for event in self._events
            if event.workspace_id == workspace_id and event.reason == reason
        ]
