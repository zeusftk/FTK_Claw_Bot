"""
OpenWork Server 调度器模块

提供计划任务的管理功能。"""

import json
import logging
import os
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from .errors import ApiError
from .types import ScheduledJob
from .utils import exists, join_path, read_json_file, resolve_home, slugify

logger = logging.getLogger(__name__)


SUPPORTED_PLATFORMS = {"darwin", "linux"}


def _ensure_scheduler_supported() -> None:
    """
    确保调度器支持当前平台

    Raises:
        ApiError: 如果平台不支持
    """
    import platform
    if platform.system().lower() not in {"darwin", "linux"}:
        raise ApiError(
            400,
            "scheduler_unsupported",
            "Scheduler is supported only on macOS and Linux."
        )


def _legacy_jobs_dir() -> str:
    """获取旧版任务目录"""
    return join_path(resolve_home(), ".config", "opencode", "jobs")


def _scheduler_scopes_dir() -> str:
    """获取调度器作用域目录"""
    return join_path(resolve_home(), ".config", "opencode", "scheduler", "scopes")


def _legacy_job_file_path(slug: str) -> str:
    """获取旧版任务文件路径"""
    return join_path(_legacy_jobs_dir(), f"{slug}.json")


def _scoped_job_file_path(scope_id: str, slug: str) -> str:
    """获取作用域任务文件路径"""
    return join_path(_scheduler_scopes_dir(), scope_id, "jobs", f"{slug}.json")


def _normalize_path_for_compare(value: str) -> str:
    """规范化路径用于比较"""
    trimmed = value.strip()
    return os.path.abspath(trimmed) if trimmed else ""


async def _load_job_file(path: str) -> Optional[ScheduledJob]:
    """
    加载任务文件

    Args:
        path: 文件路径

    Returns:
        任务对象或 None
    """
    if not await exists(path):
        return None

    try:
        data = await read_json_file(path)
        if not data or not isinstance(data, dict):
            return None

        slug = data.get("slug")
        name = data.get("name")
        schedule = data.get("schedule")

        if not slug or not name or not schedule:
            return None

        return ScheduledJob(
            slug=slug,
            name=name,
            schedule=schedule,
            created_at=data.get("createdAt", ""),
            scope_id=data.get("scopeId"),
            timeout_seconds=data.get("timeoutSeconds"),
            invocation=data.get("invocation"),
            prompt=data.get("prompt"),
            attach_url=data.get("attachUrl"),
            run=data.get("run"),
            source=data.get("source"),
            workdir=data.get("workdir"),
            updated_at=data.get("updatedAt"),
            last_run_at=data.get("lastRunAt"),
            last_run_exit_code=data.get("lastRunExitCode"),
            last_run_error=data.get("lastRunError"),
            last_run_source=data.get("lastRunSource"),
            last_run_status=data.get("lastRunStatus")
        )
    except (json.JSONDecodeError, KeyError, TypeError, ValueError) as e:
        logger.warning("Failed to parse job file {}: {}", path, e)
        return None


@dataclass
class JobEntry:
    """任务条目"""
    job: ScheduledJob
    job_file: str


async def _load_legacy_job_entries() -> List[JobEntry]:
    """加载旧版任务条目"""
    jobs_dir = _legacy_jobs_dir()
    if not await exists(jobs_dir):
        return []

    entries: List[JobEntry] = []

    try:
        for name in os.listdir(jobs_dir):
            if not name.endswith(".json"):
                continue

            path = join_path(jobs_dir, name)
            job = await _load_job_file(path)
            if job:
                entries.append(JobEntry(job=job, job_file=path))
    except (OSError, PermissionError) as e:
        logger.warning("Failed to load legacy job entries from {}: {}", jobs_dir, e)

    return entries


async def _load_scoped_job_entries() -> List[JobEntry]:
    """加载作用域任务条目"""
    scopes_dir = _scheduler_scopes_dir()
    if not await exists(scopes_dir):
        return []

    entries: List[JobEntry] = []

    try:
        for scope_name in os.listdir(scopes_dir):
            scope_path = join_path(scopes_dir, scope_name)
            if not os.path.isdir(scope_path):
                continue

            jobs_dir = join_path(scope_path, "jobs")
            if not await exists(jobs_dir):
                continue

            for name in os.listdir(jobs_dir):
                if not name.endswith(".json"):
                    continue

                path = join_path(jobs_dir, name)
                job = await _load_job_file(path)
                if job:
                    # 确保作用域 ID 正确
                    if not job.scope_id:
                        job.scope_id = scope_name
                    entries.append(JobEntry(job=job, job_file=path))
    except (OSError, PermissionError) as e:
        logger.warning("Failed to load scoped job entries from {}: {}", scopes_dir, e)

    return entries


async def _load_all_job_entries() -> List[JobEntry]:
    """加载所有任务条目"""
    scoped = await _load_scoped_job_entries()
    legacy = await _load_legacy_job_entries()
    return scoped + legacy


def _find_job_entry_by_name(entries: List[JobEntry], name: str) -> Optional[JobEntry]:
    """
    按名称查找任务条目

    Args:
        entries: 任务条目列表
        name: 任务名称

    Returns:
        任务条目或 None
    """
    trimmed = name.strip()
    if not trimmed:
        return None

    slug = slugify(trimmed)
    lower = trimmed.lower()

    for entry in entries:
        job_slug = entry.job.slug
        job_name = entry.job.name.lower()

        if job_slug == trimmed:
            return entry
        if job_slug == slug:
            return entry
        if job_slug.endswith(f"-{slug}"):
            return entry
        if job_name == lower:
            return entry
        if lower in job_name:
            return entry

    return None


def _scheduler_system_paths(job: ScheduledJob) -> List[str]:
    """获取调度器系统文件路径"""
    import platform

    home = resolve_home()
    paths: List[str] = []

    if platform.system().lower() == "darwin":
        if job.scope_id:
            paths.append(join_path(
                home, "Library", "LaunchAgents",
                f"com.opencode.job.{job.scope_id}.{job.slug}.plist"
            ))
        paths.append(join_path(
            home, "Library", "LaunchAgents",
            f"com.opencode.job.{job.slug}.plist"
        ))
    elif platform.system().lower() == "linux":
        base = join_path(home, ".config", "systemd", "user")
        if job.scope_id:
            paths.append(join_path(base, f"opencode-job-{job.scope_id}-{job.slug}.service"))
            paths.append(join_path(base, f"opencode-job-{job.scope_id}-{job.slug}.timer"))
        paths.append(join_path(base, f"opencode-job-{job.slug}.service"))
        paths.append(join_path(base, f"opencode-job-{job.slug}.timer"))

    return paths


async def _uninstall_job(job: ScheduledJob) -> None:
    """卸载任务"""
    import platform
    import subprocess

    system = platform.system().lower()

    if system == "darwin":
        for plist in _scheduler_system_paths(job):
            if await exists(plist):
                try:
                    subprocess.run(["launchctl", "unload", plist], check=False)
                except (subprocess.SubprocessError, OSError) as e:
                    logger.debug("Failed to unload launchctl {}: {}", plist, e)
                try:
                    os.remove(plist)
                except OSError as e:
                    logger.debug("Failed to remove plist {}: {}", plist, e)
        return

    if system == "linux":
        slug = job.slug
        scoped_timer = f"opencode-job-{job.scope_id}-{slug}.timer" if job.scope_id else None
        legacy_timer = f"opencode-job-{slug}.timer"

        for unit in [scoped_timer, legacy_timer]:
            if unit:
                try:
                    subprocess.run(["systemctl", "--user", "stop", unit], check=False)
                    subprocess.run(["systemctl", "--user", "disable", unit], check=False)
                except (subprocess.SubprocessError, OSError) as e:
                    logger.debug("Failed to stop/disable systemd unit {}: {}", unit, e)

        for path in _scheduler_system_paths(job):
            if await exists(path):
                try:
                    os.remove(path)
                except OSError as e:
                    logger.debug("Failed to remove systemd file {}: {}", path, e)

        try:
            subprocess.run(["systemctl", "--user", "daemon-reload"], check=False)
        except (subprocess.SubprocessError, OSError) as e:
            logger.debug("Failed to reload systemd daemon: {}", e)


async def list_scheduled_jobs(workdir: Optional[str] = None) -> List[ScheduledJob]:
    """
    列出计划任务

    Args:
        workdir: 工作目录过滤

    Returns:
        任务列表
    """
    _ensure_scheduler_supported()

    entries = await _load_all_job_entries()

    filter_root = _normalize_path_for_compare(workdir) if workdir and workdir.strip() else None

    jobs = [
        entry.job for entry in entries
        if not filter_root or (
            entry.job.workdir and
            _normalize_path_for_compare(entry.job.workdir) == filter_root
        )
    ]

    # 按名称排序
    jobs.sort(key=lambda j: j.name.lower())
    return jobs


async def resolve_scheduled_job(
    name: str,
    workdir: Optional[str] = None
) -> Dict[str, Any]:
    """
    解析计划任务

    Args:
        name: 任务名称
        workdir: 工作目录过滤

    Returns:
        {job, jobFile, systemPaths}

    Raises:
        ApiError: 如果任务不存在
    """
    _ensure_scheduler_supported()

    trimmed = name.strip()
    if not trimmed:
        raise ApiError(400, "job_name_required", "name is required")

    entries = await _load_all_job_entries()

    filter_root = _normalize_path_for_compare(workdir) if workdir and workdir.strip() else None

    if filter_root:
        entries = [
            entry for entry in entries
            if entry.job.workdir and
            _normalize_path_for_compare(entry.job.workdir) == filter_root
        ]

    found = _find_job_entry_by_name(entries, trimmed)
    if not found:
        raise ApiError(404, "job_not_found", f'Job "{trimmed}" not found.')

    return {
        "job": found.job,
        "jobFile": found.job_file,
        "systemPaths": _scheduler_system_paths(found.job)
    }


async def delete_scheduled_job(job: ScheduledJob, job_file: str) -> None:
    """
    删除计划任务

    Args:
        job: 任务对象
        job_file: 任务文件路径
    """
    _ensure_scheduler_supported()

    await _uninstall_job(job)

    # 删除任务文件
    if await exists(job_file):
        try:
            os.remove(job_file)
        except OSError as e:
            logger.warning("Failed to delete job file {}: {}", job_file, e)

    # 清理旧版任务文件
    legacy = _legacy_job_file_path(job.slug)
    if legacy != job_file and await exists(legacy):
        try:
            os.remove(legacy)
        except OSError as e:
            logger.debug("Failed to delete legacy job file {}: {}", legacy, e)

    # 清理作用域任务文件
    if job.scope_id:
        scoped = _scoped_job_file_path(job.scope_id, job.slug)
        if scoped != job_file and await exists(scoped):
            try:
                os.remove(scoped)
            except OSError as e:
                logger.debug("Failed to delete scoped job file {}: {}", scoped, e)
