"""
OpenWork Server 配置管理模块

提供服务器配置的解析和构建功能。"""

import os
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .types import (
    ApprovalConfig,
    ApprovalMode,
    LogFormat,
    ServerConfig,
    WorkspaceConfig,
)
from .utils import (
    get_env,
    get_env_int,
    get_env_list,
    join_path,
    parse_list,
    read_json_file,
    resolve_home,
    short_id,
)
from .workspaces import build_workspace_infos

# 默认值
DEFAULT_PORT = 8787
DEFAULT_HOST = "127.0.0.1"
DEFAULT_TIMEOUT_MS = 30000
DEFAULT_LOG_FORMAT = LogFormat.PRETTY
DEFAULT_LOG_REQUESTS = True


def _normalize_log_format(value: Optional[str]) -> Optional[LogFormat]:
    """
    规范化日志格式

    Args:
        value: 日志格式字符串

    Returns:
        LogFormat 枚举值
    """
    if not value:
        return None

    normalized = value.strip().lower()
    if normalized == "json":
        return LogFormat.JSON
    if normalized in ("pretty", "text", "human"):
        return LogFormat.PRETTY
    return None


def _parse_boolean(value: Optional[str]) -> Optional[bool]:
    """
    解析布尔值

    Args:
        value: 字符串值

    Returns:
        布尔值
    """
    if not value:
        return None
    normalized = value.strip().lower()
    if normalized in ("true", "1", "yes", "on"):
        return True
    if normalized in ("false", "0", "no", "off"):
        return False
    return None


@dataclass
class CliArgs:
    """命令行参数"""
    config_path: Optional[str] = None
    host: Optional[str] = None
    port: Optional[int] = None
    token: Optional[str] = None
    host_token: Optional[str] = None
    approval_mode: Optional[ApprovalMode] = None
    approval_timeout_ms: Optional[int] = None
    opencode_base_url: Optional[str] = None
    opencode_directory: Optional[str] = None
    opencode_username: Optional[str] = None
    opencode_password: Optional[str] = None
    workspaces: List[str] = field(default_factory=list)
    cors_origins: Optional[List[str]] = None
    read_only: Optional[bool] = None
    verbose: Optional[bool] = None
    log_format: Optional[LogFormat] = None
    log_requests: Optional[bool] = None
    version: Optional[bool] = None
    help: Optional[bool] = None


def parse_cli_args(argv: List[str]) -> CliArgs:
    """
    解析命令行参数

    Args:
        argv: 参数列表

    Returns:
        CliArgs 对象
    """
    args = CliArgs()
    i = 0

    while i < len(argv):
        value = argv[i]
        if not value:
            i += 1
            continue

        if value in ("--help", "-h"):
            args.help = True
            i += 1
            continue

        if value == "--version":
            args.version = True
            i += 1
            continue

        if value == "--verbose":
            args.verbose = True
            i += 1
            continue

        if value == "--log-format":
            if i + 1 < len(argv):
                args.log_format = _normalize_log_format(argv[i + 1])
            i += 2
            continue

        if value == "--log-requests":
            args.log_requests = True
            i += 1
            continue

        if value == "--no-log-requests":
            args.log_requests = False
            i += 1
            continue

        if value == "--config":
            if i + 1 < len(argv):
                args.config_path = argv[i + 1]
            i += 2
            continue

        if value == "--host":
            if i + 1 < len(argv):
                args.host = argv[i + 1]
            i += 2
            continue

        if value == "--port":
            if i + 1 < len(argv):
                try:
                    args.port = int(argv[i + 1])
                except ValueError:
                    pass
            i += 2
            continue

        if value == "--token":
            if i + 1 < len(argv):
                args.token = argv[i + 1]
            i += 2
            continue

        if value == "--host-token":
            if i + 1 < len(argv):
                args.host_token = argv[i + 1]
            i += 2
            continue

        if value == "--approval":
            if i + 1 < len(argv):
                mode = argv[i + 1]
                if mode in ("manual", "auto"):
                    args.approval_mode = ApprovalMode(mode)
            i += 2
            continue

        if value == "--approval-timeout":
            if i + 1 < len(argv):
                try:
                    args.approval_timeout_ms = int(argv[i + 1])
                except ValueError:
                    pass
            i += 2
            continue

        if value == "--workspace":
            if i + 1 < len(argv):
                args.workspaces.append(argv[i + 1])
            i += 2
            continue

        if value == "--cors":
            if i + 1 < len(argv):
                args.cors_origins = parse_list(argv[i + 1])
            i += 2
            continue

        if value == "--read-only":
            args.read_only = True
            i += 1
            continue

        i += 1

    return args


def print_help() -> None:
    """打印帮助信息"""
    message = """
openwork-server

Options:
  --config <path>          Path to server.json
  --host <host>            Hostname (default 127.0.0.1)
  --port <port>            Port (default 8787)
  --token <token>          Client bearer token
  --host-token <token>     Host approval token
  --approval <mode>        manual | auto
  --approval-timeout <ms>  Approval timeout
  --workspace <path>       Workspace root (repeatable)
  --cors <origins>         Comma-separated origins or *
  --read-only              Disable writes
  --log-format <format>    Log output format: pretty | json
  --log-requests           Log incoming requests (default: true)
  --no-log-requests        Disable request logging
  --verbose                Print resolved config
  --version                Show version
  --help, -h               Show this help
"""
    print(message)


@dataclass
class FileConfig:
    """文件配置"""
    host: Optional[str] = None
    port: Optional[int] = None
    token: Optional[str] = None
    host_token: Optional[str] = None
    approval: Optional[Dict[str, Any]] = None
    workspaces: Optional[List[WorkspaceConfig]] = None
    cors_origins: Optional[List[str]] = None
    authorized_roots: Optional[List[str]] = None
    read_only: Optional[bool] = None
    opencode_username: Optional[str] = None
    opencode_password: Optional[str] = None
    log_format: Optional[LogFormat] = None
    log_requests: Optional[bool] = None


async def _load_file_config(config_path: str) -> FileConfig:
    """
    加载文件配置

    Args:
        config_path: 配置文件路径

    Returns:
        FileConfig 对象
    """
    data = await read_json_file(config_path)
    if not data:
        return FileConfig()

    return FileConfig(
        host=data.get("host"),
        port=data.get("port"),
        token=data.get("token"),
        host_token=data.get("hostToken"),
        approval=data.get("approval"),
        workspaces=[
            WorkspaceConfig(
                path=w.get("path", ""),
                name=w.get("name"),
                workspace_type=w.get("workspaceType"),
                base_url=w.get("baseUrl"),
                directory=w.get("directory"),
                opencode_username=w.get("opencodeUsername"),
                opencode_password=w.get("opencodePassword")
            )
            for w in data.get("workspaces", [])
            if w.get("path")
        ],
        cors_origins=data.get("corsOrigins"),
        authorized_roots=data.get("authorizedRoots"),
        read_only=data.get("readOnly"),
        opencode_username=data.get("opencodeUsername"),
        opencode_password=data.get("opencodePassword"),
        log_format=_normalize_log_format(data.get("logFormat")),
        log_requests=data.get("logRequests")
    )


async def resolve_server_config(cli: CliArgs) -> ServerConfig:
    """
    解析服务器配置

    Args:
        cli: 命令行参数

    Returns:
        ServerConfig 对象
    """
    import time

    # 确定配置文件路径
    env_config_path = get_env("OPENWORK_SERVER_CONFIG")
    config_path = cli.config_path or env_config_path or join_path(
        resolve_home(), ".config", "openwork", "server.json"
    )

    file_config = await _load_file_config(config_path)
    config_dir = os.path.dirname(config_path)

    # 解析工作空间
    env_workspaces = get_env_list("OPENWORK_WORKSPACES")

    if cli.workspaces:
        workspace_configs = [WorkspaceConfig(path=p) for p in cli.workspaces]
    elif env_workspaces:
        workspace_configs = [WorkspaceConfig(path=p) for p in env_workspaces]
    else:
        workspace_configs = file_config.workspaces or []

    # 构建工作空间信息
    workspaces = build_workspace_infos(workspace_configs, config_dir)

    # 解析 Token
    token_from_env = get_env("OPENWORK_TOKEN")
    host_token_from_env = get_env("OPENWORK_HOST_TOKEN")

    token = cli.token or token_from_env or file_config.token or short_id()
    host_token = cli.host_token or host_token_from_env or file_config.host_token or short_id()

    # 确定 Token 来源
    if cli.token:
        token_source = "cli"
    elif token_from_env:
        token_source = "env"
    elif file_config.token:
        token_source = "file"
    else:
        token_source = "generated"

    if cli.host_token:
        host_token_source = "cli"
    elif host_token_from_env:
        host_token_source = "env"
    elif file_config.host_token:
        host_token_source = "file"
    else:
        host_token_source = "generated"

    # 解析审批配置
    approval_mode = (
        cli.approval_mode or
        (ApprovalMode(get_env("OPENWORK_APPROVAL_MODE")) if get_env("OPENWORK_APPROVAL_MODE") else None) or
        (ApprovalMode(file_config.approval.get("mode")) if file_config.approval else None) or
        ApprovalMode.MANUAL
    )

    approval_timeout_ms = (
        cli.approval_timeout_ms or
        get_env_int("OPENWORK_APPROVAL_TIMEOUT_MS") or
        (file_config.approval.get("timeoutMs") if file_config.approval else None) or
        DEFAULT_TIMEOUT_MS
    )

    approval = ApprovalConfig(
        mode=approval_mode,
        timeout_ms=approval_timeout_ms
    )

    # 解析 CORS
    env_cors = get_env("OPENWORK_CORS_ORIGINS")
    parsed_env_cors = parse_list(env_cors) if env_cors else None
    cors_origins = cli.cors_origins or parsed_env_cors or file_config.cors_origins or ["*"]

    # 解析只读模式
    env_read_only = get_env("OPENWORK_READONLY")
    parsed_read_only = _parse_boolean(env_read_only)
    read_only = cli.read_only or parsed_read_only or file_config.read_only or False

    # 解析日志格式
    env_log_format = get_env("OPENWORK_LOG_FORMAT")
    log_format = (
        cli.log_format or
        _normalize_log_format(env_log_format) or
        file_config.log_format or
        DEFAULT_LOG_FORMAT
    )

    # 解析日志请求
    env_log_requests = _parse_boolean(get_env("OPENWORK_LOG_REQUESTS"))
    log_requests = (
        cli.log_requests if cli.log_requests is not None else
        env_log_requests if env_log_requests is not None else
        file_config.log_requests if file_config.log_requests is not None else
        DEFAULT_LOG_REQUESTS
    )

    # 解析授权根目录
    if file_config.authorized_roots:
        authorized_roots = [
            os.path.abspath(join_path(config_dir, root))
            for root in file_config.authorized_roots
        ]
    else:
        authorized_roots = [w.path for w in workspaces]

    # 解析主机和端口
    host = cli.host or get_env("OPENWORK_HOST") or file_config.host or DEFAULT_HOST
    port = cli.port or get_env_int("OPENWORK_PORT") or file_config.port or DEFAULT_PORT

    return ServerConfig(
        host=host,
        port=port,
        token=token,
        host_token=host_token,
        config_path=config_path,
        approval=approval,
        cors_origins=cors_origins,
        workspaces=workspaces,
        authorized_roots=authorized_roots,
        read_only=read_only,
        started_at=int(time.time() * 1000),
        token_source=token_source,
        host_token_source=host_token_source,
        log_format=log_format,
        log_requests=log_requests
    )
