"""
OpenWork Server 类型定义模块

定义了 OpenWork Server 使用的所有数据类型和接口。
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class WorkspaceType(str, Enum):
    """工作空间类型"""
    LOCAL = "local"
    REMOTE = "remote"


class ApprovalMode(str, Enum):
    """审批模式"""
    MANUAL = "manual"
    AUTO = "auto"


class TokenScope(str, Enum):
    """Token 权限范围"""
    OWNER = "owner"
    COLLABORATOR = "collaborator"
    VIEWER = "viewer"


class SandboxBackend(str, Enum):
    """沙箱后端类型"""
    NONE = "none"
    DOCKER = "docker"
    CONTAINER = "container"


class ProviderPlacement(str, Enum):
    """提供者部署位置"""
    IN_SANDBOX = "in-sandbox"
    HOST_MACHINE = "host-machine"
    CLIENT_MACHINE = "client-machine"
    EXTERNAL = "external"


class LogFormat(str, Enum):
    """日志格式"""
    PRETTY = "pretty"
    JSON = "json"


@dataclass
class WorkspaceConfig:
    """工作空间配置"""
    path: str
    name: Optional[str] = None
    workspace_type: Optional[WorkspaceType] = None
    base_url: Optional[str] = None
    directory: Optional[str] = None
    opencode_username: Optional[str] = None
    opencode_password: Optional[str] = None


@dataclass
class WorkspaceInfo:
    """工作空间信息"""
    id: str
    name: str
    path: str
    workspace_type: WorkspaceType
    base_url: Optional[str] = None
    directory: Optional[str] = None
    opencode_username: Optional[str] = None
    opencode_password: Optional[str] = None
    opencode: Optional[Dict[str, Any]] = None


@dataclass
class ApprovalConfig:
    """审批配置"""
    mode: ApprovalMode
    timeout_ms: int


@dataclass
class ServerConfig:
    """服务器配置"""
    host: str
    port: int
    token: str
    host_token: str
    config_path: Optional[str] = None
    approval: Optional[ApprovalConfig] = None
    cors_origins: List[str] = field(default_factory=lambda: ["*"])
    workspaces: List[WorkspaceInfo] = field(default_factory=list)
    authorized_roots: List[str] = field(default_factory=list)
    read_only: bool = False
    started_at: int = 0
    token_source: str = "generated"
    host_token_source: str = "generated"
    log_format: LogFormat = LogFormat.PRETTY
    log_requests: bool = True


@dataclass
class Capabilities:
    """服务器能力描述"""
    schema_version: int = 1
    server_version: str = "0.1.0"
    skills: Dict[str, Any] = field(default_factory=lambda: {"read": True, "write": True, "source": "openwork"})
    hub: Dict[str, Any] = field(default_factory=lambda: {
        "skills": {
            "read": True,
            "install": True,
            "repo": {"owner": "different-ai", "name": "openwork-hub", "ref": "main"}
        }
    })
    plugins: Dict[str, Any] = field(default_factory=lambda: {"read": True, "write": True})
    mcp: Dict[str, Any] = field(default_factory=lambda: {"read": True, "write": True})
    commands: Dict[str, Any] = field(default_factory=lambda: {"read": True, "write": True})
    config: Dict[str, Any] = field(default_factory=lambda: {"read": True, "write": True})
    approvals: Dict[str, Any] = field(default_factory=lambda: {"mode": "manual", "timeout_ms": 30000})
    sandbox: Dict[str, Any] = field(default_factory=lambda: {"enabled": False, "backend": "none"})
    ui: Dict[str, Any] = field(default_factory=lambda: {"toy": True})
    tokens: Dict[str, Any] = field(default_factory=lambda: {"scoped": True, "scopes": ["owner", "collaborator", "viewer"]})
    proxy: Dict[str, Any] = field(default_factory=lambda: {"opencode": False, "opencode_router": False})
    tool_providers: Dict[str, Any] = field(default_factory=lambda: {
        "browser": {"enabled": False, "placement": "external", "mode": "none"},
        "files": {
            "injection": True,
            "outbox": True,
            "inbox_path": ".opencode/openwork/inbox/",
            "outbox_path": ".opencode/openwork/outbox/",
            "max_bytes": 50000000
        }
    })


class ReloadReason(str, Enum):
    """重载原因"""
    PLUGINS = "plugins"
    SKILLS = "skills"
    MCP = "mcp"
    CONFIG = "config"
    AGENTS = "agents"
    COMMANDS = "commands"


@dataclass
class ReloadTrigger:
    """重载触发器"""
    type: str
    name: Optional[str] = None
    action: Optional[str] = None
    path: Optional[str] = None


@dataclass
class ReloadEvent:
    """重载事件"""
    id: str
    seq: int
    workspace_id: str
    reason: ReloadReason
    timestamp: int
    trigger: Optional[ReloadTrigger] = None


@dataclass
class ApiErrorBody:
    """API 错误响应体"""
    code: str
    message: str
    details: Optional[Any] = None


@dataclass
class PluginItem:
    """插件项"""
    spec: str
    source: str
    scope: str
    path: Optional[str] = None


@dataclass
class McpItem:
    """MCP 项"""
    name: str
    config: Dict[str, Any]
    source: str
    disabled_by_tools: Optional[bool] = None


@dataclass
class SkillItem:
    """技能项"""
    name: str
    path: str
    description: str
    scope: str
    trigger: Optional[str] = None


@dataclass
class HubSkillItem:
    """Hub 技能项"""
    name: str
    description: str
    trigger: Optional[str] = None
    source: Optional[Dict[str, str]] = None


@dataclass
class CommandItem:
    """命令项"""
    name: str
    template: str
    scope: str
    description: Optional[str] = None
    agent: Optional[str] = None
    model: Optional[str] = None
    subtask: Optional[bool] = None


@dataclass
class Actor:
    """操作者信息"""
    type: str
    client_id: Optional[str] = None
    token_hash: Optional[str] = None
    scope: Optional[TokenScope] = None


@dataclass
class ApprovalRequest:
    """审批请求"""
    id: str
    workspace_id: str
    action: str
    summary: str
    paths: List[str]
    created_at: int
    actor: Actor


@dataclass
class AuditEntry:
    """审计日志条目"""
    id: str
    workspace_id: str
    actor: Actor
    action: str
    target: str
    summary: str
    timestamp: int


@dataclass
class ScheduledJobRun:
    """计划任务运行配置"""
    prompt: Optional[str] = None
    command: Optional[str] = None
    arguments: Optional[str] = None
    files: Optional[List[str]] = None
    agent: Optional[str] = None
    model: Optional[str] = None
    variant: Optional[str] = None
    title: Optional[str] = None
    share: Optional[bool] = None
    continue_session: Optional[bool] = field(default=None, metadata={"name": "continue"})
    session: Optional[str] = None
    run_format: Optional[str] = None
    attach_url: Optional[str] = None
    port: Optional[int] = None


@dataclass
class ScheduledJob:
    """计划任务"""
    slug: str
    name: str
    schedule: str
    created_at: str
    scope_id: Optional[str] = None
    timeout_seconds: Optional[int] = None
    invocation: Optional[Dict[str, Any]] = None
    prompt: Optional[str] = None
    attach_url: Optional[str] = None
    run: Optional[ScheduledJobRun] = None
    source: Optional[str] = None
    workdir: Optional[str] = None
    updated_at: Optional[str] = None
    last_run_at: Optional[str] = None
    last_run_exit_code: Optional[int] = None
    last_run_error: Optional[str] = None
    last_run_source: Optional[str] = None
    last_run_status: Optional[str] = None


@dataclass
class TokenRecord:
    """Token 记录"""
    id: str
    hash: str
    scope: TokenScope
    created_at: int
    label: Optional[str] = None
