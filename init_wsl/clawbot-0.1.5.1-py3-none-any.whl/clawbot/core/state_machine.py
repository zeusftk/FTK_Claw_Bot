"""
Project State Machine - 项目状态机

管理项目生命周期的状态转换。
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pathlib import Path

logger = logging.getLogger(__name__)


class ProjectState(Enum):
    """项目状态枚举"""
    IDLE = "idle"
    ANALYZING = "analyzing"
    PENDING_CONFIRMATION = "pending_confirmation"
    RUNNING = "running"
    WAITING_FEEDBACK = "waiting_feedback"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class InvalidStateTransitionError(Exception):
    """无效状态转换异常"""
    pass


InvalidStateTransition = InvalidStateTransitionError


@dataclass
class Project:
    """项目数据类"""
    project_id: str
    user_id: str
    original_idea: str
    state: ProjectState = ProjectState.IDLE
    workspace: Path | None = None
    processed_idea: Any | None = None
    similar_cases: list[dict] = field(default_factory=list)
    session_id: str | None = None
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    started_at: datetime | None = None
    completed_at: datetime | None = None
    result: Any | None = None
    feedback: Any | None = None
    route_decision: Any | None = None
    execution_result: Any | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def duration_seconds(self) -> float:
        """计算项目持续时间"""
        if self.started_at and self.completed_at:
            return (self.completed_at - self.started_at).total_seconds()
        return 0.0

    @property
    def is_active(self) -> bool:
        """检查项目是否活跃"""
        return self.state in [
            ProjectState.ANALYZING,
            ProjectState.PENDING_CONFIRMATION,
            ProjectState.RUNNING,
        ]


class ProjectStateMachine:
    """
    项目状态机

    状态转换规则：
    IDLE → ANALYZING → PENDING_CONFIRMATION → RUNNING → WAITING_FEEDBACK → COMPLETED
                  ↓                          ↓               RUNNING ──────────────────→ FAILED
                  ↓              CANCELLED
    """

    TRANSITIONS: dict[ProjectState, list[ProjectState]] = {
        ProjectState.IDLE: [ProjectState.ANALYZING],
        ProjectState.ANALYZING: [
            ProjectState.PENDING_CONFIRMATION,
            ProjectState.RUNNING,
            ProjectState.FAILED,
        ],
        ProjectState.PENDING_CONFIRMATION: [
            ProjectState.RUNNING,
            ProjectState.CANCELLED,
        ],
        ProjectState.RUNNING: [
            ProjectState.WAITING_FEEDBACK,
            ProjectState.FAILED,
        ],
        ProjectState.WAITING_FEEDBACK: [ProjectState.COMPLETED],
        ProjectState.COMPLETED: [],
        ProjectState.FAILED: [],
        ProjectState.CANCELLED: [],
    }

    def __init__(self):
        self._transition_history: list[dict] = []

    def transition(
        self,
        project: Project,
        new_state: ProjectState,
        reason: str | None = None,
    ) -> bool:
        """
        执行状态转换

        Args:
            project: 项目对象
            new_state: 目标状态
            reason: 转换原因

        Returns:
            是否转换成功

        Raises:
            InvalidStateTransition: 无效的状态转换
        """
        if not self.can_transition(project, new_state):
            raise InvalidStateTransition(
                f"Cannot transition from {project.state.value} to {new_state.value}"
            )

        old_state = project.state
        project.state = new_state
        project.updated_at = datetime.now()

        self._record_transition(project.project_id, old_state, new_state, reason)

        logger.info(
            f"Project {project.project_id} state transition: "
            f"{old_state.value} → {new_state.value}"
            f"{f' ({reason})' if reason else ''}"
        )

        return True

    def can_transition(self, project: Project, new_state: ProjectState) -> bool:
        """
        检查是否可以转换到目标状态

        Args:
            project: 项目对象
            new_state: 目标状态

        Returns:
            是否可以转换
        """
        return new_state in self.TRANSITIONS.get(project.state, [])

    def get_valid_transitions(self, project: Project) -> list[ProjectState]:
        """
        获取所有有效的目标状态

        Args:
            project: 项目对象

        Returns:
            有效目标状态列表
        """
        return list(self.TRANSITIONS.get(project.state, []))

    def _record_transition(
        self,
        project_id: str,
        old_state: ProjectState,
        new_state: ProjectState,
        reason: str | None,
    ) -> None:
        """记录状态转换历史"""
        self._transition_history.append({
            "project_id": project_id,
            "from_state": old_state.value,
            "to_state": new_state.value,
            "reason": reason,
            "timestamp": datetime.now().isoformat(),
        })

        if len(self._transition_history) > 1000:
            self._transition_history = self._transition_history[-500:]

    def get_transition_history(
        self,
        project_id: str | None = None,
        limit: int = 100,
    ) -> list[dict]:
        """
        获取状态转换历史

        Args:
            project_id: 项目 ID（可选，不指定则返回所有）
            limit: 返回数量限制

        Returns:
            状态转换历史列表
        """
        history = self._transition_history

        if project_id:
            history = [h for h in history if h["project_id"] == project_id]

        return history[-limit:]

    def reset(self, project: Project) -> None:
        """
        重置项目状态到 IDLE

        Args:
            project: 项目对象
        """
        project.state = ProjectState.IDLE
        project.updated_at = datetime.now()
        project.started_at = None
        project.completed_at = None
        project.result = None
        project.feedback = None
