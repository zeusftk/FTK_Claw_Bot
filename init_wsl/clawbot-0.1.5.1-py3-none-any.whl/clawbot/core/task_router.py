"""
UnifiedTaskRouter - 统一任务路由器

在 AgentLoop 层面决定执行路径：
- CONVERSATION: 纯对话，LLM 直接响应
- OPENWORK_EXECUTION: 需要 OpenWork 执行
- LOCAL_TOOL: 本地工具快速执行
- SYSTEM_COMMAND: 系统命令
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from loguru import logger

from clawbot.agent.intent_classifier import TaskCategory


@dataclass
class RouteDecision:
    """路由决策结果"""
    category: TaskCategory
    handler: str
    confidence: float = 1.0
    task_type: str | None = None
    reasoning: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)


class UnifiedTaskRouter:
    """
    统一任务路由器

    职责：
    1. 分析用户请求意图
    2. 决定执行路径
    3. 协调各执行器

    与 IntentClassifier 保持一致，使用相同的 TaskCategory 分类。
    """

    EXECUTION_KEYWORDS = [
        "实现", "开发", "创建", "写一个", "编写", "编码",
        "implement", "develop", "create", "build", "write",
        "修复", "bug", "fix", "debug", "调试",
        "重构", "refactor", "优化", "optimize",
        "配置", "设置", "安装", "部署",
        "config", "setup", "install", "deploy",
        "搜索", "查找", "检索", "搜索代码",
        "search", "find", "grep",
        "读取", "写入", "创建文件", "删除文件",
        "read", "write", "create", "delete",
        "测试", "运行", "执行",
        "test", "run", "execute",
        "分析", "analyze", "检查", "check",
        "生成", "generate", "构建", "build",
        "更新", "update", "修改", "modify",
        "删除", "remove", "清理", "clean",
        "克隆", "clone", "下载", "download",
        "编译", "compile", "打包", "package",
    ]

    CONVERSATION_KEYWORDS = [
        "你好", "hello", "hi", "早上好", "晚上好",
        "谢谢", "thanks", "thank you",
        "怎么样", "how are",
        "聊天", "chat", "talk",
        "再见", "bye", "goodbye",
    ]

    SYSTEM_COMMANDS = [
        "/new", "/help", "/stop", "/status",
        "/openwork", "/service",
    ]

    TASK_TYPE_PATTERNS = {
        "programming": [
            r"实现", r"开发", r"创建.*项目", r"写一个",
            r"implement", r"develop", r"create", r"build",
            r"编程", r"代码", r"程序", r"脚本",
            r"修复", r"bug", r"fix", r"debug",
            r"重构", r"refactor",
        ],
        "configuration": [
            r"配置", r"设置", r"安装.*环境",
            r"config", r"setup", r"install",
            r"初始化", r"initialize",
        ],
        "search": [
            r"搜索", r"查找", r"检索",
            r"search", r"find", r"grep",
            r"定位", r"locate",
        ],
        "debugging": [
            r"调试", r"debug", r"排查",
            r"诊断", r"diagnose",
            r"错误", r"error", r"异常", r"exception",
        ],
        "installation": [
            r"安装", r"install", r"部署",
            r"deploy", r"setup",
            r"下载", r"download",
        ],
        "file_operation": [
            r"读取", r"写入", r"创建文件", r"删除文件",
            r"read", r"write", r"create.*file", r"delete.*file",
            r"复制", r"copy", r"移动", r"move",
        ],
        "testing": [
            r"测试", r"test", r"单元测试",
            r"unit test", r"集成测试",
        ],
    }

    EXECUTION_THRESHOLD = 0.4
    CONVERSATION_THRESHOLD = 0.5

    def __init__(
        self,
        openwork_enabled: bool = True,
        execution_threshold: float | None = None,
        conversation_threshold: float | None = None,
    ):
        self.openwork_enabled = openwork_enabled
        self.execution_threshold = execution_threshold or self.EXECUTION_THRESHOLD
        self.conversation_threshold = conversation_threshold or self.CONVERSATION_THRESHOLD

        self._stats = {
            "total_routed": 0,
            "by_category": {cat.value: 0 for cat in TaskCategory},
        }

    def route(self, message: str, context: dict[str, Any] | None = None) -> RouteDecision:
        """
        路由决策

        Args:
            message: 用户消息
            context: 额外上下文

        Returns:
            RouteDecision: 包含目标路由和执行参数
        """
        self._stats["total_routed"] += 1

        message_lower = message.lower().strip()

        if not message_lower:
            decision = RouteDecision(
                category=TaskCategory.CONVERSATION,
                handler="llm_direct",
                reasoning="Empty message",
            )
            self._stats["by_category"][decision.category.value] += 1
            return decision

        if self._is_system_command(message_lower):
            decision = RouteDecision(
                category=TaskCategory.SYSTEM_COMMAND,
                handler="system",
                reasoning="System command detected",
            )
            self._stats["by_category"][decision.category.value] += 1
            return decision

        execution_score = self._calculate_execution_score(message_lower)
        conversation_score = self._calculate_conversation_score(message_lower)

        if execution_score > self.execution_threshold:
            task_type = self._detect_task_type(message_lower)
            decision = RouteDecision(
                category=TaskCategory.OPENWORK_EXECUTION if self.openwork_enabled else TaskCategory.LOCAL_TOOL,
                handler="openwork" if self.openwork_enabled else "local_tools",
                confidence=min(execution_score, 1.0),
                task_type=task_type,
                reasoning=f"Execution task detected (score: {execution_score:.2f}, type: {task_type})",
            )
        elif conversation_score > self.conversation_threshold:
            decision = RouteDecision(
                category=TaskCategory.CONVERSATION,
                handler="llm_direct",
                confidence=min(conversation_score, 1.0),
                reasoning=f"Conversation detected (score: {conversation_score:.2f})",
            )
        else:
            decision = RouteDecision(
                category=TaskCategory.LOCAL_TOOL,
                handler="local_tools",
                confidence=0.5,
                reasoning=f"Default routing (exec: {execution_score:.2f}, conv: {conversation_score:.2f})",
            )

        self._stats["by_category"][decision.category.value] += 1
        return decision

    def route_with_context(self, message: str, context: dict[str, Any]) -> RouteDecision:
        """
        带上下文的路由决策

        考虑频道特性和用户偏好
        """
        base_decision = self.route(message, context)

        channel = context.get("channel", "")

        if channel == "cli":
            if base_decision.category == TaskCategory.LOCAL_TOOL:
                base_decision.confidence *= 1.1
        elif channel in ["telegram", "discord", "slack"]:
            if base_decision.category == TaskCategory.CONVERSATION:
                base_decision.confidence *= 1.1

        return base_decision

    def _is_system_command(self, message: str) -> bool:
        """检查是否为系统命令"""
        for cmd in self.SYSTEM_COMMANDS:
            if message.startswith(cmd.lower()):
                return True
        return False

    def _calculate_execution_score(self, message: str) -> float:
        """计算执行意图分数"""
        score = 0.0

        for keyword in self.EXECUTION_KEYWORDS:
            if keyword.lower() in message:
                score += 0.1

        code_patterns = [
            r'\bdef\s+\w+',
            r'\bclass\s+\w+',
            r'\bfunction\s+\w+',
            r'\bimport\s+\w+',
            r'\bfrom\s+\w+\s+import',
            r'```[\s\S]*?```',
            r'`[^`]+`',
            r'\b(git|npm|pip|cargo|go)\s+',
        ]

        for pattern in code_patterns:
            if re.search(pattern, message, re.IGNORECASE):
                score += 0.15

        path_patterns = [
            r'[a-zA-Z0-9_\-./]+\.(py|js|ts|go|rs|java|cpp|c|h)',
            r'/[a-zA-Z0-9_\-/]+',
            r'~[a-zA-Z0-9_\-/]+',
        ]

        for pattern in path_patterns:
            if re.search(pattern, message):
                score += 0.1

        return min(score, 1.0)

    def _calculate_conversation_score(self, message: str) -> float:
        """计算对话意图分数"""
        score = 0.0

        for keyword in self.CONVERSATION_KEYWORDS:
            if keyword.lower() in message:
                score += 0.25

        if len(message) < 20:
            score += 0.2

        question_patterns = [
            r'^(什么|为什么|怎么|如何|哪)',
            r'^(what|why|how|where|when|who)',
            r'\?$',
        ]

        for pattern in question_patterns:
            if re.search(pattern, message, re.IGNORECASE):
                score += 0.15

        return min(score, 1.0)

    def _detect_task_type(self, message: str) -> str:
        """检测任务类型"""
        for task_type, patterns in self.TASK_TYPE_PATTERNS.items():
            for pattern in patterns:
                if re.search(pattern, message, re.IGNORECASE):
                    return task_type

        return "general"

    def get_stats(self) -> dict[str, Any]:
        """获取路由统计"""
        return {
            **self._stats,
            "openwork_enabled": self.openwork_enabled,
            "execution_threshold": self.execution_threshold,
            "conversation_threshold": self.conversation_threshold,
        }

    def update_thresholds(
        self,
        execution: float | None = None,
        conversation: float | None = None,
    ) -> None:
        """更新阈值"""
        if execution is not None:
            self.execution_threshold = execution
        if conversation is not None:
            self.conversation_threshold = conversation
        logger.info(
            f"Thresholds updated: execution={self.execution_threshold}, "
            f"conversation={self.conversation_threshold}"
        )
