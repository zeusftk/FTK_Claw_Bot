"""Qwen Portal OAuth Provider.

Uses OAuth device code flow for authentication with Qwen's free-tier API.
Supports automatic token refresh and credential sync from Qwen CLI.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import secrets
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, AsyncGenerator

import httpx
from loguru import logger

from nanobot.providers.base import LLMProvider, LLMResponse, ToolCallRequest

QWEN_OAUTH_BASE_URL = "https://chat.qwen.ai"
QWEN_OAUTH_DEVICE_CODE_ENDPOINT = f"{QWEN_OAUTH_BASE_URL}/api/v1/oauth2/device/code"
QWEN_OAUTH_TOKEN_ENDPOINT = f"{QWEN_OAUTH_BASE_URL}/api/v1/oauth2/token"
QWEN_OAUTH_CLIENT_ID = "f0304373b74a44d2b584a3fb70ca9e56"
QWEN_OAUTH_SCOPE = "openid profile email model.completion"
QWEN_OAUTH_GRANT_TYPE = "urn:ietf:params:oauth:grant-type:device_code"

QWEN_PORTAL_BASE_URL = "https://portal.qwen.ai/v1"
QWEN_CLI_CREDENTIALS_PATH = "~/.qwen/oauth_creds.json"

DEFAULT_MODEL = "qwen-portal/coder-model"
DEFAULT_MAX_TOKENS = 8192
DEFAULT_CONTEXT_WINDOW = 128000


@dataclass
class QwenOAuthToken:
    access: str
    refresh: str
    expires: float
    resource_url: str | None = None

    @property
    def is_expired(self) -> bool:
        return time.time() >= self.expires - 60

    def to_dict(self) -> dict[str, Any]:
        return {
            "access": self.access,
            "refresh": self.refresh,
            "expires": self.expires,
            "resource_url": self.resource_url,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "QwenOAuthToken":
        return cls(
            access=data["access"],
            refresh=data["refresh"],
            expires=data["expires"],
            resource_url=data.get("resource_url"),
        )


@dataclass
class QwenDeviceAuthorization:
    device_code: str
    user_code: str
    verification_uri: str
    verification_uri_complete: str | None = None
    expires_in: int = 300
    interval: int = 2


def _generate_pkce() -> tuple[str, str]:
    verifier = secrets.token_urlsafe(32)
    challenge = hashlib.sha256(verifier.encode()).digest()
    challenge_b64 = secrets.token_hex(32)
    import base64
    challenge_b64 = base64.urlsafe_b64encode(challenge).decode().rstrip("=")
    return verifier, challenge_b64


def _to_form_urlencoded(data: dict[str, str]) -> str:
    return "&".join(f"{k}={v}" for k, v in data.items())


class QwenPortalProvider(LLMProvider):
    """Qwen Portal OAuth-based provider for free-tier Qwen models."""

    def __init__(self, default_model: str = DEFAULT_MODEL):
        super().__init__(api_key=None, api_base=QWEN_PORTAL_BASE_URL)
        self.default_model = default_model
        self._token: QwenOAuthToken | None = None
        self._token_path = Path(QWEN_CLI_CREDENTIALS_PATH).expanduser()
        self._load_token()

    def _load_token(self) -> None:
        if self._token_path.exists():
            try:
                data = json.loads(self._token_path.read_text())
                self._token = QwenOAuthToken.from_dict(data)
                logger.debug(f"Loaded Qwen token from {self._token_path}")
            except Exception as e:
                logger.warning(f"Failed to load Qwen token: {e}")

    def _save_token(self) -> None:
        if self._token:
            self._token_path.parent.mkdir(parents=True, exist_ok=True)
            self._token_path.write_text(json.dumps(self._token.to_dict(), indent=2))
            logger.debug(f"Saved Qwen token to {self._token_path}")

    async def _ensure_token(self) -> str:
        if self._token and not self._token.is_expired:
            return self._token.access

        if self._token and self._token.refresh:
            try:
                await self._refresh_token()
                return self._token.access
            except Exception as e:
                logger.warning(f"Token refresh failed: {e}, need re-login")

        raise QwenOAuthError(
            "Qwen OAuth token not found or expired. "
            "Run 'nanobot qwen-login' to authenticate."
        )

    async def _refresh_token(self) -> None:
        if not self._token:
            raise QwenOAuthError("No token to refresh")

        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                QWEN_OAUTH_TOKEN_ENDPOINT,
                headers={
                    "Content-Type": "application/x-www-form-urlencoded",
                    "Accept": "application/json",
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                    "Origin": "https://chat.qwen.ai",
                    "Referer": "https://chat.qwen.ai/",
                },
                data=_to_form_urlencoded({
                    "grant_type": "refresh_token",
                    "refresh_token": self._token.refresh,
                    "client_id": QWEN_OAUTH_CLIENT_ID,
                }),
            )

            if response.status_code != 200:
                raise QwenOAuthError(f"Token refresh failed: {response.text}")

            payload = response.json()
            self._token = QwenOAuthToken(
                access=payload["access_token"],
                refresh=payload["refresh_token"],
                expires=time.time() + payload["expires_in"],
                resource_url=payload.get("resource_url"),
            )
            self._save_token()
            logger.info("Qwen OAuth token refreshed successfully")

    async def login(
        self,
        open_url: bool = True,
        print_instructions: bool = True,
    ) -> QwenOAuthToken:
        verifier, challenge = _generate_pkce()
        device_auth = await self._request_device_code(challenge)

        # Build verification URL - verification_uri_complete should include user_code
        # If not available, append user_code to verification_uri
        if device_auth.verification_uri_complete:
            verification_url = device_auth.verification_uri_complete
        else:
            # Append user_code as query parameter for device flow
            import urllib.parse
            base_url = device_auth.verification_uri
            separator = "&" if "?" in base_url else "?"
            verification_url = f"{base_url}{separator}user_code={urllib.parse.quote(device_auth.user_code)}"

        if print_instructions:
            print("\nQwen OAuth Login")
            print("=" * 40)
            print(f"1. Open: {verification_url}")
            print(f"2. Enter code: {device_auth.user_code}")
            print("=" * 40 + "\n")

        if open_url:
            try:
                import os
                import json
                from pathlib import Path

                # Detect WSL environment and use Windows browser
                if os.environ.get("WSL_DISTRO_NAME") or os.environ.get("WSLENV"):
                    # Running in WSL, try WindowsBridge first, then fallback
                    bridge_url = False
                    try:
                        from nanobot.agent.tools.windows_gui import WindowsBridgeClient

                        # Read WindowsBridge config from config.json
                        config_path = Path.home() / ".nanobot" / "config.json"
                        bridge_host = None
                        bridge_port = 9527  # default

                        if config_path.exists():
                            try:
                                config_data = json.loads(config_path.read_text())
                                bridge_config = config_data.get("tools", {}).get("windowsBridge", {})
                                if bridge_config.get("enabled"):
                                    bridge_host = bridge_config.get("host") or WindowsBridgeClient.get_windows_host_ip()
                                    bridge_port = bridge_config.get("port", 9527)
                                logger.info(f"WindowsBridge config: host={bridge_host}, port={bridge_port}")
                            except Exception as e:
                                logger.warning(f"Failed to read bridge config: {e}")

                        if not bridge_host:
                            bridge_host = WindowsBridgeClient.get_windows_host_ip()

                        client = WindowsBridgeClient(host=bridge_host, port=bridge_port)
                        if await client.connect(send_identify=False):
                            result = await client.send_request("launch_app", {
                                "app_path": verification_url,
                                "args": []
                            })
                            if result and result.get("success"):
                                bridge_url = True
                    except Exception as e:
                        logger.warning(f"WindowsBridge failed: {e}")

                    # Fallback to webbrowser if bridge not available
                    if not bridge_url:
                        import webbrowser
                        webbrowser.open(verification_url)
                else:
                    # Standard webbrowser for native Linux/Mac
                    import webbrowser
                    webbrowser.open(verification_url)
            except Exception:
                pass

        token = await self._poll_device_token(
            device_auth.device_code,
            verifier,
            device_auth.interval,
            device_auth.expires_in,
        )

        self._token = token
        self._save_token()
        logger.info("Qwen OAuth login successful")
        return token

    async def _request_device_code(self, challenge: str) -> QwenDeviceAuthorization:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                QWEN_OAUTH_DEVICE_CODE_ENDPOINT,
                headers={
                    "Content-Type": "application/x-www-form-urlencoded",
                    "Accept": "application/json",
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                    "Origin": "https://chat.qwen.ai",
                    "Referer": "https://chat.qwen.ai/",
                },
                data=_to_form_urlencoded({
                    "client_id": QWEN_OAUTH_CLIENT_ID,
                    "scope": QWEN_OAUTH_SCOPE,
                    "code_challenge": challenge,
                    "code_challenge_method": "S256",
                }),
            )

            if response.status_code != 200:
                raise QwenOAuthError(f"Device code request failed: {response.status_code} - {response.text}")

            try:
                payload = response.json()
            except Exception as e:
                logger.error(f"Failed to parse response: {response.text[:500]}")
                raise QwenOAuthError(f"Invalid response from server: {e}")
            return QwenDeviceAuthorization(
                device_code=payload["device_code"],
                user_code=payload["user_code"],
                verification_uri=payload["verification_uri"],
                verification_uri_complete=payload.get("verification_uri_complete"),
                expires_in=payload.get("expires_in", 300),
                interval=payload.get("interval", 2),
            )

    async def _poll_device_token(
        self,
        device_code: str,
        verifier: str,
        interval: int,
        expires_in: int,
    ) -> QwenOAuthToken:
        start = time.time()
        poll_interval = interval

        async with httpx.AsyncClient(timeout=30.0) as client:
            while time.time() - start < expires_in:
                await asyncio.sleep(poll_interval)

                response = await client.post(
                    QWEN_OAUTH_TOKEN_ENDPOINT,
                    headers={
                        "Content-Type": "application/x-www-form-urlencoded",
                        "Accept": "application/json",
                        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                        "Origin": "https://chat.qwen.ai",
                        "Referer": "https://chat.qwen.ai/",
                    },
                    data=_to_form_urlencoded({
                        "grant_type": QWEN_OAUTH_GRANT_TYPE,
                        "client_id": QWEN_OAUTH_CLIENT_ID,
                        "device_code": device_code,
                        "code_verifier": verifier,
                    }),
                )

                if response.status_code == 200:
                    payload = response.json()
                    return QwenOAuthToken(
                        access=payload["access_token"],
                        refresh=payload["refresh_token"],
                        expires=time.time() + payload["expires_in"],
                        resource_url=payload.get("resource_url"),
                    )

                try:
                    payload = response.json()
                    error = payload.get("error", "")
                except Exception:
                    raise QwenOAuthError(f"Token request failed: {response.status_code}")

                if error == "authorization_pending":
                    continue
                elif error == "slow_down":
                    poll_interval = min(poll_interval + 2, 10)
                    continue
                else:
                    raise QwenOAuthError(f"OAuth error: {error}")

        raise QwenOAuthError("OAuth login timed out")

    async def chat(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        model: str | None = None,
        max_tokens: int = DEFAULT_MAX_TOKENS,
        temperature: float = 0.7,
    ) -> LLMResponse:
        model = self._strip_model_prefix(model or self.default_model)
        access_token = await self._ensure_token()

        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        }

        body: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "stream": True,
        }

        if tools:
            body["tools"] = self._convert_tools(tools)
            body["tool_choice"] = "auto"

        url = f"{self.api_base}/chat/completions"

        try:
            return await self._request_stream(url, headers, body)
        except Exception as e:
            return LLMResponse(
                content=f"Error calling Qwen Portal: {str(e)}",
                finish_reason="error",
            )

    def _strip_model_prefix(self, model: str) -> str:
        if model.startswith("qwen-portal/"):
            return model.split("/", 1)[1]
        return model

    def _convert_tools(self, tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
        converted: list[dict[str, Any]] = []
        for tool in tools:
            fn = tool.get("function") if tool.get("type") == "function" else tool
            if isinstance(fn, dict) and fn.get("name"):
                converted.append({
                    "type": "function",
                    "function": {
                        "name": fn["name"],
                        "description": fn.get("description", ""),
                        "parameters": fn.get("parameters", {}),
                    },
                })
        return converted

    async def _request_stream(
        self,
        url: str,
        headers: dict[str, str],
        body: dict[str, Any],
    ) -> LLMResponse:
        async with httpx.AsyncClient(timeout=60.0) as client:
            async with client.stream(
                "POST", url, headers=headers, json=body
            ) as response:
                if response.status_code != 200:
                    text = await response.aread()
                    raise QwenAPIError(
                        f"HTTP {response.status_code}: {text.decode('utf-8', 'ignore')}"
                    )
                return await self._consume_sse(response)

    async def _consume_sse(self, response: httpx.Response) -> LLMResponse:
        content = ""
        tool_calls: list[ToolCallRequest] = []
        finish_reason = "stop"

        async for event in self._iter_sse(response):
            choices = event.get("choices", [])
            if not choices:
                continue

            delta = choices[0].get("delta", {})
            finish = choices[0].get("finish_reason")

            if "content" in delta and delta["content"]:
                content += delta["content"]

            if "tool_calls" in delta:
                for tc in delta["tool_calls"]:
                    idx = tc.get("index", len(tool_calls))
                    if idx >= len(tool_calls):
                        tool_id = tc.get("id") or f"call_{idx}"
                        fn_name = tc.get("function", {}).get("name") or ""
                        tool_calls.append(
                            ToolCallRequest(
                                id=tool_id,
                                name=fn_name,
                                arguments={},
                            )
                        )
                    fn = tc.get("function", {}) or {}
                    if fn and "arguments" in fn and fn["arguments"]:
                        try:
                            tool_calls[idx].arguments = json.loads(fn["arguments"])
                        except (json.JSONDecodeError, TypeError):
                            tool_calls[idx].arguments = {"raw": str(fn["arguments"])}

            if finish:
                finish_reason = finish

        return LLMResponse(
            content=content,
            tool_calls=tool_calls if tool_calls else [],
            finish_reason=finish_reason,
        )

    async def _iter_sse(self, response: httpx.Response) -> AsyncGenerator[dict[str, Any], None]:
        buffer: list[str] = []
        async for line in response.aiter_lines():
            if line == "":
                if buffer:
                    data_lines = [ln[5:].strip() for ln in buffer if ln.startswith("data:")]
                    buffer = []
                    if not data_lines:
                        continue
                    data = "\n".join(data_lines).strip()
                    if not data or data == "[DONE]":
                        continue
                    try:
                        yield json.loads(data)
                    except json.JSONDecodeError:
                        continue
                continue
            buffer.append(line)

    def get_default_model(self) -> str:
        return self.default_model

    @property
    def is_authenticated(self) -> bool:
        return self._token is not None and not self._token.is_expired


class QwenOAuthError(Exception):
    pass


class QwenAPIError(Exception):
    pass


async def qwen_login(open_url: bool = True) -> QwenOAuthToken:
    provider = QwenPortalProvider()
    return await provider.login(open_url=open_url)
