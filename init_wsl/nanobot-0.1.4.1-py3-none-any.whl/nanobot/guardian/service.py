"""Guardian service - health monitoring and auto-recovery for nanobot services."""

import asyncio
from loguru import logger
from typing import Any

DEFAULT_INTERVAL_S = 5 * 60  # 5 minutes
MIN_INTERVAL_S = 30  # 30 seconds
MAX_CONSECUTIVE_FAILURES = 3


class GuardianService:
    """
    Health monitoring service with adaptive intervals and auto-recovery.
    
    Monitors registered services and automatically restarts failed ones.
    """
    
    def __init__(
        self,
        interval_s: int = DEFAULT_INTERVAL_S,
        min_interval_s: int = MIN_INTERVAL_S,
        max_consecutive_failures: int = MAX_CONSECUTIVE_FAILURES,
        auto_recover: bool = True,
    ):
        self._services: dict[str, Any] = {}
        self._interval_s = interval_s
        self._min_interval_s = min_interval_s
        self._current_interval = interval_s
        self._max_failures = max_consecutive_failures
        self._consecutive_failures = 0
        self._auto_recover = auto_recover
        self._running = False
        self._task: asyncio.Task | None = None
    
    def register(self, name: str, service: Any) -> None:
        """Register a service to be monitored."""
        self._services[name] = service
        logger.info(f"Guardian: registered service '{name}'")
    
    def unregister(self, name: str) -> None:
        """Unregister a service."""
        self._services.pop(name, None)
        logger.info(f"Guardian: unregistered service '{name}'")
    
    async def start(self) -> None:
        """Start the guardian service."""
        self._running = True
        self._task = asyncio.create_task(self._run_loop())
        logger.info(f"Guardian started (interval: {self._interval_s}s)")
    
    def stop(self) -> None:
        """Stop the guardian service."""
        self._running = False
        if self._task:
            self._task.cancel()
            self._task = None
        logger.info("Guardian stopped")
    
    async def _run_loop(self) -> None:
        """Main guardian loop."""
        while self._running:
            try:
                await asyncio.sleep(self._current_interval)
                if self._running:
                    await self._check_and_recover()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Guardian error: {e}")
    
    async def _check_and_recover(self) -> None:
        """Check all services and recover if needed."""
        result = self.check_all()
        
        if result["healthy"]:
            self._record_success()
            logger.debug(f"Guardian: all {len(self._services)} services healthy")
        else:
            self._record_failure()
            logger.warning(f"Guardian: {len(result['failed'])} services failed: {result['failed']}")
            
            if self._auto_recover:
                await self._recover_failed_services(result["failed"])
    
    def check_all(self) -> dict:
        """Check all registered services."""
        failed = []
        
        for name, service in self._services.items():
            try:
                if not service.is_running():
                    failed.append(name)
            except Exception as e:
                logger.error(f"Guardian: error checking '{name}': {e}")
                failed.append(name)
        
        return {
            "healthy": len(failed) == 0,
            "total": len(self._services),
            "failed": failed,
        }
    
    async def _recover_failed_services(self, failed: list[str]) -> None:
        """Attempt to recover failed services."""
        for name in failed:
            service = self._services.get(name)
            if service:
                try:
                    logger.info(f"Guardian: attempting to restart '{name}'")
                    service.stop()
                    await service.start()
                    logger.info(f"Guardian: '{name}' restarted successfully")
                except Exception as e:
                    logger.error(f"Guardian: failed to restart '{name}': {e}")
    
    def _record_failure(self) -> None:
        """Record a check failure and adjust interval."""
        self._consecutive_failures += 1
        
        if self._consecutive_failures == 1:
            self._current_interval = 60  # 1 minute
        elif self._consecutive_failures >= 2:
            self._current_interval = self._min_interval_s
        
        logger.debug(f"Guardian: failure recorded, interval now {self._current_interval}s")
    
    def _record_success(self) -> None:
        """Record a successful check and restore interval."""
        self._consecutive_failures = 0
        if self._current_interval != self._interval_s:
            self._current_interval = self._interval_s
            logger.debug(f"Guardian: restored interval to {self._interval_s}s")
    
    async def check_now(self) -> dict:
        """Manually trigger a health check."""
        await self._check_and_recover()
        return self.check_all()
    
    @property
    def status(self) -> dict:
        """Get guardian status."""
        return {
            "running": self._running,
            "services": list(self._services.keys()),
            "current_interval": self._current_interval,
            "consecutive_failures": self._consecutive_failures,
        }


class MonitoredService:
    """Base class for services that can be monitored by Guardian."""
    
    async def start(self) -> None:
        raise NotImplementedError
    
    def stop(self) -> None:
        raise NotImplementedError
    
    def is_running(self) -> bool:
        raise NotImplementedError
