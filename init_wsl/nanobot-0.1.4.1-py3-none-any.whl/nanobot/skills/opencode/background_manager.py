import json
import subprocess
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from loguru import logger


class BackgroundTaskManager:
    """后台任务管理器，基于 tmux"""

    def __init__(self, workspace: Path):
        self.workspace = workspace
        self.socket_dir = workspace / "tmux_sockets"
        self.socket_dir.mkdir(exist_ok=True)
        self.tasks_file = workspace / "opencode_tasks.json"
        self.tasks = self._load_tasks()

    def _load_tasks(self) -> Dict:
        """加载任务列表"""
        if self.tasks_file.exists():
            return json.loads(self.tasks_file.read_text())
        return {}

    def _save_tasks(self):
        """保存任务列表"""
        self.tasks_file.write_text(json.dumps(self.tasks, indent=2))

    def _get_socket_path(self) -> Path:
        """获取 tmux socket 路径"""
        return self.socket_dir / "opencode.sock"

    def create_task(self, prompt: str) -> str:
        """
        创建新的后台任务

        Args:
            prompt: 任务描述

        Returns:
            str: 任务ID
        """
        task_id = f"opencode-{uuid.uuid4().hex[:8]}"
        socket = self._get_socket_path()
        session_name = task_id.replace("-", "_")

        cmd = [
            "tmux", "-S", str(socket),
            "new-session", "-d", "-s", session_name
        ]

        try:
            subprocess.run(cmd, check=True, capture_output=True)

            result_file = self.workspace / "opencode_results" / f"{task_id}.txt"
            result_file.parent.mkdir(exist_ok=True)

            opencode_cmd = f'opencode run "{prompt}" --save-to {result_file}'

            send_cmd = [
                "tmux", "-S", str(socket),
                "send-keys", "-t", session_name,
                opencode_cmd, "Enter"
            ]
            subprocess.run(send_cmd, check=True, capture_output=True)

            self.tasks[task_id] = {
                "prompt": prompt,
                "session": session_name,
                "result_file": str(result_file),
                "created_at": datetime.now().isoformat(),
                "status": "running"
            }
            self._save_tasks()

            logger.info(f"Created background task: {task_id}")
            return task_id

        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to create task: {e}")
            raise RuntimeError(f"Failed to create background task: {e}")

    def get_status(self, task_id: str) -> Dict:
        """获取任务状态"""
        if task_id not in self.tasks:
            return {"status": "not_found", "task_id": task_id}

        task = self.tasks[task_id]
        socket = self._get_socket_path()
        session = task["session"]

        try:
            result = subprocess.run(
                ["tmux", "-S", str(socket), "has-session", "-t", session],
                capture_output=True
            )
            is_running = result.returncode == 0
        except Exception:
            is_running = False

        if not is_running:
            task["status"] = "completed"
            self._save_tasks()

        return {
            "task_id": task_id,
            "status": task["status"],
            "created_at": task["created_at"],
            "prompt": task["prompt"][:100] + "..." if len(task["prompt"]) > 100 else task["prompt"]
        }

    def get_result(self, task_id: str) -> Optional[str]:
        """获取任务结果"""
        if task_id not in self.tasks:
            return None

        task = self.tasks[task_id]
        result_file = Path(task["result_file"])

        if result_file.exists():
            return result_file.read_text(encoding='utf-8')
        return None

    def list_tasks(self) -> List[Dict]:
        """列出所有任务"""
        return [
            {
                "task_id": tid,
                "status": t["status"],
                "created_at": t["created_at"]
            }
            for tid, t in self.tasks.items()
        ]

    def cancel_task(self, task_id: str) -> bool:
        """取消任务"""
        if task_id not in self.tasks:
            return False

        task = self.tasks[task_id]
        socket = self._get_socket_path()
        session = task["session"]

        try:
            subprocess.run(
                ["tmux", "-S", str(socket), "kill-session", "-t", session],
                check=True, capture_output=True
            )
            task["status"] = "cancelled"
            self._save_tasks()
            return True
        except subprocess.CalledProcessError:
            return False
