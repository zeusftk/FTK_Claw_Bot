"""Session management for Windows bridge tools."""

import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class SessionInfo:
    session_id: str
    session_type: str
    created_at: datetime
    last_active: datetime
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> dict:
        return {
            "session_id": self.session_id,
            "session_type": self.session_type,
            "created_at": self.created_at.isoformat(),
            "last_active": self.last_active.isoformat(),
            "metadata": self.metadata
        }


class SessionManager:
    _sessions: Dict[str, SessionInfo] = {}
    _config_path: Path | None = None
    
    def __init__(self, config_path: Path | None = None):
        self._config_path = config_path or self._find_config_path()
        self._load_config()
    
    def _find_config_path(self) -> Path | None:
        config_paths = [
            Path.home() / ".clawbot" / "config.json",
        ]
        for path in config_paths:
            if path.exists():
                return path
        return None
    
    def _load_config(self):
        self._max_sessions = 10
        self._session_timeout = 3600
        
        if self._config_path and self._config_path.exists():
            try:
                data = json.loads(self._config_path.read_text())
                self._max_sessions = data.get("tools", {}).get("session", {}).get("maxSessions", 10)
                self._session_timeout = data.get("tools", {}).get("session", {}).get("sessionTimeout", 3600)
            except (json.JSONDecodeError, KeyError):
                pass
    
    def generate_session_id(self, session_type: str) -> str:
        uuid_str = str(uuid.uuid4())[:8]
        return f"sess_{session_type}_{uuid_str}"
    
    def create_session(self, session_type: str, metadata: dict = None) -> str:
        session_id = self.generate_session_id(session_type)
        now = datetime.now()
        
        info = SessionInfo(
            session_id=session_id,
            session_type=session_type,
            created_at=now,
            last_active=now,
            metadata=metadata or {}
        )
        
        self._sessions[session_id] = info
        return session_id
    
    def get_session(self, session_id: str) -> Optional[SessionInfo]:
        return self._sessions.get(session_id)
    
    def update_session_active(self, session_id: str) -> bool:
        info = self._sessions.get(session_id)
        if info:
            info.last_active = datetime.now()
            return True
        return False
    
    def close_session(self, session_id: str) -> bool:
        if session_id in self._sessions:
            del self._sessions[session_id]
            return True
        return False
    
    def list_sessions(self) -> List[SessionInfo]:
        return list(self._sessions.values())
    
    def get_or_create(self, session_type: str) -> Tuple[str, bool]:
        for session_id, info in self._sessions.items():
            if info.session_type == session_type:
                self.update_session_active(session_id)
                return session_id, False
        
        session_id = self.create_session(session_type)
        return session_id, True
    
    def clear_expired_sessions(self, timeout_seconds: int = None) -> int:
        timeout = timeout_seconds or self._session_timeout
        now = datetime.now()
        expired = []
        
        for session_id, info in self._sessions.items():
            elapsed = (now - info.last_active).total_seconds()
            if elapsed > timeout:
                expired.append(session_id)
        
        for session_id in expired:
            del self._sessions[session_id]
        
        return len(expired)


_session_manager: SessionManager | None = None


def get_session_manager() -> SessionManager:
    global _session_manager
    if _session_manager is None:
        _session_manager = SessionManager()
    return _session_manager
