"""Windows GUI automation tool via bridge connection."""

import asyncio
import base64
import json
import os
import socket
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any

from loguru import logger

from clawbot.agent.tools.base import Tool
from clawbot.agent.tools.session_manager import get_session_manager, SessionManager
from clawbot.agent.tools.response_filter import get_response_filter, ResponseFilter


def get_distro_name() -> str:
    """Get current WSL distribution name."""
    return os.environ.get("WSL_DISTRO_NAME", "unknown")


class WindowsBridgeClient:
    """Client for connecting to Windows bridge from WSL."""

    DEFAULT_PORT = 9527
    DEFAULT_TIMEOUT = 30.0
    RECONNECT_DELAY = 5.0

    def __init__(self, host: str | None = None, port: int = DEFAULT_PORT):
        self._host = host
        self._port = port
        self._socket: socket.socket | None = None
        self._connected = False
        self._pending_requests: dict[str, asyncio.Event] = {}
        self._responses: dict[str, Any] = {}
        self._reader_task: asyncio.Task | None = None
        self._lock = asyncio.Lock()
        self._on_port_changed_callback: callable | None = None

    @staticmethod
    def get_windows_host_ip() -> str | None:
        """Get Windows host IP from WSL's /etc/resolv.conf."""
        try:
            with open("/etc/resolv.conf") as f:
                for line in f:
                    if line.startswith("nameserver"):
                        return line.split()[1].strip()
        except Exception as e:
            logger.warning(f"Failed to get Windows host IP: {e}")
        return None

    @property
    def is_connected(self) -> bool:
        return self._connected

    @property
    def host(self) -> str | None:
        return self._host

    @property
    def port(self) -> int:
        return self._port

    def set_on_port_changed_callback(self, callback: callable) -> None:
        self._on_port_changed_callback = callback

    async def connect(self, host: str | None = None, port: int | None = None, send_identify: bool = True) -> bool:
        """Connect to Windows bridge."""
        if self._connected:
            logger.info(f"[BridgeClient] 已连接到 Windows bridge: {self._host}:{self._port}")
            return True

        # 解析主机地址
        resolved_host = host or self._host
        if not resolved_host:
            resolved_host = self.get_windows_host_ip()
            if resolved_host:
                logger.info(f"[BridgeClient] 自动检测到 Windows 主机 IP: {resolved_host}")
            else:
                logger.error("[BridgeClient] 无法获取 Windows 主机 IP，请在配置中指定 host")
                return False
        
        self._host = resolved_host
        self._port = port or self._port

        logger.info(f"[BridgeClient] 尝试连接 Windows bridge: {self._host}:{self._port}")

        try:
            self._socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self._socket.settimeout(10.0)
            
            logger.debug(f"[BridgeClient] 正在连接 {self._host}:{self._port}...")
            self._socket.connect((self._host, self._port))
            logger.info(f"[BridgeClient] TCP 连接成功: {self._host}:{self._port}")
            
            self._socket.setblocking(False)
            self._connected = True

            self._reader_task = asyncio.create_task(self._receive_loop())
            logger.info(f"[BridgeClient] 已连接到 Windows bridge: {self._host}:{self._port}")

            if send_identify:
                await self._send_identify()

            return True

        except socket.timeout:
            logger.error(f"[BridgeClient] 连接超时: {self._host}:{self._port}，请检查 Windows Bridge 服务是否正在运行")
            self._connected = False
            return False
        except ConnectionRefusedError:
            logger.error(f"[BridgeClient] 连接被拒绝: {self._host}:{self._port}，请检查端口是否正确或服务是否启动")
            self._connected = False
            return False
        except OSError as e:
            if e.errno == 113:  # No route to host
                logger.error(f"[BridgeClient] 无法到达主机: {self._host}，请检查网络连接或防火墙设置")
            elif e.errno == 111:  # Connection refused
                logger.error(f"[BridgeClient] 连接被拒绝: {self._host}:{self._port}，请检查 Windows Bridge 服务是否正在运行")
            else:
                logger.error(f"[BridgeClient] 连接失败 (OSError {e.errno}): {e}")
            self._connected = False
            return False
        except Exception as e:
            logger.error(f"[BridgeClient] 连接失败: {type(e).__name__}: {e}")
            self._connected = False
            return False

    async def _send_identify(self) -> None:
        """Send identify message to server."""
        distro_name = get_distro_name()
        logger.info(f"[BridgeClient] 发送 identify 消息: distro_name={distro_name}, host={self._host}, port={self._port}")
        result = await self.send_request("identify", {
            "distro_name": distro_name,
            "clawbot_name": distro_name,
            "workspace": str(Path.cwd())
        }, timeout=10.0)
        
        if result:
            if result.get("identified"):
                logger.info(f"[BridgeClient] ✅ Identify 成功: {distro_name}")
            elif result.get("success") == False:
                logger.warning(f"[BridgeClient] ⚠️ Identify 返回失败: {result}")
            else:
                logger.info(f"[BridgeClient] ✅ Identify 完成: {result}")
        else:
            logger.warning(f"[BridgeClient] ❌ Identify 无响应，可能连接已断开")

    async def reconnect_with_port(self, new_port: int) -> bool:
        """Reconnect using a new port."""
        logger.info(f"Reconnecting with new port: {new_port}")
        await self.disconnect()
        self._port = new_port
        return await self.connect(send_identify=True)

    async def disconnect(self) -> None:
        """Disconnect from Windows bridge."""
        self._connected = False
        if self._reader_task:
            self._reader_task.cancel()
            try:
                await self._reader_task
            except asyncio.CancelledError:
                pass
            self._reader_task = None

        if self._socket:
            try:
                self._socket.close()
            except Exception:
                pass
            self._socket = None

    async def _receive_loop(self) -> None:
        """Background task to receive responses."""
        loop = asyncio.get_event_loop()
        buffer = ""

        while self._connected and self._socket:
            try:
                data = await loop.sock_recv(self._socket, 65536)
                if not data:
                    break
                buffer += data.decode("utf-8")

                while "\n" in buffer:
                    line, buffer = buffer.split("\n", 1)
                    if line.strip():
                        await self._handle_response(line.strip())

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.debug(f"Receive error: {e}")
                break

        self._connected = False

    async def _handle_response(self, message_str: str) -> None:
        """Handle incoming response or request message."""
        try:
            data = json.loads(message_str)
            msg_type = data.get("type", "")

            if msg_type == "notification":
                await self._handle_notification(data)
                return

            # Handle server-initiated requests (e.g., request_identify)
            if msg_type == "request":
                await self._handle_server_request(data)
                return

            # Handle response to our request
            msg_id = data.get("id", "")
            if msg_id in self._pending_requests:
                self._responses[msg_id] = data
                self._pending_requests[msg_id].set()
        except Exception as e:
            logger.warning(f"Failed to handle response: {e}")

    async def _handle_server_request(self, request: dict) -> None:
        """Handle server-initiated requests."""
        action = request.get("payload", {}).get("action", "")
        msg_id = request.get("id", "")
        
        logger.debug(f"[BridgeClient] Received server request: action={action}")
        
        if action == "request_identify":
            # Server wants us to identify, send identify response
            await self._send_identify()
        else:
            # Unknown server request, send empty response
            if msg_id and self._socket and self._connected:
                try:
                    loop = asyncio.get_event_loop()
                    response = {
                        "version": "1.0",
                        "type": "response",
                        "id": msg_id,
                        "timestamp": datetime.now().isoformat(),
                        "payload": {"success": False, "error": f"Unknown server action: {action}"}
                    }
                    await loop.sock_sendall(self._socket, (json.dumps(response) + "\n").encode("utf-8"))
                except Exception as e:
                    logger.warning(f"Failed to send response to server request: {e}")

    async def _handle_notification(self, notification: dict) -> None:
        """Handle server notification."""
        action = notification.get("action", "")
        if action == "port_changed":
            new_port = notification.get("data", {}).get("new_port")
            if new_port:
                logger.info(f"Server notified port change to {new_port}")
                if self._on_port_changed_callback:
                    await self._on_port_changed_callback(new_port)
                else:
                    await self.reconnect_with_port(new_port)

    async def send_request(
        self,
        action: str,
        params: dict[str, Any] | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        session_id: str | None = None,
    ) -> dict[str, Any] | None:
        """Send a request to Windows bridge and wait for response."""
        if not self._connected or not self._socket:
            return None

        request_id = str(uuid.uuid4())
        event = asyncio.Event()
        self._pending_requests[request_id] = event

        message = {
            "version": "1.0",
            "type": "request",
            "id": request_id,
            "timestamp": datetime.now().isoformat(),
            "session_id": session_id or "",
            "payload": {
                "action": action,
                "params": params or {},
            },
        }

        try:
            loop = asyncio.get_event_loop()
            await loop.sock_sendall(self._socket, (json.dumps(message) + "\n").encode("utf-8"))

            try:
                await asyncio.wait_for(event.wait(), timeout=timeout)
                response = self._responses.pop(request_id, None)
                if response:
                    payload = response.get("payload", {})
                    if payload.get("error"):
                        return {"success": False, "error": payload.get("error")}
                    return payload.get("result") or payload
            except asyncio.TimeoutError:
                logger.warning(f"Request {action} timed out")
                return {"success": False, "error": "Request timed out"}

        except Exception as e:
            logger.error(f"Request failed: {e}")
            return {"success": False, "error": str(e)}
        finally:
            self._pending_requests.pop(request_id, None)

        return None


class WindowsGUITool(Tool):
    """Tool for Windows GUI automation via bridge."""

    _client: WindowsBridgeClient | None = None

    def __init__(self, host: str | None = None, port: int = 9527, auto_connect: bool = True):
        self._host = host
        self._port = port
        self._auto_connect = auto_connect
        self._config_path = self._find_config_path()
        self._session_manager = get_session_manager()
        self._response_filter = get_response_filter()

    def _find_config_path(self) -> Path | None:
        config_paths = [
            Path.home() / ".clawbot" / "config.json",
        ]
        for path in config_paths:
            if path.exists():
                return path
        return None

    def _reload_port_from_config(self) -> int:
        if self._config_path and self._config_path.exists():
            try:
                import json
                data = json.loads(self._config_path.read_text())
                port = data.get("tools", {}).get("windowsBridge", {}).get("port")
                if port and port != self._port:
                    logger.info(f"Port changed from {self._port} to {port} (from config)")
                    self._port = port
                    WindowsGUITool._client = None
            except (json.JSONDecodeError, KeyError):
                pass
        return self._port

    def set_config(self, host: str | None = None, port: int | None = None, auto_connect: bool | None = None) -> None:
        if host is not None:
            self._host = host
        if port is not None:
            self._port = port
        if auto_connect is not None:
            self._auto_connect = auto_connect

    @property
    def name(self) -> str:
        return "windows_gui"

    @property
    def description(self) -> str:
        return """Windows GUI and Web browser automation tool.

## WHEN TO USE THIS TOOL (触发条件):
- 用户要求打开浏览器访问网站、进行网页操作
- 用户要求在 Windows 上打开应用程序
- 用户要求进行 GUI 自动化（点击、输入、截图等）
- 用户要求进行 OCR 识别屏幕元素
- 用户提到 "bridge"、"Windows 操作"、"浏览器自动化"

## QUICK START - Web Automation (网页自动化):
1. web_start: 启动浏览器 → {"action": "web_start", "params": {}}
2. web_navigate_safe: 安全打开网页 → {"action": "web_navigate_safe", "params": {"url": "https://example.com"}}
3. web_ai_snapshot: 获取 AI 快照 → {"action": "web_ai_snapshot", "params": {}}
4. web_click/web_fill: 使用 ref 操作 → {"action": "web_click", "params": {"ref": "ref5"}}

## AI Snapshot (AI 快照):
- web_ai_snapshot: 生成页面结构快照，返回 refs 字典
- 每个 ref 包含: role, name, selector
- 使用 ref 可以精确定位元素

## QUICK START - GUI Automation (桌面自动化):
1. screenshot: 截图 → {"action": "screenshot", "params": {}}
2. gui_screenshot_ocr: OCR识别 → {"action": "gui_screenshot_ocr", "params": {}}
3. gui_click/gui_input: 点击或输入 → {"action": "gui_click", "params": {"text": "确定"}}

## Key Actions:
- web_start/stop/navigate_safe/ai_snapshot (网页核心)
- web_click/web_fill (使用 ref 或 selector)
- gui_screenshot_ocr/gui_click/gui_input (OCR桌面)
- mouse_click/keyboard_type/launch_app (基础桌面)
- session_create/close/list (会话管理)"""

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": [
                        # Session management
                        "session_create", "session_close", "session_list",
                        # Connection
                        "connect", "disconnect", "get_status",
                        # Mouse
                        "mouse_click", "mouse_move", "mouse_drag", "mouse_scroll",
                        # Keyboard
                        "keyboard_type", "keyboard_press", "keyboard_hotkey",
                        # Screenshot
                        "screenshot",
                        # Window
                        "find_window", "launch_app",
                        # Clipboard
                        "get_clipboard", "set_clipboard",
                        # Screen info
                        "get_screen_size", "get_mouse_position",
                        # GUI OCR
                        "gui_screenshot_ocr", "gui_click", "gui_input",
                        # Web automation
                        "web_start", "web_stop", "web_navigate", "web_navigate_safe", "web_click",
                        "web_fill", "web_scroll", "web_screenshot", "web_get_content",
                        "web_get_url", "web_get_title", "web_extract_elements",
                        "web_extract_data", "web_get_cookies", "web_set_cookies",
                        "web_save_session", "web_load_session", "web_login",
                        "web_press", "web_type", "web_evaluate", "web_wait_for_selector",
                        "web_go_back", "web_go_forward", "web_refresh", "web_ai_snapshot"
                    ],
                    "description": "The action to perform"
                },
                "params": {
                    "type": "object",
                    "description": "Parameters for the action",
                    "properties": {
                        # Session params
                        "type": {"type": "string", "description": "Session type: web or app"},
                        "session_id": {"type": "string", "description": "Session identifier"},
                        
                        # Connection params
                        "host": {"type": "string", "description": "Windows host IP (for connect)"},
                        "port": {"type": "integer", "description": "Bridge port (default 9527)"},
                        
                        # Mouse params
                        "x": {"type": "integer", "description": "X coordinate"},
                        "y": {"type": "integer", "description": "Y coordinate"},
                        "button": {"type": "string", "enum": ["left", "right", "middle"], "description": "Mouse button"},
                        "clicks": {"type": "integer", "description": "Number of clicks"},
                        "duration": {"type": "number", "description": "Duration in seconds"},
                        "start_x": {"type": "integer", "description": "Drag start X coordinate"},
                        "start_y": {"type": "integer", "description": "Drag start Y coordinate"},
                        "end_x": {"type": "integer", "description": "Drag end X coordinate"},
                        "end_y": {"type": "integer", "description": "Drag end Y coordinate"},
                        
                        # Keyboard params
                        "text": {"type": "string", "description": "Text to type or set clipboard"},
                        "key": {"type": "string", "description": "Key to press"},
                        "keys": {"type": "array", "items": {"type": "string"}, "description": "Keys for hotkey"},
                        "interval": {"type": "number", "description": "Interval between keystrokes"},
                        
                        # Screenshot params
                        "region": {"type": "array", "items": {"type": "integer"}, "description": "Screenshot region [x, y, width, height]"},
                        
                        # Window params
                        "title": {"type": "string", "description": "Window title to find"},
                        
                        # App launch params
                        "app_path": {"type": "string", "description": "Application path or URL to launch"},
                        "args": {"type": "array", "items": {"type": "string"}, "description": "Application arguments"},
                        
                        # Web automation params
                        "url": {"type": "string", "description": "URL to navigate to"},
                        "selector": {"type": "string", "description": "CSS selector for element"},
                        "value": {"type": "string", "description": "Value to fill in input"},
                        "headless": {"type": "boolean", "description": "Run browser in headless mode (default false)"},
                        "timeout": {"type": "integer", "description": "Timeout in milliseconds"},
                        "wait_until": {"type": "string", "enum": ["load", "domcontentloaded", "networkidle"], "description": "Wait condition for navigation"},
                        
                        # Web scroll params
                        "direction": {"type": "string", "enum": ["up", "down"], "description": "Scroll direction"},
                        "amount": {"type": "integer", "description": "Scroll amount in pixels"},
                        
                        # Web screenshot params
                        "full_page": {"type": "boolean", "description": "Capture full page screenshot"},
                        
                        # Web data extraction params
                        "selectors": {"type": "array", "items": {"type": "object"}, "description": "Selectors for data extraction [{name, selector}]"},
                        "config": {"type": "object", "description": "Element extraction config"},
                        
                        # Web cookie params
                        "cookies": {"type": "array", "items": {"type": "object"}, "description": "Cookies to set [{name, value, domain}]"},
                        
                        # Web session params
                        "session_id": {"type": "string", "description": "Session identifier for save/load"},
                        
                        # Web login params
                        "type": {"type": "string", "enum": ["form", "cookie", "qr"], "description": "Login type"},
                        "params": {"type": "object", "description": "Login parameters (form/cookie/qr)"},
                        
                        # Web typing params
                        "delay": {"type": "integer", "description": "Typing delay between keystrokes in ms"},
                        
                        # Web script params
                        "script": {"type": "string", "description": "JavaScript code to execute"},
                        
                        # AI Snapshot params
                        "ref": {"type": "string", "description": "Element reference from AI snapshot (e.g., 'ref5')"}
                    }
                }
            },
            "required": ["action"]
        }

    def _get_client(self) -> WindowsBridgeClient:
        self._reload_port_from_config()
        if WindowsGUITool._client is None:
            WindowsGUITool._client = WindowsBridgeClient(host=self._host, port=self._port)
        return WindowsGUITool._client

    def _determine_session_type(self, action: str) -> str | None:
        web_actions = {"web_start", "web_stop", "web_navigate", "web_click", "web_fill",
                       "web_scroll", "web_screenshot", "web_get_content", "web_get_url",
                       "web_get_title", "web_extract_elements", "web_extract_data",
                       "web_get_cookies", "web_set_cookies", "web_login", "web_press",
                       "web_type", "web_evaluate", "web_wait_for_selector", "web_go_back",
                       "web_go_forward", "web_refresh", "web_save_session", "web_load_session"}
        
        gui_actions = {"gui_screenshot_ocr", "gui_click", "gui_input", "gui_press",
                       "screenshot", "mouse_click", "mouse_move", "keyboard_type"}
        
        if action in web_actions:
            return "web"
        elif action in gui_actions:
            return "app"
        return None

    def _get_or_create_session(self, action: str, params: dict) -> tuple[str | None, bool]:
        session_type = self._determine_session_type(action)
        if not session_type:
            return None, False
        
        if params.get("session_id"):
            session_id = params["session_id"]
            self._session_manager.update_session_active(session_id)
            return session_id, False
        
        session_id, is_new = self._session_manager.get_or_create(session_type)
        return session_id, is_new

    def _format_filtered_result(self, result: dict, action: str, session_id: str = None) -> str:
        if not result:
            return "No response from Windows bridge"
        
        if result.get("success") == False:
            return f"Failed: {result.get('error', 'Unknown error')}"
        
        summary = result.get("summary", "")
        elements = result.get("elements", [])
        
        result_parts = [summary] if summary else ["Operation completed"]
        
        if session_id:
            result_parts.append(f"Session: {session_id}")
        
        if elements:
            result_parts.append(f"\n可交互元素 ({len(elements)} 个):")
            for i, el in enumerate(elements[:10]):
                hint = el.get("hint", "")
                action_type = el.get("action_type", "")
                result_parts.append(f"  {i+1}. [{action_type}] {hint}")
            if len(elements) > 10:
                result_parts.append(f"  ... 还有 {len(elements) - 10} 个元素")
        
        return "\n".join(result_parts)

    async def execute(self, **kwargs: Any) -> str:
        action = kwargs.get("action")
        params = kwargs.get("params", {})

        client = self._get_client()

        if action == "connect":
            host = params.get("host")
            port = params.get("port", 9527)
            if await client.connect(host, port, send_identify=True):
                return f"Connected to Windows bridge at {client.host}:{client.port}"
            return "无法连接到 Windows Bridge。请在 FTK_Claw_Bot 桥接面板点击刷新按钮重启 bridge 服务。"

        if action == "disconnect":
            await client.disconnect()
            return "Disconnected from Windows bridge"

        if action == "get_status":
            if client.is_connected:
                return f"Connected to Windows bridge at {client.host}:{client.port}"
            return "Not connected to Windows bridge"

        if not client.is_connected:
            if not await client.connect(send_identify=True):
                return "无法连接到 Windows Bridge 服务。请在 FTK_Claw_Bot 桥接面板点击刷新按钮重启 bridge 服务，或检查端口是否被占用。"

        # Session management actions
        if action == "session_create":
            session_type = params.get("type", "web")
            result = await client.send_request("session_create", {"type": session_type})
            if result and result.get("success"):
                remote_session_id = result.get("session_id")
                local_session_id = self._session_manager.create_session(
                    session_type, 
                    {"remote_session_id": remote_session_id}
                )
                return f"Session created: {local_session_id} (remote: {remote_session_id})"
            return self._format_result(result, "Session creation failed")
        
        if action == "session_close":
            session_id = params.get("session_id")
            result = await client.send_request("session_close", {"session_id": session_id}, session_id=session_id)
            if result and result.get("success"):
                self._session_manager.close_session(session_id)
            return self._format_result(result, f"Session closed: {session_id}")
        
        if action == "session_list":
            local_sessions = self._session_manager.list_sessions()
            result = await client.send_request("session_list", {})
            remote_sessions = result.get("sessions", []) if result else []
            return f"Local sessions: {len(local_sessions)}\nRemote sessions: {len(remote_sessions)}"

        # Get or create session for web/gui actions
        session_id, is_new_session = self._get_or_create_session(action, params)

        if action == "mouse_click":
            result = await client.send_request("mouse_click", {
                "x": params.get("x", 0),
                "y": params.get("y", 0),
                "button": params.get("button", "left"),
                "clicks": params.get("clicks", 1)
            })
            return self._format_result(result, f"Clicked at ({params.get('x')}, {params.get('y')})")

        if action == "mouse_move":
            result = await client.send_request("mouse_move", {
                "x": params.get("x", 0),
                "y": params.get("y", 0),
                "duration": params.get("duration", 0.0)
            })
            return self._format_result(result, f"Mouse moved to ({params.get('x')}, {params.get('y')})")

        if action == "mouse_drag":
            result = await client.send_request("mouse_drag", {
                "start_x": params.get("start_x", 0),
                "start_y": params.get("start_y", 0),
                "end_x": params.get("end_x", 0),
                "end_y": params.get("end_y", 0),
                "duration": params.get("duration", 0.5),
                "button": params.get("button", "left")
            })
            return self._format_result(result, f"Dragged from ({params.get('start_x')}, {params.get('start_y')}) to ({params.get('end_x')}, {params.get('end_y')})")

        if action == "mouse_scroll":
            result = await client.send_request("mouse_scroll", {
                "clicks": params.get("clicks", 0),
                "x": params.get("x"),
                "y": params.get("y")
            })
            return self._format_result(result, f"Scrolled {params.get('clicks')} clicks")

        if action == "keyboard_type":
            result = await client.send_request("keyboard_type", {
                "text": params.get("text", ""),
                "interval": params.get("interval", 0.0)
            })
            return self._format_result(result, f"Typed: {params.get('text')[:50]}...")

        if action == "keyboard_press":
            result = await client.send_request("keyboard_press", {
                "key": params.get("key", "")
            })
            return self._format_result(result, f"Pressed key: {params.get('key')}")

        if action == "keyboard_hotkey":
            keys = params.get("keys", [])
            result = await client.send_request("keyboard_hotkey", {"keys": keys})
            return self._format_result(result, f"Pressed hotkey: {'+'.join(keys)}")

        if action == "screenshot":
            result = await client.send_request("screenshot", {
                "region": params.get("region")
            })
            if result and result.get("success"):
                data = result.get("data", "")
                if data:
                    img_data = base64.b64decode(data)
                    import os
                    import tempfile
                    temp_dir = tempfile.gettempdir()
                    filepath = os.path.join(temp_dir, f"screenshot_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png")
                    with open(filepath, "wb") as f:
                        f.write(img_data)
                    return f"Screenshot saved to: {filepath}"
            return self._format_result(result, "Screenshot captured")

        if action == "find_window":
            result = await client.send_request("find_window", {
                "title": params.get("title", "")
            })
            if result and result.get("success"):
                window = result.get("window", {})
                return f"Found window: {window.get('title')}\nHandle: {window.get('handle')}\nRect: {window.get('rect')}"
            return f"Window not found: {params.get('title')}"

        if action == "launch_app":
            result = await client.send_request("launch_app", {
                "app_path": params.get("app_path", ""),
                "args": params.get("args", [])
            })
            return self._format_result(result, f"Launched: {params.get('app_path')}")

        if action == "get_clipboard":
            result = await client.send_request("get_clipboard", {})
            if result:
                return f"Clipboard: {result.get('text', '')}"
            return "Failed to get clipboard"

        if action == "set_clipboard":
            result = await client.send_request("set_clipboard", {
                "text": params.get("text", "")
            })
            return self._format_result(result, f"Clipboard set to: {params.get('text')[:50]}...")

        if action == "get_screen_size":
            result = await client.send_request("get_screen_size", {})
            if result and result.get("success"):
                return f"Screen size: {result.get('width')}x{result.get('height')}"
            return "Failed to get screen size"

        if action == "get_mouse_position":
            result = await client.send_request("get_mouse_position", {})
            if result and result.get("success"):
                return f"Mouse position: ({result.get('x')}, {result.get('y')})"
            return "Failed to get mouse position"

        # ==================== Web Automation Actions ====================
        
        if action == "web_start":
            # 强制使用有头模式，不支持 headless
            result = await client.send_request("web_start", {
                "headless": False
            }, session_id=session_id)
            if result and result.get("success"):
                if is_new_session:
                    self._session_manager.register_session(session_id, {"browser_started": True})
            return self._format_filtered_result(result, action, session_id)

        if action == "web_stop":
            result = await client.send_request("web_stop", {})
            return self._format_result(result, "Browser stopped")

        if action == "web_navigate":
            result = await client.send_request("web_navigate", {
                "url": params.get("url", ""),
                "wait_until": params.get("wait_until", "domcontentloaded"),
                "timeout": params.get("timeout", 30000)
            }, session_id=session_id)
            if result and result.get("success"):
                return f"Navigated to: {result.get('url', params.get('url'))}\nTitle: {result.get('title', '')}\nSession: {session_id}"
            return self._format_filtered_result(result, action, session_id)

        if action == "web_navigate_safe":
            """Safe navigation with SSRF protection."""
            result = await client.send_request("web_navigate_safe", {
                "url": params.get("url", ""),
                "wait_until": params.get("wait_until", "domcontentloaded"),
                "timeout": params.get("timeout", 30000)
            }, session_id=session_id)
            if result and result.get("success"):
                return f"Safely navigated to: {result.get('url', params.get('url'))}\nTitle: {result.get('title', '')}\nSession: {session_id}"
            error = result.get("error", "unknown") if result else "no response"
            return f"Safe navigation failed: {error}"

        if action == "web_ai_snapshot":
            """Generate AI-friendly page snapshot with element refs."""
            result = await client.send_request("web_ai_snapshot", {}, session_id=session_id)
            if result and result.get("success"):
                snapshot = result.get("snapshot", "")
                refs = result.get("refs", {})
                url = result.get("url", "")
                title = result.get("title", "")
                summary = f"AI Snapshot for: {url}\nTitle: {title}\n"
                summary += f"Elements found: {len(refs)}\n\n"
                summary += snapshot[:3000]
                if len(snapshot) > 3000:
                    summary += "\n... (truncated)"
                return summary
            error = result.get("error", "unknown") if result else "no response"
            return f"AI snapshot failed: {error}"

        if action == "web_click":
            # Support both selector and ref (ref resolved on Windows side)
            selector = params.get("selector", "")
            ref = params.get("ref", "")
            result = await client.send_request("web_click", {
                "selector": selector,
                "ref": ref,
                "timeout": params.get("timeout", 10000)
            }, session_id=session_id)
            return self._format_filtered_result(result, action, session_id)

        if action == "web_fill":
            # Support both selector and ref (ref resolved on Windows side)
            selector = params.get("selector", "")
            ref = params.get("ref", "")
            result = await client.send_request("web_fill", {
                "selector": selector,
                "ref": ref,
                "value": params.get("value", ""),
                "timeout": params.get("timeout", 10000)
            }, session_id=session_id)
            return self._format_filtered_result(result, action, session_id)

        if action == "web_scroll":
            result = await client.send_request("web_scroll", {
                "direction": params.get("direction", "down"),
                "amount": params.get("amount", 500)
            })
            return self._format_result(result, f"Scrolled {params.get('direction')}")

        if action == "web_screenshot":
            result = await client.send_request("web_screenshot", {
                "selector": params.get("selector"),
                "full_page": params.get("full_page", False)
            })
            if result and result.get("success"):
                data = result.get("data", "")
                if data:
                    img_data = base64.b64decode(data)
                    import os
                    import tempfile
                    temp_dir = tempfile.gettempdir()
                    filepath = os.path.join(temp_dir, f"web_screenshot_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png")
                    with open(filepath, "wb") as f:
                        f.write(img_data)
                    return f"Web screenshot saved to: {filepath}"
            return self._format_result(result, "Web screenshot captured")

        if action == "web_get_content":
            result = await client.send_request("web_get_content", {})
            if result and result.get("success"):
                content = result.get("content", "")
                return f"Page content ({len(content)} chars):\n{content[:1000]}{'...' if len(content) > 1000 else ''}"
            return "Failed to get page content"

        if action == "web_get_url":
            result = await client.send_request("web_get_url", {})
            if result and result.get("success"):
                return f"Current URL: {result.get('url')}"
            return "Failed to get URL"

        if action == "web_get_title":
            result = await client.send_request("web_get_title", {})
            if result and result.get("success"):
                return f"Page title: {result.get('title')}"
            return "Failed to get title"

        if action == "web_extract_elements":
            result = await client.send_request("web_extract_elements", {
                "config": params.get("config", {})
            })
            if result and result.get("success"):
                elements = result.get("elements", [])
                summary = result.get("summary", {})
                return f"Extracted {len(elements)} elements (interactive: {summary.get('interactive', 0)})"
            return self._format_result(result, "Elements extracted")

        if action == "web_extract_data":
            result = await client.send_request("web_extract_data", {
                "selectors": params.get("selectors", [])
            })
            if result and result.get("success"):
                data = result.get("data", {})
                return f"Extracted data: {json.dumps(data, ensure_ascii=False, indent=2)}"
            return self._format_result(result, "Data extracted")

        if action == "web_get_cookies":
            result = await client.send_request("web_get_cookies", {})
            if result and result.get("success"):
                cookies = result.get("cookies", [])
                return f"Cookies ({len(cookies)}): {json.dumps(cookies[:5], ensure_ascii=False)}{'...' if len(cookies) > 5 else ''}"
            return "Failed to get cookies"

        if action == "web_set_cookies":
            result = await client.send_request("web_set_cookies", {
                "cookies": params.get("cookies", [])
            })
            return self._format_result(result, f"Set {len(params.get('cookies', []))} cookies")

        if action == "web_save_session":
            result = await client.send_request("web_save_session", {
                "session_id": params.get("session_id", "default")
            })
            return self._format_result(result, f"Session saved: {params.get('session_id')}")

        if action == "web_load_session":
            result = await client.send_request("web_load_session", {
                "session_id": params.get("session_id", "default")
            })
            return self._format_result(result, f"Session loaded: {params.get('session_id')}")

        if action == "web_login":
            result = await client.send_request("web_login", {
                "type": params.get("type", "form"),
                "params": params.get("params", {})
            })
            return self._format_result(result, "Login performed")

        if action == "web_press":
            result = await client.send_request("web_press", {
                "key": params.get("key", "")
            })
            return self._format_result(result, f"Pressed key: {params.get('key')}")

        if action == "web_type":
            result = await client.send_request("web_type", {
                "text": params.get("text", ""),
                "delay": params.get("delay", 50)
            })
            return self._format_result(result, f"Typed: {params.get('text')[:50]}...")

        if action == "web_evaluate":
            result = await client.send_request("web_evaluate", {
                "script": params.get("script", "")
            })
            if result and result.get("success"):
                return f"Result: {result.get('result')}"
            return self._format_result(result, "Script executed")

        if action == "web_wait_for_selector":
            result = await client.send_request("web_wait_for_selector", {
                "selector": params.get("selector", ""),
                "timeout": params.get("timeout", 10000)
            })
            return self._format_result(result, f"Element found: {params.get('selector')}")

        if action == "web_go_back":
            result = await client.send_request("web_go_back", {})
            if result and result.get("success"):
                return f"Went back to: {result.get('url')}"
            return self._format_result(result, "Went back")

        if action == "web_go_forward":
            result = await client.send_request("web_go_forward", {})
            if result and result.get("success"):
                return f"Went forward to: {result.get('url')}"
            return self._format_result(result, "Went forward")

        if action == "web_refresh":
            result = await client.send_request("web_refresh", {})
            if result and result.get("success"):
                return f"Refreshed: {result.get('url')}"
            return self._format_result(result, "Page refreshed")

        return f"Unknown action: {action}"

    def _format_result(self, result: dict[str, Any] | None, success_msg: str) -> str:
        if result is None:
            return "No response from Windows bridge"
        if result.get("success"):
            return success_msg
        return f"Failed: {result.get('error', 'Unknown error')}"
