"""Response filtering for Windows bridge tools."""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class ActionableElement:
    element_id: str
    text: str
    action_type: str
    tag: Optional[str] = None
    selector: Optional[str] = None
    bbox: Optional[List[int]] = None
    confidence: Optional[float] = None
    hint: str = ""
    
    def to_dict(self) -> dict:
        result = {
            "element_id": self.element_id,
            "text": self.text[:500] if self.text else "",
            "action_type": self.action_type,
            "hint": self.hint
        }
        if self.tag:
            result["tag"] = self.tag
        if self.selector:
            result["selector"] = self.selector
        if self.bbox:
            result["bbox"] = self.bbox
        if self.confidence is not None:
            result["confidence"] = self.confidence
        return result


@dataclass
class FilteredResult:
    success: bool
    session_id: Optional[str] = None
    action_type: str = ""
    elements: List[ActionableElement] = field(default_factory=list)
    summary: str = ""
    error: Optional[str] = None
    raw_data: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> dict:
        result = {
            "success": self.success,
            "session_id": self.session_id,
            "action_type": self.action_type,
            "elements": [e.to_dict() for e in self.elements],
            "summary": self.summary
        }
        if self.error:
            result["error"] = self.error
        return result


class ResponseFilter:
    MAX_ELEMENTS = 50
    MIN_CONFIDENCE = 0.7
    
    INTERACTIVE_TAGS = {"a", "button", "input", "select", "textarea"}
    INTERACTIVE_ACTIONS = {"click", "fill", "input"}
    
    def filter_web_response(self, result: dict, action: str, session_id: str = None) -> FilteredResult:
        if result is None:
            return FilteredResult(
                success=False,
                session_id=session_id,
                action_type=action,
                error="No response from bridge"
            )
        
        if result.get("success") == False:
            return FilteredResult(
                success=False,
                session_id=session_id,
                action_type=action,
                error=result.get("error") or result.get("message", "Unknown error"),
                raw_data=result
            )
        
        elements = []
        raw_elements = result.get("elements", [])
        
        for i, el in enumerate(raw_elements[:self.MAX_ELEMENTS]):
            if not self._is_interactive_element(el):
                continue
            
            element = ActionableElement(
                element_id=str(el.get("id", i + 1)),
                text=el.get("text", ""),
                action_type=self._map_action_type(el.get("action_type", "click")),
                tag=el.get("tag"),
                selector=el.get("selector"),
                hint=self._generate_web_hint(el)
            )
            elements.append(element)
        
        summary = self._generate_web_summary(result, elements, action)
        
        return FilteredResult(
            success=True,
            session_id=session_id,
            action_type=action,
            elements=elements,
            summary=summary,
            raw_data=result
        )
    
    def filter_app_response(self, result: dict, action: str, session_id: str = None) -> FilteredResult:
        if result is None:
            return FilteredResult(
                success=False,
                session_id=session_id,
                action_type=action,
                error="No response from bridge"
            )
        
        if result.get("success") == False:
            return FilteredResult(
                success=False,
                session_id=session_id,
                action_type=action,
                error=result.get("error") or result.get("message", "Unknown error"),
                raw_data=result
            )
        
        elements = []
        raw_elements = result.get("elements", [])
        
        for i, el in enumerate(raw_elements[:self.MAX_ELEMENTS]):
            confidence = el.get("confidence", 1.0)
            if confidence < self.MIN_CONFIDENCE:
                continue
            
            action_type = el.get("action_type", "none")
            if action_type not in self.INTERACTIVE_ACTIONS:
                continue
            
            element = ActionableElement(
                element_id=f"gui_{i + 1}",
                text=el.get("text", ""),
                action_type=action_type,
                bbox=el.get("bbox"),
                confidence=confidence,
                hint=el.get("hint", "")
            )
            elements.append(element)
        
        summary = self._generate_app_summary(result, elements, action)
        
        return FilteredResult(
            success=True,
            session_id=session_id,
            action_type=action,
            elements=elements,
            summary=summary,
            raw_data=result
        )
    
    def filter_gui_elements(self, elements: List[dict]) -> List[ActionableElement]:
        result = []
        
        for i, el in enumerate(elements[:self.MAX_ELEMENTS]):
            confidence = el.get("confidence", 1.0)
            if confidence < self.MIN_CONFIDENCE:
                continue
            
            action_type = el.get("action_type", "none")
            if action_type not in self.INTERACTIVE_ACTIONS:
                continue
            
            element = ActionableElement(
                element_id=f"gui_{i + 1}",
                text=el.get("text", ""),
                action_type=action_type,
                bbox=el.get("bbox"),
                confidence=confidence,
                hint=el.get("hint", "")
            )
            result.append(element)
        
        return result
    
    def _is_interactive_element(self, el: dict) -> bool:
        tag = el.get("tag", "").lower()
        action_type = el.get("action_type", "").lower()
        is_interactive = el.get("is_interactive", False)
        
        if tag in self.INTERACTIVE_TAGS:
            return True
        if action_type in self.INTERACTIVE_ACTIONS:
            return True
        if is_interactive:
            return True
        return False
    
    def _map_action_type(self, action_type: str) -> str:
        mapping = {
            "fill": "input",
            "type": "input",
            "submit": "click",
        }
        return mapping.get(action_type.lower(), action_type.lower())
    
    def _generate_web_hint(self, el: dict) -> str:
        tag = el.get("tag", "").lower()
        text = el.get("text", "")[:50]
        action = el.get("action_type", "click")
        
        if tag == "a":
            return f"点击链接「{text}」"
        elif tag == "button":
            return f"点击按钮「{text}」"
        elif tag in ("input", "textarea"):
            input_type = el.get("type", "text")
            if input_type == "submit":
                return f"点击提交按钮「{text}」"
            return f"在输入框输入"
        elif tag == "select":
            return f"选择「{text}」"
        else:
            if action == "click":
                return f"点击「{text}」"
            elif action == "fill":
                return f"在「{text}」输入"
            return ""
    
    def _generate_web_summary(self, result: dict, elements: List[ActionableElement], action: str) -> str:
        url = result.get("url", "")
        title = result.get("title", "")
        
        if action == "navigate":
            return f"已导航到 {url}，发现 {len(elements)} 个可交互元素"
        elif action == "extract_elements":
            return f"提取到 {len(elements)} 个可交互元素"
        elif action == "click":
            return f"已点击元素"
        elif action == "fill":
            return f"已填写表单"
        else:
            if title:
                return f"页面: {title}，{len(elements)} 个可交互元素"
            return f"操作完成，{len(elements)} 个可交互元素"
    
    def _generate_app_summary(self, result: dict, elements: List[ActionableElement], action: str) -> str:
        summary_data = result.get("summary", {})
        
        if action == "screenshot_ocr":
            total = summary_data.get("total", len(elements))
            clickable = summary_data.get("clickable", 0)
            inputable = summary_data.get("inputable", 0)
            return f"OCR 识别到 {total} 个元素（{clickable} 个可点击，{inputable} 个可输入）"
        elif action == "click":
            return f"已点击元素"
        elif action == "input":
            return f"已输入文本"
        else:
            return f"操作完成，发现 {len(elements)} 个可交互元素"


_response_filter: ResponseFilter | None = None


def get_response_filter() -> ResponseFilter:
    global _response_filter
    if _response_filter is None:
        _response_filter = ResponseFilter()
    return _response_filter
