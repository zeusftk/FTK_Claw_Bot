"""Agent loop: the core processing engine."""

from __future__ import annotations

import asyncio
import json
import re
from contextlib import AsyncExitStack
from pathlib import Path
from typing import TYPE_CHECKING, Awaitable, Callable

from loguru import logger

from clawbot.agent.context import ContextBuilder
from clawbot.hooks import trigger_hook, HookEvent, HookEventType
from clawbot.agent.intent_classifier import IntentClassifier, TaskCategory
from clawbot.agent.memory import MemoryStore
from clawbot.agent.subagent import SubagentManager
from clawbot.agent.tools.cron import CronTool
from clawbot.agent.tools.filesystem import EditFileTool, ListDirTool, ReadFileTool, WriteFileTool
from clawbot.agent.tools.message import MessageTool
from clawbot.agent.tools.registry import ToolRegistry
from clawbot.agent.tools.shell import ExecTool
from clawbot.agent.tools.spawn import SpawnTool
from clawbot.agent.tools.web import WebFetchTool, WebSearchTool
from clawbot.agent.tools.windows_gui import WindowsGUITool
from clawbot.bus.events import InboundMessage, OutboundMessage
from clawbot.bus.queue import MessageBus
from clawbot.core.task_router import RouteDecision, TaskCategory, UnifiedTaskRouter
from clawbot.memory.config import EmbeddingApiConfig, MemOSConfig
from clawbot.providers.base import LLMProvider
from clawbot.session.manager import Session, SessionManager

if TYPE_CHECKING:
    from clawbot.config.schema import ChannelsConfig, ExecToolConfig, OpenWorkConfig, WindowsBridgeConfig, SkillsConfig
    from clawbot.cron.service import CronService
    from clawbot.openwork.integration import OpenWorkIntegration
    from clawbot.services.openwork_manager import OpenWorkServiceManager


class AgentLoop:
    """
    The agent loop is the core processing engine.

    It:
    1. Receives messages from the bus
    2. Builds context with history, memory, skills
    3. Calls the LLM
    4. Executes tool calls
    5. Sends responses back
    """

    _SENSITIVE_TOOLS = frozenset({"message", "exec", "write_file", "edit_file"})
    _SENSITIVE_PATTERNS = [
        "api_key", "apikey", "api-key",
        "token", "access_token", "auth_token",
        "password", "passwd", "pwd",
        "secret", "credential", "private_key",
        "authorization", "bearer",
    ]

    def __init__(
        self,
        bus: MessageBus,
        provider: LLMProvider,
        workspace: Path,
        model: str | None = None,
        max_iterations: int = 200,
        temperature: float = 0.1,
        max_tokens: int = 4096,
        memory_window: int = 100,
        brave_api_key: str | None = None,
        exec_config: ExecToolConfig | None = None,
        cron_service: CronService | None = None,
        restrict_to_workspace: bool = False,
        session_manager: SessionManager | None = None,
        mcp_servers: dict | None = None,
        channels_config: "ChannelsConfig | None" = None,
        windows_bridge_config: "WindowsBridgeConfig | None" = None,
        embedding_api_config: EmbeddingApiConfig | None = None,
        memos_config: MemOSConfig | None = None,
        openwork_config: "OpenWorkConfig | None" = None,
        skills_config: "SkillsConfig | None" = None,
    ):
        from clawbot.config.schema import ExecToolConfig
        self.bus = bus
        self.channels_config = channels_config
        self.provider = provider
        self.workspace = workspace
        self.model = model or provider.get_default_model()
        self.max_iterations = max_iterations
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.memory_window = memory_window
        self.brave_api_key = brave_api_key
        self.exec_config = exec_config or ExecToolConfig()
        self.cron_service = cron_service
        self.restrict_to_workspace = restrict_to_workspace
        self.windows_bridge_config = windows_bridge_config
        self.embedding_api_config = embedding_api_config
        self.memos_config = memos_config
        self.openwork_config = openwork_config
        self.skills_config = skills_config

        self.context = ContextBuilder(workspace, embedding_api_config, memos_config, skills_config)
        self.sessions = session_manager or SessionManager(workspace)
        self.tools = ToolRegistry()
        self.subagents = SubagentManager(
            provider=provider,
            workspace=workspace,
            bus=bus,
            model=self.model,
            temperature=self.temperature,
            max_tokens=self.max_tokens,
            brave_api_key=brave_api_key,
            exec_config=self.exec_config,
            restrict_to_workspace=restrict_to_workspace,
        )

        self.intent_classifier = IntentClassifier(
            openwork_enabled=openwork_config.enabled if openwork_config else False
        )

        self._task_router = UnifiedTaskRouter(
            openwork_enabled=openwork_config.enabled if openwork_config else False,
            execution_threshold=openwork_config.router.execution_threshold if openwork_config else 0.4,
            conversation_threshold=openwork_config.router.conversation_threshold if openwork_config else 0.5,
        )

        self._openwork_manager: "OpenWorkServiceManager | None" = None
        self._openwork_integration: "OpenWorkIntegration | None" = None
        if openwork_config and openwork_config.enabled:
            self._init_openwork_manager(openwork_config)

        self._running = False
        self.conversation_count = 0
        self._reflection_threshold = 10
        self._mcp_servers = mcp_servers or {}
        self._mcp_stack: AsyncExitStack | None = None
        self._mcp_connected = False
        self._mcp_connecting = False
        self._consolidating: set[str] = set()
        self._consolidation_tasks: set[asyncio.Task] = set()
        self._consolidation_locks: dict[str, asyncio.Lock] = {}
        self._consolidation_lock_creation = asyncio.Lock()
        self._register_default_tools()

    def _register_default_tools(self) -> None:
        """Register the default set of tools."""
        allowed_dir = self.workspace if self.restrict_to_workspace else None
        self.tools.register(ReadFileTool(allowed_dir=allowed_dir))
        self.tools.register(WriteFileTool(allowed_dir=allowed_dir))
        self.tools.register(EditFileTool(allowed_dir=allowed_dir))
        self.tools.register(ListDirTool(allowed_dir=allowed_dir))

        self.tools.register(ExecTool(
            working_dir=str(self.workspace),
            timeout=self.exec_config.timeout,
            restrict_to_workspace=self.restrict_to_workspace,
        ))

        self.tools.register(WebSearchTool(
            api_key=self.brave_api_key,
            workspace=self.workspace,
        ))
        self.tools.register(WebFetchTool())
        self.tools.register(MessageTool(send_callback=self.bus.publish_outbound))
        self.tools.register(SpawnTool(manager=self.subagents))
        if self.cron_service:
            self.tools.register(CronTool(self.cron_service))

        wb = self.windows_bridge_config
        self.tools.register(WindowsGUITool(
            host=wb.host if wb else None,
            port=wb.port if wb else 9527,
            auto_connect=wb.auto_connect if wb else True,
        ))

    def _init_openwork_manager(self, config: "OpenWorkConfig") -> None:
        """Initialize OpenWork service manager if enabled."""
        try:
            from clawbot.services.openwork_manager import OpenWorkServiceManager

            self._openwork_manager = OpenWorkServiceManager(
                port=config.orchestrator_port,
                workspace=self.workspace / "openwork",
                auto_start=config.auto_start,
                auto_restart=config.auto_restart,
                startup_timeout=config.startup_timeout,
                fallback_to_local=config.router.fallback_to_local,
            )
            logger.info(f"OpenWork service manager initialized (port: {config.orchestrator_port})")
        except ImportError:
            logger.warning("OpenWork service manager module not available")
            self._openwork_manager = None
        except Exception as e:
            logger.warning(f"Failed to initialize OpenWork service manager: {e}")
            self._openwork_manager = None

        try:
            from clawbot.openwork.integration import OpenWorkIntegration

            self._openwork_integration = OpenWorkIntegration(
                workspace=self.workspace,
                provider=self.provider,
                send_message=self._send_openwork_message,
                openwork_url=f"http://localhost:{config.orchestrator_port}",
                enhancement_interval_hours=config.enhancement_interval_hours,
            )
            logger.info(f"OpenWork integration initialized (port: {config.orchestrator_port})")
        except ImportError:
            logger.warning("OpenWork integration module not available")
            self._openwork_integration = None
        except Exception as e:
            logger.warning(f"Failed to initialize OpenWork integration: {e}")
            self._openwork_integration = None

    def _send_openwork_message(self, user_id: str, content: str) -> None:
        """Send message from OpenWork to user."""
        asyncio.create_task(self.bus.publish_outbound(OutboundMessage(
            channel="websocket",
            chat_id=user_id,
            content=content,
        )))

    async def _process_openwork_task(self, msg: InboundMessage, intent_result) -> OutboundMessage | None:
        """Process a programming task through OpenWork pipeline."""
        if not self._openwork_integration:
            return OutboundMessage(
                channel=msg.channel,
                chat_id=msg.chat_id,
                content="OpenWork service not enabled. Please enable openwork.enabled = true in config",
            )

        try:
            from clawbot.openwork.idea_processor import IdeaProcessor
            from clawbot.openwork.task_router import TaskRouter

            idea_processor = IdeaProcessor(
                llm_provider=self.provider,
                workspace=self.workspace,
            )

            processed_idea = await idea_processor.process(msg.content, user_id=msg.sender_id)

            if processed_idea.clarifications_needed:
                clarifications = await idea_processor.clarify(msg.content, processed_idea.clarifications_needed)
                return OutboundMessage(
                    channel=msg.channel,
                    chat_id=msg.chat_id,
                    content=clarifications,
                )

            task_router = TaskRouter(
                openwork_service=None,
                orchestrator=self._openwork_integration._orchestrator if self._openwork_integration else None,
                default_workspace=self.workspace / "openwork",
                auto_confirm=True,
            )

            route_decision = await task_router.route(processed_idea)

            if route_decision.requires_confirmation and route_decision.confirmation_message:
                return OutboundMessage(
                    channel=msg.channel,
                    chat_id=msg.chat_id,
                    content=route_decision.confirmation_message,
                )

            execution_result = await task_router.execute(route_decision, msg.content)

            if execution_result.success:
                return OutboundMessage(
                    channel=msg.channel,
                    chat_id=msg.chat_id,
                    content=f"Task completed\n\n{execution_result.output}",
                )
            else:
                return OutboundMessage(
                    channel=msg.channel,
                    chat_id=msg.chat_id,
                    content=f"Task execution failed\n\n{execution_result.output}",
                )

        except Exception as e:
            logger.exception(
                "OpenWork task processing failed: {}",
                str(e),
                extra={
                    "channel": msg.channel,
                    "sender_id": msg.sender_id,
                    "task_preview": msg.content[:100] if msg.content else "",
                }
            )
            return OutboundMessage(
                channel=msg.channel,
                chat_id=msg.chat_id,
                content=f"OpenWork processing error: {str(e)}\n\nWill use regular flow for your request.",
            )

    async def _execute_via_openwork(
        self,
        msg: InboundMessage,
        decision: RouteDecision,
    ) -> OutboundMessage | None:
        """Execute task via OpenWork service manager."""
        if not self._openwork_manager:
            logger.warning(
                "OpenWork not enabled, routing to local tools",
                extra={"channel": msg.channel, "sender_id": msg.sender_id}
            )
            return OutboundMessage(
                channel=msg.channel,
                chat_id=msg.chat_id,
                content="OpenWork service not enabled. Please enable openwork.enabled = true in config",
            )

        service_status = self._openwork_manager.status.value
        logger.info(
            f"Attempting OpenWork execution (status: {service_status})",
            extra={
                "channel": msg.channel,
                "task_type": decision.task_type,
                "confidence": decision.confidence,
            }
        )

        if not await self._openwork_manager.ensure_running():
            fallback_to_local = (
                self.openwork_config
                and self.openwork_config.router.fallback_to_local
            )

            logger.warning(
                "OpenWork service unavailable",
                extra={
                    "reason": "service_unavailable",
                    "status": self._openwork_manager.status.value,
                    "fallback_to_local": fallback_to_local,
                    "task_preview": msg.content[:100],
                }
            )

            if fallback_to_local:
                return None

            status_info = self._openwork_manager.get_status_info()
            install_hint = ""
            if status_info.get("status") == "not_installed":
                install_hint = "\n\nInstall:\n```bash\nnpm install -g openwork-server\n# or\nbun install -g openwork-server\n```"

            return OutboundMessage(
                channel=msg.channel,
                chat_id=msg.chat_id,
                content=f"OpenWork service unavailable (status: {status_info.get('status')}). {install_hint}",
            )

        try:
            result = await self._openwork_manager.execute(
                task=msg.content,
                task_type=decision.task_type,
                workspace=self.workspace,
            )

            if result.get("success"):
                output = result.get("output", "")
                logger.info(
                    "OpenWork task completed successfully",
                    extra={
                        "task_type": decision.task_type,
                        "output_length": len(output) if output else 0,
                    }
                )
                return OutboundMessage(
                    channel=msg.channel,
                    chat_id=msg.chat_id,
                    content=f"Task completed\n\n{output}",
                )
            else:
                error = result.get("error", "Unknown error")
                logger.error(
                    "OpenWork task execution failed",
                    extra={
                        "error": error,
                        "task_type": decision.task_type,
                    }
                )
                return OutboundMessage(
                    channel=msg.channel,
                    chat_id=msg.chat_id,
                    content=f"Task execution failed\n\n{error}",
                )

        except Exception as e:
            logger.exception(
                "OpenWork execution error",
                extra={
                    "error": str(e),
                    "task_type": decision.task_type,
                }
            )
            return OutboundMessage(
                channel=msg.channel,
                chat_id=msg.chat_id,
                content=f"OpenWork execution error: {str(e)}",
            )

    async def _connect_mcp(self) -> None:
        """Connect to configured MCP servers (one-time, lazy)."""
        if self._mcp_connected or self._mcp_connecting or not self._mcp_servers:
            return
        self._mcp_connecting = True
        from clawbot.agent.tools.mcp import connect_mcp_servers
        try:
            self._mcp_stack = AsyncExitStack()
            await self._mcp_stack.__aenter__()
            await connect_mcp_servers(self._mcp_servers, self.tools, self._mcp_stack)
            self._mcp_connected = True
        except Exception as e:
            logger.error("Failed to connect MCP servers (will retry next message): {}", e)
            if self._mcp_stack:
                try:
                    await self._mcp_stack.aclose()
                except (RuntimeError, OSError) as e:
                    logger.debug("MCP stack close error ignored: {}", e)
                self._mcp_stack = None
        finally:
            self._mcp_connecting = False

    async def _connect_windows_bridge(self) -> None:
        """Connect to Windows bridge if auto_connect is enabled."""
        wb = self.windows_bridge_config
        if not wb or not wb.enabled or not wb.auto_connect:
            return

        windows_gui_tool = self.tools.get("windows_gui")
        if not windows_gui_tool or not isinstance(windows_gui_tool, WindowsGUITool):
            return

        host = wb.host or "Windows host"
        logger.info(f"[AgentLoop] Attempting auto-connect Windows bridge: host={wb.host}, port={wb.port}")

        try:
            client = windows_gui_tool._get_client()
            success = await client.connect(host=wb.host, port=wb.port, send_identify=True)
            if success:
                logger.info(f"[AgentLoop] Windows bridge auto-connect success: {client.host}:{client.port}")
            else:
                logger.warning(
                    f"[AgentLoop] Windows bridge auto-connect failed. "
                    f"请在 FTK_Claw_Bot 桥接面板点击刷新按钮重启 bridge 服务，"
                    f"或检查端口 {wb.port} 是否被占用。"
                )
        except Exception as e:
            logger.warning(
                f"[AgentLoop] Windows bridge auto-connect error: {e}. "
                f"请在 FTK_Claw_Bot 桥接面板点击刷新按钮重启 bridge 服务。"
            )

    def _set_tool_context(self, channel: str, chat_id: str, message_id: str | None = None) -> None:
        """Update context for all tools that need routing info."""
        if message_tool := self.tools.get("message"):
            if isinstance(message_tool, MessageTool):
                message_tool.set_context(channel, chat_id, message_id)

        if spawn_tool := self.tools.get("spawn"):
            if isinstance(spawn_tool, SpawnTool):
                spawn_tool.set_context(channel, chat_id)

        if cron_tool := self.tools.get("cron"):
            if isinstance(cron_tool, CronTool):
                cron_tool.set_context(channel, chat_id)

    def _contains_sensitive_info(self, text: str) -> bool:
        """Check if text contains sensitive information patterns."""
        lower_text = text.lower()
        return any(pattern in lower_text for pattern in self._SENSITIVE_PATTERNS)

    @staticmethod
    def _strip_think(text: str | None) -> str | None:
        """Remove <think&gt;...&lt;/think&gt; blocks that some models embed in content."""
        if not text:
            return None
        return re.sub(r"<think&gt;[\s\S]*?&lt;/think&gt;", "", text).strip() or None

    @staticmethod
    def _tool_hint(tool_calls: list) -> str:
        """Format tool calls as concise hint, e.g. 'web_search("query")'."""
        def _fmt(tc):
            val = next(iter(tc.arguments.values()), None) if tc.arguments else None
            if not isinstance(val, str):
                return tc.name
            return f'{tc.name}("{val[:40]}...")' if len(val) > 40 else f'{tc.name}("{val}")'
        return ", ".join(_fmt(tc) for tc in tool_calls)

    async def _run_agent_loop(
        self,
        initial_messages: list[dict],
        on_progress: Callable[..., Awaitable[None]] | None = None,
    ) -> tuple[str | None, list[str], list[dict]]:
        """Run the agent iteration loop. Returns (final_content, tools_used, messages)."""
        messages = initial_messages
        iteration = 0
        final_content = None
        tools_used: list[str] = []

        while iteration < self.max_iterations:
            iteration += 1

            response = await self.provider.chat(
                messages=messages,
                tools=self.tools.get_definitions(),
                model=self.model,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
            )

            if response.has_tool_calls:
                if on_progress:
                    clean = self._strip_think(response.content)
                    if clean:
                        await on_progress(clean)
                    await on_progress(self._tool_hint(response.tool_calls), tool_hint=True)

                tool_call_dicts = [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {
                            "name": tc.name,
                            "arguments": json.dumps(tc.arguments, ensure_ascii=False)
                        }
                    }
                    for tc in response.tool_calls
                ]
                messages = self.context.add_assistant_message(
                    messages, response.content, tool_call_dicts,
                    reasoning_content=response.reasoning_content,
                )

                for tool_call in response.tool_calls:
                    tools_used.append(tool_call.name)
                    if tool_call.name in self._SENSITIVE_TOOLS:
                        logger.info("Tool call: {}(args omitted)", tool_call.name)
                    else:
                        args_str = json.dumps(tool_call.arguments, ensure_ascii=False)
                        if self._contains_sensitive_info(args_str):
                            logger.info("Tool call: {}(args redacted - sensitive data)", tool_call.name)
                        else:
                            logger.info("Tool call: {}({})", tool_call.name, args_str[:200])
                    result = await self.tools.execute(tool_call.name, tool_call.arguments)
                    messages = self.context.add_tool_result(
                        messages, tool_call.id, tool_call.name, result
                    )
            else:
                final_content = self._strip_think(response.content)
                break

        if final_content is None and iteration >= self.max_iterations:
            logger.warning("Max iterations ({}) reached", self.max_iterations)
            final_content = (
                f"I reached the maximum number of tool call iterations ({self.max_iterations}) "
                "without completing the task. You can try breaking the task into smaller steps."
            )

        return final_content, tools_used, messages

    async def run(self) -> None:
        """Run the agent loop, processing messages from the bus."""
        self._running = True

        # Trigger gateway:startup hook
        await trigger_hook(HookEvent(
            type=HookEventType.GATEWAY,
            action="startup",
            session_key="",
            context={"provider": self.provider.__class__.__name__, "workspace": str(self.workspace)}
        ))

        if self._openwork_manager:
            await self._openwork_manager.start()
            logger.info("OpenWork service started")

        await self._connect_mcp()
        await self._connect_windows_bridge()
        logger.info("Agent loop started")

        while self._running:
            try:
                msg = await asyncio.wait_for(
                    self.bus.consume_inbound(),
                    timeout=1.0
                )
                try:
                    response = await self._process_message(msg)
                    if response is not None:
                        await self.bus.publish_outbound(response)
                    elif msg.channel == "cli":
                        await self.bus.publish_outbound(OutboundMessage(
                            channel=msg.channel, chat_id=msg.chat_id, content="", metadata=msg.metadata or {},
                        ))
                except Exception as e:
                    logger.exception("Error processing message from {}:{}", msg.channel, msg.sender_id)
                    error_msg = self._format_user_error(e)
                    await self.bus.publish_outbound(OutboundMessage(
                        channel=msg.channel,
                        chat_id=msg.chat_id,
                        content=error_msg
                    ))
            except asyncio.TimeoutError:
                continue

    async def close_mcp(self) -> None:
        """Close MCP connections and cancel background tasks."""
        for task in list(self._consolidation_tasks):
            task.cancel()
        if self._consolidation_tasks:
            await asyncio.gather(*self._consolidation_tasks, return_exceptions=True)
            self._consolidation_tasks.clear()

        if self._mcp_stack:
            try:
                await self._mcp_stack.aclose()
            except RuntimeError as e:
                logger.warning("MCP stack close runtime error: {}", e)
            except BaseExceptionGroup as e:
                logger.warning("MCP stack close exception group: {}", e)
                for exc in e.exceptions:
                    logger.debug("MCP stack close exception detail: {}", exc)
            except Exception as e:
                logger.warning("MCP stack close unexpected error: {}", e)
            finally:
                self._mcp_stack = None

    def stop(self) -> None:
        """Stop the agent loop."""
        self._running = False

        if self._openwork_manager:
            asyncio.create_task(self._openwork_manager.stop())

        # Clear hooks to prevent stale handlers
        from clawbot.hooks import HookRegistry
        HookRegistry().clear()

        logger.info("Agent loop stopping")

    @staticmethod
    def _format_user_error(error: Exception) -> str:
        """Format error message safe for user display."""
        if isinstance(error, (TimeoutError, asyncio.TimeoutError)):
            return "Operation timed out, please try again later."
        if isinstance(error, (ConnectionError, ConnectionRefusedError, ConnectionResetError)):
            return "Network connection issue, please check your network and try again."
        if isinstance(error, PermissionError):
            return "Permission denied, cannot execute this operation."
        if isinstance(error, FileNotFoundError):
            return "Requested resource does not exist."
        if isinstance(error, ValueError):
            return f"Invalid request parameter: {str(error)[:100]}"
        return "An issue occurred while processing your request, please try again later."

    async def _get_consolidation_lock(self, session_key: str) -> asyncio.Lock:
        async with self._consolidation_lock_creation:
            lock = self._consolidation_locks.get(session_key)
            if lock is None:
                lock = asyncio.Lock()
                self._consolidation_locks[session_key] = lock
            return lock

    def _prune_consolidation_lock(self, session_key: str, lock: asyncio.Lock) -> None:
        """Drop lock entry if no longer in use."""
        if not lock.locked():
            if self._consolidation_locks.get(session_key) is lock:
                self._consolidation_locks.pop(session_key, None)

    async def _process_message(
        self,
        msg: InboundMessage,
        session_key: str | None = None,
        on_progress: Callable[[str], Awaitable[None]] | None = None,
    ) -> OutboundMessage | None:
        """Process a single inbound message and return the response."""
        if msg.channel == "system":
            channel, chat_id = (msg.chat_id.split(":", 1) if ":" in msg.chat_id
                                else ("cli", msg.chat_id))
            logger.info("Processing system message from {}", msg.sender_id)
            key = f"{channel}:{chat_id}"
            session = self.sessions.get_or_create(key)
            self._set_tool_context(channel, chat_id, msg.metadata.get("message_id"))
            history = session.get_history(max_messages=self.memory_window)
            messages = self.context.build_messages(
                history=history,
                current_message=msg.content, channel=channel, chat_id=chat_id,
            )
            final_content, _, all_msgs = await self._run_agent_loop(messages)
            self._save_turn(session, all_msgs, 1 + len(history))
            self.sessions.save(session)
            return OutboundMessage(channel=channel, chat_id=chat_id,
                                  content=final_content or "Background task completed.")

        preview = msg.content[:80] + "..." if len(msg.content) > 80 else msg.content
        logger.info("Processing message from {}:{}: {}", msg.channel, msg.sender_id, preview)

        route_decision = self._task_router.route(msg.content, {
            "channel": msg.channel,
            "sender_id": msg.sender_id,
        })
        logger.info("Task routing: {} (category: {}, confidence: {:.2f})",
                   route_decision.handler, route_decision.category.value, route_decision.confidence)

        if route_decision.category == TaskCategory.OPENWORK_EXECUTION:
            logger.info("Routing to OpenWork for execution task")
            return await self._execute_via_openwork(msg, route_decision)

        key = session_key or msg.session_key
        session = self.sessions.get_or_create(key)

        # Trigger message:received hook
        await trigger_hook(HookEvent(
            type=HookEventType.MESSAGE,
            action="received",
            session_key=key,
            context={
                "from": msg.sender_id,
                "content": msg.content[:200] if len(msg.content) > 200 else msg.content,
                "channel_id": msg.channel,
                "chat_id": msg.chat_id,
            }
        ))

        cmd = msg.content.strip().lower()
        if cmd == "/new":
            lock = await self._get_consolidation_lock(session.key)
            self._consolidating.add(session.key)
            try:
                async with lock:
                    snapshot = session.messages[session.last_consolidated:]
                    if snapshot:
                        temp = Session(key=session.key)
                        temp.messages = list(snapshot)
                        if not await self._consolidate_memory(temp, archive_all=True):
                            return OutboundMessage(
                                channel=msg.channel, chat_id=msg.chat_id,
                                content="Memory archival failed, session not cleared. Please try again.",
                            )
            except (IOError, json.JSONDecodeError) as e:
                logger.exception("/new archival failed for {}: {}", session.key, e)
                return OutboundMessage(
                    channel=msg.channel, chat_id=msg.chat_id,
                    content="Memory archival failed, session not cleared. Please try again.",
                )
            finally:
                self._consolidating.discard(session.key)
                self._prune_consolidation_lock(session.key, lock)

            session.clear()
            self.sessions.save(session)
            self.sessions.invalidate(session.key)
            return OutboundMessage(channel=msg.channel, chat_id=msg.chat_id,
                                  content="New session started.")
        if cmd == "/help":
            return OutboundMessage(channel=msg.channel, chat_id=msg.chat_id,
                                  content="clawbot commands:\n/new - Start a new conversation\n/stop - Stop processing and clear pending messages\n/help - Show available commands")

        if cmd == "/stop":
            inbound_cleared = self.bus.clear_inbound()
            self.bus.clear_outbound()
            return OutboundMessage(channel=msg.channel, chat_id=msg.chat_id,
                                  content=f"Stopped. Cleared {inbound_cleared} pending messages.")

        unconsolidated = len(session.messages) - session.last_consolidated
        if (unconsolidated >= self.memory_window and session.key not in self._consolidating):
            self._consolidating.add(session.key)
            lock = await self._get_consolidation_lock(session.key)

            async def _consolidate_and_unlock():
                try:
                    async with lock:
                        await self._consolidate_memory(session)
                finally:
                    self._consolidating.discard(session.key)
                    self._prune_consolidation_lock(session.key, lock)
                    _task = asyncio.current_task()
                    if _task is not None:
                        self._consolidation_tasks.discard(_task)

            _task = asyncio.create_task(_consolidate_and_unlock())
            self._consolidation_tasks.add(_task)

        self._set_tool_context(msg.channel, msg.chat_id, msg.metadata.get("message_id"))
        if message_tool := self.tools.get("message"):
            if isinstance(message_tool, MessageTool):
                message_tool.start_turn()

        history = session.get_history(max_messages=self.memory_window)
        initial_messages = self.context.build_messages(
            history=history,
            current_message=msg.content,
            media=msg.media if msg.media else None,
            channel=msg.channel, chat_id=msg.chat_id,
        )

        async def _bus_progress(content: str, *, tool_hint: bool = False) -> None:
            meta = dict(msg.metadata or {})
            meta["_progress"] = True
            meta["_tool_hint"] = tool_hint
            await self.bus.publish_outbound(OutboundMessage(
                channel=msg.channel, chat_id=msg.chat_id, content=content, metadata=meta,
            ))

        final_content, _, all_msgs = await self._run_agent_loop(
            initial_messages, on_progress=on_progress or _bus_progress,
        )

        if final_content is None:
            final_content = "I've completed processing but have no response to give."

        preview = final_content[:120] + "..." if len(final_content) > 120 else final_content
        logger.info("Response to {}:{}: {}", msg.channel, msg.sender_id, preview)

        # Trigger message:sent hook
        await trigger_hook(HookEvent(
            type=HookEventType.MESSAGE,
            action="sent",
            session_key=key,
            context={
                "to": msg.sender_id,
                "content": preview,
                "success": True,
                "channel_id": msg.channel,
                "chat_id": msg.chat_id,
            }
        ))

        self._save_turn(session, all_msgs, 1 + len(history))
        self.sessions.save(session)

        if message_tool := self.tools.get("message"):
            if isinstance(message_tool, MessageTool) and message_tool._sent_in_turn:
                return None

        return OutboundMessage(
            channel=msg.channel, chat_id=msg.chat_id, content=final_content,
            metadata=msg.metadata or {},
        )

    _TOOL_RESULT_MAX_CHARS = 500

    def _save_turn(self, session: Session, messages: list[dict], skip: int) -> None:
        """Save new-turn messages into session, truncating large tool results."""
        from datetime import datetime
        timestamp = datetime.now()
        timestamp_iso = timestamp.isoformat()

        for m in messages[skip:]:
            entry = {k: v for k, v in m.items() if k != "reasoning_content"}
            if entry.get("role") == "tool" and isinstance(entry.get("content"), str):
                content = entry["content"]
                if len(content) > self._TOOL_RESULT_MAX_CHARS:
                    entry["content"] = content[:self._TOOL_RESULT_MAX_CHARS] + "\n... (truncated)"
            entry.setdefault("timestamp", timestamp_iso)
            session.messages.append(entry)
        session.updated_at = timestamp

    async def _consolidate_memory(self, session, archive_all: bool = False) -> bool:
        """Delegate to MemoryStore.consolidate(). Returns True on success."""
        return await MemoryStore(self.workspace).consolidate(
            session, self.provider, self.model,
            archive_all=archive_all, memory_window=self.memory_window,
        )

    async def process_direct(
        self,
        content: str,
        session_key: str = "cli:direct",
        channel: str = "cli",
        chat_id: str = "direct",
        on_progress: Callable[[str], Awaitable[None]] | None = None,
    ) -> str:
        """Process a message directly (for CLI or cron usage)."""
        await self._connect_mcp()
        msg = InboundMessage(channel=channel, sender_id="user", chat_id=chat_id, content=content)
        response = await self._process_message(msg, session_key=session_key, on_progress=on_progress)
        return response.content if response else ""
