"""
路由共享常量

统一管理 IntentClassifier 和 UnifiedTaskRouter 使用的常量，
避免代码重复，确保行为一致。
"""

import re
from enum import Enum
from typing import Any


class TaskCategory(Enum):
    """任务类别"""
    CONVERSATION = "conversation"
    OPENWORK_EXECUTION = "openwork"
    LOCAL_TOOL = "local_tool"
    SYSTEM_COMMAND = "system_command"
    GUI_AUTOMATION = "gui_automation"  # GUI 自动化任务，走本地工具


# GUI 自动化关键词 - 这些请求应该走本地 WindowsGUITool，不走 OpenWork
GUI_AUTOMATION_KEYWORDS = [
    # 浏览器相关
    "浏览器", "browser", "网页", "web", "网站",
    "打开浏览器", "open browser", "访问网站",
    "网页操作", "web automation", "网页自动化",
    "playwright", "selenium",
    
    # GUI 相关
    "截图", "screenshot", "截屏",
    "GUI", "桌面", "desktop",
    "鼠标", "mouse", "点击", "click",
    "键盘", "keyboard", "输入", "type",
    "窗口", "window", "找窗口",
    
    # 表单操作
    "填表", "fill form", "表单",
    "登录网页", "web login", "网页登录",
    "自动登录", "auto login",
    
    # OCR 相关
    "OCR", "文字识别", "识别屏幕",
    
    # Bridge 相关
    "bridge", "桥接", "Windows操作",
]

# 执行任务关键词
EXECUTION_KEYWORDS = [
    "实现", "开发", "创建", "写一个", "编写", "编码",
    "implement", "develop", "create", "build", "write",
    "修复", "bug", "fix", "debug", "调试",
    "重构", "refactor", "优化", "optimize",
    "配置", "设置", "安装", "部署",
    "config", "setup", "install", "deploy",
    "搜索", "查找", "检索", "搜索代码",
    "search", "find", "grep",
    "读取", "写入", "创建文件", "删除文件",
    "read", "write", "create", "delete",
    "测试", "运行", "执行",
    "test", "run", "execute",
    "分析", "analyze", "检查", "check",
    "生成", "generate", "构建", "build",
    "更新", "update", "修改", "modify",
    "删除", "remove", "清理", "clean",
    "克隆", "clone", "下载", "download",
    "编译", "compile", "打包", "package",
]

# 对话关键词
CONVERSATION_KEYWORDS = [
    "你好", "hello", "hi", "早上好", "晚上好",
    "谢谢", "thanks", "thank you",
    "怎么样", "how are",
    "聊天", "chat", "talk",
    "再见", "bye", "goodbye",
]

# 系统命令
SYSTEM_COMMANDS = [
    "/new", "/help", "/stop", "/status",
    "/openwork", "/service",
]

# 任务类型模式
TASK_TYPE_PATTERNS: dict[str, list[str]] = {
    "gui_automation": [
        # 浏览器
        r"打开.*浏览器", r"open.*browser",
        r"访问.*网站", r"visit.*website",
        r"网页.*操作", r"web.*automation",
        r"浏览器.*自动", r"browser.*automation",
        r"playwright", r"selenium",
        
        # GUI 操作
        r"截图", r"screenshot",
        r"截屏", r"屏幕.*截图",
        r"GUI.*操作", r"桌面.*操作",
        r"鼠标.*点击", r"mouse.*click",
        r"键盘.*输入", r"keyboard.*type",
        
        # 表单
        r"填.*表", r"fill.*form",
        r"网页.*登录", r"web.*login",
        r"自动.*登录", r"auto.*login",
        
        # OCR
        r"OCR", r"文字识别",
        r"识别.*屏幕", r"屏幕.*文字",
        
        # Bridge
        r"bridge", r"桥接",
        r"Windows.*操作",
    ],
    "programming": [
        r"实现", r"开发", r"创建.*项目", r"写一个",
        r"implement", r"develop", r"create", r"build",
        r"编程", r"代码", r"程序", r"脚本",
        r"修复", r"bug", r"fix", r"debug",
        r"重构", r"refactor",
    ],
    "configuration": [
        r"配置", r"设置", r"安装.*环境",
        r"config", r"setup", r"install",
        r"初始化", r"initialize",
    ],
    "search": [
        r"搜索", r"查找", r"检索",
        r"search", r"find", r"grep",
        r"定位", r"locate",
    ],
    "debugging": [
        r"调试", r"debug", r"排查",
        r"诊断", r"diagnose",
        r"错误", r"error", r"异常", r"exception",
    ],
    "installation": [
        r"安装", r"install", r"部署",
        r"deploy", r"setup",
        r"下载", r"download",
    ],
    "file_operation": [
        r"读取", r"写入", r"创建文件", r"删除文件",
        r"read", r"write", r"create.*file", r"delete.*file",
        r"复制", r"copy", r"移动", r"move",
    ],
    "testing": [
        r"测试", r"test", r"单元测试",
        r"unit test", r"集成测试",
    ],
}

# 阈值常量
EXECUTION_THRESHOLD = 0.4
CONVERSATION_THRESHOLD = 0.5


class RoutingHelper:
    """路由辅助类 - 提供共享的路由计算方法"""

    CODE_PATTERNS = [
        r'\bdef\s+\w+',
        r'\bclass\s+\w+',
        r'\bfunction\s+\w+',
        r'\bimport\s+\w+',
        r'\bfrom\s+\w+\s+import',
        r'```[\s\S]*?```',
        r'`[^`]+`',
        r'\b(git|npm|pip|cargo|go)\s+',
    ]

    PATH_PATTERNS = [
        r'[a-zA-Z0-9_\-./]+\.(py|js|ts|go|rs|java|cpp|c|h)',
        r'/[a-zA-Z0-9_\-/]+',
        r'~[a-zA-Z0-9_\-/]+',
    ]

    QUESTION_PATTERNS = [
        r'^(什么|为什么|怎么|如何|哪)',
        r'^(what|why|how|where|when|who)',
        r'\?$',
    ]

    @staticmethod
    def is_system_command(message: str) -> bool:
        """检查是否为系统命令"""
        for cmd in SYSTEM_COMMANDS:
            if message.startswith(cmd.lower()):
                return True
        return False

    @staticmethod
    def calculate_execution_score(message: str, include_code_patterns: bool = True) -> float:
        """计算执行分数
        
        Args:
            message: 用户消息
            include_code_patterns: 是否包含代码模式检测（IntentClassifier 和 TaskRouter 特有）
        
        Returns:
            执行意图分数 (0.0 - 1.0)
        """
        score = 0.0
        
        for keyword in EXECUTION_KEYWORDS:
            if keyword in message:
                score += 0.15
        
        for task_type, patterns in TASK_TYPE_PATTERNS.items():
            for pattern in patterns:
                if re.search(pattern, message, re.IGNORECASE):
                    score += 0.2
                    break
        
        if include_code_patterns:
            for pattern in RoutingHelper.CODE_PATTERNS:
                if re.search(pattern, message, re.IGNORECASE):
                    score += 0.15
            
            for pattern in RoutingHelper.PATH_PATTERNS:
                if re.search(pattern, message):
                    score += 0.1
        
        return min(score, 1.0)

    @staticmethod
    def calculate_conversation_score(message: str, include_question_patterns: bool = True) -> float:
        """计算对话分数
        
        Args:
            message: 用户消息
            include_question_patterns: 是否包含问题模式检测（IntentClassifier 和 TaskRouter 特有）
        
        Returns:
            对话意图分数 (0.0 - 1.0)
        """
        score = 0.0
        
        for keyword in CONVERSATION_KEYWORDS:
            if keyword in message:
                score += 0.3
        
        if len(message.split()) <= 5:
            score += 0.2
        
        if re.match(r"^(hi|hello|hey|你好|嗨)[\s!?.]*$", message):
            score += 0.5
        
        if include_question_patterns:
            if len(message) < 20:
                score += 0.2
            
            for pattern in RoutingHelper.QUESTION_PATTERNS:
                if re.search(pattern, message, re.IGNORECASE):
                    score += 0.15
        
        return min(score, 1.0)

    @staticmethod
    def detect_task_type(message: str) -> str:
        """检测任务类型"""
        for task_type, patterns in TASK_TYPE_PATTERNS.items():
            for pattern in patterns:
                if re.search(pattern, message, re.IGNORECASE):
                    return task_type
        return "unknown"
