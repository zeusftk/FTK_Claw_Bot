# -*- coding: utf-8 -*-
"""
Session memory hook - persists session context across restarts.
"""

from loguru import logger
from clawbot.hooks.types import HookEvent


async def default(event: HookEvent) -> None:
    """Handle session events for memory persistence."""
    if event.action == "start":
        logger.info(f"[SessionMemory] Session started: {event.session_key}")
        # TODO: Load previous session context from storage
        
    elif event.action == "end":
        logger.info(f"[SessionMemory] Session ended: {event.session_key}")
        # TODO: Save session context to storage


# Also export as 'handler' for compatibility
handler = default
