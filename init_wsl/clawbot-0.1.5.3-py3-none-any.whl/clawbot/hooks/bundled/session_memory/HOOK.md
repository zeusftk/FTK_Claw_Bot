# Session Memory Hook

Records session context to enable memory persistence across sessions.

## Events

- `session:start` - When a new session begins
- `session:end` - When a session ends

## Usage

This hook is automatically loaded when hooks are enabled.

## Configuration

No configuration required.
