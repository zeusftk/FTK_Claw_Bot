# -*- coding: utf-8 -*-
"""
Command logger hook - logs command executions for debugging.
"""

from loguru import logger
from clawbot.hooks.types import HookEvent


async def default(event: HookEvent) -> None:
    """Handle command/tool events for logging."""
    if event.type.value == "command":
        command = event.context.get("command", "unknown")
        args = event.context.get("args", {})
        logger.info(f"[CommandLogger] Command: {command}, Args: {args}")
        
    elif event.type.value == "tool":
        tool = event.context.get("tool", "unknown")
        params = event.context.get("params", {})
        logger.info(f"[CommandLogger] Tool: {tool}, Params: {params}")


# Also export as 'handler' for compatibility
handler = default
