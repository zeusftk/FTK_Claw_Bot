# Command Logger Hook

Logs all command executions for debugging and audit purposes.

## Events

- `command:execute` - When a command is executed
- `tool:execute` - When a tool is executed

## Usage

This hook is automatically loaded when hooks are enabled.
