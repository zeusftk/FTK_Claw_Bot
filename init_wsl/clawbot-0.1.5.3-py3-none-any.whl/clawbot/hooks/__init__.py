# -*- coding: utf-8 -*-
"""
Hooks system for clawbot.

Provides event-driven extensibility through hooks that can be triggered
at various points in the agent lifecycle.
"""

from .types import HookEvent, HookEventType, HookHandler, HookMetadata
from .registry import HookRegistry, register_hook, unregister_hook, trigger_hook

__all__ = [
    "HookEvent",
    "HookEventType",
    "HookHandler",
    "HookMetadata",
    "HookRegistry",
    "register_hook",
    "unregister_hook",
    "trigger_hook",
]
