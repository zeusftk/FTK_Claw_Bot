# -*- coding: utf-8 -*-
"""
Hook types and event definitions.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Awaitable, Union


class HookEventType(Enum):
    """Types of hook events that can be triggered."""
    COMMAND = "command"
    SESSION = "session"
    AGENT = "agent"
    GATEWAY = "gateway"
    MESSAGE = "message"
    TOOL = "tool"


@dataclass
class HookEvent:
    """Event data passed to hook handlers."""
    type: HookEventType
    action: str
    session_key: str
    context: dict[str, Any] = field(default_factory=dict)
    messages: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert event to dictionary for serialization."""
        return {
            "type": self.type.value,
            "action": self.action,
            "session_key": self.session_key,
            "context": self.context,
            "messages": self.messages,
        }


# Type alias for hook handlers (can be sync or async)
HookHandler = Callable[[HookEvent], Union[None, Awaitable[None]]]


@dataclass
class HookMetadata:
    """Metadata for a hook handler."""
    events: list[str]
    always: bool = False
    emoji: str = "🪝"
    export: str = "default"
    os: list[str] | None = None
    description: str = ""
