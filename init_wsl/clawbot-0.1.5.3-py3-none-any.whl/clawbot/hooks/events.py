# -*- coding: utf-8 -*-
"""
Event types and event data classes for the hooks system.
"""

from enum import Enum
from dataclasses import dataclass, field
from typing import Any, Callable, Awaitable, Union


class HookEventType(Enum):
    """Types of events that can trigger hooks."""
    COMMAND = "command"       # Command execution events
    SESSION = "session"       # Session lifecycle events
    AGENT = "agent"           # Agent lifecycle events
    GATEWAY = "gateway"       # Gateway lifecycle events
    MESSAGE = "message"       # Message processing events
    TOOL = "tool"             # Tool execution events


@dataclass
class HookEvent:
    """Event data passed to hook handlers."""
    type: HookEventType
    action: str
    session_key: str
    context: dict[str, Any] = field(default_factory=dict)
    messages: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert event to dictionary for serialization."""
        return {
            "type": self.type.value,
            "action": self.action,
            "session_key": self.session_key,
            "context": self.context,
            "messages": self.messages,
        }


# Type alias for hook handlers (can be sync or async)
HookHandler = Callable[[HookEvent], Union[None, Awaitable[None]]]


@dataclass
class HookMetadata:
    """Metadata for a hook handler."""
    events: list[str]
    always: bool = False
    emoji: str = "🪝"
    export: str = "default"
    os: list[str] | None = None
    description: str = ""
