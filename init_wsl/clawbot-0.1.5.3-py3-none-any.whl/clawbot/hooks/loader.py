# -*- coding: utf-8 -*-
"""
Dynamic hook loader for loading hook handlers from directories.
"""

import importlib.util
from pathlib import Path
from typing import TYPE_CHECKING
from loguru import logger

if TYPE_CHECKING:
    from .types import HookMetadata


def load_hooks_from_dir(hooks_dir: Path) -> list[tuple[str, HookMetadata, callable]]:
    """
    Load all hook handlers from a directory.
    
    Each hook should be in a subdirectory with:
    - HOOK.md: Metadata file describing the hook
    - handler.py: Python module with the handler function
    
    Args:
        hooks_dir: Directory containing hook subdirectories
        
    Returns:
        List of (event_key, metadata, handler) tuples
    """
    loaded = []
    
    if not hooks_dir.exists():
        logger.debug(f"[Hooks] Directory not found: {hooks_dir}")
        return loaded
    
    for hook_subdir in hooks_dir.iterdir():
        if not hook_subdir.is_dir():
            continue
        
        hook_md = hook_subdir / "HOOK.md"
        handler_py = hook_subdir / "handler.py"
        
        if not handler_py.exists():
            logger.warning(f"[Hooks] No handler.py in {hook_subdir}")
            continue
        
        # Load handler module
        try:
            spec = importlib.util.spec_from_file_location(
                f"hook_{hook_subdir.name}",
                handler_py
            )
            if spec and spec.loader:
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                
                # Get handler function (default export)
                handler = getattr(module, "default", None) or getattr(module, "handler", None)
                if not handler:
                    logger.warning(f"[Hooks] No handler function in {handler_py}")
                    continue
                
                # Parse metadata from HOOK.md if exists
                metadata = parse_hook_metadata(hook_md) if hook_md.exists() else None
                
                if metadata:
                    for event_key in metadata.events:
                        loaded.append((event_key, metadata, handler))
                        logger.info(f"[Hooks] Loaded hook '{hook_subdir.name}' for '{event_key}'")
                else:
                    # Default: register for all events
                    loaded.append(("all", None, handler))
                    logger.info(f"[Hooks] Loaded hook '{hook_subdir.name}' (no metadata)")
                    
        except Exception as e:
            logger.error(f"[Hooks] Failed to load {handler_py}: {e}")
    
    return loaded


def parse_hook_metadata(hook_md: Path) -> HookMetadata | None:
    """
    Parse hook metadata from HOOK.md file.
    
    Expected format (YAML frontmatter):
    ```yaml
    events:
      - message:received
      - message:sent
    always: false
    emoji: 📝
    export: default
    os:
      - linux
      - darwin
    ```
    
    Args:
        hook_md: Path to HOOK.md file
        
    Returns:
        HookMetadata if parsing successful, None otherwise
    """
    import yaml
    
    try:
        content = hook_md.read_text()
        
        # Extract YAML frontmatter
        if content.startswith("---"):
            parts = content.split("---", 2)
            if len(parts) >= 3:
                frontmatter = yaml.safe_load(parts[1])
                from .types import HookMetadata
                return HookMetadata(
                    events=frontmatter.get("events", []),
                    always=frontmatter.get("always", False),
                    emoji=frontmatter.get("emoji", "🪝"),
                    export=frontmatter.get("export", "default"),
                    os=frontmatter.get("os"),
                    description=frontmatter.get("description", ""),
                )
    except Exception as e:
        logger.warning(f"[Hooks] Failed to parse {hook_md}: {e}")
    
    return None
