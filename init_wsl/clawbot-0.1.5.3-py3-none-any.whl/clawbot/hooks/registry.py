# -*- coding: utf-8 -*-
"""
Hook registry for managing and triggering hooks.
"""

from __future__ import annotations
import asyncio
from typing import TYPE_CHECKING
from loguru import logger

if TYPE_CHECKING:
    from .types import HookEvent, HookHandler


class HookRegistry:
    """
    Singleton registry for managing hook handlers.
    
    Handlers can be registered for:
    - Event types: "message", "session", "gateway", etc.
    - Specific events: "message:received", "session:start", etc.
    """
    _instance: HookRegistry | None = None
    _handlers: dict[str, list[HookHandler]]
    
    def __new__(cls) -> HookRegistry:
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._handlers = {}
        return cls._instance
    
    def register(self, event_key: str, handler: HookHandler) -> None:
        """
        Register a handler for an event key.
        
        Args:
            event_key: Event type (e.g., "message") or specific event (e.g., "message:received")
            handler: Function to call when event is triggered
        """
        if event_key not in self._handlers:
            self._handlers[event_key] = []
        self._handlers[event_key].append(handler)
        logger.debug(f"[Hooks] Registered handler for '{event_key}'")
    
    def unregister(self, event_key: str, handler: HookHandler) -> None:
        """
        Unregister a handler for an event key.
        
        Args:
            event_key: Event key the handler was registered for
            handler: Handler to remove
        """
        if event_key in self._handlers:
            try:
                self._handlers[event_key].remove(handler)
                logger.debug(f"[Hooks] Unregistered handler for '{event_key}'")
            except ValueError:
                pass
    
    async def trigger(self, event: HookEvent) -> None:
        """
        Trigger all handlers for an event.
        
        Handlers are triggered for:
        1. The event type (e.g., "message")
        2. The specific event (e.g., "message:received")
        
        Errors in handlers are caught and logged, not propagated.
        
        Args:
            event: The event to trigger
        """
        type_handlers = self._handlers.get(event.type.value, [])
        action_handlers = self._handlers.get(f"{event.type.value}:{event.action}", [])
        
        all_handlers = list(type_handlers) + list(action_handlers)
        
        if all_handlers:
            logger.debug(f"[Hooks] Triggering {len(all_handlers)} handlers for '{event.type.value}:{event.action}'")
        
        for handler in all_handlers:
            try:
                result = handler(event)
                if asyncio.iscoroutine(result):
                    await result
            except Exception as e:
                logger.error(f"[Hooks] Handler error for '{event.type.value}:{event.action}': {e}")
    
    def clear(self) -> None:
        """Clear all registered handlers."""
        self._handlers.clear()
        logger.debug("[Hooks] Cleared all handlers")
    
    def list_handlers(self) -> dict[str, int]:
        """List all registered event keys and their handler counts."""
        return {key: len(handlers) for key, handlers in self._handlers.items()}


# Module-level convenience functions
def register_hook(event_key: str, handler: HookHandler) -> None:
    """Register a hook handler."""
    HookRegistry().register(event_key, handler)


def unregister_hook(event_key: str, handler: HookHandler) -> None:
    """Unregister a hook handler."""
    HookRegistry().unregister(event_key, handler)


async def trigger_hook(event: HookEvent) -> None:
    """Trigger all handlers for an event."""
    await HookRegistry().trigger(event)
