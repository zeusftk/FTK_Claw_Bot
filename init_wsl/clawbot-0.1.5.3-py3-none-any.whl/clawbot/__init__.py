"""
clawbot - A lightweight AI agent framework
"""

__version__ = "0.1.5.3"
__logo__ = "🦐"
